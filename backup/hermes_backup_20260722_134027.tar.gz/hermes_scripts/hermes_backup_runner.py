#!/usr/bin/env python3
"""Wrapper: hermes 双备份 runner — 本地 tarball + Git push to GitHub"""
import subprocess, os, sys, shutil, glob, time

os.chdir("C:/Users/Admin/AppData/Local/hermes/scripts")

from dotenv import load_dotenv
load_dotenv("C:/Users/Admin/AppData/Local/hermes/.env")
os.environ["GH_PAT"] = os.environ.get("GH_PAT", "")
os.environ["GH_REPO"] = os.environ.get("GH_REPO", "maclandfx/HERMES")

PY = sys.executable
REPO = os.environ.get("GH_REPO", "maclandfx/HERMES")
PAT = os.environ.get("GH_PAT", "")
WORK = "C:/Temp/hb-" + __import__("uuid").uuid4().hex[:8]

def run(cmd, timeout=120):
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return r

print("=== 1. 本地备份 ===")
r = run([PY, "hermes_backup.py"])
for line in r.stdout.split("\n"):
    if line.strip(): print(f"  {line}")
if r.returncode != 0:
    print(f"  ❌ 失败: {r.stderr}")
    sys.exit(1)

tarballs = sorted(glob.glob("D:/Hermes/评估中心/backup/hermes_backup_*.tar.gz"))
if not tarballs:
    print("  no tarball"); sys.exit(1)
latest = tarballs[-1]
print(f"\n=== 2. 推送 GitHub: {latest} ===")
print(f"  repo: {REPO}")

if not PAT:
    print("  ⏭️  GH_PAT 未设置，跳过 GitHub"); sys.exit(0)

# Clean work dir
if os.path.exists(WORK):
    shutil.rmtree(WORK)
    time.sleep(0.5)
os.makedirs(WORK, exist_ok=True); 

# Clone
r = run(["git", "-c", "http.proxy=http://127.0.0.1:7890", "clone",
         f"https://{PAT}@github.com/{REPO}.git", WORK], timeout=60)
if r.returncode != 0:
    print(f"  ❌ clone: {r.stderr.strip()[-200:]}"); sys.exit(1)

os.chdir(WORK)
run(["git", "config", "user.email", "hermes@local"])
run(["git", "config", "user.name", "Hermes"])
run(["git", "config", "http.proxy", "http://127.0.0.1:7890"])
run(["git", "config", "http.postBuffer", "524288000"])

# Copy files
bak = os.path.join(WORK, "backup")
os.makedirs(bak, exist_ok=True)
shutil.copy2(latest, os.path.join(bak, os.path.basename(latest)))
mf = "D:/Hermes/评估中心/backup/latest.json"
if os.path.exists(mf):
    shutil.copy2(mf, os.path.join(bak, "latest.json"))

# Commit
run(["git", "add", "backup/"])
r2 = run(["git", "commit", "-m", f"Hermes backup {os.path.basename(latest).split('_')[1]}"])
if "nothing to commit" in r2.stdout:
    print("  (no changes)")
else:
    print(r2.stdout.strip()[-200:])
    r3 = run(["git", "push", f"https://{PAT}@github.com/{REPO}.git", "main"], timeout=120)
    if r3.returncode != 0:
        print(f"  ❌ push: {r3.stderr.strip()[-300:]}"); sys.exit(1)
    print(f"  ✅ 推送成功")

print(f"\n本地: {latest}")
print(f"GitHub: https://github.com/{REPO}")
