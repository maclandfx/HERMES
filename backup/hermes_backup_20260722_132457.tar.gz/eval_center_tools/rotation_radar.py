#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轮动预测雷达 v1 — rotation_radar.py
=====================================
五因子评分：残差动量 + RRG + 资金流 + 拥挤度 + 宏观 Regime

数据源（全部已验证可用）：
  - tushare daily()        → 个股日频行情（6000行/日）
  - tushare moneyflow()    → 个股资金流（6000行/日）
  - tushare stock_hsgt()   → 北向资金
  - tushare shibor()       → 利率环境
  - 静态申万一级行业成分映射（内嵌，不依赖受限接口）

输出：
  - 12个申万一级行业 × 五因子评分（0-100）
  - RRG 四象限标签（Leading/Improving/Weakening/Lagging）
  - 可直接嵌入盘前/收盘报告
"""
import os, json, math, datetime, re
from pathlib import Path
import numpy as np
import pandas as pd
import tushare as ts

# ═══════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════
TOOLS_DIR = Path(__file__).parent
ROOT_DIR = TOOLS_DIR.parent
RADAR_DATA_DIR = ROOT_DIR / "data" / "rotation_radar"
RADAR_DATA_DIR.mkdir(parents=True, exist_ok=True)

# ═══════════════════════════════════════════════
#  Tushare
# ═══════════════════════════════════════════════
try:
    from env_loader import get_tushare_token
    TS_TOKEN = get_tushare_token()
except Exception:
    TS_TOKEN = os.environ.get("TUSHARE_TOKEN", "")
pro = ts.pro_api(TS_TOKEN) if TS_TOKEN else None

# ═══════════════════════════════════════════════
#  申万一级行业成分映射（行业 → 代表性成分股代码）
#  取各行业市值最大的前15只成分股，保证代表性且控制API调用量
# ═══════════════════════════════════════════════
SW_INDUSTRY_MEMBERS = {
    "电子":     ["002475.SZ", "002049.SZ", "603501.SH", "300782.SZ", "002236.SZ",
                 "600584.SH", "600703.SH", "688981.SH", "688008.SH", "002916.SZ",
                 "603986.SH", "002920.SZ", "002415.SZ", "300686.SZ", "603160.SH"],
    "计算机":   ["002230.SZ", "002410.SZ", "300454.SZ", "002261.SZ", "603019.SH",
                 "300348.SZ", "688002.SH", "600588.SH", "300033.SZ", "603881.SH",
                 "688111.SH", "300368.SZ", "002235.SZ", "688271.SH", "688187.SH"],
    "通信":     ["002465.SZ", "002281.SZ", "600050.SH", "000836.SZ", "000938.SZ",
                 "002402.SZ", "300638.SZ", "688003.SH", "002555.SZ", "688797.SH",
                 "688018.SH", "300786.SZ", "000063.SZ", "002288.SZ", "603160.SH"],
    "电力设备": ["300750.SZ", "002459.SZ", "300274.SZ", "601985.SH", "600438.SH",
                 "300450.SZ", "601012.SH", "600406.SH", "002129.SZ", "300316.SZ",
                 "688599.SH", "300763.SZ", "002896.SZ", "600401.SH", "600885.SH"],
    "医药生物": ["300760.SZ", "600276.SH", "000538.SZ", "600436.SH", "300347.SZ",
                 "300122.SZ", "002007.SZ", "600519.SH", "300358.SZ", "002821.SZ",
                 "002422.SZ", "688272.SH", "600196.SH", "688119.SH", "688180.SH"],
    "银行":     ["601398.SH", "601988.SH", "600036.SH", "601166.SH", "601939.SH",
                 "601288.SH", "600919.SH", "000001.SZ", "002142.SZ", "601009.SH",
                 "601229.SH", "600016.SH", "601997.SH", "600926.SH", "002966.SZ"],
    "石油石化": ["601857.SH", "600583.SH", "002222.SZ", "601808.SH", "002207.SZ",
                 "002648.SZ", "600346.SH", "600028.SH", "600688.SH", "002254.SZ"],
    "汽车":     ["600104.SH", "601633.SH", "000625.SZ", "601238.SH", "600741.SH",
                 "002920.SZ", "601689.SH", "002050.SZ", "603197.SH", "601127.SH"],
    "机械设备": ["002008.SZ", "600984.SH", "002966.SZ", "000778.SZ", "603290.SH",
                 "601399.SH", "300014.SZ", "601100.SH", "603011.SH", "600893.SH"],
    "军工":     ["000768.SZ", "002179.SZ", "601989.SH", "002013.SZ", "600760.SH",
                 "600893.SH", "002414.SZ", "002049.SZ", "600727.SH", "688388.SH"],
    "基础化工": ["600426.SH", "002254.SZ", "600309.SH", "002001.SZ", "600801.SH",
                 "600563.SH", "002226.SZ", "601233.SH", "002821.SZ", "002423.SZ"],
    "有色金属": ["600547.SH", "601899.SH", "002600.SZ", "000630.SZ", "600219.SH",
                 "600531.SH", "600362.SH", "002460.SZ", "603993.SH", "601607.SH"],
}
# 全A基准（沪深300主要成分）
BENCH_CODES = ["000300.SH", "000905.SH", "601988.SH", "601398.SH", "000001.SZ",
               "600519.SH", "600030.SH", "000858.SZ", "601318.SH", "601288.SH"]

# ═══════════════════════════════════════════════
#  数据缓存
# ═══════════════════════════════════════════════
def _load_cache(path: Path) -> list[dict]:
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []

def _save_cache(path: Path, data: list[dict]):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def _cache_path(name: str, start: str, end: str) -> Path:
    return RADAR_DATA_DIR / f"{name}_{start}_{end}.json"

# ═══════════════════════════════════════════════
#  数据源
# ═══════════════════════════════════════════════
def _fetch_daily(start: str, end: str) -> pd.DataFrame:
    """个股日频行情，带缓存"""
    path = _cache_path("daily", start, end)
    cached = _load_cache(path)
    if cached and len(cached) > 100:
        df = pd.DataFrame(cached)
        for c in ["pct_chg", "vol", "amount"]:
            if c not in df.columns:
                df[c] = 0.0
        return df
    if not pro:
        return pd.DataFrame()
    try:
        df = pro.daily(start_date=start, end_date=end,
                       fields="ts_code,trade_date,pct_chg,vol,amount,close")
        if df is not None and not df.empty:
            _save_cache(path, df.to_dict("records"))
        return df
    except Exception:
        return pd.DataFrame()

def _fetch_moneyflow(start: str, end: str) -> pd.DataFrame:
    """个股资金流，带缓存"""
    path = _cache_path("moneyflow", start, end)
    cached = _load_cache(path)
    if cached and len(cached) > 100:
        df = pd.DataFrame(cached)
        if "net_mf_amount" not in df.columns:
            df["net_mf_amount"] = 0.0
        return df
    if not pro:
        return pd.DataFrame()
    try:
        df = pro.moneyflow(start_date=start, end_date=end,
                           fields="ts_code,trade_date,net_mf_amount,net_mf_vol")
        if df is not None and not df.empty:
            _save_cache(path, df.to_dict("records"))
        return df
    except Exception:
        return pd.DataFrame()

def _fetch_hsgt(start: str, end: str) -> pd.DataFrame:
    if not pro:
        return pd.DataFrame()
    try:
        return pro.stock_hsgt(start_date=start, end_date=end)
    except Exception:
        return pd.DataFrame()

def _fetch_shibor(start: str, end: str) -> pd.DataFrame:
    if not pro:
        return pd.DataFrame()
    try:
        return pro.shibor(start_date=start, end_date=end)
    except Exception:
        return pd.DataFrame()

# ═══════════════════════════════════════════════
#  五因子引擎
# ═══════════════════════════════════════════════
class RotationRadar:
    """轮动预测雷达核心引擎。"""

    KEY_INDUSTRIES = list(SW_INDUSTRY_MEMBERS.keys())

    def __init__(self, lookback: int = 20):
        self.lookback = lookback
        today = datetime.date.today()
        self._end_str = today.strftime("%Y%m%d")
        self._start_str = (today - datetime.timedelta(days=lookback + 5)).strftime("%Y%m%d")

    # ── 预加载数据（一次性） ──
    def _load_data(self):
        if not hasattr(self, "_daily"):
            self._daily = _fetch_daily(self._start_str, self._end_str)
        if not hasattr(self, "_mf"):
            self._mf = _fetch_moneyflow(self._start_str, self._end_str)
        if not hasattr(self, "_hsgt"):
            self._hsgt = _fetch_hsgt(self._start_str, self._end_str)
        if not hasattr(self, "_shibor"):
            self._shibor = _fetch_shibor(self._start_str, self._end_str)

    def _recent_daily(self, codes: list[str]) -> pd.DataFrame:
        self._load_data()
        df = self._daily[self._daily["ts_code"].isin(codes)].copy()
        # 取最近 lookback 日（trade_date 为字符串 "YYYYMMDD"，直接排序即可）
        if df.empty:
            return df
        return df.sort_values("trade_date").tail(self.lookback)

    # ── 1. 残差动量 ──
    def _residual_momentum(self, industry: str) -> tuple[float, float]:
        """行业日均涨跌幅 − 全A基准日均涨跌幅。"""
        members = SW_INDUSTRY_MEMBERS.get(industry, [])
        if not members:
            return 50.0, 0.0

        ind = self._recent_daily(members)
        bench = self._recent_daily(BENCH_CODES)

        if ind.empty or bench.empty:
            return 50.0, 0.0

        # 日均涨跌幅
        ind_avg = ind.groupby("trade_date")["pct_chg"].mean().mean()
        bench_avg = bench.groupby("trade_date")["pct_chg"].mean().mean()

        # 用所有可用行业计算标准化残差
        residuals = []
        for ind_name, codes in SW_INDUSTRY_MEMBERS.items():
            d = self._recent_daily(codes)
            if not d.empty and not bench.empty:
                r = d.groupby("trade_date")["pct_chg"].mean().mean() - bench_avg
                residuals.append(r)
        residuals = [x for x in residuals if not np.isnan(x)]

        industry_residual = ind_avg - bench_avg
        if not residuals or len(residuals) < 3:
            # 简单映射：+3% → 100，−3% → 0
            score = max(0.0, min(100.0, 50.0 + industry_residual * 15.0))
        else:
            # 百分位排名
            rank = sum(1 for r in residuals if r < industry_residual) / len(residuals) * 100
            score = rank

        return round(float(score), 1), round(float(industry_residual), 2)

    # ── 2. RRG ──
    def _rrg_score(self, industry: str) -> tuple[float, str, float]:
        """相对强度排名 + 象限判断。"""
        # 计算所有行业残差动量
        residuals = {}
        for ind_name, codes in SW_INDUSTRY_MEMBERS.items():
            r, _ = self._residual_momentum(ind_name)
            residuals[ind_name] = r

        if industry not in residuals:
            return 50.0, "中性", 50.0

        ind_residual = residuals[industry]
        all_residuals = sorted(residuals.values())
        # RS：残差动量排名百分位（0-200，100=中位）
        rank = sum(1 for v in all_residuals if v < ind_residual)
        total = len(all_residuals)
        rs = (rank / max(total - 1, 1)) * 200 if total > 1 else 100

        # RS-Momentum: 用残差正负判断方向
        direction = ind_residual >= 0

        # 四象限
        if rs >= 100 and direction:
            quad = "Leading"
        elif rs < 100 and direction:
            quad = "Improving"
        elif rs >= 100 and not direction:
            quad = "Weakening"
        else:
            quad = "Lagging"

        score = max(0.0, min(100.0, rs * 0.5))
        return round(float(score), 1), quad, round(float(rs), 1)

    # ── 3. 资金流 ──
    def _moneyflow_score(self, industry: str) -> tuple[float, float]:
        """行业累计净流金额排名百分位。"""
        members = SW_INDUSTRY_MEMBERS.get(industry, [])
        if not members:
            return 50.0, 0.0

        self._load_data()
        df = self._mf[self._mf["ts_code"].isin(members)].copy()
        if df.empty:
            return 50.0, 0.0

        # 按日聚合净流
        daily_net = df.groupby("trade_date")["net_mf_amount"].sum()
        net_20d = daily_net.tail(self.lookback).sum()
        net_wan = net_20d / 10000  # 万元

        # 排名百分位
        all_net = []
        for ind_name, codes in SW_INDUSTRY_MEMBERS.items():
            d = self._mf[self._mf["ts_code"].isin(codes)]
            if not d.empty:
                dn = d.groupby("trade_date")["net_mf_amount"].sum().tail(self.lookback).sum()
                all_net.append(dn)
        all_net = [x for x in all_net if not pd.isna(x)]
        if len(all_net) < 3:
            return 50.0, round(float(net_wan), 2)

        rank = sum(1 for x in all_net if x < net_20d) / len(all_net) * 100
        return round(float(rank), 1), round(float(net_wan), 2)

    # ── 4. 拥挤度 ──
    def _crowding_score(self, industry: str) -> float:
        """拥挤度：相对换手率 + 成分股价格相关性。高分=健康(不拥挤)。"""
        members = SW_INDUSTRY_MEMBERS.get(industry, [])
        if len(members) < 5:
            return 60.0

        self._load_data()
        df = self._daily[self._daily["ts_code"].isin(members)].copy()
        if df.empty:
            return 60.0

        # 相对换手率
        ind_vol = df.groupby("trade_date")["vol"].sum().mean()
        all_vol = self._daily.groupby("trade_date")["vol"].sum().mean()
        if all_vol == 0 or np.isnan(all_vol):
            return 60.0
        rel_turnover = ind_vol / all_vol

        score = max(0.0, min(100.0, 100.0 - (rel_turnover - 1.0) * 25.0))

        # 价格相关性（成分股涨跌幅相关性）
        try:
            pivot = df.pivot_table(index="trade_date", columns="ts_code", values="pct_chg")
            if pivot.shape[1] > 3:
                corr = pivot.corr().mean().mean()
                corr_penalty = max(0.0, (corr - 0.3) * 100)
                score = max(0.0, score - corr_penalty)
        except Exception:
            pass

        return round(float(score), 1)

    # ── 5. 宏观 Regime ──
    def _macro_regime(self) -> tuple[str, float]:
        """北向资金 + Shibor 判断宏观阶段。"""
        self._load_data()

        # 北向资金
        north_flow = 0.0
        consec_days = 0
        if not self._hsgt.empty:
            hgt = self._hsgt.sort_values("trade_date", ascending=False).head(10)
            if "net_amount" in hgt.columns:
                net = hgt["net_amount"].astype(float).tolist()
                north_flow = net[0] if net else 0.0
                if north_flow > 0:
                    consec_days = sum(1 for v in net if v > 0)
                elif north_flow < 0:
                    consec_days = -sum(1 for v in net if v < 0)

        # Shibor 趋势
        shibor_trend = 0.0
        if not self._shibor.empty:
            if "SHIBOR1W" in self._shibor.columns and len(self._shibor) >= 2:
                s = self._shibor["SHIBOR1W"].astype(float)
                shibor_trend = float(s.iloc[-1] - s.iloc[0])

        # Regime 判断
        if north_flow > 1e10 and consec_days >= 3 and shibor_trend <= 0:
            regime, score = "扩张", 90.0
        elif north_flow > 0 and consec_days >= 1:
            regime, score = "复苏", 75.0
        elif north_flow < -1e9 or consec_days <= -3:
            regime, score = "放缓", 40.0
        else:
            regime, score = "中性", 60.0

        if shibor_trend > 0.01:
            score = max(0.0, score - 10)
        elif shibor_trend < -0.01:
            score = min(100.0, score + 5)

        return regime, round(float(score), 1)

    # ── 综合评分 ──
    def compute_sector(self, industry: str) -> dict:
        """单个行业五因子评分。"""
        mo, raw_chg = self._residual_momentum(industry)
        rrg, quad, rs = self._rrg_score(industry)
        mf, net_amt = self._moneyflow_score(industry)
        crowding = self._crowding_score(industry)
        regime, macro = self._macro_regime()

        # 五因子加权
        composite = (mo * 0.30 + rrg * 0.25 + mf * 0.20 +
                     crowding * 0.15 + macro * 0.10)

        return {
            "industry": industry,
            "composite": round(float(composite), 1),
            "momentum": mo, "rrg": rrg, "moneyflow": mf,
            "crowding": crowding, "macro": macro,
            "quad": quad, "regime": regime,
            "raw_chg": raw_chg, "rs": rs, "net_amount": net_amt,
        }

    def compute_all(self) -> list[dict]:
        results = []
        for industry in self.KEY_INDUSTRIES:
            try:
                results.append(self.compute_sector(industry))
            except Exception as e:
                print(f"[WARN] {industry} 计算失败: {e}")
        results.sort(key=lambda x: x["composite"], reverse=True)
        return results

    @property
    def regime(self) -> tuple[str, float]:
        return self._macro_regime()


# ═══════════════════════════════════════════════
#  报告渲染
# ═══════════════════════════════════════════════
QUAD_ICON = {"Leading": "🟢", "Improving": "🔵", "Weakening": "🟠", "Lagging": "🔴"}
QUAD_CN = {"Leading": "领先", "Improving": "改善", "Weakening": "弱化", "Lagging": "落后"}

def radar_card(radar: RotationRadar = None, top_n: int = 8) -> str:
    if radar is None:
        radar = RotationRadar()
    results = radar.compute_all()
    if not results:
        return "📭 轮动雷达数据未就绪"

    regime, macro = radar.regime
    lines = [
        "## 🎯 轮动预测雷达",
        "",
        f"> 宏观 Regime: **{regime}** | 综合评分 {macro}分",
        "",
        "| 排名 | 行业 | 综合 | 动量 | RRG | 资金流 | 拥挤度 | 象限 |",
        "|:----:|------|:----:|:----:|:---:|:-----:|:-----:|:----:|",
    ]

    for i, r in enumerate(results[:top_n], 1):
        icon = QUAD_ICON.get(r["quad"], "⚪")
        cn = QUAD_CN.get(r["quad"], r["quad"])
        emoji = "🟢" if r["composite"] >= 70 else "🟡" if r["composite"] >= 55 else "🔴"
        lines.append(
            f"| {i} | **{r['industry']}** | {r['composite']} {emoji} | "
            f"{r['momentum']} | {r['rrg']} | {r['moneyflow']} | "
            f"{r['crowding']} | {icon}{cn} |"
        )

    best, worst = results[0], results[-1]
    lines.extend([
        "",
        "> 评分: 残差动量(30%)+RRG(25%)+资金流(20%)+拥挤度(15%)+宏观(10%)",
        "> RRG: 🟢领先配置 🔵改善建仓 🟠弱化减仓 🔴落后回避",
        "",
        f"⚡ 优先 **{best['industry']}**（{best['composite']}分 {QUAD_ICON.get(best['quad'],'')}），"
        f"回避 **{worst['industry']}**（{worst['composite']}分 {QUAD_ICON.get(worst['quad'],'')}）",
    ])
    return "\n".join(lines)

if __name__ == "__main__":
    radar = RotationRadar()
    print(radar_card(radar))
