#!/usr/bin/env python3
"""
hermes-backup.py — Hermes 系统本地 + GitHub 双备份
用法:
  python hermes_backup.py --all    # 本地 + GitHub（需要 GH_PAT 环境变量）
  python hermes_backup.py          # 仅本地

备份内容:
  - Hermes scripts/*.py（全部）
  - 评估中心 tools/ 代码（排除 __pycache__, pkl, data）
  - 评估中心 reports/（粗评报告）

跳过:
  - .git / node_modules / __pycache__ / .pkl / .db / .sqlite
  - tdx_connector/logs/ telegram_queue/ zxsx_data/（运行态数据）
  - 899MB f2_factors.pkl（太大）

GitHub PAT 设置:
  hermes secrets set GH_PAT <你的经典token>  # 推荐
  或直接 export GH_PAT=ghp_xxxxx
"""
import os
import sys
import json
import shutil
import tarfile
import hashlib
import argparse
from datetime import datetime
from pathlib import Path

BACKUP_ROOT = Path(r"D:/Hermes/评估中心/backup")
TODAY = datetime.now().strftime("%Y%m%d")
TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

# === 配置（要备份什么）===
SOURCE_DIRS = [
    # (路径, 标签, 排除扩展名)
    (Path(r"C:/Users/Admin/AppData/Local/hermes/scripts"), "hermes_scripts", [".pyc"]),
    (Path(r"D:/Hermes/评估中心/tools"), "eval_center_tools", [".pyc", ".pkl", ".db", ".sqlite"]),
    (Path(r"D:/Hermes/评估中心/reports/粗评"), "eval_reports", []),
    (Path(r"D:/Hermes/评估中心/reports"), "eval_reports_meta", [".md"], "templates", "dependency_graph.md", "PIAF"),
]

EXCLUDE_DIRS = {"__pycache__", ".git", "node_modules", ".venv", "venv", "trash"}
EXCLUDE_FILES = {"tracked_2026", "preview_data.json", "zxsx_analysis.json",
                 "weekly_selected_factors.json", "3factor_holdings.csv"}

# === 日志 ===
class Logger:
    def __init__(self):
        self.info = []
    def log(self, msg: str):
        print(f"  {msg}")
        self.info.append(msg)

def fmt_size(n: int) -> str:
    if n < 1024: return f"{n}B"
    if n < 1024**2: return f"{n/1024:.1f}KB"
    return f"{n/1024**2:.1f}MB"

def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()[:16]

def should_skip(path: Path) -> bool:
    """检查是否应该跳过某个文件"""
    for part in path.parts:
        if part in EXCLUDE_DIRS:
            return True
        if any(ex in part for ex in EXCLUDE_FILES):
            return True
    ext = path.suffix.lower()
    if ext in {".pyc", ".pkl", ".db", ".sqlite", ".pyo"}:
        return True
    return False

def collect_files(base: Path, logger: Logger):
    """收集所有应备份的文件"""
    files = []
    if not base.exists():
        logger.log(f"  ⚠️  目录不存在: {base}")
        return files
    for f in base.rglob("*"):
        if not f.is_file():
            continue
        if should_skip(f):
            continue
        files.append(f)
    logger.log(f"  📂 {base.name}: {len(files)} 个文件")
    return files

def build_tarball(logger: Logger) -> Path:
    """创建本地 tarball 备份"""
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    tarball = BACKUP_ROOT / f"hermes_backup_{TIMESTAMP}.tar.gz"

    total_files = 0
    total_size = 0
    md5 = hashlib.md5()

    with tarfile.open(str(tarball), "w:gz") as tar:
        for base, label, *_ in SOURCE_DIRS:
            files = collect_files(base, logger)
            for f in files:
                rel = str(f).replace("\\", "/")
                # 去掉绝对路径前缀，保留相对路径
                arcname = f"{label}/{f.relative_to(base)}"
                arcname = arcname.replace("\\", "/")
                try:
                    tar.add(str(f), arcname=arcname)
                    sz = f.stat().st_size
                    total_files += 1
                    total_size += sz
                    md5.update(arcname.encode())
                except Exception as e:
                    logger.log(f"    ⚠️  跳过 {f.name}: {e}")

    tarball_size = tarball.stat().st_size
    logger.log(f"\n  ✅ 本地备份: {tarball}")
    logger.log(f"     文件数: {total_files}")
    logger.log(f"     压缩后: {fmt_size(tarball_size)}")

    return tarball

def cleanup_old_backups(keep: int = 7):
    """只保留最近 N 个本地备份"""
    old = sorted(BACKUP_ROOT.glob("hermes_backup_*.tar.gz"))[:-keep]
    for f in old:
        f.unlink()
        print(f"  🗑️  清理旧备份: {f.name}")

def backup_to_github(tarball: Path, logger: Logger):
    """推送备份到 GitHub Releases"""
    import urllib.request
    import urllib.error
    import urllib.parse
    import ssl

    pat = os.environ.get("GH_PAT")
    if not pat:
        print("  ❌ GH_PAT 环境变量未设置")
        return False

    # GitHub repo (from config or ask user)
    repo = os.environ.get("GH_REPO", "syncingabout/hermes-backup")
    branch = os.environ.get("GH_BRANCH", "main")

    # Step 1: Create/ensure repo exists
    logger.log(f"  📤 上传到 GitHub: {repo}")

    # Check if repo exists
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(
        f"https://api.github.com/repos/{repo}",
        headers={"Authorization": f"token {pat}", "Accept": "application/vnd.github.v3+json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            json.loads(r.read())
    except urllib.error.HTTPError as e:
        if e.code == 404:
            logger.log(f"  ℹ️  仓库不存在，尝试创建...")
            data = json.dumps({"name": repo.split("/")[-1], "private": False}).encode()
            req2 = urllib.request.Request(
                "https://api.github.com/user/repos",
                data=data, headers={"Authorization": f"token {pat}", "Accept": "application/vnd.github.v3+json"}
            )
            try:
                with urllib.request.urlopen(req2, timeout=15) as r2:
                    json.loads(r2.read())
                    logger.log(f"  ✅ 仓库创建成功")
            except Exception as e2:
                logger.log(f"  ❌ 创建仓库失败: {e2}")
                return False

    # Step 2: Create release + upload asset
    tag = f"backup-{TIMESTAMP}"
    release_data = json.dumps({"tag_name": tag, "name": f"Hermes Backup {TIMESTAMP}",
                                "body": f"Automatic backup {TIMESTAMP}"}).encode()
    req3 = urllib.request.Request(
        f"https://api.github.com/repos/{repo}/releases",
        data=release_data,
        headers={"Authorization": f"token {pat}", "Accept": "application/vnd.github.v3+json",
                 "Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req3, timeout=15) as r3:
            release = json.loads(r3.read())
            upload_url = release["upload_url"].split("{")[0]
    except Exception as e:
        logger.log(f"  ❌ 创建 release 失败: {e}")
        return False

    # Step 3: Upload tarball as release asset
    data = open(tarball, "rb").read()
    req4 = urllib.request.Request(
        f"{upload_url}?name={tarball.name}",
        data=data,
        headers={"Authorization": f"token {pat}", "Accept": "application/vnd.github.v3+json",
                 "Content-Type": "application/octet-stream"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req4, timeout=60) as r4:
            asset = json.loads(r4.read())
            logger.log(f"  ✅ GitHub 备份成功: {asset.get('browser_download_url')}")
            return True
    except Exception as e:
        logger.log(f"  ❌ 上传失败: {e}")
        return False

def write_manifest(tarball: Path):
    """写入备份清单"""
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    manifest = {
        "timestamp": TIMESTAMP,
        "tarball": str(tarball),
        "size_bytes": tarball.stat().st_size,
        "md5": hashlib.md5(open(tarball, "rb").read()).hexdigest(),
    }
    mf = BACKUP_ROOT / "latest.json"
    with open(mf, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"  📄 清单: {mf}")

def run_all():
    print("=" * 50)
    print(f"🧹 Hermes 双备份 — {TIMESTAMP}")
    print("=" * 50)

    logger = Logger()

    # 1. 本地备份
    print("\n[1/2] 本地备份...")
    tarball = build_tarball(logger)
    write_manifest(tarball)
    cleanup_old_backups(keep=7)

    # 2. GitHub 备份
    print("\n[2/2] GitHub 备份...")
    if os.environ.get("GH_PAT"):
        backup_to_github(tarball, logger)
    else:
        print("  ⏭️  GH_PAT 未设置，跳过 GitHub 备份")
        print("  ℹ️  设置方式: export GH_PAT=ghp_xxxxx")
        print("  ℹ️  仓库设置: export GH_REPO=你的用户名/仓库名")

    print("\n" + "=" * 50)
    print("✅ 备份完成")
    print(f"   本地: {tarball}")
    print("=" * 50)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Hermes 双备份工具")
    parser.add_argument("--github", action="store_true", help="仅 GitHub 备份")
    parser.add_argument("--all", action="store_true", help="本地 + GitHub")
    parser.add_argument("--repo", default="syncingabout/hermes-backup", help="GitHub repo (owner/name)")
    args = parser.parse_args()

    if args.repo:
        os.environ["GH_REPO"] = args.repo

    run_all()
