#!/usr/bin/env python3
"""Wrapper: run hermes_backup.py with --all, then push new backup to GitHub via git CLI."""
import subprocess, os, sys
from pathlib import Path

os.chdir("C:/Users/Admin/AppData/Local/hermes/scripts")

# Load .env
from dotenv import load_dotenv
load_dotenv("C:/Users/Admin/AppData/Local/hermes/.env")
os.environ["GH_PAT"] = os.environ.get("GH_PAT", "")
os.environ["GH_REPO"] = os.environ.get("GH_REPO", "maclandfx/HERMES")

PY = "C:/Python314/python.exe"
REPO = os.environ.get("GH_REPO", "maclandfx/HERMES")
PAT = os.environ.get("GH_PAT", "")
WORK = "/tmp/hermes-backup-git"

print("=== 1. 本地备份 ===")
r = subprocess.run([PY, "hermes_backup.py"], capture_output=True, text=True, timeout=120)
print(r.stdout[-500:])
if r.returncode != 0:
    print(f"local backup failed: {r.stderr}")
    sys.exit(1)

# Get latest tarball
import glob
tarballs = sorted(glob.glob(r"D:/Hermes/评估中心/backup/hermes_backup_*.tar.gz"))
if not tarballs:
    print("no tarball found")
    sys.exit(1)
latest = tarballs[-1]
print(f"\n=== 2. 推送 GitHub: {latest}")

if not PAT:
    print("GH_PAT not set, skipping GitHub")
    print(f"本地备份: {latest}")
    sys.exit(0)

# git clone or pull
import shutil
if os.path.exists(WORK):
    shutil.rmtree(WORK)
os.makedirs(WORK, exist_ok=True)

# Clone
subprocess.run(["git", "clone", f"https://{PAT}@github.com/{REPO}.git", WORK],
               capture_output=True, timeout=30)
os.chdir(WORK)
subprocess.run(["git", "config", "user.email", "hermes@local"], capture_output=True)
subprocess.run(["git", "config", "user.name", "Hermes Agent"], capture_output=True)

# Copy latest backup
backup_dir = os.path.join(WORK, "backup")
os.makedirs(backup_dir, exist_ok=True)
target = os.path.join(backup_dir, os.path.basename(latest))
subprocess.run(["cp", latest, target], capture_output=True)
mf = "D:/Hermes/评估中心/backup/latest.json"
if os.path.exists(mf):
    subprocess.run(["cp", mf, os.path.join(backup_dir, "latest.json")], capture_output=True)

# Commit + push
subprocess.run(["git", "add", "backup/"], capture_output=True)
r2 = subprocess.run(["git", "commit", "-m", f"Hermes backup {os.path.basename(latest).split('_')[1]}"],
                    capture_output=True, text=True)
if "nothing to commit" in r2.stdout:
    print("  (no changes to commit)")
else:
    print(r2.stdout.strip()[-200:])
    subprocess.run(["git", "push", f"https://{PAT}@github.com/{REPO}.git", "main"],
                   capture_output=True, timeout=60)
    print(f"  ✅ pushed to https://github.com/{REPO}")

print(f"\n本地: {latest}")
print(f"GitHub: https://github.com/{REPO}")
print(f"下载: https://github.com/{REPO}/blob/main/backup/{os.path.basename(latest)}")
