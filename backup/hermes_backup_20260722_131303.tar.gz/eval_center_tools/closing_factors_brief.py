#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
收盘因子快读 — closing_factors_brief.py
========================================
用途: 收盘后推送因子排名 + 异动速览 + 评估结论，5 分钟读完

数据流:
  - factors_raw.json: 16 因子得分（资金面 A 组 + 技术面 B 组）
  - track_history.csv: 当日行情（涨跌/涨停/量比）
  - 粗评报告: 当日评估结论

用法 (cron no-agent 直投 Telegram):
    python closing_factors_brief.py
"""
import os, sys, json, datetime, csv, re
from pathlib import Path

# ═══════════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════════
ROOT = Path(r"D:/Hermes/评估中心")
TRACK_DIR = ROOT / "reports" / "追踪"
FACTORS_PATH = TRACK_DIR / "factors_raw.json"
TRACK_CSV = TRACK_DIR / "track_history.csv"
REPORT_DIR = ROOT / "reports" / "粗评"
TOOLS_DIR = ROOT / "tools"
sys.path.insert(0, str(TOOLS_DIR))
from _stock_names import STOCK_NAMES, get_name

# 导入 PIAF 信号卡片模块（两融四区间 + Z-score 背离）
try:
    from piaf_signals import piaf_full_card
    _PIAF_AVAILABLE = True
except ImportError:
    _PIAF_AVAILABLE = False
    piaf_full_card = lambda: ""

WEIGHTS = {"A1_big_net_ratio": 15, "A3_strength": 13, "A2_consecutive_days": 12,
           "A4_north_flow": 10, "B4_rel_strength": 10, "B1_divergence": 8,
           "B3_gap": 8, "B5_trend": 8, "B2_limit_quality": 5, "B6_volatility": 5}
SUM_W = sum(WEIGHTS.values())


# ═══════════════════════════════════════════════════
#  综合分计算
# ═══════════════════════════════════════════════════
def composite(f):
    """16 因子加权综合分"""
    return sum(f.get(k, 50) * w for k, w in WEIGHTS.items()) / SUM_W


def dim_score(f, keys):
    """维度均分"""
    vals = [f.get(k, 50) for k in keys]
    return round(sum(vals) / len(vals), 1)


FUND_KEYS = ["A1_big_net_ratio", "A2_consecutive_days", "A3_strength", "A4_north_flow"]
TECH_KEYS = ["B1_divergence", "B2_limit_quality", "B3_gap", "B4_rel_strength", "B5_trend"]

# ═══════════════════════════════════════════════════
#  因子数据加载
# ═══════════════════════════════════════════════════
def load_factors():
    """返回 [(name, code, comp, fund_dim, tech_dim, factor_dict), ...]"""
    if not FACTORS_PATH.exists():
        return []
    try:
        raw = json.loads(FACTORS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []
    result = []
    for code, f in raw.items():
        if "error" in f:
            continue
        comp = round(composite(f), 1)
        fund = dim_score(f, FUND_KEYS)
        tech = dim_score(f, TECH_KEYS)
        name = STOCK_NAMES.get(code, code)
        result.append((name, code, comp, fund, tech, f))
    result.sort(key=lambda x: -x[2])
    return result


# ═══════════════════════════════════════════════════
#  异动速览（从 track_history.csv 读取当日涨跌/涨停）
# ═══════════════════════════════════════════════════
def load_daily_anomalies():
    """返回 {(code, name): (pct_chg, is_limit, vol_ratio)}"""
    if not TRACK_CSV.exists():
        return {}
    today = datetime.datetime.now().strftime("%Y%m%d")
    anomalies = {}
    try:
        with open(TRACK_CSV, encoding="utf-8-sig") as fp:
            reader = csv.DictReader(fp)
            for row in reader:
                if row.get("date", "") == today:
                    code = row.get("code", "")
                    try:
                        pct = float(row.get("pct_chg", 0))
                        is_limit = row.get("is_limit", "0") == "1"
                        vr = float(row.get("vol_ratio", 1))
                    except Exception:
                        continue
                    name = row.get("name", STOCK_NAMES.get(code, code))
                    anomalies[code] = (name, pct, is_limit, vr)
    except Exception:
        pass
    return anomalies


# ═══════════════════════════════════════════════════
#  读取当日评估报告摘要
# ═══════════════════════════════════════════════════
def load_eval_summary():
    """找今日最新粗评报告，提取核心结论（若有）"""
    today = datetime.datetime.now().strftime("%Y%m%d")
    try:
        files = sorted([f for f in REPORT_DIR.iterdir()
                        if f.suffix == ".md" and today in f.name and "核心" in f.name],
                       key=lambda f: f.stat().st_mtime, reverse=True)
        if not files:
            return None
        content = files[0].read_text(encoding="utf-8", errors="ignore")
        # 找结论段落
        m = re.search(r"(综合评分|综合得分|评估结论|总体评估)[^\n]*[:：]\s*([^\n]+)", content)
        if m:
            return m.group(0)[:120]
        # 兜底：返回标题
        for line in content.split("\n")[:3]:
            if "评估" in line and "核心" in line:
                return line[:80]
        return None
    except Exception:
        return None


# ═══════════════════════════════════════════════════
#  生成收盘快读
# ═══════════════════════════════════════════════════
def generate_brief():
    now = datetime.datetime.now()
    now_str = now.strftime("%Y-%m-%d")
    is_weekday = now.weekday() < 5

    factors = load_factors()
    anomalies = load_daily_anomalies()
    eval_summary = load_eval_summary()

    lines = []
    lines.append(f"# 📈 {now_str} 收盘因子快读")
    lines.append(f"⏰ {now.strftime('%H:%M')}  |  {'交易日' if is_weekday else '非交易日(回顾)'}")
    lines.append("")

    # ===== 1. 因子综合 TOP10 =====
    lines.append("## 🏆 因子综合 TOP10")
    lines.append("")
    lines.append("| # | 标的 | 综合分 | 资金面 | 技术面 | 信号 |")
    lines.append("|:--:|------|:-----:|:-----:|:-----:|:----:|")
    for i, (name, code, comp, fund, tech, f) in enumerate(factors[:10], 1):
        if comp >= 65:
            emoji = "🟢 强势"
        elif comp >= 55:
            emoji = "🟡 关注"
        else:
            emoji = "⚪ 观察"
        lines.append(f"| {i} | **{name}** | {comp} | {fund} | {tech} | {emoji} |")
    lines.append("")

    # ===== 2. 资金面最强 =====
    lines.append("## 💰 资金面 TOP3（大单净流入 + 资金持续性）")
    lines.append("")
    fund_ranked = sorted(factors, key=lambda x: -x[3])[:3]
    if fund_ranked:
        for name, code, comp, fund, tech, f in fund_ranked:
            big_net = f.get("A1_big_net_ratio", 50)
            consec = f.get("A2_consecutive_days", 0)
            lines.append(f"- **{name}** 资金面{fund} | 大单比{big_net:.0f} | 连续{consec:.0f}日净流入")
    else:
        lines.append("📭 无资金面数据")
    lines.append("")

    # ===== 3. 技术面最强 =====
    lines.append("## 📊 技术面 TOP3（量价背离 + 相对强弱）")
    lines.append("")
    tech_ranked = sorted(factors, key=lambda x: -x[4])[:3]
    if tech_ranked:
        for name, code, comp, fund, tech, f in tech_ranked:
            diverg = f.get("B1_divergence", 50)
            rel = f.get("B4_rel_strength", 50)
            tag = "放量突破" if diverg > 70 else "量价背离" if diverg < 30 else "中性"
            lines.append(f"- **{name}** 技术面{tech} | 背离{diverg:.0f}({tag}) | 相对强弱{rel:.0f}")
    else:
        lines.append("📭 无技术面数据")
    lines.append("")

    # ===== 4. 异动速览 =====
    lines.append("## ⚡ 异动速览")
    lines.append("")
    if anomalies:
        # 涨停
        limits = [(c, n) for c, (n, p, l, v) in anomalies.items() if l]
        # 涨超 5%
        strong = [(c, n, p) for c, (n, p, l, v) in anomalies.items() if p >= 5 and not l]
        # 跌超 3%
        weak = [(c, n, p) for c, (n, p, l, v) in anomalies.items() if p <= -3]

        if limits:
            lines.append("**🚨 涨停**: " + "、".join([f"**{n}**" for c, n in limits]))
        if strong:
            lines.append("**📈 大涨**: " + "、".join([f"**{n}**(+{p:.1f}%)" for c, n, p in strong]))
        if weak:
            lines.append("**📉 大跌**: " + "、".join([f"**{n}**({p:.1f}%)" for c, n, p in weak]))
        if not limits and not strong and not weak:
            lines.append("📭 无明显异动")
    else:
        lines.append("📭 暂无当日行情数据（盘前/盘后数据，收盘后自动更新）")
    lines.append("")

    # ===== 5. 评估结论 =====
    if eval_summary:
        lines.append("## 🎯 当日评估结论")
        lines.append("")
        lines.append(f"> {eval_summary}")
        lines.append("")

    # ===== 5. PIAF 信号卡片（两融四区间 + Z-score 背离）=====
    piaf_card = piaf_full_card()
    if piaf_card:
        lines.append("## 📊 PIAF 两融与Z-score信号")
        lines.append("")
        lines.append(piaf_card)
        lines.append("")

    # ===== 6. 行动暗示 =====
    lines.append("## ⚡ 明日行动建议")
    lines.append("")
    if factors:
        top3 = factors[:3]
        top_str = "、".join([f"**{n}**({c})" for n, c, comp, _, _, _ in top3])
        comp_top = top3[0][2]
        if comp_top >= 65:
            advice = f"因子强势，明日盯 {top_str}，开盘观察资金是否延续"
        elif comp_top >= 55:
            advice = f"因子中性偏强，明日盯 {top_str}，结合盘前政策方向决定"
        else:
            advice = f"因子整体偏弱，以防守为主，重点关注 {top_str} 是否出现资金回流"
        lines.append(f"> 🎯 {advice}")
    else:
        lines.append("> 📭 因子数据未更新，待收盘后因子引擎运行后补充")
    lines.append("")
    lines.append("---")
    lines.append(f"*数据: 16 因子(资金面 A + 技术面 B) + 通达信追踪 + 八维度评估*")
    lines.append(f"*生成: {now.strftime('%Y-%m-%d %H:%M:%S')}*")

    return "\n".join(lines)


if __name__ == "__main__":
    print(generate_brief())
