#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
月度复盘报告 — 每月 1 号 09:00 生成并推 TG
============================================
汇总上月评估系统运行数据：预警次数、综合分分布、推送成功率、
问题与改进点，供复盘提升。
"""
import os, sys, re, json, time, urllib.request
from pathlib import Path
from datetime import datetime as _dt, timedelta
from collections import defaultdict, Counter

# ═══════════════════════════════════════════════════
TOKEN = get_telegram_token()
CHAT_ID = "8673372605"
PROXY = "127.0.0.1:7890"

# 路径
BASE = Path(__file__).parent
TOOLS = BASE / "tdx_connector"
DONE_DIR = TOOLS / "telegram_queue" / "done"
QUEUE_DIR = TOOLS / "telegram_queue"
REPORTS_DIR = BASE / ".." / "reports" / "粗评"

# ═══════════════════════════════════════════════════
def get_last_month() -> tuple[str, str]:
    """返回 (上月 YYYY-MM, 本月 YYYY-MM)"""
    now = _dt.now()
    # 上个月的最后一天
    if now.month == 1:
        y, m = now.year - 1, 12
    else:
        y, m = now.year, now.month - 1
    last_month = f"{y}-{m:02d}"
    this_month = f"{now.year}-{now.month:02d}"
    return last_month, this_month


def parse_done_file(fpath: Path) -> dict:
    """解析归档预警文件"""
    try:
        content = fpath.read_text(encoding="utf-8")
    except Exception:
        return {}
    code = fpath.stem.split("_")[0]
    if len(code) == 7 and code[0] in "01":
        code = code[1:]
    ts = ""
    m = re.search(r"(\d{2}):(\d{2}):(\d{2})", fpath.stem)
    if m:
        ts = f"{m.group(1)}:{m.group(2)}:{m.group(3)}"
    score = 0.0
    m = re.search(r"综合分 (\d+\.?\d*) 分", content)
    if m:
        score = float(m.group(1))
    grade = ""
    m = re.search(r"综合分 \d+\.?\d* 分 \(([^)]+)\)", content)
    if m:
        grade = m.group(1)
    risk = ""
    m = re.search(r"\*\*风险\*\*:\s*(.+)", content)
    if m:
        risk = m.group(1).strip()
    return {"code": code, "ts": ts, "score": score, "grade": grade, "risk": risk, "file": fpath.name}


def build_opener():
    proxy = urllib.request.ProxyHandler({"http": f"http://{PROXY}", "https": f"http://{PROXY}"})
    return urllib.request.build_opener(proxy)


def send_tg(msg_text):
    opener = build_opener()
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    lines = msg_text.split("\n")
    chunks, current, length = [], [], 0
    for line in lines:
        if length + len(line) > 3500 and current:
            chunks.append("\n".join(current))
            current, length = [line], len(line)
        else:
            current.append(line)
            length += len(line)
    if current:
        chunks.append("\n".join(current))
    sent = 0
    for chunk in chunks:
        for attempt in range(3):
            try:
                data = json.dumps({
                    "chat_id": CHAT_ID, "text": chunk,
                    "parse_mode": "HTML", "disable_web_page_preview": True,
                }).encode("utf-8")
                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
                result = json.loads(opener.open(req, timeout=20).read())
                if result.get("ok"):
                    sent += 1
                    break
                else:
                    print(f"  ❌ TG API 拒绝: {result}")
            except Exception as e:
                if attempt < 2:
                    time.sleep(2)
                else:
                    print(f"  ❌ 发送失败: {e}")
        time.sleep(1)
    return sent


# ═══════════════════════════════════════════════════
def build_report(last_month: str, this_month: str) -> str:
    # 取 done/ 中上个月的文件（用 mtime）
    now = _dt.now()
    if now.month == 1:
        last_year, last_mon = now.year - 1, 12
    else:
        last_year, last_mon = now.year, now.month - 1
    cutoff_start = _dt(now.year - (1 if now.month == 1 else 0),
                       last_mon, 1, 0, 0, 0)
    # 下个月 1 号 0 点
    if last_mon == 12:
        cutoff_end = _dt(last_year + 1, 1, 1, 0, 0, 0)
    else:
        cutoff_end = _dt(last_year, last_mon + 1, 1, 0, 0, 0)

    # 解析所有 done 文件，按月分组
    all_records = []
    month_files = defaultdict(list)
    if DONE_DIR.exists():
        for f in sorted(DONE_DIR.glob("*.txt")):
            r = parse_done_file(f)
            if not r:
                continue
            mtime = _dt.fromtimestamp(f.stat().st_mtime)
            # 判断文件生成月份
            f_month = f"{mtime.year}-{mtime.month:02d}"
            r["mtime"] = mtime
            month_files[f_month].append(r)
            if cutoff_start <= mtime < cutoff_end:
                all_records.append(r)

    # 上月数据
    last_month_key = last_month
    last_records = month_files.get(last_month_key, [])

    # 本月至今数据
    this_records = month_files.get(this_month, [])

    # 统计
    total_last = len(last_records)
    total_this = len(this_records)

    # 综合分分布（上月）
    grade_dist = Counter(r.get("grade", "未知") for r in last_records if r.get("grade"))
    scores = [r["score"] for r in last_records if r["score"] > 0]
    avg_score = sum(scores) / len(scores) if scores else 0

    # 风险命中率
    risk_count = sum(1 for r in last_records if r.get("risk"))
    risk_rate = f"{risk_count}/{total_last}" if total_last else "0/0"

    # 报告数
    report_count = len(list(REPORTS_DIR.glob("*.md"))) if REPORTS_DIR.exists() else 0

    # 去重股票数
    unique_codes = len(set(r["code"] for r in last_records))

    ts = _dt.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        f"# 📊 {last_month} 月度复盘报告",
        f"",
        f"⏰ 生成时间: {ts}",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"## 📈 数据概览",
        f"",
        f"| 指标 | {last_month} | 本月至今 |",
        f"|------|-------------|----------|",
        f"| 预警总量 | {total_last} 条 | {total_this} 条 |",
        f"| 去重股票 | {unique_codes} 只 | — |",
        f"| 粗评报告 | {report_count} 份 | — |",
        f"| 平均综合分 | {avg_score:.1f} 分 | — |",
        f"| 含风险信号 | {risk_count} 条 | — |",
        f"",
        f"## 🏅 综合分评级分布 ({last_month})",
        f"",
    ]
    if grade_dist:
        for g in ["S", "A", "B", "C", "D", "未知"]:
            label = {"S": "S级", "A": "A级", "B": "B级", "C": "C级", "D": "D级"}.get(g, g)
            cnt = grade_dist.get(g, 0)
            if cnt:
                bar = "█" * min(cnt, 20)
                lines.append(f"- {label}: {cnt} 条 {bar}")
    else:
        lines.append("- 暂无评级数据")
    lines.append("")

    # Top 预警（按综合分）
    lines.append(f"## 🏆 {last_month} TOP 预警")
    lines.append("")
    top = sorted([r for r in last_records if r["score"] > 0], key=lambda x: -x["score"])[:5]
    if top:
        lines.append("| # | 代码 | 综合分 | 评级 | 预警时间 |")
        lines.append("|---|------|--------|------|----------|")
        for i, r in enumerate(top, 1):
            lines.append(f"| {i} | `{r['code']}` | {r['score']} 分 | {r.get('grade','—') or '—'} | {r.get('ts','—')} |")
    else:
        lines.append("- 暂无有效预警数据")
    lines.append("")

    # 本月改进点
    lines.append(f"## 🔧 本月改进项")
    lines.append("")
    lines.append("- 看门狗频率调整为 14:00-15:00 每 2 分钟，对齐预警运行窗口")
    lines.append("- 盘中预警推送格式升级：均线/主进/反身/筹码/风险六维度精简报告")
    lines.append("- 新增 14:50 尾盘总评，横向比对当日所有预警挑 TOP3")
    lines.append("- 风险信号实时抽取（资金流出/MACD死叉/下跌概率/国家队撤离）")
    lines.append("- 北向资金数据替换为实时环境共振（大盘/行业/领涨状态）")
    lines.append("")

    # 待改进
    lines.append(f"## 📋 待改进")
    lines.append("")
    lines.append("- PZYJ.blk 当前预警数量偏少，验证多只预警时的总评横向对比效果")
    lines.append("- eval_smart 单只耗时 ~27s，午盘密集出票时考虑缓存或异步")
    lines.append("- 早盘 09:30-14:00 无预警推送，考虑是否补充大盘状态监控")
    lines.append("- 月度数据量不足，待积累后增加趋势对比（环比涨跌）")
    lines.append("")

    lines.append(f"## 💬 小结")
    lines.append("")
    if total_last == 0:
        lines.append(f"> ⚠️ {last_month} 暂无盘中预警数据，报告为空。待预警系统稳定运行后开始积累。")
    elif total_last < 10:
        lines.append(f"> {last_month} 共 {total_last} 条预警，系统刚上线积累中。综合分均值 {avg_score:.1f} 分。重点关注：多只预警同时出现的总评对比效果、午盘密集出票时的推送速度。")
    else:
        lines.append(f"> {last_month} 共 {total_last} 条预警，覆盖 {unique_codes} 只股票，综合分均值 {avg_score:.1f} 分。含风险信号预警 {risk_count} 条（命中率 {risk_rate}）。系统运行稳定，持续积累中。")
    lines.append("")
    lines.append(f"━━━━━━━━━━━━━━")
    lines.append(f"*报告由评估中心自动生成*")

    return "\n".join(lines)


# ═══════════════════════════════════════════════════
def run_report():
    ts = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"📊 月度复盘报告 — {ts}")
    print("=" * 50)

    last_month, this_month = get_last_month()
    print(f"统计月份: {last_month} → 本月: {this_month}")

    msg = build_report(last_month, this_month)
    print("\n" + msg)

    sent = send_tg(msg)
    if sent:
        print(f"\n✅ 月度复盘推送完成 ({sent} 条消息)")
    else:
        print("\n❌ 推送失败")


if __name__ == "__main__":
    run_report()
