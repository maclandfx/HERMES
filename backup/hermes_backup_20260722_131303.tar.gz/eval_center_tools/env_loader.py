# -*- coding: utf-8 -*-
"""
统一环境变量加载器 — 所有脚本共享，杜绝硬编码凭据

用法:
    from env_loader import get_telegram_token, get_chat_id, get_env
    token = get_telegram_token()   # 自动读取 .env 或 TELEGRAM_BOT_TOKEN 环境变量
    chat_id = get_chat_id()         # 同上，CHATTER_CHAT_ID 或 TELEGRAM_HOME_CHANNEL
    proxy = get_proxy()             # 同 TELEGRAM_PROXY
    tushare_token = get_env("TUSHARE_TOKEN")
"""
import os

# Hermes .env 路径
HERMES_HOME = os.environ.get("HERMES_HOME", "C:/Users/Admin/AppData/Local/hermes")
ENV_FILE = os.path.join(HERMES_HOME, ".env")

# 已缓存的环境变量（避免重复读文件）
_env_cache = {}

def _load_env_file():
    """从 Hermes .env 文件加载键值对"""
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" in line:
                    key, _, value = line.partition("=")
                    key = key.strip()
                    value = value.strip().strip("\"").strip("'")
                    if key and value:
                        _env_cache[key] = value

def get_env(name, default=None):
    """
    获取环境变量，优先级:
    1. os.environ[name]
    2. .env 文件中的 [name]
    3. default
    """
    _load_env_file()
    return os.environ.get(name) or _env_cache.get(name) or default

def get_telegram_token():
    """获取 Telegram Bot Token"""
    for key in ("TELEGRAM_BOT_TOKEN", "TG_BOT_TOKEN"):
        v = get_env(key)
        if v and len(v) > 30:
            return v
    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN 未设置。\n"
        "设置方式: hermes config set env TELEGRAM_BOT_TOKEN=你的token\n"
        "或在 ~/.hermes/.env 中添加: TELEGRAM_BOT_TOKEN=你的token"
    )

def get_chat_id():
    """获取默认 Chat ID"""
    for key in ("CHATTER_CHAT_ID", "TELEGRAM_HOME_CHANNEL"):
        v = get_env(key)
        if v:
            return v
    return "8673372605"  # 默认值，无安全风险

def get_proxy():
    """获取代理地址"""
    return get_env("TELEGRAM_PROXY", "http://127.0.0.1:7890")

def get_tushare_token():
    """获取 Tushare Token"""
    v = get_env("TUSHARE_TOKEN")
    if not v:
        raise RuntimeError("TUSHARE_TOKEN 未设置")
    return v

if __name__ == "__main__":
    print(f"TELEGRAM_BOT_TOKEN: {get_telegram_token()[:10]}...{get_telegram_token()[-10:]}")
    print(f"CHATTER_CHAT_ID: {get_chat_id()}")
    print(f"TELEGRAM_PROXY: {get_proxy()}")
    print(f"TUSHARE_TOKEN: {get_tushare_token()[:10]}...")
