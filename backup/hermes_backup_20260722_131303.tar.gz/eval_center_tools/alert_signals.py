#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PIAF 重大信号监控 — 独立脚本
================================================================
在盘前/收盘 cron 运行后调用，检查 7 模型决策卡是否触发重大信号。
触发时主动推 Telegram，不触发时静默。

用法:
    python alert_signals.py          # 检查并推送
    python alert_signals.py --dry    # 只打印不推送

重大信号阈值:
    - 综合评分 ≥ 65 (B级及以上)
    - 背离度 ≥ 2.5 (极度虚假繁荣)
    - 综合评分 ≤ 35 (F级)
    - 5日两融跌幅 ≥ 15% (杠杆资金大幅撤离)
"""
import os, sys, json, datetime, urllib.request

# 路径
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

try:
    from piaf_signals import compute_decision_card, _load_zscore_latest, _load_margin_z, piaf_margin_card
except ImportError:
    print("ERROR: piaf_signals.py 不可用")
    sys.exit(1)

# 阈值
THRESHOLDS = {
    "HIGH_SCORE": 65,       # ≥ 65 分 = B级及以上
    "EXTREME_DIV": 2.5,     # ≥ 2.5 = 极度虚假繁荣
    "CRASH_SCORE": 35,      # ≤ 35 分 = F级
    "MARGIN_DROP": 15,      # ≥ 15% = 杠杆资金大幅撤离
    # 重大机会
    "BULL_CONSISTENT": 60,  # 评分≥60且背离度≤0.5 → B型共振机会
    "OVERSOLD_Z": -2.0,     # 综合Z≤-2.0 → 超跌反弹机会
    "STRONG_MOMENTUM": 0.3, # 动量衰减>0.3 → 动量加速机会
}

def _load_token() -> str:
    for var in ("TELEGRAM_BOT_TOKEN", "TG_BOT_TOKEN"):
        v = os.environ.get(var, "")
        if v and len(v) > 30:
            return v
    env_file = os.path.join(os.path.expanduser("~"), "AppData", "Local", "hermes", ".env")
    if os.path.exists(env_file):
        with open(env_file, encoding="utf-8") as f:
            for line in f:
                if line.startswith("TELEGRAM_BOT_TOKEN="):
                    v = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if v and len(v) > 30:
                        return v
    return ""

def _send_alert(text: str):
    """发送 Telegram 警告"""
    token = _load_token()
    if not token:
        print("WARN: Telegram token 不可用，跳过推送")
        return False
    chat = "8673372605"
    proxy = urllib.request.build_opener(
        urllib.request.ProxyHandler({"http": "http://127.0.0.1:7890", "https": "http://127.0.0.1:7890"})
    )
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = json.dumps({"chat_id": chat, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        resp = json.loads(proxy.open(req, timeout=20).read())
        return resp.get("ok", False)
    except Exception as e:
        print(f"SEND ERROR: {e}")
        return False

def check_signals():
    """检查是否触发重大信号，返回 (是否触发, alert文本)"""
    z_data = _load_zscore_latest()
    margin_z_data = _load_margin_z()
    decisions = compute_decision_card(z_data, margin_z_data)

    if not decisions:
        return False, ""

    # 风险信号
    alerts = []
    high_score = [d for d in decisions if d["total"] >= THRESHOLDS["HIGH_SCORE"]]
    extreme_div = [d for d in decisions if d["divergence"] >= THRESHOLDS["EXTREME_DIV"]]
    crash = [d for d in decisions if d["total"] <= THRESHOLDS["CRASH_SCORE"]]
    margin_drop = [d for d in decisions if d["margin_5d"] <= -THRESHOLDS["MARGIN_DROP"]]
    # 重大机会信号
    bull_consistent = [d for d in decisions if d["total"] >= THRESHOLDS["BULL_CONSISTENT"] and d["divergence"] <= 0.5]
    oversold = [d for d in decisions if d["z_comp"] <= THRESHOLDS["OVERSOLD_Z"]]
    strong_mom = [d for d in decisions if d.get("z_momentum") and d["z_momentum"] >= THRESHOLDS["STRONG_MOMENTUM"]]

    if high_score:
        for d in high_score:
            alerts.append(f"{d['icon']} <b>{d['sector']}</b>: {d['total']}分({d['grade']}级) — 达到B级阈值，背离度{d['divergence']:+.2f}")
    if extreme_div:
        for d in extreme_div:
            alerts.append(f"⚠️ <b>{d['sector']}</b>: 极度虚假繁荣，背离度{d['divergence']:+.2f}，预测Z(t+3)={d['pred_z']:+.2f}")
    if crash:
        for d in crash:
            alerts.append(f"🔴 <b>{d['sector']}</b>: {d['total']}分({d['grade']}级) — 系统性风险")
    if margin_drop:
        for d in margin_drop:
            alerts.append(f"💰 <b>{d['sector']}</b>: 5日两融跌幅{d['margin_5d']:+.2f}%，杠杆资金大幅撤离")

    # 机会信号
    opportunities = []
    if bull_consistent:
        for d in bull_consistent:
            opportunities.append(f"🟢 <b>{d['sector']}</b>: {d['total']}分({d['grade']}级) B型共振机会，综合Z{d['z_comp']:+.2f}两融Z{d['margin_z']:+.2f}背离度仅{d['divergence']:+.2f}，仓位{d['position']}")
    if oversold:
        for d in oversold:
            opportunities.append(f"💎 <b>{d['sector']}</b>: 超跌反弹机会，综合Z{d['z_comp']:+.2f}，预测Z(t+3)={d['pred_z']:+.2f}，两融5日{d['margin_5d']:+.2f}%")
    if strong_mom:
        for d in strong_mom:
            opportunities.append(f"🚀 <b>{d['sector']}</b>: 动量加速机会，Z动量+{d['z_momentum']:.2f}，评分{d['total']}分，仓位{d['position']}")

    if not alerts and not opportunities:
        return False, ""

    # 生成 alert 文本
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    is_opportunity_only = not alerts and opportunities

    if is_opportunity_only:
        header = "🟢 <b>PIAF 重大机会预警</b>"
    elif alerts and opportunities:
        header = "⚠️ <b>PIAF 信号预警</b>"
    else:
        header = "🚨 <b>PIAF 重大风险预警</b>"

    lines = [f"{header} ({now})", ""]
    for a in alerts:
        lines.append(f"• 风险: {a}")
    for o in opportunities:
        lines.append(f"• 机会: {o}")
    lines.append("")
    lines.append("━━━")
    lines.append("> PIAF 7模型监控自动触发 | 完整报告见盘前/收盘简报")

    return True, "\n".join(lines)

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--dry", action="store_true", help="只打印不推送")
    args = parser.parse_args()

    triggered, text = check_signals()

    if not triggered:
        print("OK: 无重大信号")
        return

    print("ALERT: 触发重大信号")
    print(text)

    if args.dry:
        print("\n[DRY RUN] 跳过推送")
        return

    ok = _send_alert(text)
    print(f"PUSH: {'成功' if ok else '失败'}")

if __name__ == "__main__":
    main()
