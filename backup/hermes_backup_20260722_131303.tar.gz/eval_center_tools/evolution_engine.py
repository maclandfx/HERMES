#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
进化引擎 — 每周日 23:00 运行
=================================
读取 decision_bus.json 的 accuracy_log 和 signal_source_performance，
分析各信号来源的命中率，生成权重调整建议和错误模式报告。

用法:
    python evolution_engine.py

输出:
    - 打印进化报告到 stdout
    - 更新 decision_bus.json 的 evolution 字段
    - 输出权重调整建议供 eval_weight_regression 使用
"""
import os, sys, json
from pathlib import Path
from datetime import datetime as _dt, timedelta

TOOLS_DIR = Path(__file__).parent
BUS_PATH = TOOLS_DIR / "decision_bus.json"


def _load_bus() -> dict:
    if BUS_PATH.exists():
        return json.loads(BUS_PATH.read_text(encoding="utf-8"))
    return {"feedback": {}, "evolution": {}}


def _save_bus(data: dict):
    # 保留 feedback.accuracy_log（write 函数会覆盖，这里先保存再合并）
    _PRESERVE_ACCURACY = None
    if BUS_PATH.exists():
        try:
            old = json.loads(BUS_PATH.read_text(encoding="utf-8"))
            _PRESERVE_ACCURACY = old.get("feedback", {}).get("accuracy_log", [])
        except Exception:
            pass
    data["last_updated"] = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")
    BUS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    # 再读回，保留 accuracy_log
    if _PRESERVE_ACCURACY:
        try:
            saved = json.loads(BUS_PATH.read_text(encoding="utf-8"))
            saved.setdefault("feedback", {})["accuracy_log"] = _PRESERVE_ACCURACY
            BUS_PATH.write_text(json.dumps(saved, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
    print(f"✅ decision_bus.json evolution 字段已更新")


def run_evolution() -> str:
    """运行进化引擎，返回进化报告文本"""
    data = _load_bus()
    fb = data.get("feedback", {})
    accuracy_log = fb.get("accuracy_log", [])
    perf = fb.get("signal_source_performance", {})
    error_patterns = fb.get("error_patterns", [])

    lines = []
    lines.append("# 🧬 进化引擎周报")
    lines.append("")
    lines.append(f"⏰ {_dt.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")

    # ===== 1. 信号来源命中率分析 =====
    lines.append("## 📊 信号来源命中率分析（过去30日）")
    lines.append("")
    lines.append("| 信号源 | 命中率 | 命中/总数 | 建议权重调整 |")
    lines.append("|--------|:------:|:---------:|:------------:|")

    total_weight_change = {}
    for src, p in perf.items():
        total = p.get("total", 0)
        hits = p.get("hits", 0)
        rate = p.get("hit_rate", 0)
        if total == 0:
            lines.append(f"| {src} | 无数据 | — | ⚪ 维持 |")
            continue
        emoji = "🟢" if rate >= 0.6 else "🟡" if rate >= 0.4 else "🔴"
        if rate >= 0.7:
            adj = "↑ +5%"
            w_change = 5
        elif rate >= 0.5:
            adj = "→ 维持"
            w_change = 0
        elif rate >= 0.3:
            adj = "↓ -3%"
            w_change = -3
        else:
            adj = "↓↓ -8%"
            w_change = -8
        total_weight_change[src] = w_change
        lines.append(f"| {src} | {emoji} {rate*100:.0f}% | {hits}/{total} | {adj} |")
    lines.append("")

    # ===== 2. 准确率趋势（近7日）=====
    lines.append("## 📈 准确率趋势（近7日）")
    lines.append("")
    cutoff = (_dt.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    recent = [e for e in accuracy_log if e.get("date", "") >= cutoff]
    if recent:
        lines.append("| 日期 | 命中率 | 预测数 | 命中数 |")
        lines.append("|------|:------:|:------:|:------:|")
        for e in recent:
            rate = e.get("hit_rate", 0)
            lines.append(f"| {e.get('date','?')} | {rate*100:.0f}% | {e.get('predictions_count',0)} | {e.get('hit_count',0)}/{e.get('total',0)} |")
        # 趋势判断
        rates = [e.get("hit_rate", 0) for e in recent if e.get("hit_rate") is not None]
        if len(rates) >= 2:
            trend = "↗ 上升" if rates[-1] > rates[0] else "↘ 下降" if rates[-1] < rates[0] else "→ 平稳"
            lines.append("")
            lines.append(f"> 趋势: **{trend}** (最近: {rates[-1]*100:.0f}% → 对比7日前: {rates[0]*100:.0f}%)")
    else:
        lines.append("📭 近7日无准确率数据（可能尚未运行足够天数）")
    lines.append("")

    # ===== 3. 错误模式分析 =====
    lines.append("## 🚩 错误模式分析")
    lines.append("")
    if error_patterns:
        lines.append("| 错误模式 | 出现次数 | 影响 |")
        lines.append("|----------|:--------:|------|")
        for ep in error_patterns[:5]:
            lines.append(f"| {ep.get('pattern','?')} | {ep.get('count',0)} | {ep.get('impact','?')} |")
    else:
        # 从 accuracy_log 自动提取错误模式
        errors = []
        for e in accuracy_log:
            for a in e.get("actuals", []):
                if a.get("hit") is False:
                    errors.append(a)
        if errors:
            # 分类错误
            overconfident = [e for e in errors if e.get("predicted_confidence", 0) > 0.7]
            if overconfident:
                error_patterns.append({
                    "pattern": f"高置信度错误预测",
                    "count": len(overconfident),
                    "impact": f"置信度>70% 的推荐中有 {len(overconfident)} 次打错",
                    "suggested_action": "高置信度但打错时，次日对同标的降权30%"
                })
                lines.append(f"- 🚩 **高置信度错误预测**: {len(overconfident)} 次（置信度>70% 的推荐打错）")
                lines.append(f"  → 建议: 高置信度但打错时，次日对同标的降权30%")

            # 连续错误
            consecutive_failures = 0
            max_consecutive = 0
            for e in reversed(accuracy_log):
                if e.get("hit_rate", 1) < 0.4:
                    consecutive_failures += 1
                    max_consecutive = max(max_consecutive, consecutive_failures)
                else:
                    consecutive_failures = 0
            if max_consecutive >= 3:
                lines.append(f"- 🚩 **连续低命中**: 曾连续 {max_consecutive} 天命中率<40%")
                lines.append(f"  → 建议: 连续3天低命中时，触发'防御模式'——推荐置信度阈值从0.5提到0.7")
        else:
            lines.append("📭 无错误数据（准确率尚未累积）")
    lines.append("")

    # ===== 4. 权重调整建议 =====
    lines.append("## ⚙️ 权重调整建议")
    lines.append("")
    if total_weight_change:
        lines.append("| 信号源 | 当前建议 | 具体调整 |")
        lines.append("|--------|:--------:|:--------:|")
        for src, w in total_weight_change.items():
            if w > 0:
                lines.append(f"| {src} | 🟢 加强 | 权重 +{w}% |")
            elif w < 0:
                lines.append(f"| {src} | 🔴 降权 | 权重 {w}% |")
            else:
                lines.append(f"| {src} | ⚪ 维持 | 不变 |")
        lines.append("")
        lines.append("> 📌 以上建议应在下一周期（周日权重回归）时应用到 eval_weight_regression 模型")
    else:
        lines.append("⚪ 无权重调整建议（数据不足）")
    lines.append("")

    # ===== 5. 下周关注 =====
    lines.append("## 🔭 下周关注事项")
    lines.append("")
    lines.append(f"- 总样本量: {sum(p.get('total', 0) for p in perf.values())} 次预测")
    overall_rate = fb.get("last_hit_rate")
    if overall_rate is not None:
        lines.append(f"- 综合命中率: {overall_rate*100:.1f}%")
        if overall_rate < 0.5:
            lines.append(f"- ⚠️ 综合命中率低于50%，建议加强数据采集质量")
    lines.append(f"- 准确率日志记录: {len(accuracy_log)} 条")
    lines.append("")

    # ===== 更新决策总线的 evolution 字段 =====
    evolution = data.setdefault("evolution", {})
    evolution["last_weight_adjustment"] = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")
    evolution["weight_history"] = evolution.get("weight_history", [])
    evolution["weight_history"].append({
        "date": _dt.now().strftime("%Y-%m-%d"),
        "weights": total_weight_change,
        "overall_hit_rate": overall_rate,
        "sample_size": sum(p.get("total", 0) for p in perf.values()),
    })
    # 只保留最近12周
    if len(evolution["weight_history"]) > 12:
        evolution["weight_history"] = evolution["weight_history"][-12:]
    evolution["next_evolution_run"] = (_dt.now() + timedelta(days=7)).strftime("%Y-%m-%d")

    _save_bus(data)

    report = "\n".join(lines)
    return report


if __name__ == "__main__":
    report = run_evolution()
    print(report)
