#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
尾盘总评脚本 — 14:50 定时触发
=====================================
读取当天所有已归档的盘中预警（done/），横向比对综合分/主进/反身/风险，
挑出最好的 1-3 只推送 TG，供尾盘捡钱包决策。
"""
import os, sys, re, json, time, urllib.request
from pathlib import Path
from datetime import datetime as _dt

# ═══════════════════════════════════════════════════
#  Telegram 配置（安全：从环境变量/._safe_tg 读取，不用硬编码）
# ═══════════════════════════════════════════════════
def _load_token():
    for var in ("TELEGRAM_BOT_TOKEN", "TG_BOT_TOKEN"):
        v = os.environ.get(var, "")
        if v and len(v) > 30:
            return v
    env_file = Path("C:/Users/Admin/AppData/Local/hermes/.env")
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if line.startswith("TELEGRAM_BOT_TOKEN="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v and len(v) > 30:
                    return v
    return get_telegram_token()

TOKEN = _load_token()
CHAT_ID = "8673372605"
MAX_MSG = 3500
PROXY = "127.0.0.1:7890"

# ═══════════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════════
TOOLS_DIR = Path(__file__).parent
QUEUE_DIR = TOOLS_DIR / "tdx_connector" / "telegram_queue"
DONE_DIR = QUEUE_DIR / "done"
REPORTS_DIR = TOOLS_DIR / ".." / "reports" / "粗评"
REPORTS_DIR = REPORTS_DIR.resolve()  # 确保绝对路径

# 导入决策总线（反馈闭环）
try:
    from _decision_bus import Bus
    _BUS_AVAILABLE = True
except ImportError:
    _BUS_AVAILABLE = False


def _get_opening_price_pct() -> dict:
    """
    从因子引擎 factors_raw.json 或 track_history.csv 获取当日开盘价/涨跌幅
    用于计算预测到收盘的价格变化（accuracy_log 实际值）
    """
    result = {}
    TRACK_DIR = REPORTS_DIR.parent / "追踪"
    FACTORS_PATH = TRACK_DIR / "factors_raw.json"
    TRACK_CSV = TRACK_DIR / "track_history.csv"
    today = _dt.now().strftime("%Y%m%d")

    # 从 track_history.csv 读当日行情（最可靠）
    if TRACK_CSV.exists():
        try:
            with open(TRACK_CSV, encoding="utf-8-sig") as fp:
                for row in __import__("csv").DictReader(fp):
                    if row.get("date", "") == today:
                        code = row.get("code", "")
                        try:
                            pct = float(row.get("pct_chg", 0))
                            open_p = float(row.get("open", 0))
                            result[code] = {"pct_chg": pct, "open": open_p}
                        except Exception:
                            pass
        except Exception:
            pass

    return result


def _write_accuracy_feedback(fusion, actual_changes, all_records):
    """
    收盘反馈：对比决策总线盘前推荐 vs 实际收盘表现，写入 accuracy_log
    """
    if not _BUS_AVAILABLE:
        return
    today = _dt.now().strftime("%Y-%m-%d")
    try:
        bus = Bus()
    except Exception:
        return

    fusion_recs = fusion.get("recommendations", [])
    if not fusion_recs:
        return

    actuals = []
    for rec in fusion_recs:
        code = rec.get("code", "")
        action = rec.get("action", "")
        # 判断方向：涨为bull，跌为bear
        direction = rec.get("direction", "bull")  # 默认看多

        # 从 actual_changes 找实际涨跌幅
        actual_data = actual_changes.get(code, {})
        pct_chg = actual_data.get("pct_chg", 0)

        # 找对应记录（从 all_records）
        rec_entry = next((r for r in all_records if r.get("code") == code), None)
        rec_change_str = rec_entry.get("change", "") if rec_entry else ""
        try:
            rec_change_pct = float(rec_change_str.strip("%")) if rec_change_str else 0
        except ValueError:
            rec_change_pct = pct_chg

        # 判定 hit：预测看多且实际涨 > 0，或预测看空且实际跌 < 0
        if direction == "bull":
            hit = rec_change_pct > 0
        elif direction == "bear":
            hit = rec_change_pct < 0
        else:
            hit = None  # neutral 不计入

        actuals.append({
            "code": code,
            "predicted_direction": direction,
            "predicted_confidence": rec.get("confidence", 0),
            "actual_change_pct": rec_change_pct,
            "hit": hit,
        })

    # 计算命中率（只算有明确方向的）
    decided = [a for a in actuals if a["hit"] is not None]
    hits = sum(1 for a in decided if a["hit"])
    bus.write_accuracy_log(
        date=today,
        predictions=[{k: v for k, v in r.items() if k != "sources"} for r in fusion_recs],
        actuals=actuals,
        source="fusion",
    )
    print(f"  📊 accuracy_log 已写入: {hits}/{len(decided)} hit (命中率 {hits/len(decided)*100:.0f}%)" if decided else "  ⚪ 无明确方向推荐，跳过 accuracy 计算")


def _read_fusion_recommendations() -> dict:
    """读取决策总线的融合推荐"""
    if not _BUS_AVAILABLE:
        return {}
    try:
        bus = Bus()
        return bus.get_fusion()
    except Exception:
        return {}


def _build_feedback_section(fusion, actual_changes) -> list[str]:
    """生成反馈段落：命中率 + 表现对比"""
    lines = []
    if not fusion.get("recommendations"):
        lines.append("📊 **反馈**: 无盘前推荐数据（决策总线尚未写入）")
        lines.append("")
        return lines

    decided_actuals = []
    for rec in fusion.get("recommendations", []):
        code = rec.get("code", "")
        direction = rec.get("direction", "bull")
        actual_data = actual_changes.get(code, {})
        pct = actual_data.get("pct_chg", 0)
        decided_actuals.append((code, rec.get("name", ""), direction, pct))

    if not decided_actuals:
        lines.append("📊 **反馈**: 无实际数据可对比")
        lines.append("")
        return lines

    lines.append("📊 **盘前推荐 vs 实际表现**")
    lines.append("")
    lines.append("| 标的 | 预测 | 实际涨跌 | 结果 |")
    lines.append("|------|------|---------|------|")
    for code, name, direction, pct in decided_actuals:
        if pct > 0.5:
            emoji = "🟢"
        elif pct < -0.5:
            emoji = "🔴"
        else:
            emoji = "⚪"
        arrow = "📈" if direction == "bull" else "📉" if direction == "bear" else "⚪"
        result = "✅" if (direction == "bull" and pct > 0) or (direction == "bear" and pct < 0) else "❌"
        lines.append(f"| {name}({code}) | {arrow} | {pct:+.2f}% {emoji} | {result} |")
    lines.append("")
    return lines

STOCK_NAMES = {
    "600118": "中国卫星", "300418": "昆仑万维", "600288": "大恒科技",
    "688135": "利扬芯片", "688175": "高凌信息", "603296": "华勤技术",
    "603893": "瑞芯微", "688802": "沐曦股份", "000518": "四环生物",
    "301516": "中远通", "300454": "深信服", "688722": "同益中",
    "688039": "当虹科技", "001395": "亚联机械", "600992": "贵绳股份",
    "300649": "杭州园林", "002414": "高德红外", "002490": "山东墨龙",
    "000779": "甘咨询", "603339": "四方科技", "300558": "贝达药业",
}

# ═══════════════════════════════════════════════════
#  约束规则 — 针对散户常见弱点硬性编码
# ═══════════════════════════════════════════════════
# 弱点1: 追高——只在尾盘买入，不上盘中追涨
# 弱点2: 重仓——单日最大仓位30%，单只最大15%
# 弱点3: 不止损——每次操作必须报止损价，否则跳过
# 弱点4: 频繁——环境红灯时强制空仓
# 弱点5: 恋战——持仓不超过3日，不恋战
CONSTRAINT_RULES = {
    "max_daily_position": 30,   # 单日最大仓位%
    "max_single_position": 15,  # 单只最大仓位%
    "max_holding_days": 3,      # 最大持仓天数
    "buy_time": "14:30后",      # 只允许尾盘买入
    "stop_loss_required": True, # 必须有止损价
}

# ═══════════════════════════════════════════════════
#  环境温度计 — 从归档报告中抽环境数据
# ═══════════════════════════════════════════════════
def get_env_from_md(md_path: Path) -> dict:
    """从最新 md 报告里抽环境数据"""
    try:
        content = md_path.read_text(encoding="utf-8")
    except Exception:
        return {}
    lines = content.split("\n")
    # 涨停家数 TOP3
    limit_up_top3 = []
    volume_status = ""
    for l in lines:
        m = re.search(r"🔥 \*\*(.+?)\*\*\s*\(涨停(\d+)家\)", l)
        if m:
            limit_up_top3.append((m.group(1), int(m.group(2))))
    # 量能（从周线趋势行抽，或趋势行；可能没有结尾 | ）
    for l in lines:
        if "量能" in l:
            m = re.search(r"量能:\s*(.+?)(?:\s*\||$)", l)
            if m:
                volume_status = m.group(1).strip()
            break
    # 大盘共振
    market_state = ""
    for l in lines:
        if "大盘多头" in l and "|" in l and "花神红" in l:
            continue  # 表头
        if "大盘" in l and "共振层级" in l and "|" in l:
            continue  # 表头
    return {
        "limit_up_top3": limit_up_top3[:3],
        "volume_status": volume_status,
    }


def build_opener():
    proxy = urllib.request.ProxyHandler({"http": f"http://{PROXY}", "https": f"http://{PROXY}"})
    return urllib.request.build_opener(proxy)


def send_tg(msg_text):
    opener = build_opener()
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    lines = msg_text.split("\n")
    chunks, current, length = [], [], 0
    for line in lines:
        if length + len(line) > MAX_MSG and current:
            chunks.append("\n".join(current))
            current, length = [line], len(line)
        else:
            current.append(line)
            length += len(line)
    if current:
        chunks.append("\n".join(current))
    sent = 0
    for chunk in chunks:
        for attempt in range(3):
            try:
                data = json.dumps({
                    "chat_id": CHAT_ID, "text": chunk,
                    "parse_mode": "HTML", "disable_web_page_preview": True,
                }).encode("utf-8")
                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
                result = json.loads(opener.open(req, timeout=20).read())
                if result.get("ok"):
                    sent += 1
                    break
                else:
                    print(f"  ❌ TG API 拒绝: {result}")
            except Exception as e:
                if attempt < 2:
                    time.sleep(2)
                else:
                    print(f"  ❌ 发送失败: {e}")
        time.sleep(1)
    return sent

def parse_stock_record(fpath: Path) -> dict:
    """从归档 txt（精简格式）中抽取关键字段"""
    try:
        content = fpath.read_text(encoding="utf-8")
    except Exception:
        return {}

    code = fpath.stem.split("_")[0]
    # 去掉可能的 7 位前缀
    if len(code) == 7 and code[0] in "01":
        code = code[1:]
    name = STOCK_NAMES.get(code, "")

    def _gr(pattern):
        m = re.search(pattern, content)
        return m.group(1).strip() if m else ""

    # 标的行: **贝达药业**(`300558`) ¥69.80 +8.22%
    m_name = re.search(r"\*\*([\u4e00-\u9fff\w]{1,6})\*\*\s*\(`(\d{6})`\)\s*¥([\d.]+)\s*([+-]?[\d.]+%)", content)
    if m_name:
        name = m_name.group(1)
        code = m_name.group(2)
        price = m_name.group(3)
        change = m_name.group(4)
    else:
        price = _gr(r"¥([\d.]+)")
        change = _gr(r"([+-]?[\d.]+%)")

    score = _gr(r"综合分 (\d+\.?\d*) 分")
    # 行: **综合分 85.1 分 (S级)**
    grade_m = re.search(r"综合分 \d+\.?\d* 分 \(([^)]+)\)", content)
    grade = grade_m.group(1) if grade_m else ""
    tech = _gr(r"技术 (\d+) \)")
    capital = _gr(r"资金 (\d+) \|")
    sentiment = _gr(r"情绪 (\d+)")
    advise = _gr(r"\*\*操作\*\*:\s*(.+)")
    target = _gr(r"目标 ¥([\d.]+)")
    stop_loss = _gr(r"止损 ¥([\d.]+)")
    buy_tan = _gr(r"盈亏比 ([\d.]+):1")
    main_signal = _gr(r"\*\*主进\*\*:\s*(.+)")
    refx = _gr(r"\*\*反身\*\*:\s*(.+)")
    chip = _gr(r"\*\*筹码\*\*:\s*(.+)")
    weekly = _gr(r"\*\*周线\*\*:\s*(.+)")
    risk = _gr(r"\*\*风险\*\*:\s*(.+)")

    return {
        "name": name, "code": code, "price": price, "change": change,
        "score": float(score) if score else 0, "grade": grade,
        "tech": float(tech) if tech else 0,
        "capital": float(capital) if capital else 0,
        "sentiment": float(sentiment) if sentiment else 0,
        "advise": advise, "target": target, "stop_loss": stop_loss,
        "buy_tan": buy_tan,
        "main_signal": main_signal, "refx": refx, "chip": chip,
        "weekly": weekly, "risk": risk,
        "file": fpath.name,
    }


# ═══════════════════════════════════════════════════
#  评分排序 + 选 TOP
# ═══════════════════════════════════════════════════
def rank_and_pick(records: list[dict], top_n: int = 3) -> list[dict]:
    """按综合分降序，前 3 名"""
    valid = [r for r in records if r["score"] > 0]
    valid.sort(key=lambda x: -x["score"])
    return valid[:top_n]


# ═══════════════════════════════════════════════════
#  生成总评消息
# ═══════════════════════════════════════════════════
def get_top_md_report() -> Path | None:
    """找最新 md 报告取环境数据"""
    if not REPORTS_DIR.exists():
        return None
    files = sorted(REPORTS_DIR.glob("*.md"), reverse=True)
    return files[0] if files else None


def check_constraints(r: dict) -> list[str]:
    """对单只标的检查约束条件，返回违反项"""
    violations = []
    # 1. 必须有止损价
    if CONSTRAINT_RULES["stop_loss_required"] and not r.get("stop_loss"):
        violations.append("无止损价")
    # 2. 综合分 < 60 不推荐
    if r["score"] < 60:
        violations.append("综合分过低")
    # 3. 有🔴或⚠️风险信号时降低推荐
    risk = r.get("risk", "")
    if "国家队撤离" in risk:
        violations.append("国家队撤离")
    if "MACD死叉" in risk:
        violations.append("MACD死叉")
    return violations


def build_review_msg(top: list[dict], all_count: int,
                     actual_changes: dict = None, fusion: dict = None) -> str:
    ts = _dt.now().strftime("%Y-%m-%d %H:%M")
    actual_changes = actual_changes or {}
    fusion = fusion or {}

    # ── 环境温度计 ──
    env = {}
    md_file = get_top_md_report()
    if md_file:
        env = get_env_from_md(md_file)
    limit_up_top3 = env.get("limit_up_top3", [])
    limit_up_str = ", ".join(f"{n}({n2}家)" for n, n2 in limit_up_top3) if limit_up_top3 else "无数据"
    vol_str = env.get("volume_status", "无数据")

    # 环境判断（基于涨停家数）
    total_limit_up = sum(n2 for _, n2 in limit_up_top3)
    if total_limit_up >= 400:
        env_state, env_icon, action_verdict = "🟢强", "🟢", "允许攻击"
    elif total_limit_up >= 150:
        env_state, env_icon, action_verdict = "🟡中性", "🟡", "只买最确定的"
    else:
        env_state, env_icon, action_verdict = "🔴弱", "🔴", "今日不宜动手"

    # ── 决策总线信号（读盘前融合推荐）──
    bus_section = []
    if fusion.get("recommendations"):
        bus_section.append("🧠 **决策总线·盘前推荐**")
        bus_section.append("")
        for rec in fusion["recommendations"][:3]:
            code = rec.get("code", "?")
            name = rec.get("name", code)
            action = rec.get("action", "观察")
            conf = rec.get("confidence", 0)
            reason = (rec.get("reason", "") or "")[:60]
            arrow = {"bull": "📈", "bear": "📉", "buy": "💎", "sell": "⚠️"}.get(action.lower(), "⚪")
            bus_section.append(f"  {arrow} **{name}**({code}) — {action} (置信度{conf*100:.0f}%)")
            if reason:
                bus_section.append(f"     {reason}")
        bus_section.append("")
    elif fusion.get("overall_direction"):
        pol_dir = {"bull": "📈看多", "neutral": "⚪中性", "bear": "📉看空"}.get(
            fusion.get("overall_direction", "").lower(), "⚪"
        )
        bus_section.append(f"🧠 **决策总线**: {pol_dir} (整体置信度{fusion.get('overall_confidence',0)*100:.0f}%)")
        bus_section.append("")

    # ── 反馈段落（对比盘前推荐 vs 实际收盘）──
    feedback_section = _build_feedback_section(fusion, actual_changes) if _BUS_AVAILABLE else []

    # ── 约束（从伙伴日志读自适应约束）──
    import importlib.util
    _partner_path = TOOLS_DIR / "partner_log.py"
    _partner = None
    if _partner_path.exists():
        try:
            _partner = importlib.util.module_from_spec(
                importlib.util.spec_from_file_location("partner_log", str(_partner_path))
            )
            importlib.util.spec_from_file_location("partner_log", str(_partner_path)).loader.exec_module(_partner)
        except Exception:
            pass

    if _partner and hasattr(_partner, "adaptive_constraints"):
        rules = _partner.adaptive_constraints()
    else:
        rules = CONSTRAINT_RULES
    best_r = top[0] if top else {}
    violations = check_constraints(best_r) if top else []

    # ── 回测胜率（读 insights.json）──
    _insights_path = TOOLS_DIR / "partner_data" / "insights.json"
    win_rate = "无数据"
    if _insights_path.exists():
        try:
            _insights = json.loads(_insights_path.read_text(encoding="utf-8"))
            win_rate = f"{_insights.get('win_rate', 0)*100:.0f}%"
        except Exception:
            pass

    # ── 信号命中率（从决策总线读）──
    signal_hit_rate = ""
    if _BUS_AVAILABLE:
        try:
            bus = Bus()
            perf = bus.get_signal_performance()
            parts = []
            for src, p in perf.items():
                if p.get("total", 0) > 0:
                    parts.append(f"{src}:{p['hit_rate']*100:.0f}%({p['hits']}/{p['total']})")
            if parts:
                signal_hit_rate = " | ".join(parts)
        except Exception:
            pass

    # ── 构建消息 ──
    lines = [
        f"# 🏆 尾盘总评",
        f"",
        f"⏰ {ts} | 今日 {all_count} 只预警",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"🌡️ **环境**: {env_icon} {env_state}",
        f"  热门板块: {limit_up_str}",
        f"  量能: {vol_str}",
        f"  决策: **{action_verdict}**",
        f"",
        f"🔒 **约束**",
        f"  只允许尾盘({rules.get('buy_time','14:30后')})买入 | 单日≤{rules.get('max_daily_position',30)}% | 单只≤{rules.get('max_single_position',15)}% | 持仓≤{rules.get('max_holding_days',3)}日",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"📊 **回测胜率**: {win_rate}（过去30天）",
    ]
    if signal_hit_rate:
        lines.append(f"📊 **信号命中率(30日)**: {signal_hit_rate}")
    lines.append("")
    lines.append("━━━━━━━━━━━━━━")
    lines.append("")

    # ── 决策总线信号段落 ──
    if bus_section:
        lines.extend(bus_section)
        lines.append("━━━━━━━━━━━━━━")
        lines.append("")

    # ── 反馈段落 ──
    if feedback_section:
        lines.extend(feedback_section)
        lines.append("━━━━━━━━━━━━━━")
        lines.append("")

    if not top:
        lines.append("⚠️ 当日无有效预警")
        return "\n".join(lines)

    # 排名表格
    lines.append("| # | 标的 | 综合分 | 技术 | 资金 | 情绪 | 主进 | 风险 |")
    lines.append("|---|------|--------|------|------|------|------|------|")
    for i, r in enumerate(top, 1):
        risk_flag = "⚠️" if r.get("risk") else "—"
        lines.append(
            f"| {i} | {r['name']}(`{r['code']}`) | "
            f"**{r['score']}分**({r.get('grade','—') or '—'}) | "
            f"{r['tech']:.0f} | {r['capital']:.0f} | {r['sentiment']:.0f} | "
            f"{'✅' if '✅' in r.get('main_signal','') else '❌'} | {risk_flag} |"
        )

    lines.append("")
    lines.append("━━━━━━━━━━━━━━")

    for i, r in enumerate(top, 1):
        medal = ["🥇", "🥈", "🥉"][i - 1]
        v = check_constraints(r)
        v_str = " | ".join(v) if v else "✅通过"
        lines.append(
            f"\n{medal} **{r['name']}**(`{r['code']}`) ¥{r.get('price','—')} {r.get('change','')}\n"
            f"   **{r['score']}分 ({r.get('grade','—') or '—'})** | 技术{r['tech']:.0f} 资金{r['capital']:.0f} 情绪{r['sentiment']:.0f}\n"
            f"   🔵 主进: {r.get('main_signal','—')}\n"
            f"   🔄 反身: {r.get('refx','—')}\n"
            f"   🪙 筹码: {r.get('chip','—')}\n"
            f"   📈 周线: {r.get('weekly','—')}\n"
            f"   🎯 操作: {r.get('advise','—')} | 目标¥{r.get('target','—')} 止损¥{r.get('stop_loss','—')} 盈亏比{r.get('buy_tan','—')}:1\n"
            f"   🔒 约束: {v_str}"
        )
        risk = r.get("risk", "").strip()
        if risk:
            lines.append(f"   🚩 风险: {risk}")

    lines.append("")
    lines.append("━━━━━━━━━━━━━━")

    # 最终决策
    if violations:
        verdict_text = (
            f"⚠️ **今日首选**: {best_r['name']}(`{best_r['code']}`) {best_r['score']}分\n"
            f"   但有约束警示: {'; '.join(violations)}\n"
            f"   → {'建议观望' if len(violations) >= 2 else '谨慎执行，严守止损'}"
        )
    else:
        verdict_text = (
            f"💎 **今日首选**: {best_r['name']}(`{best_r['code']}`) {best_r['score']}分\n"
            f"   操作: {best_r.get('advise','')}\n"
            f"   止损: ¥{best_r.get('stop_loss','—')} | 仓位: ≤{CONSTRAINT_RULES['max_single_position']}%"
        )
    lines.append(verdict_text)

    return "\n".join(lines)




# ═══════════════════════════════════════════════════
#  主流程
# ═══════════════════════════════════════════════════
def run_review():
    ts = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"🏆 尾盘总评 — {ts}")
    print("=" * 50)

    if not DONE_DIR.exists():
        print("⚠️ done 目录不存在")
        return

    files = sorted(DONE_DIR.glob("*.txt"))
    if not files:
        print("📭 无当日预警记录")
        return

    # 解析所有记录
    all_records = []
    for f in files:
        r = parse_stock_record(f)
        if r:
            all_records.append(r)

    # 同只股票取最新一条（文件名时间戳最大）
    best = {}
    for r in all_records:
        code = r["code"]
        if code not in best or r["file"] > best[code]["file"]:
            best[code] = r
    records = list(best.values())

    # 过滤无效记录（旧格式/解析失败 score=0 的，不纳入总评）
    records = [r for r in records if r["score"] > 0]
    if not records:
        print("⚠️ 无有效预警记录（全部解析失败或综合分为 0）")
        return

    print(f"📊 有效记录 {len(records)} 只（去重 {len(all_records)} → {len(records)}）")
    for r in records:
        print(f"  {r['code']} {r['name']}: {r['score']}分")

    top = rank_and_pick(records, top_n=3)
    if not top:
        print("⚠️ 无有效记录")
        return

    # ── P2: 收盘反馈闭环 ──
    # 1. 读实际收盘涨跌幅
    actual_changes = _get_opening_price_pct()
    # 2. 读决策总线的盘前融合推荐
    fusion = _read_fusion_recommendations()
    # 3. 对比盘前推荐 vs 实际收盘 → 写入 accuracy_log
    _write_accuracy_feedback(fusion, actual_changes, all_records)

    # ── 生成总评消息（传入实际数据和融合推荐）──
    msg = build_review_msg(top, len(records),
                           actual_changes=actual_changes, fusion=fusion)
    print("\n" + msg)

    sent = send_tg(msg)
    if sent:
        print(f"\n✅ 总评推送完成 ({sent} 条消息)")
    else:
        print("\n❌ 推送失败")


if __name__ == "__main__":
    run_review()
