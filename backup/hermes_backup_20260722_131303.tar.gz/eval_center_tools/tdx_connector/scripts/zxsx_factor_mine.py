import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_telegram_token
"""
zxsx_factor_mine.py — 周线手选因子反推引擎（周线框架）
==================================================
只分析周线公式因子，不与综合评分因子混合。
每天15:30跑，追踪周线标的未来2-3周收益。
"""
import sys, os, json, time, math
sys.path.insert(0, r'D:/Hermes/评估中心/tools')
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')

import numpy as np
from datetime import datetime, timedelta

DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)
SNAPSHOT_FILE = os.path.join(DATA_DIR, 'zxsx_snapshots.json')
RESULT_FILE = os.path.join(DATA_DIR, 'zxsx_results.json')
CORR_FILE = os.path.join(DATA_DIR, 'zxsx_factor_corr.json')
WEIGHT_FILE = os.path.join(DATA_DIR, 'zxsx_weights.json')


def normalize(c):
    return c[1:] if len(c) == 7 and c[0] in '012' else c


def rank_data(x):
    arr = np.array(x, dtype=float)
    order = np.argsort(arr)
    ranks = np.empty(len(arr), dtype=float)
    i = 0
    while i < len(order):
        j = i
        while j < len(order) - 1 and np.abs(arr[order[j]] - arr[order[i]]) < 1e-12:
            j += 1
        avg = (i + j) / 2.0 + 1
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def spearmanr_np(x, y):
    rx, ry = rank_data(x), rank_data(y)
    sx, sy = np.std(rx), np.std(ry)
    if sx == 0 or sy == 0:
        return 0.0, 1.0
    rho = np.corrcoef(rx, ry)[0, 1]
    n = len(x)
    if n < 6:
        return float(rho), 1.0
    t_val = rho * math.sqrt((n - 2) / max(1e-10, 1 - rho * rho))
    p = math.erfc(abs(t_val) / math.sqrt(2))
    return float(rho), float(p)


def load_snapshots():
    if os.path.exists(SNAPSHOT_FILE):
        return json.load(open(SNAPSHOT_FILE, encoding='utf-8'))
    return {'entries': [], 'stats': {}}


def save_snapshots(data):
    json.dump(data, open(SNAPSHOT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)


def record_snapshot(codes_7, factors, market_data, end_date=None):
    if end_date is None:
        end_date = datetime.now().strftime('%Y%m%d')
    data = load_snapshots()
    stats = data.get('stats', {})
    new = 0
    for orig in codes_7:
        p = normalize(orig)
        if not p or len(p) != 6:
            continue
        f = factors.get(p, {})
        if 'error' in f:
            continue
        if any(e['code'] == p and e['date'] == end_date for e in data['entries']):
            continue
        data['entries'].append({
            'code': p, 'date': end_date, 'factors': f,
            'market': market_data.get(p, {}),
        })
        stats[p] = {'first_seen': end_date, 'count': stats.get(p, {}).get('count', 0) + 1}
        new += 1
    save_snapshots(data)
    print(f'[ZXSX] new={new} total={len(data["entries"])}')
    return new


def calc_future_return(start_date, code, forward_days):
    """计算 forward_days 日后的累计收益率"""
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        ts_code = code + '.SH' if code[0] in '69' else code + '.SZ'
        start_dt = datetime.strptime(start_date, '%Y%m%d')
        future_dt = start_dt + timedelta(days=forward_days)
        future_end = future_dt.strftime('%Y%m%d')
        df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=future_end)
        if df is None or df.empty or len(df) < 2:
            return None
        df = df.sort_values('trade_date').reset_index(drop=True)
        return round((df.iloc[-1]['close'] / df.iloc[0]['close'] - 1) * 100, 2)
    except Exception as e:
        print(f'  [WARN] {code} {forward_days}d: {e}')
        return None


def track_results(codes_list, days_check=[7, 14, 21, 30, 60]):
    """周线引擎用周级别跟踪：1周/2周/3周/1月/2月"""
    data = load_snapshots()
    if not data['entries']:
        print('[ZXSX] no snapshots')
        return []
    results = []
    for entry in data['entries']:
        code, start = entry['code'], entry['date']
        elapsed = (datetime.now() - datetime.strptime(start, '%Y%m%d')).days
        for d in days_check:
            if elapsed < d:
                continue
            ret = calc_future_return(start, code, d)
            if ret is not None:
                results.append({
                    'code': code, 'start': start, 'days': d,
                    'return': ret, 'factors': entry['factors'],
                })
    json.dump(results, open(RESULT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f'[ZXSX] {len(results)} records')
    return results


def compute_correlation(results):
    if not results:
        return {}
    import pandas as pd
    df = pd.DataFrame(results)
    corr = {}
    for d in sorted(df['days'].unique()):
        g = df[df['days'] == d]
        if len(g) < 5:
            continue
        fkeys = list(g['factors'].iloc[0].keys())
        for fk in fkeys:
            vals, rets = [], []
            for _, row in g.iterrows():
                fv = row['factors'].get(fk)
                if fv is not None and isinstance(fv, (int, float, np.floating)):
                    vals.append(float(fv))
                    rets.append(row['return'])
            if len(vals) < 5:
                continue
            rho, pval = spearmanr_np(vals, rets)
            corr.setdefault(fk, {})[f'day{d}'] = {
                'rho': round(rho, 3), 'pval': round(pval, 4),
                'n': len(vals), 'sig': pval < 0.05}
    json.dump(corr, open(CORR_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return corr


def recommend_weights(corr):
    if not corr:
        return {}
    names = {
        'weekly_macd_golden': '周线MACD金叉',
        'weekly_macd_dif_above_dea': '周线DIF>DEA',
        'weekly_kdj_bull': '周线KDJ多头',
        'weekly_avg_turning': '平均线拐头',
        'weekly_core_trend_low': '趋势低位',
        'weekly_vol_freeze': '量能冰点',
        'weekly_atr_rising': 'ATR抬升',
        'weekly_winner_safe': 'WINNER>35%',
        'weekly_strategic_build': '战略建仓',
        'weekly_long_backbone': '长线底气',
        'weekly_c_above_ma60': '站上60周线',
        'weekly_huashen_red': '花神红',
        'weekly_vol_moderate': '量能温和递增',
        'weekly_ma_bull': '均线多头',
        'weekly_trend_golden': '趋势金叉',
        'weekly_individual_trend_low': '趋势低位(普及版)',
        'weekly_non_high': '非高位',
        'weekly_cost_conc_safe': '筹码集中',
        'weekly_no_long_upper_shadow': '无长上影',
        'weekly_body_dominant': '实体占优',
        'weekly_rps_50': '50周RPS',
        'weekly_rps_120': '120周RPS',
        'weekly_macd_dif': '周线DIF值',
        'weekly_macd_dea': '周线DEA值',
        'weekly_kdj_k': '周线K值',
        'weekly_kdj_d': '周线D值',
        'weekly_avg_line': '平均线值',
        'weekly_wave': '波动线',
        'weekly_dif_z': 'DIF Z值',
        'weekly_core_trend': '核心趋势',
        'weekly_vol_oscillation': '量能摆动',
        'weekly_atr14': '周线ATR',
        'weekly_winner_pct': 'WINNER%',
        'weekly_cost_concentration': '筹码集中度',
        'weekly_cost_mid': '筹码中位价',
        'weekly_relative_position': '相对价位',
        'weekly_individual_trend': '个股趋势',
        'weekly_retail_momentum': '散户动能',
    }
    w = {}
    for fk, days in corr.items():
        rhos = [abs(v['rho']) for v in days.values()]
        if not rhos:
            continue
        avg = sum(rhos) / len(rhos)
        sig = sum(1 for v in days.values() if v['sig'])
        weight = max(1.0, round(avg * 100, 1))
        w[fk] = {'weight': weight, 'avg_rho': round(avg, 3), 'sig_days': sig,
                 'name': names.get(fk, fk)}
    total = sum(v['weight'] for v in w.values())
    if total > 0:
        for k in w:
            w[k]['weight'] = round(w[k]['weight'] / total * 100, 1)
    json.dump(w, open(WEIGHT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return w


def run():
    from astock_bridge import tencent_quote
    from formula_factors import calc_weekly_formula_factors

    print('=' * 50)
    print('周线手选因子反推引擎（周线框架）')
    print('=' * 50)

    try:
        content = open(r'D:/TDX/T0002/blocknew/ZXSX.blk', encoding='gbk').read()
        codes_7 = [l.strip() for l in content.splitlines() if l.strip()]
    except Exception as e:
        print(f'[ERROR] ZXSX.blk: {e}')
        return

    pure = [normalize(c) for c in codes_7]
    if not pure:
        print('[WARN] 板块为空')
        return

    print(f'当前周线手选: {len(pure)} 只')
    market_data = tencent_quote(pure)

    t0 = time.time()
    weekly_factors = calc_weekly_formula_factors(codes_7)
    print(f'周线公式因子计算: {time.time()-t0:.1f}s')

    today = datetime.now().strftime('%Y%m%d')
    new = record_snapshot(codes_7, weekly_factors, market_data, today)

    results = track_results(pure, [7, 14, 21, 30, 60])
    corr = compute_correlation(results)
    weights = recommend_weights(corr)

    # 报告
    lines = []
    lines.append(f'# 周线手选因子反推报告 {today}')
    lines.append('')
    data = load_snapshots()
    lines.append(f'## 快照统计')
    lines.append(f'累计: {len(data["entries"])} | 收益: {len(results)} | 新增: {new}')
    lines.append('')
    lines.append('## 因子相关性（周线框架）')
    lines.append('')

    if corr:
        lines.append('| 因子 | 7d | 14d | 21d | 30d | 60d | 显著 |')
        lines.append('|------|----|-----|-----|-----|-----|------|')
        for fk, days in sorted(corr.items(),
                               key=lambda x: max(abs(v['rho']) for v in x[1].values()),
                               reverse=True):
            info = days.get('day7', {})
            d14 = days.get('day14', {})
            d21 = days.get('day21', {})
            d30 = days.get('day30', {})
            d60 = days.get('day60', {})
            sig = sum(1 for v in days.values() if v['sig'])
            r7 = f'{info.get("rho",0):+.3f}' if 'rho' in info else '-'
            r14 = f'{d14.get("rho",0):+.3f}' if 'rho' in d14 else '-'
            r21 = f'{d21.get("rho",0):+.3f}' if 'rho' in d21 else '-'
            r30 = f'{d30.get("rho",0):+.3f}' if 'rho' in d30 else '-'
            r60 = f'{d60.get("rho",0):+.3f}' if 'rho' in d60 else '-'
            lines.append(f'| {fk} | {r7} | {r14} | {r21} | {r30} | {r60} | {sig} |')
    else:
        lines.append('数据不足（需≥5个有效样本）')

    lines.append('')
    lines.append('## 推荐权重（周线因子）')
    lines.append('')
    if weights:
        for fk, wv in sorted(weights.items(), key=lambda x: -x[1]['weight']):
            lines.append(f'- **{wv["name"]}**({fk}): {wv["weight"]:.1f}% rho={wv["avg_rho"]:+.3f}')
    else:
        lines.append('数据不足')

    report = '\n'.join(lines)
    print(report)

    # 推TG
    try:
        import urllib.request
        TOKEN = get_telegram_token()
        CHAT_ID = '8673372605'
        handler = urllib.request.ProxyHandler({'http': 'http://127.0.0.1:7890',
                                               'https': 'http://127.0.0.1:7890'})
        opener = urllib.request.build_opener(handler)
        opener.timeout = 60
        url = f'https://api.telegram.org/bot{TOKEN}/sendMessage'
        data_tg = json.dumps({'chat_id': CHAT_ID, 'text': report,
                              'parse_mode': 'Markdown', 'disable_web_page_preview': True}).encode('utf-8')
        req = urllib.request.Request(url, data=data_tg, headers={'Content-Type': 'application/json'})
        resp = opener.open(req)
        result = json.loads(resp.read())
        print(f'[TG] {"ok" if result.get("ok") else result}')
    except Exception as e:
        print(f'[TG] 失败: {e}')


if __name__ == '__main__':
    run()
