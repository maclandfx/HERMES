import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_tushare_token
"""
combo_formula_test.py — 组合公式全市场回测验证
用Spearman相关性最强的因子做组合选股，验证组合预测力
"""
import sys, os, json, time, math, traceback, shutil
sys.path.insert(0, r'D:/Hermes/评估中心/tools')
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from factor_utils import spearmanr_np, normalize
from formula_factors import calc_weekly_formula_factors, calc_daily_formula_factors
from self_driving_backtest import get_a_share_sample, push_tg

DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)

def run():
    log = lambda m: (print(f'[{datetime.now().strftime("%H:%M:%S")}] {m}', flush=True) or open(LOG_FILE,'a',encoding='utf-8').write(f'[{datetime.now().strftime("%H:%M:%S")}] {m}\n'))
    global LOG_FILE
    LOG_FILE = os.path.join(DATA_DIR, 'combo_test_log.txt')
    open(LOG_FILE,'w',encoding='utf-8').close()
    
    log('='*60)
    log('组合公式全市场回测验证')
    log(f'时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    log('='*60)
    
    # Phase 1: 获取样本+因子
    log('获取样本...')
    codes = get_a_share_sample(max_codes=200)
    if not codes:
        log('[FAIL]')
        return
    log(f'样本: {len(codes)} 只')
    
    log('周线因子计算...')
    t0 = time.time()
    wf = calc_weekly_formula_factors(codes)
    log(f'  {time.time()-t0:.0f}s, 有效:{sum(1 for f in wf.values() if "_error" not in f)}/{len(codes)}')
    
    log('日线因子计算...')
    t0 = time.time()
    df = calc_daily_formula_factors(codes)
    log(f'  {time.time()-t0:.0f}s, 有效:{sum(1 for f in df.values() if "_error" not in f)}/{len(codes)}')
    
    # Phase 2: 拉历史日K
    log('拉历史日K...')
    pro = __import__('tushare').pro_api(get_tushare_token())
    end = datetime.now().strftime('%Y%m%d')
    start = (datetime.now()-timedelta(days=180)).strftime('%Y%m%d')
    hist = {}
    for c7 in codes:
        c = normalize(c7)
        if not c or len(c)!=6: continue
        try:
            tsc = c+'.SH' if c[0] in '69' else c+'.SZ'
            d = pro.daily(ts_code=tsc, start_date=start, end_date=end)
            if d is not None and not d.empty and len(d)>=30:
                d = d.sort_values('trade_date').reset_index(drop=True)
                d['close'] = pd.to_numeric(d['close'],errors='coerce')
                hist[c] = d
        except: pass
    log(f'日K有效: {len(hist)} 只')
    
    # Phase 3: 构建组合条件，回测历史窗口
    log('\n构建组合选股，历史回测...')
    
    # 定义组合规则
    # 规则1: 周线MACD金叉 + RPS_50>50 + 主力四量占比>0.55
    # 规则2: 日线RPS_120>55 + DCZ不上行(daily_dcz_up=0)
    
    rules = {
        'R1_macd_rps_四量': lambda code, wf_d, df_d: (
            wf_d.get('weekly_macd_golden',0)==1 and
            wf_d.get('weekly_rps_50',0)>50 and
            wf_d.get('weekly_four_vol_main_ratio',0)>0.55
        ),
        'R2_rps120_dcz避': lambda code, wf_d, df_d: (
            df_d.get('daily_rps_120',0)>55 and
            df_d.get('daily_dcz_up',0)==0
        ),
        'R3_macd_rps_dcz': lambda code, wf_d, df_d: (
            wf_d.get('weekly_macd_golden',0)==1 and
            wf_d.get('weekly_rps_50',0)>50 and
            df_d.get('daily_dcz_up',0)==0
        ),
        'R4_四量_rps_macd': lambda code, wf_d, df_d: (
            wf_d.get('weekly_four_vol_main_ratio',0)>0.60 and
            wf_d.get('weekly_rps_50',0)>55 and
            wf_d.get('weekly_macd_dif_above_dea',0)==1
        ),
        'R5_纯macd_rps': lambda code, wf_d, df_d: (
            wf_d.get('weekly_macd_golden',0)==1 and
            wf_d.get('weekly_rps_50',0)>50
        ),
    }
    
    N = len(hist) if hist else 0
    max_f = 30
    
    # 构建历史窗口回测数据
    # 每个历史日，用当时的因子筛选组合，追踪未来收益
    
    all_results = {}
    
    for rule_name, rule_fn in rules.items():
        log(f'\n规则 {rule_name}:')
        
        # 简单版：用当前因子值+历史价格窗口回测
        # 每个股票每个历史日产生一个 (selected, return) 样本
        
        selected_returns = {d: [] for d in range(1, max_f+1)}
        unselected_returns = {d: [] for d in range(1, max_f+1)}
        selected_count = 0
        unselected_count = 0
        
        for c7 in codes:
            c = normalize(c7)
            if c not in wf or c not in df or c not in hist:
                continue
            wf_d = wf[c]
            df_d = df[c]
            if '_error' in wf_d or '_error' in df_d:
                continue
            closes = hist[c]['close'].values
            n_c = len(closes)
            
            if rule_fn(c, wf_d, df_d):
                selected_count += 1
                for w in range(n_c - max_f):
                    for d in range(1, max_f+1):
                        base = closes[w]
                        fut = closes[w+d]
                        if base>0 and fut>0:
                            ret = (fut/base-1)*100
                            selected_returns[d].append(ret)
            else:
                unselected_count += 1
                for w in range(n_c - max_f):
                    for d in range(1, max_f+1):
                        base = closes[w]
                        fut = closes[w+d]
                        if base>0 and fut>0:
                            ret = (fut/base-1)*100
                            unselected_returns[d].append(ret)
        
        all_results[rule_name] = {
            'selected_n': selected_count,
            'unselected_n': unselected_count,
            'selected_pct': round(selected_count/max(1,(selected_count+unselected_count))*100,1),
            'returns': {}
        }
        log(f'  选出:{selected_count}只 ({all_results[rule_name]["selected_pct"]}%) | 未选:{unselected_count}只')
        
        for d in range(1, max_f+1):
            sr = selected_returns[d]
            ur = unselected_returns[d]
            if len(sr) < 50 or len(ur) < 50:
                continue
            # 胜率（正收益比例）
            win_s = sum(1 for r in sr if r>0)/len(sr)*100
            win_u = sum(1 for r in ur if r>0)/len(ur)*100
            # 平均收益
            avg_s = np.mean(sr)
            avg_u = np.mean(ur)
            # 超额收益
            excess = avg_s - avg_u
            all_results[rule_name]['returns'][d] = {
                'win_rate_s': round(win_s,1),
                'win_rate_u': round(win_u,1),
                'avg_s': round(float(avg_s),2),
                'avg_u': round(float(avg_u),2),
                'excess': round(float(excess),2),
            }
        
        # 打印前5日
        for d in [1,3,5,10,20,30]:
            if d in all_results[rule_name]['returns']:
                r = all_results[rule_name]['returns'][d]
                log(f'  day{d}: 选中胜率={r["win_rate_s"]}% vs 未选={r["win_rate_u"]}% | 超额={r["excess"]:+.2f}%')
    
    # 保存结果
    today = datetime.now().strftime('%Y%m%d')
    out = os.path.join(DATA_DIR, f'combo_results_{today}.json')
    json.dump(all_results, open(out,'w',encoding='utf-8'), ensure_ascii=False, indent=2)
    
    # 报告
    lines = []
    lines.append(f'# 组合公式回测验证 {today}')
    lines.append('')
    lines.append(f'样本: {len(codes)}只 | 日K有效: {len(hist)}只 | 回测窗口: {max_f}日')
    lines.append('')
    
    # 排序：按30日超额收益
    ranked = sorted(all_results.items(), key=lambda x: x[1]['returns'].get(30,{}).get('excess',-999), reverse=True)
    
    lines.append('## 组合排名（按30日超额收益）')
    lines.append('')
    for rank, (name, data) in enumerate(ranked, 1):
        r30 = data['returns'].get(30, {})
        r10 = data['returns'].get(10, {})
        r5 = data['returns'].get(5, {})
        lines.append(f'#{rank} {name}')
        lines.append(f'  选出率: {data["selected_pct"]}% | 30日超额: {r30.get("excess","+0.00")}% | 10日: {r10.get("excess","+0.00")}% | 5日: {r5.get("excess","+0.00")}%')
        lines.append(f'  30日胜率: {r30.get("win_rate_s","-")}%(选中) vs {r30.get("win_rate_u","-")}%(未选)')
    
    report = '\n'.join(lines)
    log('\n'+report)
    log(f'\n报告: {out}')
    log('推送TG...')
    push_tg(report)
    log('完成')

if __name__ == '__main__':
    run()
