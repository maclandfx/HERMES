"""Diagnose F8 on real backtest data using existing factor cache.
Reads from compute_weekly_factors output directly."""
import pandas as pd, numpy as np, sys, os, glob, struct, time, math
from collections import Counter

# Import module functions without running main
import importlib.util

def load_module():
    spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
    mod = importlib.util.module_from_spec(spec)
    # Run up to compute_weekly_factors definition only
    src = open('weekly_formula_backtest.py').read()
    # Find where main guard starts
    main_idx = src.find("if __name__")
    head = src[:main_idx]
    exec(compile(head, 'weekly_formula_backtest.py', 'exec'), mod.__dict__)
    return mod

wf = load_module()

# Load a few stocks manually to compute factors
def load_1d(fp):
    with open(fp,'rb') as f: d=f.read()
    n=len(d)//32
    data=np.frombuffer(d,dtype=np.float32).reshape(n,8)
    df=pd.DataFrame(data[:,:7],columns=['open','high','low','close','vol','amount','fl'])
    df=df.iloc[:-1]; df=df[df['close']>0]
    df=df.set_index(pd.to_datetime(df['fl'].astype(np.int64)))
    return df[['open','high','low','close','vol','amount']].sort_index()

weekly={}
for m in ('sh','sz','bj'):
    pats=glob.glob(os.path.join('D:/TDX/vipdoc',m,'lday','*.day'))
    for fp in sorted(pats):
        code=os.path.basename(fp).replace('.day','')
        # Skip index codes
        c_upper=code.upper()
        if c_upper.startswith(('SH','SZ')) and c_upper[2:8] in ('000001','000300','399001','399006','399106','399107','399300','000016','000688','399005','399673','399675'):
            continue
        try: df=load_1d(fp)
        except: continue
        if df.empty or len(df)<10: continue
        W=df.resample('W').agg({'open':'first','high':'max','low':'min','close':'last','vol':'sum','amount':'sum'})
        W=W.dropna(subset=['close'])
        if len(W)<10: continue
        weekly[code]=W
        if len(weekly)>=200: break
    if len(weekly)>=200: break

print(f'Loaded {len(weekly)} real stocks')

# Compute factors using actual function (skips RPS by passing subset)
# We'll compute F8 conditions inline from the factor computation
bottleneck=Counter()
for code,W in weekly.items():
    C=W['close']; H=W['high']; L=W['low']; O=W['open']; V=W['vol']; AM=W['amount']
    try:
        # Replicate factors from compute_weekly_factors
        R0=(C-C.shift(1))/C.shift(1)
        avg_line=V.ewm(span=3,adjust=False).mean()
        main_in=(R0>0)&(avg_line>avg_line.shift(1))
        f_8={'main_in':main_in}

        # DCZ
        mid=(C+O+((H-L)/4))/2
        DCZ=mid.ewm(span=20,adjust=False).mean()
        f_8['DCZ']=DCZ

        # vol_burst (board-dependent)
        vol_ma5=V.rolling(5).mean()
        if code.startswith('30'): thr=1.8
        elif code.startswith('68'): thr=2.2
        elif code.startswith(('43','83','92')): thr=2.5
        else: thr=2.0
        vol_burst=(V>vol_ma5*thr)
        f_8['vol_burst']=vol_burst

        # MACD
        EMA12=C.ewm(span=12,adjust=False).mean(); EMA26=C.ewm(span=26,adjust=False).mean()
        DIF=(EMA12-EMA26); DEA=DIF.ewm(span=9,adjust=False).mean()
        gc=(DIF>DEA)&(DIF.shift(1)<=DEA.shift(1))
        above_zero=(DEA>0)
        f_8['macd_strong']=gc&above_zero
        f_8['macd_mid']=gc|above_zero

        # trend
        ma20=C.rolling(20).mean()
        f_8['trend_healthy']=(ma20>ma20.shift(5))
        f_8['trend_hold']=(C>ma20*0.95)

        # pressure
        h30=H.rolling(30).max()
        f_8['p75']=(C<h30*0.75)
        f_8['p80']=(C<h30*0.80)

        # risk_ctrl (from actual code: cumsum>52 & V>0)
        cc=C.notna().cumsum()
        f_8['risk_ctrl']=(cc>52)&(V>0)

        # anti_dump (v4_safe_vol)
        v4_dump=((V/AM.fillna(1).replace(0,1)>3)&(C<C.shift(1))).astype(int)
        f_8['safe_vol']=(v4_dump==0)

        # profit_safe (winner_pct<70)
        f_8['profit_safe']=True

        # chip_conc (chip_spread<35) - placeholder always true
        f_8['chip_conc']=True

        # Signal combos
        base_all = f_8['main_in'] & f_8['vol_burst'] & f_8['safe_vol'] & f_8['risk_ctrl'] & f_8['profit_safe'] & f_8['chip_conc']
        strong = base_all & f_8['macd_strong'] & f_8['trend_healthy'] & f_8['p75']
        steady = base_all & f_8['macd_mid'] & f_8['trend_hold'] & f_8['p80']
        f8 = strong | steady

        N=len(f_8['main_in'])
        bottleneck['weeks']+=N
        for k in f_8:
            if k in ['main_in','vol_burst','macd_strong','macd_mid','trend_healthy','trend_hold','p75','p80','risk_ctrl','safe_vol','chip_conc','profit_safe']:
                bottleneck[k]+=int(f_8[k].sum())
        bottleneck['base_all']+=int(base_all.sum())
        bottleneck['strong']+=int(strong.sum())
        bottleneck['steady']+=int(steady.sum())
        bottleneck['f8']+=int(f8.sum())
    except Exception as e:
        pass

N=bottleneck['weeks']
print(f'\nBottleneck ({len(weekly)} stocks, {N} total weeks):')
print(f'{"factor":<18}{"count":>8}{"%":>8}')
for k in ['main_in','vol_burst','safe_vol','risk_ctrl','chip_conc','profit_safe','base_all',
          'macd_strong','macd_mid','trend_healthy','trend_hold','p75','p80','strong','steady','f8']:
    print(f'{k:<18}{bottleneck[k]:>8}{100*bottleneck[k]/N:>7.1f}%')
