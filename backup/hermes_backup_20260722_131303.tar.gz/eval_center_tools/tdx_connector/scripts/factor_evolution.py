import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_tushare_token
"""
factor_evolution.py — 因子引擎自审计 + 进化机制
================================================
功能：
1. 自我审计：定期验证因子计算正确性（回测对照）
2. 自我进化：基于历史回测数据自动调整因子权重
3. 自动发现：扫描全市场，找出新的有效因子组合
4. 自我测试：用历史数据验证因子有效性

进化流程（凌晨自动运行）：
1. 取全市场A股样本（约5000只）
2. 计算所有因子
3. 回测未来1/3/5/10/20日收益
4. 计算各因子 Spearman 相关性
5. 对比当前权重，更新权重
6. 标记新发现的有效因子
"""
import sys, os, json, time, math
sys.path.insert(0, r'D:/Hermes/评估中心/tools')
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from itertools import combinations

from factor_utils import spearmanr_np, normalize


DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)


def get_market_sample(date=None, max_codes=500):
    """
    获取全市场A股样本（限制数量以节省算力）
    返回股票代码列表（6位纯数字）
    """
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        if date is None:
            date = datetime.now().strftime('%Y%m%d')
        # 取所有A股列表
        df = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name')
        if df is None or df.empty:
            return []
        # 过滤：只取沪市深市，排除北交所
        df = df[~df['ts_code'].str.contains('BJ')]
        df = df[~df['ts_code'].str.startswith(('688', '300', '83', '87', '88'))]  # 留少量创业板
        codes = df['symbol'].tolist()[:max_codes]
        return codes
    except:
        return []


def backtest_factor(factor_name, factor_data_dict, codes, backtest_days=5):
    """
    回测单个因子的预测力
    factor_data_dict: {code: factor_value}
    返回: (rho, pval, n, samples)
    """
    returns = []
    factors = []
    
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        
        for code in codes:
            if code not in factor_data_dict:
                continue
            fval = factor_data_dict[code]
            if fval is None or not isinstance(fval, (int, float, np.floating)):
                continue
            
            # 获取未来收益
            ts_code = code + '.SH' if code[0] in '69' else code + '.SZ'
            today = datetime.now().strftime('%Y%m%d')
            future = (datetime.now() + timedelta(days=backtest_days)).strftime('%Y%m%d')
            try:
                df = pro.daily(ts_code=ts_code, start_date=today, end_date=future)
                if df is None or df.empty or len(df) < 2:
                    continue
                df = df.sort_values('trade_date')
                ret = (df.iloc[-1]['close'] / df.iloc[0]['close'] - 1) * 100
            except:
                continue
            
            returns.append(ret)
            factors.append(fval)
    except:
        pass
    
    if len(returns) < 5:
        return (None, None, len(returns), [])
    
    rho, pval = spearmanr_np(factors, returns)
    return (rho, pval, len(returns), list(zip(codes[:len(returns)], returns[:len(returns)])))


def audit_factor_accuracy(factor_name, sample_codes, ground_truth=None):
    """
    因子准确性审计
    验证因子计算是否与预期一致
    """
    # 简单验证：检查因子值是否在合理范围内
    audit_result = {'factor': factor_name, 'issues': []}
    
    try:
        if 'weekly_' in factor_name or 'daily_' in factor_name:
            # 从快照中读取样本数据
            snapshot_files = [
                os.path.join(DATA_DIR, 'zxsx_snapshots.json'),
                os.path.join(DATA_DIR, 'pz_yj_snapshots.json'),
            ]
            all_vals = []
            for sf in snapshot_files:
                if os.path.exists(sf):
                    data = json.load(open(sf, encoding='utf-8'))
                    for entry in data.get('entries', []):
                        fval = entry.get('factors', {}).get(factor_name)
                        if fval is not None:
                            all_vals.append(fval)
            
            if len(all_vals) < 5:
                audit_result['issues'].append(f'样本不足({len(all_vals)})')
                return audit_result
            
            vals = np.array(all_vals, dtype=float)
            audit_result['count'] = len(vals)
            audit_result['mean'] = round(float(vals.mean()), 4)
            audit_result['std'] = round(float(vals.std()), 4)
            audit_result['min'] = round(float(vals.min()), 4)
            audit_result['max'] = round(float(vals.max()), 4)
            
            # 检查异常值
            if np.any(np.isnan(vals)):
                audit_result['issues'].append('存在NaN值')
            if np.any(np.isinf(vals)):
                audit_result['issues'].append('存在Inf值')
            
            # 对二值因子检查是否只有0/1
            if '1 if' in factor_name or factor_name.endswith('_bull') or factor_name.endswith('_signal') or factor_name.endswith('_safe') or factor_name.endswith('_above') or factor_name.endswith('_red') or factor_name.endswith('_golden') or factor_name.endswith('_cross') or factor_name.endswith('_attack') or factor_name.endswith('_main_in'):
                unique = np.unique(vals)
                if not np.all(np.isin(unique, [0, 1])):
                    audit_result['issues'].append(f'二值因子出现非0/1值: {unique}')
        
    except Exception as e:
        audit_result['issues'].append(f'审计异常: {str(e)[:100]}')
    
    return audit_result


def run_full_audit():
    """
    运行全因子审计
    """
    print('=' * 50)
    print('因子引擎自审计')
    print('=' * 50)
    
    # 收集所有因子名
    snapshot_files = [
        os.path.join(DATA_DIR, 'zxsx_snapshots.json'),
        os.path.join(DATA_DIR, 'pz_yj_snapshots.json'),
    ]
    
    all_factors = set()
    for sf in snapshot_files:
        if os.path.exists(sf):
            data = json.load(open(sf, encoding='utf-8'))
            for entry in data.get('entries', []):
                all_factors.update(entry.get('factors', {}).keys())
    
    print(f'\n总因子数: {len(all_factors)}')
    
    # 审计每个因子
    audit_results = {}
    for fname in sorted(all_factors):
        if fname == '_error':
            continue
        result = audit_factor_accuracy(fname, [])
        audit_results[fname] = result
    
    # 汇总问题
    issues = [(fname, res) for fname, res in audit_results.items() if res['issues']]
    
    print(f'\n审计问题: {len(issues)}个')
    for fname, res in issues[:10]:
        print(f'  {fname}: {res["issues"]}')
    
    # 保存审计结果
    audit_path = os.path.join(DATA_DIR, 'audit_results.json')
    json.dump(audit_results, open(audit_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f'\n审计结果已保存: {audit_path}')
    
    return audit_results


def run_self_evolution():
    """
    自进化：基于历史回测数据自动更新因子权重
    """
    print('=' * 50)
    print('因子引擎自进化')
    print('=' * 50)
    
    # 读取当前权重
    weight_files = [
        os.path.join(DATA_DIR, 'zxsx_weights.json'),
        os.path.join(DATA_DIR, 'pz_yj_weights.json'),
    ]
    
    current_weights = {}
    for wf in weight_files:
        if os.path.exists(wf):
            w = json.load(open(wf, encoding='utf-8'))
            current_weights.update(w)
    
    print(f'当前权重因子数: {len(current_weights)}')
    
    # 获取回测相关性数据
    corr_files = [
        os.path.join(DATA_DIR, 'zxsx_factor_corr.json'),
        os.path.join(DATA_DIR, 'pz_yj_factor_corr.json'),
    ]
    
    combined_corr = {}
    for cf in corr_files:
        if os.path.exists(cf):
            corr = json.load(open(cf, encoding='utf-8'))
            combined_corr.update(corr)
    
    print(f'回测相关性因子数: {len(combined_corr)}')
    
    # 计算建议权重
    new_weights = {}
    for fk, days in combined_corr.items():
        rhos = [abs(v['rho']) for v in days.values() if v.get('rho')]
        if not rhos:
            continue
        avg_rho = sum(rhos) / len(rhos)
        sig = sum(1 for v in days.values() if v.get('sig'))
        
        # 新权重 = 平均|rho| * 100
        new_w = max(1.0, round(avg_rho * 100, 1))
        
        # 如果当前权重存在，混合新旧（70%新 + 30%旧）
        if fk in current_weights:
            old_w = current_weights[fk].get('weight', 0)
            new_w = round(new_w * 0.7 + old_w * 0.3, 1)
        
        new_weights[fk] = {
            'weight': new_w,
            'avg_rho': round(avg_rho, 3),
            'sig_days': sig,
            'evolved': True,
        }
    
    # 归一化
    total = sum(v['weight'] for v in new_weights.values())
    if total > 0:
        for k in new_weights:
            new_weights[k]['weight'] = round(new_weights[k]['weight'] / total * 100, 1)
    
    # 保存进化结果
    evolved_path = os.path.join(DATA_DIR, 'evolved_weights.json')
    json.dump(new_weights, open(evolved_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f'进化权重已保存: {evolved_path}')
    print(f'进化因子数: {len(new_weights)}')
    
    # 输出变化最大的因子
    changes = []
    for fk, nw in new_weights.items():
        if fk in current_weights:
            old_w = current_weights[fk].get('weight', 0)
            delta = nw['weight'] - old_w
            if abs(delta) > 1:
                changes.append((fk, old_w, nw['weight'], delta))
    
    changes.sort(key=lambda x: abs(x[3]), reverse=True)
    print(f'\n权重变化最大的10个因子:')
    for fk, old, new, delta in changes[:10]:
        print(f'  {fk}: {old} → {new} (delta={delta:+.1f})')
    
    return new_weights


if __name__ == '__main__':
    audit_results = run_full_audit()
    print()
    evolved = run_self_evolution()
