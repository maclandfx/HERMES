"""
tdx_local_reader.py — 通达信本地K线读取器（直接读vipdoc/lday/*.day）

用法:
    from tdx_local_reader import TdxLocalReader
    reader = TdxLocalReader('D:/TDX/vipdoc')
    df = reader.get_daily('600007')  # 返回DataFrame: date, open, high, low, close, volume, amount
    df = reader.get_weekly('600007')  # 周K（从日K合成）
    codes = reader.list_codes()      # 所有可用股票列表

记录格式: 32字节 LE
  date(4) | open(4) | high(4) | low(4) | close(4) | volume(4) | amount(4) | extra(4)
  价格需÷100, date为YYYYMMDD
"""

import struct
import os
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

# ── 全局缓存 ──
_DAY_CACHE = {}       # code -> list of records
_WEEKLY_CACHE = {}    # code -> DataFrame


def _parse_day_file(path: str) -> list:
    """解析单个.day文件，返回 [(date, o, h, l, c, v, a), ...]"""
    if path in _DAY_CACHE:
        return _DAY_CACHE[path]
    
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except Exception:
        return []
    
    records = []
    for i in range(0, len(data) - 31, 32):
        chunk = data[i:i+32]
        dt = struct.unpack('<I', chunk[0:4])[0]
        if not (20000000 < dt < 20300000):
            continue
        o = struct.unpack('<I', chunk[4:8])[0] / 100.0
        h = struct.unpack('<I', chunk[8:12])[0] / 100.0
        l = struct.unpack('<I', chunk[12:16])[0] / 100.0
        c = struct.unpack('<I', chunk[16:20])[0] / 100.0
        v = struct.unpack('<I', chunk[20:24])[0]
        a = struct.unpack('<I', chunk[24:28])[0]
        records.append((dt, o, h, l, c, v, a))
    
    if records:
        _DAY_CACHE[path] = records
    
    return records


def _code_to_path(vipdoc: str, code: str, exchange: str) -> str:
    """code(6位) + exchange(sh/sz) -> .day文件路径"""
    sub = os.path.join(vipdoc, exchange, 'lday')
    return os.path.join(sub, f'{exchange}{code}.day')


def _normalize_code(code: str) -> str:
    """7位代码（首位1=沪/0=深）→ 6位纯代码"""
    code = str(code).strip()
    if len(code) == 7:
        code = code[1:]
    return code.zfill(6)


class TdxLocalReader:
    """通达信本地K线读取器"""
    
    def __init__(self, vipdoc: str = 'D:/TDX/vipdoc'):
        self.vipdoc = vipdoc.replace('/', '\\').replace('\\', '/')
        self._cached_codes = None
    
    def get_daily(self, code: str) -> pd.DataFrame:
        """获取日K数据"""
        code = _normalize_code(code)
        exchange = 'sh' if code[0] in '69' else 'sz'
        path = _code_to_path(self.vipdoc, code, exchange)
        records = _parse_day_file(path)
        if not records:
            return pd.DataFrame()
        
        df = pd.DataFrame(records, columns=['date', 'open', 'high', 'low', 'close', 'volume', 'amount'])
        df['date'] = pd.to_datetime(df['date'].astype(str))
        df = df.sort_values('date').reset_index(drop=True)
        df['code'] = code
        return df
    
    def get_daily_close(self, code: str) -> np.ndarray:
        """快速获取收盘价数组（numpy）"""
        df = self.get_daily(code)
        if df.empty:
            return np.array([])
        return df['close'].values
    
    def get_daily_array(self, code: str) -> dict:
        """获取OHLCV数组（dict）"""
        df = self.get_daily(code)
        if df.empty:
            return {}
        return {
            'open': df['open'].values,
            'high': df['high'].values,
            'low': df['low'].values,
            'close': df['close'].values,
            'volume': df['volume'].values,
            'amount': df['amount'].values,
            'dates': df['date'].values,
        }
    
    def get_weekly(self, code: str) -> pd.DataFrame:
        """从日K合成周K（周五收盘价）"""
        if code in _WEEKLY_CACHE:
            return _WEEKLY_CACHE[code]
        
        df = self.get_daily(code)
        if df.empty or len(df) < 5:
            return pd.DataFrame()
        
        df = df.copy()
        df['week'] = df['date'].dt.isocalendar().week.astype(int)
        df['year'] = df['date'].dt.year
        
        # 周线 = 每周周一开盘、周最高、周最低、周五收盘
        weekly = []
        for (year, week), grp in df.groupby(['year', 'week']):
            if len(grp) < 1:
                continue
            rec = {
                'date': grp['date'].iloc[-1],
                'open': grp['open'].iloc[0],
                'high': grp['high'].max(),
                'low': grp['low'].min(),
                'close': grp['close'].iloc[-1],
                'volume': grp['volume'].sum(),
                'amount': grp['amount'].sum(),
            }
            weekly.append(rec)
        
        wdf = pd.DataFrame(weekly).sort_values('date').reset_index(drop=True)
        _WEEKLY_CACHE[code] = wdf
        return wdf
    
    def list_codes(self) -> list:
        """列出所有可用股票代码（6位）"""
        if self._cached_codes is not None:
            return self._cached_codes
        
        codes = set()
        for exchange in ['sh', 'sz']:
            dpath = os.path.join(self.vipdoc, exchange, 'lday')
            if not os.path.isdir(dpath):
                continue
            for fname in os.listdir(dpath):
                if not fname.endswith('.day'):
                    continue
                fcode = fname.replace(f'{exchange}', '').replace('.day', '')
                if len(fcode) == 6 and fcode.isdigit():
                    codes.add(fcode)
        
        self._cached_codes = sorted(codes)
        return self._cached_codes
    
    def list_codes_prefix(self, prefix: str) -> list:
        """按前缀筛选（如 '60' 找所有沪市主板）"""
        return [c for c in self.list_codes() if c.startswith(prefix)]
    
    def get_batch_daily(self, codes: list, max_days: int = 180) -> dict:
        """批量获取日K（最近N天），返回 {code: {open,high,low,close,volume,amount,dates}}"""
        result = {}
        for c in codes:
            df = self.get_daily(c)
            if df.empty:
                continue
            if len(df) > max_days:
                df = df.tail(max_days)
            result[_normalize_code(c)] = {
                'open': df['open'].values,
                'high': df['high'].values,
                'low': df['low'].values,
                'close': df['close'].values,
                'volume': df['volume'].values,
                'amount': df['amount'].values,
                'dates': df['date'].values,
            }
        return result
    
    def get_batch_close(self, codes: list) -> dict:
        """批量获取收盘价数组"""
        return {c: self.get_daily_close(c) for c in codes}


# ── 扩展指标读取器 ──
def read_extdata_header(info_path: str = 'D:/TDX/T0002/extdata/extdata.info'):
    """读取扩展指标信息头"""
    with open(info_path, 'rb') as f:
        data = f.read()
    # 提取指标名称（GBK编码字符串）
    names = []
    i = 0
    while i < len(data) - 10:
        # 查找 ASCII 字符串
        j = i
        while j < len(data) and 32 <= data[j] <= 126:
            j += 1
        if j - i >= 4:
            names.append(data[i:j].decode('ascii', errors='ignore'))
        i = j + 1
    return names


def read_extdata_block(dat_path: str, idx_path: str):
    """读取扩展指标数据块"""
    with open(idx_path, 'rb') as f:
        idx_data = f.read()
    with open(dat_path, 'rb') as f:
        dat_data = f.read()
    # 解析索引找到股票代码 → 数据偏移
    codes = {}
    for i in range(0, len(idx_data), 12):
        if i + 12 > len(idx_data):
            break
        c6 = idx_data[i:i+6].decode('ascii', errors='ignore')
        if len(c6) == 6 and c6.isdigit():
            offset = struct.unpack('<I', idx_data[i+6:i+10])[0]
            codes[c6] = offset
    return codes, dat_data


# ── 测试 ──
if __name__ == '__main__':
    reader = TdxLocalReader('D:/TDX/vipdoc')
    
    print('=== 代码列表 ===')
    codes = reader.list_codes()
    print(f'总数: {len(codes)}')
    print(f'前10: {codes[:10]}')
    print(f'沪市60: {reader.list_codes_prefix("60")[:5]}')
    print(f'深市00: {reader.list_codes_prefix("00")[:5]}')
    
    print('\n=== 单只日K (600007) ===')
    df = reader.get_daily('600007')
    print(f'记录数: {len(df)}')
    print(f'首条: {df.iloc[0].to_dict()}')
    print(f'末条: {df.iloc[-1].to_dict()}')
    
    print('\n=== 周K (600007) ===')
    wf = reader.get_weekly('600007')
    print(f'周线记录数: {len(wf)}')
    print(f'末条: {wf.iloc[-1].to_dict()}')
    
    print('\n=== 批量 (前5只) ===')
    batch = reader.get_batch_daily(codes[:5], max_days=30)
    for c, arr in batch.items():
        print(f'{c}: close={arr["close"][-1]:.2f}, 高={arr["high"][-1]:.2f}, 低={arr["low"][-1]:.2f}')
