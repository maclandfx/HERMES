"""诊断F2基准收益异常 - 只检查F2 trades的基准计算"""
import os, struct, glob, pandas as pd, numpy as np
TDX_BASE='D:/TDX/vipdoc'; DIV={'sh':1000,'sz':10,'bj':100}
LIMIT=0.10; COST_RATE=0.00232
def parse(path):
    try:
        with open(path,'rb') as f: raw=f.read()
    except: return pd.DataFrame()
    if len(raw)%32!=0: return pd.DataFrame()
    fn=os.path.basename(path)
    if fn.startswith('sh'): m='sh'
    elif fn.startswith('sz'): m='sz'
    else: return pd.DataFrame()
    d=DIV[m]; rows=[]
    for i in range(len(raw)//32):
        c=raw[i*32:(i+1)*32]
        di=struct.unpack('<I',c[0:4])[0]
        try: ts=pd.Timestamp(di//10000,(di//100)%100,di%100)
        except: continue
        o=struct.unpack('<I',c[4:8])[0]/d; cl=struct.unpack('<I',c[8:12])[0]/d
        h=struct.unpack('<I',c[12:16])[0]/d; lo=struct.unpack('<I',c[16:20])[0]/d
        v=struct.unpack('<Q',c[20:28])[0]
        rows.append((ts,o,h,lo,cl,v))
    if not rows: return pd.DataFrame()
    return pd.DataFrame(rows,columns=['date','open','high','low','close','vol']).sort_values('date').set_index('date')

# load all stocks
daily={}; cnt=0
for fp in sorted(glob.glob(os.path.join(TDX_BASE,'sh','lday','*.day'))+glob.glob(os.path.join(TDX_BASE,'sz','lday','*.day'))):
    fn=os.path.basename(fp); code=fn[:-4]
    ts=code.upper()+('.SH' if 'sh' in code else '.SZ')
    df=parse(fp)
    if len(df)>60: daily[ts]=df; cnt+=1
print(f'loaded {cnt} stocks')
# benchmark weekly
bench=parse('D:/TDX/vipdoc/sh/lday/sh000300.day')
wb=bench.groupby(bench.index.to_period('W')).last(); wb.index=wb.index.to_timestamp()
wb=wb[['open','high','low','close','vol']]

weekly={}
for c,df in daily.items():
    wd=df.groupby(df.index.to_period('W')).last(); wd.index=wd.index.to_timestamp()
    wd=wd[['open','high','low','close','vol']]
    if len(wd)>=30: weekly[c]=wd
# rps
recs=[(c,d,v) for c,df in weekly.items() for d,v in df['close'].items() if v>0]
pivot=pd.DataFrame(recs,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True)*100
# factors (minimal F2)
factors={}
idx_df=wb['close']; idx_ma60=idx_df.rolling(60).mean()
market_bull_vals=((idx_df>idx_ma60)&(idx_ma60>idx_ma60.shift(5))).astype(int).values
for code,df in weekly.items():
    C=df['close']; H=df['high']; L=df['low']; V=df['vol']
    try:
        f={}
        VV=V/(V.rolling(5).mean()+0.0001)
        R0=((C-C.shift(1))/(C.shift(1)+0.0001)*100)*VV
        R0_abs=abs(R0.shift(1))+abs(R0.shift(2))+abs(R0.shift(3))+abs(R0.shift(4))+abs(R0.shift(5))/2
        f['main_in_signal']=(R0>R0_abs).astype(int)
        mn10=L.rolling(10).min(); mx25=H.rolling(25).max()
        wave=(((C-mn10)/(mx25-mn10+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['avg_line']=wave.ewm(span=3,adjust=False).mean()
        f['DCZ']=((H+L)/2).ewm(span=10,adjust=False).mean()
        f['vol_ratio']=V/(V.rolling(5).mean()+0.0001)
        f['huashen']=(C.ewm(span=3,adjust=False).mean()>C.ewm(span=7,adjust=False).mean()).astype(int)
        f['ma20']=C.rolling(20).mean()
        f['market_bull']=pd.Series(market_bull_vals,index=C.index)
        f['rps50']=rps.loc[code] if code in rps.index else pd.Series(np.nan,index=C.index)
        f['close']=C
        factors[code]=f
    except: pass
print(f'factors: {len(factors)}')
def s(f,n,ts):
    x=f.get(n); return x.loc[ts] if x is not None and ts in x.index else np.nan
all_weeks=sorted(set().union(*[set(f['close'].index) for f in factors.values()]))
wb_idx=wb.index
trades=[]
for wk in all_weeks:
    if wk.dayofweek!=0: continue
    picked=[]
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        main=s(f,'main_in_signal',wk); bull=s(f,'market_bull',wk)
        DCZ=s(f,'DCZ',wk); C=s(f,'close',wk); vol_r=s(f,'vol_ratio',wk)
        DCZ5=f['DCZ'].shift(5).loc[wk] if wk in f['DCZ'].shift(5).index else np.nan
        A=main==1 and bull==1 and pd.notna(DCZ) and pd.notna(DCZ5) and DCZ>DCZ5 and vol_r>1.5 and C>DCZ
        avg=s(f,'avg_line',wk); hu=s(f,'huashen',wk)
        DCZ3=f['DCZ'].shift(3).loc[wk] if wk in f['DCZ'].shift(3).index else np.nan
        B=main==1 and pd.notna(DCZ) and pd.notna(DCZ3) and DCZ>=DCZ3 and pd.notna(avg) and avg<2.3 and hu==1 and not A
        ma20=s(f,'ma20',wk)
        trend=pd.notna(C) and pd.notna(ma20) and C>=ma20 and (C>DCZ if pd.notna(C) and pd.notna(DCZ) else False)
        if (A or B) and trend:
            rv=s(f,'rps50',wk); rv=rv if pd.notna(rv) else 50
            picked.append((code,rv))
    picked.sort(key=lambda x:x[1],reverse=True)
    if len(picked)<2: continue
    for code,_ in picked[:20]:
        dd=daily.get(code)
        if dd is None or wk not in dd.index: continue
        idx_s=dd.index.searchsorted(wk,side='left')
        if idx_s>=len(dd) or dd.index[idx_s]!=wk: continue
        entry=dd.iloc[idx_s]['close']
        if idx_s>0:
            prev=dd.iloc[idx_s-1]['close']
            if prev>0 and entry>=prev*1.1: continue
        exit_ts=wk+pd.Timedelta(days=30)
        fi=dd.index.searchsorted(exit_ts,side='left')
        if fi<0 or fi>=len(dd): continue
        exit_close=dd.iloc[fi]['close']
        gross=exit_close/entry-1; net=gross-COST_RATE
        # benchmark: WEEKLY close at entry week vs exit week
        tb=wb_idx.searchsorted(wk,side='left'); eb=wb_idx.searchsorted(exit_ts,side='left')
        b_wk=(wb.iloc[eb]['close']/wb.iloc[tb]['close']-1) if 0<=tb<len(wb) and 0<=eb<len(wb) else np.nan
        # benchmark: DAILY close at entry date vs exit date
        eb_daily=dd.index.searchsorted(exit_ts,side='left')
        b_d=(dd.iloc[eb_daily]['close']/dd.iloc[idx_s]['close']-1)
        trades.append({'code':code,'wk':wk,'entry':entry,'exit':exit_close,'gross':gross,'net':net,'b_wk':b_wk,'b_d':b_d,'exit_date':dd.index[fi],'hold_days':(dd.index[fi]-wk).days})

df=pd.DataFrame(trades)
print(f'\nF2 trades: {len(df)}')
print(f'gross mean: {df["gross"].mean()*100:.2f}%')
print(f'net mean: {df["net"].mean()*100:.2f}%')
print(f'win rate: {(df["net"]>0).mean()*100:.1f}%')
print(f'bench weekly mean: {df["b_wk"].mean()*100:.2f}%')
print(f'bench DAILY mean: {df["b_d"].mean()*100:.2f}%')
print(f'excess (vs weekly bench) mean: {(df["net"]-df["b_wk"]).mean()*100:.2f}%')
print(f'excess (vs daily bench) mean: {(df["net"]-df["b_d"]).mean()*100:.2f}%')
print(f'\nbench weekly stats: min={df["b_wk"].min()*100:.1f}% max={df["b_wk"].max()*100:.1f}% median={df["b_wk"].median()*100:.1f}%')
print(f'bench daily stats: min={df["b_d"].min()*100:.1f}% max={df["b_d"].max()*100:.1f}% median={df["b_d"].median()*100:.1f}%')
print(f'hold days: min={df["hold_days"].min()} max={df["hold_days"].max()} mean={df["hold_days"].mean():.0f}')
print(f'\nTop 10 net:')
for _,r in df.nlargest(10,'net').iterrows():
    print(f'  {r["code"]} {r["wk"].date()} entry={r["entry"]:.2f} exit={r["exit"]:.2f} on {r["exit_date"].date()} gross={r["gross"]*100:.1f}% net={r["net"]*100:.1f}% b_wk={r["b_wk"]*100:.1f}% b_d={r["b_d"]*100:.1f}% hold={r["hold_days"]}d')
# is the bench_wk matching what the backtest computed?
# check: in backtest code, bench is daily (not weekly). So b_d should match.
print(f'\n--- backtest uses daily bench, so b_d is correct ---')
print(f'So F2 excess = net - b_d = {(df["net"]-df["b_d"]).mean()*100:.2f}% (correct figure)')
