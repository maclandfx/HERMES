"""Diagnostic: find F8 bottleneck conditions using compute_weekly_factors output"""
import pandas as pd, numpy as np, sys, os, glob, struct, time, math
from collections import Counter
sys.path.insert(0,'.')

# Load compute_weekly_factors inline
exec(open('weekly_formula_backtest.py').read().split('def compute_weekly_factors')[0])

# Load a few stocks manually
def load_1d(fp):
    with open(fp,'rb') as f: d=f.read()
    n=len(d)//32
    data=np.frombuffer(d,dtype=np.float32).reshape(n,8)
    df=pd.DataFrame(data[:,:7],columns=['open','high','low','close','vol','amount','fl'])
    df=df.iloc[:-1]
    df=df[df['close']>0]
    df=df.set_index(pd.to_datetime(df['fl'].astype(np.int64)))
    return df[['open','high','low','close','vol','amount']].sort_index()

# Use load_daily's logic - just pick 300 codes
weekly={}
t0=time.time()
for m in ('sh','sz','bj'):
    pats=glob.glob(os.path.join('D:/TDX/vipdoc',m,'lday','*.day'))
    for fp in sorted(pats):
        code=os.path.basename(fp).replace('.day','')
        try:
            df=load_1d(fp)
        except Exception:
            continue
        if df.empty or len(df)<10: continue
        W=df.resample('W').agg({'open':'first','high':'max','low':'min','close':'last','vol':'sum','amount':'sum'})
        W=W.dropna(subset=['close'])
        if len(W)<10: continue
        weekly[code]=W
        if len(weekly)>=300: break
    if len(weekly)>=300: break
print(f'Loaded {len(weekly)} stocks in {time.time()-t0:.1f}s')

# Use actual compute_weekly_factors on these 300
t0=time.time()
factors = {}
# Monkey-patch to skip RPS (slow)
import types

bottleneck=Counter()
for code,W in weekly.items():
    C=W['close']; H=W['high']; L=W['low']; O=W['open']; V=W['vol']; AM=W['amount']
    try:
        # === Replicate F8 conditions from formula_8_macd_tiered ===
        # 主力介入
        R0=(C-C.shift(1))/C.shift(1)
        avg_line=V.ewm(span=3,adjust=False).mean()
        main_in=(R0>0)&(avg_line>avg_line.shift(1))
        # 板块放量
        vol_ma5=V.rolling(5).mean()
        if code.startswith('30'): thr=1.8
        elif code.startswith('68'): thr=2.2
        elif code.startswith(('43','83','92')): thr=2.5
        else: thr=2.0
        vol_burst=(V>vol_ma5*thr)
        # MACD
        EMA12=C.ewm(span=12,adjust=False).mean(); EMA26=C.ewm(span=26,adjust=False).mean()
        DIF=(EMA12-EMA26); DEA=DIF.ewm(span=9,adjust=False).mean()
        gc=(DIF>DEA)&(DIF.shift(1)<=DEA.shift(1))
        above_zero=(DEA>0)
        below_zero=(DEA<=0)
        macd_strong=gc&above_zero
        macd_mid=gc|above_zero
        macd_bear=gc&below_zero
        # 筹码集中 (placeholder: always true since no real chip data)
        chip_conc=True
        # 趋势
        ma20=C.rolling(20).mean()
        trend_healthy=(ma20>ma20.shift(5))
        trend_hold=(C>ma20*0.95)
        trend_weak=(C>ma20*0.90)
        # 压力
        h30=H.rolling(30).max()
        p75=(C<h30*0.75)
        p80=(C<h30*0.80)
        # 风控
        risk=(C.notna().cumsum()>52)&(V>0)
        # 防骗 (no abnormal vol + no long upper)
        # Using actual v4 factors: anti_dump = no (vol_ratio>3 & C down)
        v4_dump=((V/AM.fillna(1).replace(0,1)>3)&(C<C.shift(1))).astype(int)
        anti_dump=(v4_dump==0)
        # 获利安全 = winner_pct<70
        profit_safe=True  # placeholder

        # Signal combos (per F8 function)
        base_all = main_in & vol_burst & anti_dump & risk
        strong = base_all & macd_strong & trend_healthy & p75 & chip_conc
        steady = base_all & macd_mid & trend_hold & p80 & chip_conc & profit_safe
        attack = base_all & macd_bear & trend_weak & chip_conc & profit_safe
        f8_signal = strong | steady | attack

        N=len(main_in)
        bottleneck['weeks']+=N
        bottleneck['main_in']+=int(main_in.sum())
        bottleneck['vol_burst']+=int(vol_burst.sum())
        bottleneck['anti_dump']+=int(anti_dump.sum())
        bottleneck['risk']+=int(risk.sum())
        bottleneck['base_all']+=int(base_all.sum())
        bottleneck['macd_strong']+=int(macd_strong.sum())
        bottleneck['macd_mid']+=int(macd_mid.sum())
        bottleneck['macd_bear']+=int(macd_bear.sum())
        bottleneck['trend_healthy']+=int(trend_healthy.sum())
        bottleneck['trend_hold']+=int(trend_hold.sum())
        bottleneck['p75']+=int(p75.sum())
        bottleneck['p80']+=int(p80.sum())
        bottleneck['strong']+=int(strong.sum())
        bottleneck['steady']+=int(steady.sum())
        bottleneck['attack']+=int(attack.sum())
        bottleneck['f8']+=int(f8_signal.sum())
    except Exception as e:
        pass

N=bottleneck['weeks']
print(f'\nBottleneck (300 stocks, {N} total weeks):')
print(f'{"factor":<18}{"count":>8}{"%":>8}')
for k in ['main_in','vol_burst','anti_dump','risk','base_all',
          'macd_strong','macd_mid','macd_bear',
          'trend_healthy','trend_hold','p75','p80',
          'strong','steady','attack','f8']:
    print(f'{k:<18}{bottleneck[k]:>8}{100*bottleneck[k]/N:>7.1f}%')
