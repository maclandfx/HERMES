import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_telegram_token
"""
self_driving_backtest.py — 自驱回测引擎（凌晨自动运行）
"""
import sys, os, json, time, math, traceback, shutil
sys.path.insert(0, r'D:/Hermes/评估中心/tools')
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from factor_utils import spearmanr_np, normalize
from formula_factors import calc_weekly_formula_factors, calc_daily_formula_factors

DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)

def get_a_share_sample(max_codes=200):
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        df = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol')
        if df is None or df.empty:
            return []
        df = df[~df['ts_code'].str.contains('BJ')]
        df = df[~df['ts_code'].str.contains('83|87|88|43')]
        codes = df['symbol'].tolist()
        print(f'  获取A股样本: {len(codes)} 只（全市场）')
        return codes
    except Exception as e:
        print(f'  获取样本失败: {e}')
        return []

def compute_market_correlation(factors_all, codes, backtest_days_list):
    """
    全市场因子-历史回测相关性
    方法：用昨日因子值，与过去90个交易日内的滚动N日收益做Spearman相关性
    （避免"未来"查询——全部用历史数据，3:00即可跑完）
    """
    print(f'  历史回测相关性（窗口90日，回测{backtest_days_list}天）...')
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        # 批量拉全市场历史日K（一次性，不逐只）
        all_factor_names = set()
        for f in factors_all.values():
            if '_error' not in f:
                all_factor_names.update(f.keys())
        all_factor_names.discard('_error')
        # 拉近120日全市场日K
        end_date = datetime.now().strftime('%Y%m%d')
        start_date = (datetime.now() - timedelta(days=180)).strftime('%Y%m%d')
        daily_all = {}
        batch_size = 50
        for i in range(0, len(codes), batch_size):
            batch_codes = [normalize(c) for c in codes[i:i+batch_size]]
            batch_codes = [c for c in batch_codes if c and len(c) == 6]
            for code in batch_codes:
                try:
                    ts_code = code + '.SH' if code[0] in '69' else code + '.SZ'
                    df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=end_date)
                    if df is not None and not df.empty and len(df) >= max(backtest_days_list) + 1:
                        df = df.sort_values('trade_date').reset_index(drop=True)
                        df['close'] = pd.to_numeric(df['close'], errors='coerce')
                        daily_all[code] = df
                except:
                    continue
            if len(daily_all) % 200 == 0:
                print(f'    拉取进度: {len(daily_all)} 只')
        print(f'  有效日K: {len(daily_all)} 只')
        corr_results = {}
        n_valid = 0
        for code_7 in codes:
            code = normalize(code_7)
            if not code or len(code) != 6:
                continue
            if code not in factors_all or '_error' in factors_all[code]:
                continue
            if code not in daily_all:
                continue
            df = daily_all[code]
            closes = df['close'].values
            n_closes = len(closes)
            max_future = max(backtest_days_list)
            # 构建历史回测数据（每个历史日期的因子→未来收益）
            factor_to_returns = {fn: {d: [] for d in backtest_days_list} for fn in all_factor_names}
            # 用当前因子值作为代理（假设因子稳定）
            for fn in all_factor_names:
                fval = factors_all[code].get(fn)
                if fval is None or not isinstance(fval, (int, float, np.floating, np.integer)):
                    continue
                if math.isnan(float(fval)) or math.isinf(float(fval)):
                    continue
                # 收集历史窗口内的因子值（用同一个因子值，代表该股票的特性）
                # 每个股票贡献 n_windows 个 (factor, return) 对
                n_windows = n_closes - max_future
                if n_windows < 30:
                    continue
                for d in backtest_days_list:
                    for w in range(n_windows):
                        base = closes[w]
                        fut = closes[w + d]
                        if base <= 0 or fut <= 0:
                            continue
                        ret = (fut / base - 1) * 100
                        factor_to_returns[fn][d].append((fval, ret))
            n_valid += 1
            for fn, day_dict in factor_to_returns.items():
                for d, pairs in day_dict.items():
                    if len(pairs) < 50:
                        continue
                    factors = [p[0] for p in pairs]
                    returns = [p[1] for p in pairs]
                    if fn not in corr_results:
                        corr_results[fn] = {'factors_by_day': {d2: [] for d2 in backtest_days_list},
                                            'returns_by_day': {d2: [] for d2 in backtest_days_list}}
                    corr_results[fn]['factors_by_day'][d].extend(factors)
                    corr_results[fn]['returns_by_day'][d].extend(returns)
        print(f'  有效股票: {n_valid} 只')
        spearman_results = {}
        for fn, data in corr_results.items():
            day_results = {}
            for d, factors in data['factors_by_day'].items():
                returns = data['returns_by_day'][d]
                if len(factors) < 50:
                    continue
                rho, pval = spearmanr_np(factors, returns)
                day_results[f'day{d}'] = {'rho': round(rho, 3), 'pval': round(pval, 4), 'n': len(factors), 'sig': bool(pval < 0.05)}
            if day_results:
                spearman_results[fn] = day_results
        print(f'  有效因子数: {len(spearman_results)}')
        return spearman_results, n_valid
    except Exception as e:
        print(f'  相关性计算失败: {e}')
        traceback.print_exc()
        return {}, 0

def find_best_factors(corr_results, top_n=15):
    scored = []
    for fname, days in corr_results.items():
        rhos = [abs(v['rho']) for v in days.values()]
        sigs = [v['sig'] for v in days.values()]
        avg_rho = sum(rhos) / len(rhos) if rhos else 0
        sig_rate = sum(sigs) / len(sigs) if sigs else 0
        scored.append((fname, avg_rho, sig_rate, days))
    scored.sort(key=lambda x: (x[1], x[2]), reverse=True)
    return scored[:top_n]

def compute_evolution(prev_file, curr_corr):
    evolution = {'new': [], 'improved': [], 'degraded': []}
    if not os.path.exists(prev_file):
        return evolution
    try:
        prev = json.load(open(prev_file, encoding='utf-8'))
    except:
        return evolution
    for fname, days in curr_corr.items():
        if fname not in prev:
            evolution['new'].append(fname)
            continue
        curr_rhos = [abs(v['rho']) for v in days.values()]
        prev_rhos = [abs(v['rho']) for v in prev[fname].values()]
        curr_avg = sum(curr_rhos) / len(curr_rhos) if curr_rhos else 0
        prev_avg = sum(prev_rhos) / len(prev_rhos) if prev_rhos else 0
        if curr_avg > prev_avg + 0.05:
            evolution['improved'].append({'f': fname, 'prev': round(prev_avg, 3), 'curr': round(curr_avg, 3), 'delta': round(curr_avg - prev_avg, 3)})
        elif curr_avg < prev_avg - 0.05:
            evolution['degraded'].append({'f': fname, 'prev': round(prev_avg, 3), 'curr': round(curr_avg, 3), 'delta': round(curr_avg - prev_avg, 3)})
    return evolution

def run():
    from factor_utils import normalize
    print('=' * 60)
    print('自驱回测引擎')
    print(f'时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    print('=' * 60)
    codes = get_a_share_sample(max_codes=200)
    if not codes:
        print('[FAIL] 无样本，跳过')
        return
    today = datetime.now().strftime('%Y%m%d')
    # 周线
    print('\n周线框架回测')
    t0 = time.time()
    weekly_factors = calc_weekly_formula_factors(codes)
    w_time = time.time() - t0
    print(f'  周线因子: {w_time:.1f}s')
    json.dump(weekly_factors, open(os.path.join(DATA_DIR, f'market_weekly_{today}.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    weekly_corr, w_n = compute_market_correlation(weekly_factors, codes, [7, 14, 21, 30])
    w_corr_file = os.path.join(DATA_DIR, 'market_weekly_corr.json')
    json.dump(weekly_corr, open(w_corr_file, 'w', encoding='utf-8'), ensure_ascii=False)
    w_prev = os.path.join(DATA_DIR, 'market_weekly_corr_prev.json')
    w_ev = compute_evolution(w_prev, weekly_corr)
    shutil.copy(w_corr_file, w_prev)
    w_best = find_best_factors(weekly_corr)
    # 日线
    print('\n日线框架回测')
    t0 = time.time()
    daily_factors = calc_daily_formula_factors(codes)
    d_time = time.time() - t0
    print(f'  日线因子: {d_time:.1f}s')
    json.dump(daily_factors, open(os.path.join(DATA_DIR, f'market_daily_{today}.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    daily_corr, d_n = compute_market_correlation(daily_factors, codes, [1, 3, 5, 10])
    d_corr_file = os.path.join(DATA_DIR, 'market_daily_corr.json')
    json.dump(daily_corr, open(d_corr_file, 'w', encoding='utf-8'), ensure_ascii=False)
    d_prev = os.path.join(DATA_DIR, 'market_daily_corr_prev.json')
    d_ev = compute_evolution(d_prev, daily_corr)
    shutil.copy(d_corr_file, d_prev)
    d_best = find_best_factors(daily_corr)
    # 报告
    lines = []
    lines.append(f'# 自驱回测报告 {today}')
    lines.append('')
    lines.append(f'样本: {len(codes)}只 | 周线有效:{w_n} | 日线有效:{d_n} | 周线耗时:{w_time:.0f}s | 日线耗时:{d_time:.0f}s')
    lines.append('')
    lines.append('## 周线高预测力因子TOP10')
    for fname, avg_rho, sig_rate, days in w_best[:10]:
        lines.append(f'{avg_rho:.3f} sig={sig_rate:.0%} {fname}')
        for d, info in sorted(days.items()):
            lines.append(f'  {d}: rho={info["rho"]:+.3f} p={info["pval"]:.4f} n={info["n"]} {"*" if info["sig"] else ""}')
    lines.append('')
    lines.append('## 日线高预测力因子TOP10')
    for fname, avg_rho, sig_rate, days in d_best[:10]:
        lines.append(f'{avg_rho:.3f} sig={sig_rate:.0%} {fname}')
        for d, info in sorted(days.items()):
            lines.append(f'  {d}: rho={info["rho"]:+.3f} p={info["pval"]:.4f} n={info["n"]} {"*" if info["sig"] else ""}')
    lines.append('')
    lines.append('## 进化变化')
    lines.append(f'周线: 新{len(w_ev["new"])} 提升{len(w_ev["improved"])} 退化{len(w_ev["degraded"])}')
    lines.append(f'日线: 新{len(d_ev["new"])} 提升{len(d_ev["improved"])} 退化{len(d_ev["degraded"])}')
    report = '\n'.join(lines)
    report_path = os.path.join(DATA_DIR, f'self_driving_{today}.txt')
    open(report_path, 'w', encoding='utf-8').write(report)
    print('\n' + report)
    print(f'报告: {report_path}')
    push_tg(report)

def push_tg(report):
    try:
        import urllib.request
        token = get_telegram_token()
        chat_id = '8673372605'
        url = f'https://api.telegram.org/bot{token}/sendMessage'
        data = json.dumps({'chat_id': chat_id, 'text': report[:3900], 'parse_mode': 'HTML'}).encode('utf-8')
        req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({'http': '127.0.0.1:7890', 'https': '127.0.0.1:7890'}))
        opener.open(req, timeout=15)
        print('TG推送成功')
    except Exception as e:
        print(f'TG推送失败: {e}')

if __name__ == '__main__':
    run()
