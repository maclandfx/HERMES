"""
factor_utils.py — 因子计算辅助函数（工业级验证版）
"""
import numpy as np
import pandas as pd
import math


def spearmanr_np(x, y):
    """numpy 实现 Spearman 秩相关（进化模块依赖）"""
    arr_x, arr_y = np.array(x, dtype=float), np.array(y, dtype=float)
    # 秩
    rx = pd.Series(arr_x).rank().values
    ry = pd.Series(arr_y).rank().values
    sx, sy = np.std(rx), np.std(ry)
    if sx == 0 or sy == 0:
        return (0.0, 1.0)
    rho = np.corrcoef(rx, ry)[0, 1]
    n = len(x)
    if n < 6:
        return (float(rho), 1.0)
    t_val = rho * math.sqrt((n - 2) / max(1e-10, 1 - rho * rho))
    p = math.erfc(abs(t_val) / math.sqrt(2))
    return (float(rho), float(p))


def normalize(c):
    return c[1:] if len(c) == 7 and c[0] in '012' else c


def weighted_nx_20(mid):
    """
    通达信 NX 20日衰减加权均线
    权重: 20,19,18,...,1  总分=210
    公式: NX = SUM(MID * 权重) / 210
    """
    weights = np.arange(20, 0, -1)  # [20,19,...,1]
    total = weights.sum()  # 210
    
    result = pd.Series(np.nan, index=mid.index, dtype=float)
    arr = mid.values.astype(float)
    
    for i in range(len(arr) - 19):
        window = arr[i:i+20]
        weighted_sum = np.dot(window, weights)
        result.iloc[i+19] = weighted_sum / total
    
    return result


def calc_four_volume(o, h, l, c, v):
    """
    四量算法：基于 OHLCV 判断大单/中单/小单/超大单成交量
    
    通达信四量逻辑（成交量分级）：
    - 超大单: 单笔金额占比最大，通常 > 流通市值*0.1%
    - 大单:   单笔金额在 流通市值*0.03%~0.1%
    - 中单:   单笔金额在 流通市值*0.01%~0.03%
    - 小单:   单笔金额 < 流通市值*0.01%
    
    在无逐笔数据时，用以下代理算法：
    - 按价量关系估算成交结构
    - 大涨+高量 → 超大单+大单占比高
    - 小涨/跌+高量 → 中单/小单占比高
    - 使用成交量分布模型
    
    简化版（适用于因子追踪）：
    用 OHLC 实体/影线比例 + 涨跌幅 + 成交量分级估算
    """
    chg_pct = ((c - c.shift(1)) / (c.shift(1) + 0.0001) * 100)
    body = np.abs(c - o)
    candle_range = h - l
    shadow_ratio = (candle_range - body) / (candle_range + 0.0001)
    
    # 超大单量代理：大涨+高量+长下影（主力承接）
    # 当股价大涨且成交量放大，超大单/大单通常占主导
    is_bull_breakout = (chg_pct > 5) & (shadow_ratio > 0.5)
    # 当股价大跌幅+高量，超大单/大单可能在卖出
    is_bear_climax = (chg_pct < -5) & (v > v.rolling(5, min_periods=1).mean() * 2)
    
    # 超大单量估计 = 总成交量 * 主力行为系数
    # 主力行为系数：基于价格波动幅度+成交量比例
    range_pct = candle_range / (c.shift(1) + 0.0001) * 100
    vol_ratio = v / (v.rolling(5, min_periods=1).mean() + 0.0001)
    
    # 主力系数模型
    # 高振幅 + 高量比 → 主力活跃
    main_force_factor = np.minimum(1.0, (range_pct / 10) * (vol_ratio / 3))
    
    # 四量分配模型
    # 基于通达信经验：主力控盘时，超大单+大单占总量60-80%
    # 散户主导时，超大单+大单占总量10-30%
    
    # 主力占比 = 主力系数 + 基础值
    main_ratio = 0.2 + 0.6 * main_force_factor  # 范围 20%-80%
    
    # 细分四量
    mega_ratio = np.clip(main_ratio * 0.3, 0, 0.3)  # 超大单占比
    large_ratio = np.clip(main_ratio * 0.5, 0, 0.5)  # 大单占比
    mid_ratio = 0.2  # 中单固定20%
    small_ratio = 1.0 - mega_ratio - large_ratio - mid_ratio  # 小单
    small_ratio = np.maximum(small_ratio, 0.05)
    
    # 归一化
    total = mega_ratio + large_ratio + mid_ratio + small_ratio
    mega_ratio /= total
    large_ratio /= total
    mid_ratio /= total
    small_ratio /= total
    
    # 计算四量金额
    mega_vol = v * mega_ratio
    large_vol = v * large_ratio
    mid_vol = v * mid_ratio
    small_vol = v * small_ratio
    
    # 净四量（方向判断）
    # 上涨日：超大单/大单为买入；下跌日：超大单/大单为卖出
    mega_net = np.where(chg_pct > 0, mega_vol, -mega_vol)
    large_net = np.where(chg_pct > 0, large_vol, -large_vol)
    combined_main = mega_net + large_net
    
    return {
        'four_vol_mega_ratio': mega_ratio,
        'four_vol_large_ratio': large_ratio,
        'four_vol_mid_ratio': mid_ratio,
        'four_vol_small_ratio': small_ratio,
        'four_vol_main_ratio': mega_ratio + large_ratio,
        'four_vol_combined_net': combined_main,
        'four_vol_main_force_factor': main_force_factor,
    }


def calc_dense_zone(df, window=60):
    """
    成交密集区识别
    返回：密集区间 [low, high] 和密集度
    
    算法：按价格分bin统计成交量，找到成交量最大的区间
    """
    c = df['close']
    v = df['vol']
    amt = c * v
    
    recent = df.tail(window).copy()
    if len(recent) < 10:
        return {'dense_low': None, 'dense_high': None, 'density': 0}
    
    # 价格范围
    p_min = recent['low'].min()
    p_max = recent['high'].max()
    if p_max - p_min < 0.01:
        return {'dense_low': None, 'dense_high': None, 'density': 0}
    
    # 分30个bin统计成交量
    n_bins = 30
    bin_size = (p_max - p_min) / n_bins
    bin_volumes = np.zeros(n_bins)
    bin_amounts = np.zeros(n_bins)
    
    for _, row in recent.iterrows():
        close = row['close']
        vol = row['vol']
        amt = row['close'] * row['vol']
        bin_idx = min(int((close - p_min) / bin_size), n_bins - 1)
        bin_idx = max(bin_idx, 0)
        bin_volumes[bin_idx] += vol
        bin_amounts[bin_idx] += amt
    
    # 找成交量最大的3个连续bin
    top_idx = np.argsort(bin_volumes)[-3:][::-1]
    # FIX: 用min/max确保low<high，而不是按volume排序
    dense_low = (min(top_idx) * bin_size + p_min)
    dense_high = ((max(top_idx) + 1) * bin_size + p_min)
    density = bin_volumes.max() / (bin_volumes.sum() + 0.0001)
    
    return {
        'dense_low': round(float(dense_low), 2),
        'dense_high': round(float(dense_high), 2),
        'density': round(float(density), 4),
    }


def calc_support_resistance(df, lookback=20):
    """
    支撑压力识别
    返回近期高点/低点列表和当前相对位置
    """
    h = df['high']
    l = df['low']
    c = df['close']
    
    recent = df.tail(lookback * 2)
    if len(recent) < lookback:
        return {}
    
    # 找近期局部高点（25日内的峰）
    hhv_25 = h.rolling(25, min_periods=1).max()
    llv_25 = l.rolling(25, min_periods=1).min()
    
    current_price = c.iloc[-1]
    
    # 最近一次高位和低位
    last_resistance = float(hhv_25.iloc[-1])
    last_support = float(llv_25.iloc[-1])
    
    # 当前价格距支撑/压力的距离
    dist_to_resistance = (last_resistance - current_price) / current_price * 100 if current_price > 0 else 0
    dist_to_support = (current_price - last_support) / last_support * 100 if last_support > 0 else 0
    
    return {
        'resistance': round(last_resistance, 2),
        'support': round(last_support, 2),
        'dist_to_resistance_pct': round(dist_to_resistance, 2),
        'dist_to_support_pct': round(dist_to_support, 2),
    }


def calc_momentum_acceleration(trend_series):
    """
    趋势加速度 = 趋势的一阶差分
    衡量趋势变化速度
    """
    if len(trend_series) < 2:
        return 0
    return round(float(trend_series.iloc[-1] - trend_series.iloc[-2]), 4)
