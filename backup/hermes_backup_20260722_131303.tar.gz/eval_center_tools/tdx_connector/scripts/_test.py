
import sys, os, json, time, math
sys.path.insert(0, r"D:/Hermes/评估中心/tools")

import numpy as np
from datetime import datetime, timedelta

DATA_DIR = r"D:/Hermes/评估中心/tools/tdx_connector/zxsx_data"
os.makedirs(DATA_DIR, exist_ok=True)
SNAPSHOT_FILE = os.path.join(DATA_DIR, "snapshots.json")
RESULT_FILE = os.path.join(DATA_DIR, "results.json")
FACTOR_CORR_FILE = os.path.join(DATA_DIR, "factor_correlation.json")
WEIGHT_FILE = os.path.join(DATA_DIR, "factor_weights.json")
