import os, struct, glob, pandas as pd, numpy as np, time
TDX_BASE='D:/TDX/vipdoc'; DIV={'sh':1000,'sz':10}
def parse(path):
    try:
        with open(path,'rb') as f: raw=f.read()
    except: return pd.DataFrame()
    if len(raw)%32!=0: return pd.DataFrame()
    fn=os.path.basename(path)
    if fn.startswith('sh'): m='sh'
    elif fn.startswith('sz'): m='sz'
    else: return pd.DataFrame()
    d=DIV.get(m,1000); rows=[]
    for i in range(len(raw)//32):
        c=raw[i*32:(i+1)*32]
        di=struct.unpack('<I',c[0:4])[0]
        try: ts=pd.Timestamp(di//10000,(di//100)%100,di%100)
        except: continue
        o=struct.unpack('<I',c[4:8])[0]/d; cc=struct.unpack('<I',c[8:12])[0]/d
        h=struct.unpack('<I',c[12:16])[0]/d; l=struct.unpack('<I',c[16:20])[0]/d
        v=struct.unpack('<Q',c[20:28])[0]
        rows.append((ts,o,h,l,cc,v))
    if not rows: return pd.DataFrame()
    return pd.DataFrame(rows,columns=['date','o','h','l','c','v']).sort_values('date').set_index('date')

daily={}; cnt=0
for fp in sorted(glob.glob(os.path.join(TDX_BASE,'sh','lday','*.day'))+glob.glob(os.path.join(TDX_BASE,'sz','lday','*.day'))):
    fn=os.path.basename(fp); code=fn[:-4]
    ts=code.upper()+('.SH' if 'sh' in code else '.SZ')
    df=parse(fp)
    if len(df)>60: daily[ts]=df; cnt+=1
    if cnt>=200: break
weekly={}
for code,df in daily.items():
    wd=df.groupby(df.index.to_period('W')).last(); wd.index=wd.index.to_timestamp()
    wd=wd[['o','h','l','c','v']]
    if len(wd)>=30: weekly[code]=wd
print('weekly:',len(weekly))

recs=[(c,d,v) for c,df in weekly.items() for d,v in df['c'].items() if v>0]
pivot=pd.DataFrame(recs,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True)*100

idx_df=None
for key in ('SH000300.SH','SZ399001.SZ'):
    if key in weekly: idx_df=weekly[key]['c']; break
print('idx_df len:', len(idx_df) if idx_df is not None else 0)

t0=time.time()
factors={}; errs=0
for code,df in weekly.items():
    try:
        C=df['c']; H=df['h']; L=df['l']; V=df['v']
        f={}
        f['ma5']=C.rolling(5).mean(); f['ma20']=C.rolling(20).mean()
        f['ma30']=C.rolling(30).mean(); f['ma45']=C.rolling(45).mean()
        f['ma60']=C.rolling(60).mean(); f['ma90']=C.rolling(90).mean()
        ema12=C.ewm(span=12,adjust=False).mean(); ema26=C.ewm(span=26,adjust=False).mean()
        dif=ema12-ema26; f['dif']=dif
        f['dea']=dif.ewm(span=9,adjust=False).mean()
        f['macd_golden_wide']=(dif>f['dea']).astype(int)
        LL9=L.rolling(9).min(); HH9=H.rolling(9).max()
        RSV=(C-LL9)/(HH9-LL9+0.0001)*100
        f['kdj_K']=RSV.ewm(span=3,adjust=False).mean(); f['kdj_D']=f['kdj_K'].ewm(span=3,adjust=False).mean()
        f['huashen']=(C.ewm(span=3,adjust=False).mean()>C.ewm(span=7,adjust=False).mean()).astype(int)
        f['huashen_p1']=((C+1).ewm(span=3,adjust=False).mean()>(C+1).ewm(span=7,adjust=False).mean()).astype(int)
        VV=V/V.rolling(5).mean()
        R0=((C-C.shift(1))/(C.shift(1)+0.0001)*100)*VV
        R0_abs_sum=abs(R0.shift(1))+abs(R0.shift(2))+abs(R0.shift(3))+abs(R0.shift(4))+abs(R0.shift(5))/2
        f['R0']=R0; f['main_in_signal']=(R0>R0_abs_sum).astype(int)
        mn10=L.rolling(10).min(); mx25=H.rolling(25).max()
        wave=(((C-mn10)/(mx25-mn10+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['avg_line']=wave.ewm(span=3,adjust=False).mean()
        f['DCZ']=(H.rolling(30).mean()+L.rolling(30).mean())/2
        f['vol_ma5']=V.rolling(5).mean(); f['vol_ratio']=V/(V.rolling(5).mean()+0.0001)
        tr=pd.concat([H-L,abs(H-C.shift(1)),abs(L-C.shift(1))],axis=1).max(axis=1)
        f['atr14']=tr.rolling(14).mean()
        SHORT,LONG,ZWIN,SCALE=12,26,60,20
        dif_all=C.ewm(span=SHORT,adjust=False).mean()-C.ewm(span=LONG,adjust=False).mean()
        dif_ma=dif_all.rolling(ZWIN).mean(); dif_std=dif_all.rolling(ZWIN).std().fillna(0.0001)
        dif_z=(dif_all-dif_ma)/(dif_std+0.0001)
        f['core_trend']=50+SCALE*dif_z
        f['core_trend_low']=(f['core_trend']<45).astype(int)
        VOSC_RAW=100*(V.rolling(12).mean()-V.rolling(26).mean())/(V.rolling(26).mean()+0.0001)
        vosc_ma=VOSC_RAW.rolling(ZWIN).mean(); vosc_std=VOSC_RAW.rolling(ZWIN).std().fillna(0.0001)
        f['vol_swing']=50+SCALE*(VOSC_RAW-vosc_ma)/(vosc_std+0.0001)
        f['vol_freeze']=((f['vol_swing']<38).astype(int).rolling(3).max()>0).astype(int)
        f['winner_pct']=(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)*100
        f['inst_ctrl']=(C>f['ma45']).astype(int); f['main_lock']=(C>f['ma30']).astype(int)
        wkret=(C/C.shift(1)-1)*100
        big=(wkret>5)&(f['vol_ratio']>1.5)
        f['strat_ignition']=((big).astype(int).rolling(12).max()>0).astype(int)
        f['trend_turn']=((f['core_trend']>f['core_trend'].shift(1))&(f['core_trend'].shift(1)<=f['core_trend'].shift(2))).astype(int)
        ww=(((C-L.rolling(3).min())/(H.rolling(6).max()-L.rolling(3).min()+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['weekly_avg']=ww.ewm(span=3,adjust=False).mean()
        f['weekly_avg_turn']=((f['weekly_avg']>=f['weekly_avg'].shift(1))&(f['weekly_avg'].shift(1)<f['weekly_avg'].shift(2))).astype(int)
        f['vol_inc']=((V>f['vol_ma5'])&(V<f['vol_ma5']*3)).astype(int)
        f['ma_bull']=((C>f['ma20'])&(f['ma5']>f['ma30'])).astype(int)
        f['above_ma60']=(C>f['ma60']).astype(int)
        f['not_high']=(f['weekly_avg']<2.5).astype(int)
        crange=H-L+0.0001; f['no_long_shadow']=(H-C<0.4*crange).astype(int)
        f['body_dom']=((C-df['o'])>(H-L)*0.5).astype(int)
        AA=(C-L.rolling(20).min())*100/(H.rolling(20).max()-L.rolling(20).min()+0.0001)
        f['rel_pos']=AA
        f['ind_trend']=(100*(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)).ewm(span=3,adjust=False).mean()
        f['retail_mom']=f['rel_pos'].rolling(6).mean()
        if idx_df is not None and len(idx_df)>0:
            idx_ma60=idx_df.rolling(60).mean()
            f['market_bull']=((idx_df>idx_ma60)&(idx_ma60>idx_ma60.shift(5))).astype(int)
        else:
            f['market_bull']=pd.Series(0,index=C.index,dtype=int)
        if code in rps.index:
            f['rps50']=rps.loc[code]
        else:
            f['rps50']=pd.Series(np.nan,index=C.index)
        f['close']=C
        factors[code]=f
    except Exception as e:
        errs+=1
        if errs<=5: print('  ERR on',code,':',type(e).__name__,str(e)[:80])
print(f'factors: {len(factors)}, errs: {errs}, time: {time.time()-t0:.1f}s')
sample=list(factors.keys())[0]
print('sample keys:', sorted(factors[sample].keys())[:20])
count=0; ts0=None
for code,f in factors.items():
    for ts in f['close'].index[-10:]:
        def s(n):
            x=f.get(n); return x.loc[ts] if x is not None and ts in x.index else np.nan
        main=s('main_in_signal'); bull=s('market_bull'); DCZ=s('DCZ'); Cc=s('close')
        DCZ_s=f['DCZ']
        try: DCZ5=DCZ_s.shift(5).loc[ts]
        except: DCZ5=np.nan
        C_above= (pd.notna(Cc) and pd.notna(DCZ) and Cc>DCZ)
        A= (main==1 and bull==1 and pd.notna(DCZ) and pd.notna(DCZ5) and DCZ>DCZ5 and s('vol_ratio')>1.5 and C_above)
        avg=s('avg_line'); hu=s('huashen')
        try: DCZ3=DCZ_s.shift(3).loc[ts]
        except: DCZ3=np.nan
        B= (main==1 and pd.notna(DCZ) and pd.notna(DCZ3) and DCZ>=DCZ3 and pd.notna(avg) and avg<2.3 and hu==1 and not A)
        if A or B:
            count+=1
            if ts0 is None: ts0=ts
print(f'F2 triggers (last 10 weeks, 200 stocks): {count}, sample week: {ts0}')
