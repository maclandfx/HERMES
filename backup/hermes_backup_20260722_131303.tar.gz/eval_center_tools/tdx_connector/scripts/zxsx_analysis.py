import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_telegram_token
import sys, time, json, urllib.request
sys.path.insert(0, r'D:/Hermes/评估中心/tools')

def normalize(c):
    return c[1:] if len(c)==7 and c[0] in '012' else c

try:
    content = open(r'D:/TDX/T0002/blocknew/ZXSX.blk', encoding='gbk').read()
    codes_7 = [l.strip() for l in content.splitlines() if l.strip()]
except:
    print('[WARN] ZXSX.blk 读取失败'); sys.exit(0)

pure = [normalize(c) for c in codes_7]
if not pure:
    print('[INFO] 周线手选板块为空'); sys.exit(0)

from astock_bridge import tencent_quote
d = tencent_quote(pure)

from factor_engine import calc_factors, normalize_factors
t0 = time.time()
raw = calc_factors(pure)
norm = normalize_factors(raw)
print(f'[INFO] 因子计算 {time.time()-t0:.1f}s, 共{len(norm)}只')

factor_labels = {'A1_big_net_ratio':'主力资金强度','A2_consecutive_days':'资金持续性',
                 'B1_divergence':'量价背离','B4_rel_strength':'相对强弱',
                 'B5_trend':'20日趋势','B6_volatility':'波动率'}
rows = []
for orig, p in zip(codes_7, pure):
    info = d.get(p,{})
    n = norm.get(p,{})
    if 'error' in n: continue
    name = info.get('name',p)
    chg = info.get('change_pct',0)
    price = info.get('price',0)
    vals = [n.get(k,50) for k in factor_labels]
    avg = sum(vals)/len(vals)
    rows.append({'name':name,'code':p,'price':price,'chg':chg,'avg':avg,'vals':{k:v for k,v in zip(factor_labels.keys(),vals)}})
rows.sort(key=lambda x: -x['avg'])

avg_chg = sum(r['chg'] for r in rows)/len(rows)
env = '强' if avg_chg > 2 else ('中性' if avg_chg > -2 else '弱')

lines = ['# 周线手选板块滚动分析','',
         f'板块: {len(rows)}只 | 平均{avg_chg:+.2f}% | 综合分均值{sum(r["avg"] for r in rows)/len(rows):.0f}',
         f'环境: {"🟢" if env=="强" else "🟡" if env=="中性" else "🔴"} {env}','',
         '🏆 TOP5']
for i,r in enumerate(rows[:5],1):
    lines.append(f'{i}. {r["name"]}({r["code"]}) ¥{r["price"]:.2f} {r["chg"]:+.1f}% {r["avg"]:.0f}分')
lines.append('')
lines.append('🔥 强势因子')
for fk,label in factor_labels.items():
    ranked = sorted(rows, key=lambda x: -x['vals'][fk])
    top3 = ', '.join([f'{r["name"]}({r["vals"][fk]:.0f})' for r in ranked[:3]])
    lines.append(f'{label}: {top3}')
lines.append('')
lines.append(f'💡 {env}势，关注逆势强势标的')

report = '\n'.join(lines)
print(report)

with open(r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_analysis.json','w',encoding='utf-8') as f:
    json.dump({'ts':time.strftime('%Y-%m-%d %H:%M'),'report':report,'rows':rows}, f, ensure_ascii=False)

try:
    TOKEN = get_telegram_token()
    CHAT_ID = '8673372605'
    handler = urllib.request.ProxyHandler({'http':'http://127.0.0.1:7890','https':'http://127.0.0.1:7890'})
    opener = urllib.request.build_opener(handler); opener.timeout=60
    url = f'https://api.telegram.org/bot{TOKEN}/sendMessage'
    data = json.dumps({'chat_id':CHAT_ID,'text':report,'parse_mode':'Markdown','disable_web_page_preview':True}).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'})
    resp = opener.open(req)
    result = json.loads(resp.read())
    print(f'[TG] {"ok" if result.get("ok") else result}')
except Exception as e:
    print(f'[TG] 失败: {e}')
