"""Quick diagnosis: sample 3-factor and F2 realistic trades, compare net distributions."""
import pandas as pd, numpy as np, sys, os, time, math
sys.path.insert(0,'.')
import importlib.util

spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

# Reuse existing loaded data (fast)
daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)

# Sample 80 eligible codes for speed
sample_codes = [c for c in weekly if wf.is_eligible(c)][:80]
print(f"Sampling {len(sample_codes)} stocks")

# Load benchmark daily
bench_code = 'SH000300.SH'
bench = wf.load_benchmark(daily)

# Run a mini backtest for both 3factor and F2 on subset
def mini_backtest(formula_fn, label, codes):
    trades = []
    for code in codes:
        W = weekly.get(code)
        if W is None: continue
        f = {}  # skip full factor computation; test with simple factors
        C = W['close']
        for ts in W.index:
            # Simplified 3-factor inline
            if label == '3factor':
                # RPS simplified: rank among sampled
                # Use close rank as proxy
                pass
    return trades

# Instead, run actual full formula backtest on subset via the real run_formula_backtest
# We need factors. Compute factors for subset only.
print("Computing factors for subset...")
t0 = time.time()

# RPS on full market (fast)
price_records = []
for code, df in weekly.items():
    for d, c in df['close'].items():
        if c and c > 0:
            price_records.append((code, d, c))
pivot = pd.DataFrame(price_records, columns=['code','date','close']).pivot(index='code', columns='date', values='close')
rps = pivot.rank(axis=1, pct=True, method='average') * 100

# market_bull from benchmark
bweekly = wf.daily_to_weekly({bench_code: bench})
mbull = None; mbull_sz = None
if bench_code in bweekly:
    bw = bweekly[bench_code]
    if len(bw) >= 60:
        ma60 = bw['close'].rolling(60).mean()
        if pd.notna(ma60).sum() >= 10:
            ref_idx = weekly[list(weekly.keys())[0]].index
            mbull = (bw['close'] > ma60).map({True:1, False:0}).reindex(ref_idx).fillna(0)
            mbull_sz = mbull.copy()

print(f"RPS+mbull in {time.time()-t0:.1f}s")

# Compute factors for sample
t0 = time.time()
factors = {}
for code in sample_codes:
    W = weekly[code]
    C = W['close']; H = W['high']; L = W['low']; O = W['open']; V = W['vol']
    try:
        f = {}
        # EMA/MACD
        EMA12 = C.ewm(span=12, adjust=False).mean()
        EMA26 = C.ewm(span=26, adjust=False).mean()
        dif = EMA12 - EMA26
        dea = dif.ewm(span=9, adjust=False).mean()
        f['dif'] = dif; f['dea'] = dea
        f['macd_golden_wide'] = (dif > dea).astype(int)
        # MA
        f['ma5'] = C.rolling(5).mean()
        f['ma10'] = C.rolling(10).mean()
        f['ma20'] = C.rolling(20).mean()
        f['ma60'] = C.rolling(60).mean()
        f['close'] = C
        # RPS
        f['rps50'] = rps.loc[code] if code in rps.index else pd.Series(np.nan, index=C.index)
        # retail_mom
        HH20 = H.rolling(20).max(); LL20 = L.rolling(20).min()
        rel_pos = (C - LL20) * 100 / (HH20 - LL20 + 0.0001)
        f['retail_mom'] = rel_pos.rolling(6).mean()
        # DCZ
        mid = (C + O + ((H - L) / 4)) / 2
        f['DCZ'] = mid.ewm(span=20, adjust=False).mean()
        # ATR (simplified)
        hcl = pd.concat([H - L, (H - C.shift(1)).fillna(0), (C - L.shift(1)).fillna(0)], axis=1).max(axis=1)
        f['atr14'] = hcl.rolling(14).mean()
        # market_bull
        f['market_bull'] = mbull if mbull is not None else pd.Series(1, index=C.index)
        f['market_bull_sz'] = mbull_sz if mbull_sz is not None else pd.Series(1, index=C.index)
        # avg_line
        f['avg_line'] = V.ewm(span=3, adjust=False).mean()
        factors[code] = f
    except Exception as e:
        if len(factors) < 1:
            import traceback; traceback.print_exc()
print(f"Factors: {len(factors)} in {time.time()-t0:.1f}s")

# Mini backtest for 3-factor realistic
print("\n--- 3-factor realistic (80 stocks subset) ---")
t0 = time.time()
holdings_3f = []
all_dates = sorted(set(bw.index)) if bench_code in bweekly else []
start = pd.Timestamp('20230101'); end_ts = pd.Timestamp('20251231')
all_dates = [d for d in all_dates if d >= start and d <= end_ts and d.dayofweek == 0]
bench_index = bench.sort_index().index if bench is not None else pd.DatetimeIndex()

for T in all_dates:
    picked = []
    for code in sample_codes:
        if code not in factors: continue
        f = factors[code]
        if T not in f['close'].index: continue
        rps_v = wf._s(f, 'rps50', T)
        macd_g = wf._s(f, 'macd_golden_wide', T)
        rm = wf._s(f, 'retail_mom', T)
        if not all(pd.notna(x) for x in (rps_v, macd_g, rm)): continue
        if not (rps_v >= 50 and macd_g == 1 and rm >= 45): continue
        picked.append((code, rps_v))
    picked.sort(key=lambda x: x[1], reverse=True)
    picked = picked[:20]
    for code, _ in picked:
        dd = daily.get(code)
        if dd is None or T not in dd.index: continue
        dd_sorted_idx = dd.index.searchsorted(T, side='left')
        if dd_sorted_idx >= len(dd) or dd.index[dd_sorted_idx] != T: continue
        entry = dd.iloc[dd_sorted_idx + 1]['open'] if dd_sorted_idx < len(dd) - 1 else dd.iloc[dd_sorted_idx]['close']
        if entry <= 0: continue
        exit_ts = T + pd.Timedelta(days=30)
        fut_idx = dd.index.searchsorted(exit_ts, side='left')
        if fut_idx < 0 or fut_idx >= len(dd): continue
        exit_close = dd.iloc[fut_idx]['close']
        if exit_close <= 0: continue
        gross = exit_close / entry - 1 - 0.002
        net = gross - 0.00232
        holdings_3f.append({'code': code, 'T': T, 'entry': entry, 'exit': exit_close, 'net': net,
                           'gross': exit_close / entry - 1})
print(f"3-factor trades: {len(holdings_3f)}")

# Mini backtest for F2 realistic
print("\n--- F2 realistic (80 stocks subset) ---")
formulas_f2 = lambda f, ts: wf.formula_2_main(f, ts)
holdings_f2 = []
for T in all_dates:
    picked = []
    for code in sample_codes:
        if code not in factors: continue
        f = factors[code]
        if T not in f['close'].index: continue
        if not formulas_f2(f, T): continue
        rps_v = wf._s(f, 'rps50', T)
        picked.append((code, rps_v if pd.notna(rps_v) else 50))
    picked.sort(key=lambda x: x[1], reverse=True)
    picked = picked[:20]
    for code, _ in picked:
        dd = daily.get(code)
        if dd is None or T not in dd.index: continue
        dd_sorted_idx = dd.index.searchsorted(T, side='left')
        if dd_sorted_idx >= len(dd) or dd.index[dd_sorted_idx] != T: continue
        entry = dd.iloc[dd_sorted_idx + 1]['open'] if dd_sorted_idx < len(dd) - 1 else dd.iloc[dd_sorted_idx]['close']
        if entry <= 0: continue
        exit_ts = T + pd.Timedelta(days=30)
        fut_idx = dd.index.searchsorted(exit_ts, side='left')
        if fut_idx < 0 or fut_idx >= len(dd): continue
        exit_close = dd.iloc[fut_idx]['close']
        if exit_close <= 0: continue
        gross = exit_close / entry - 1 - 0.002
        net = gross - 0.00232
        holdings_f2.append({'code': code, 'T': T, 'entry': entry, 'exit': exit_close, 'net': net,
                           'gross': exit_close / entry - 1})
print(f"F2 trades: {len(holdings_f2)}")

# Compare
if holdings_3f:
    df3 = pd.DataFrame(holdings_3f)
    print(f"\n3-factor net stats: mean={df3['net'].mean()*100:.2f}% median={df3['net'].median()*100:.2f}% max={df3['net'].max()*100:.2f}% min={df3['net'].min()*100:.2f}%")
    print("Top 10 net:")
    print(df3.nlargest(10, 'net')[['code','T','entry','exit','net']].to_string(index=False))
if holdings_f2:
    df2 = pd.DataFrame(holdings_f2)
    print(f"\nF2 net stats: mean={df2['net'].mean()*100:.2f}% median={df2['net'].median()*100:.2f}% max={df2['net'].max()*100:.2f}% min={df2['net'].min()*100:.2f}%")
