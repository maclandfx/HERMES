"""Diagnose F8 zero trades: count satisfaction of each blocking condition.
Uses the REAL formula_8_macd_tiered logic with computed factors."""
import pandas as pd, numpy as np, sys, os, time, struct
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)

# Factor computations (use real compute_weekly_factors, but skip RPS for speed)
# Instead compute factors inline for ~200 stocks
sample = [c for c in weekly if wf.is_eligible(c)][:200]
print(f"Sampling {len(sample)} eligible stocks")

# Benchmark for market_bull
bench_code = 'SH000300.SH'
bench = wf.load_benchmark(daily)
bweekly = wf.daily_to_weekly({bench_code: bench})
mbull = None; mbull_sz = None
if bench_code in bweekly:
    bw = bweekly[bench_code]
    if len(bw) >= 60:
        ma60 = bw['close'].rolling(60).mean()
        if pd.notna(ma60).sum() >= 10:
            ref_idx = weekly[list(weekly.keys())[0]].index
            mbull = (bw['close'] > ma60).map({True:1, False:0}).reindex(ref_idx).fillna(0)
            mbull_sz = mbull.copy()

# Compute factors inline (minimal set needed by F8)
t0 = time.time()
factors = {}
for code in sample:
    W = weekly[code]
    C = W['close']; H = W['high']; L = W['low']; O = W['open']; V = W['vol']
    AM = W.get('amount', pd.Series(1.0, index=W.index))
    try:
        f = {}
        # EMA/MACD
        EMA12 = C.ewm(span=12, adjust=False).mean()
        EMA26 = C.ewm(span=26, adjust=False).mean()
        dif = EMA12 - EMA26; dea = dif.ewm(span=9, adjust=False).mean()
        f['dif'] = dif; f['dea'] = dea
        f['macd_golden_wide'] = (dif > dea).astype(int)
        # MACD zero-axis tiering
        gc = (dif > dea) & (dif.shift(1) <= dea.shift(1))
        above_zero = (dea > 0); below_zero = (dea <= 0)
        f['v4_macd_strong'] = (gc & above_zero & (f['dea'] > 0)).astype(int)
        f['v4_macd_mid'] = (gc | above_zero).astype(int)
        f['v4_macd_bear'] = (gc & below_zero).astype(int)
        # MA
        f['ma5'] = C.rolling(5).mean()
        f['ma10'] = C.rolling(10).mean()
        f['ma20'] = C.rolling(20).mean()
        f['ma60'] = C.rolling(60).mean()
        f['close'] = C
        # DCZ
        mid = (C + O + ((H - L) / 4)) / 2
        f['DCZ'] = mid.ewm(span=20, adjust=False).mean()
        # avg_line
        f['avg_line'] = V.ewm(span=3, adjust=False).mean()
        # main_engage
        R0 = (C - C.shift(1)) / C.shift(1)
        f['v4_main_engage'] = ((R0 > 0) & (f['avg_line'] > f['avg_line'].shift(1))).astype(int)
        # 板块放量
        vol_ma5 = V.rolling(5).mean()
        code_str = str(code)
        if code_str.startswith('30'): thr = 1.8
        elif code_str.startswith('68'): thr = 2.2
        elif code_str.startswith(('43', '83', '92')): thr = 2.5
        else: thr = 2.0
        vol_rat20b = V / (vol_ma5 + 0.01)
        f['v4_vol_pass'] = (vol_rat20b > thr).astype(int)
        f['v4_vol_steady'] = (vol_rat20b > 1.3).astype(int)
        # 防骗
        f['v4_abnormal_vol'] = (vol_rat20b > 3).astype(int)
        upper_shadow = (H - C) / (C - L + 0.001)
        f['v4_long_upper'] = (upper_shadow > 0.6).astype(int)
        f['v4_safe_vol'] = (~((f['v4_abnormal_vol'] == 1) & (f['v4_long_upper'] == 1))).astype(int)
        # 趋势
        f['v4_trend_healthy'] = (f['ma20'] > f['ma20'].shift(5)).astype(int)
        f['v4_trend_hold'] = (C > f['ma20'] * 0.95).astype(int)
        f['v4_trend_weak_hold'] = (C > f['ma20'] * 0.90).astype(int)
        # 压力
        h30 = H.rolling(30).max()
        f['v4_pressure1'] = (C < h30 * 0.75).astype(int)
        f['v4_pressure2'] = (C < h30 * 0.80).astype(int)
        # 风控
        f['v4_risk_ctrl'] = ((C.notna().cumsum() > 52) & (V > 0)).astype(int)
        # 获利安全 - use winner_pct proxy (use close vs 52W high)
        h52 = H.rolling(52).max()
        f['winner_pct'] = ((C < h52).astype(int)) * 100  # simplified: if C<h52 then winner<100
        f['v4_profit_safe'] = (f['winner_pct'] < 70).astype(int)
        # 筹码集中 - placeholder (no real chip data)
        f['chip_spread'] = pd.Series(30, index=C.index)  # always concentrated
        f['v4_chip_concentrated'] = pd.Series(1, index=C.index, dtype=int)
        # market_bull
        f['market_bull'] = mbull if mbull is not None else pd.Series(1, index=C.index)
        f['market_bull_sz'] = mbull_sz if mbull_sz is not None else pd.Series(1, index=C.index)
        factors[code] = f
    except Exception as e:
        if len(factors) < 1:
            import traceback; traceback.print_exc()
        pass

print(f"Factors: {len(factors)} in {time.time()-t0:.1f}s")

# Count F8 conditions
from collections import Counter
bottleneck = Counter()
for code, f in factors.items():
    C = f['close']
    N = len(C)
    bottleneck['weeks'] += N
    # Each condition as evaluated in formula_8_macd_tiered
    bottleneck['main_engage'] += int((f['v4_main_engage'] == 1).sum())
    bottleneck['risk_ctrl'] += int((f['v4_risk_ctrl'] == 1).sum())
    bottleneck['profit_safe'] += int((f['v4_profit_safe'] == 1).sum())
    bottleneck['chip_conc'] += int((f['v4_chip_concentrated'] == 1).sum())
    bottleneck['safe_vol'] += int((f['v4_safe_vol'] == 1).sum())
    # MACD
    bottleneck['macd_strong'] += int((f['v4_macd_strong'] == 1).sum())
    bottleneck['macd_mid'] += int((f['v4_macd_mid'] == 1).sum())
    bottleneck['macd_bear'] += int((f['v4_macd_bear'] == 1).sum())
    # Pressure
    bottleneck['press1'] += int((f['v4_pressure1'] == 1).sum())
    bottleneck['press2'] += int((f['v4_pressure2'] == 1).sum())
    # Trend
    bottleneck['trend_healthy'] += int((f['v4_trend_healthy'] == 1).sum())
    bottleneck['trend_hold'] += int((f['v4_trend_hold'] == 1).sum())
    bottleneck['trend_weak'] += int((f['v4_trend_weak_hold'] == 1).sum())
    # Vol
    bottleneck['vol_pass'] += int((f['v4_vol_pass'] == 1).sum())
    bottleneck['vol_steady'] += int((f['v4_vol_steady'] == 1).sum())
    # F8 signals
    # Strong: main+risk+profit+chip+safe+macd_strong+vol_pass+trend_healthy+press1
    strong = (f['v4_main_engage']==1)&(f['v4_risk_ctrl']==1)&(f['v4_profit_safe']==1)&(f['v4_chip_concentrated']==1)&(f['v4_safe_vol']==1)&(f['v4_macd_strong']==1)&(f['v4_vol_pass']==1)&(f['v4_trend_healthy']==1)&(f['v4_pressure1']==1)
    # Steady: main+risk+profit+chip+safe+macd_mid+vol_steady+trend_hold+press2+avg<2.5
    steady = (f['v4_main_engage']==1)&(f['v4_risk_ctrl']==1)&(f['v4_profit_safe']==1)&(f['v4_chip_concentrated']==1)&(f['v4_safe_vol']==1)&(f['v4_macd_mid']==1)&(f['v4_vol_steady']==1)&(f['v4_trend_hold']==1)&(f['v4_pressure2']==1)&(pd.notna(f['avg_line'])&((f['avg_line']<2.5)))
    # Attack: main+risk+profit+chip+safe+macd_bear+(vol_pass|vol_steady)+trend_weak
    attack = (f['v4_main_engage']==1)&(f['v4_risk_ctrl']==1)&(f['v4_profit_safe']==1)&(f['v4_chip_concentrated']==1)&(f['v4_safe_vol']==1)&(f['v4_macd_bear']==1)&((f['v4_vol_pass']==1)|(f['v4_vol_steady']==1))&(f['v4_trend_weak_hold']==1)
    bottleneck['strong'] += int(strong.sum())
    bottleneck['steady'] += int(steady.sum())
    bottleneck['attack'] += int(attack.sum())
    bottleneck['f8'] += int((strong | steady | attack).sum())

N = bottleneck['weeks']
print(f"\nBottleneck ({len(factors)} stocks, {N} total weeks):")
print(f"{'factor':<20}{'count':>8}{'%':>8}")
for k in ['main_engage','risk_ctrl','profit_safe','chip_conc','safe_vol',
          'macd_strong','macd_mid','macd_bear',
          'trend_healthy','trend_hold','trend_weak',
          'press1','press2','vol_pass','vol_steady',
          'strong','steady','attack','f8']:
    if N > 0:
        print(f"{k:<20}{bottleneck[k]:>8}{100*bottleneck[k]/N:>7.1f}%")
