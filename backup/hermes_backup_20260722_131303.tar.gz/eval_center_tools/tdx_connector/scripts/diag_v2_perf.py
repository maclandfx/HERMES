"""快速验证v2.0因子计算性能——只跑100只"""
import os,struct,glob,pandas as pd,numpy as np,time
TDX='D:/TDX/vipdoc';DIV={'sh':1000,'sz':10}
def parse(p):
    with open(p,'rb') as f:r=f.read()
    if len(r)%32!=0:return pd.DataFrame()
    fn=os.path.basename(p);d=DIV['sh'] if fn.startswith('sh') else DIV['sz']
    rows=[]
    for i in range(len(r)//32):
        c=r[i*32:(i+1)*32];di=struct.unpack('<I',c[0:4])[0]
        try:ts=pd.Timestamp(di//10000,(di//100)%100,di%100)
        except:continue
        rows.append((ts,struct.unpack('<I',c[4:8])[0]/d,struct.unpack('<I',c[12:16])[0]/d,struct.unpack('<I',c[16:20])[0]/d,struct.unpack('<I',c[8:12])[0]/d,struct.unpack('<Q',c[20:28])[0]))
    return pd.DataFrame(rows,columns=['date','open','high','low','close','vol']).sort_values('date').set_index('date')
daily={};cnt=0
for fp in sorted(glob.glob(os.path.join(TDX,'sh','lday','*.day'))+glob.glob(os.path.join(TDX,'sz','lday','*.day'))):
    fn=os.path.basename(fp);code=fn[:-4];ts=code.upper()+('.SH' if 'sh' in code else '.SZ')
    df=parse(fp)
    if len(df)>60: daily[ts]=df;cnt+=1
    if cnt>=100: break
weekly={}
for code,df in daily.items():
    wd=df.groupby(df.index.to_period('W')).last();wd.index=wd.index.to_timestamp()
    if len(wd)>=30: weekly[code]=wd
print(f'100只, 因子计算:')
t=time.time()
for code,wd in weekly.items():
    C=wd['close'];H=wd['high'];L=wd['low'];V=wd['vol'];O=wd['open']
    f={}
    mid=(H+L)/2;f['DCZ']=mid.ewm(span=10,adjust=False).mean()
    ma20=C.rolling(20).mean();ma60=C.rolling(60).mean()
    f['ma_bull']=((C>ma20)&(C.rolling(5).mean()>C.rolling(10).mean())).astype(int)
    VV=V/(V.rolling(5).mean()+1e-4)
    R0=((C-C.shift(1))/(C.shift(1)+1e-4)*100)*VV
    R0a=abs(R0.shift(1))+abs(R0.shift(2))+abs(R0.shift(3))+abs(R0.shift(4))+abs(R0.shift(5))/2
    f['main_in_signal']=(R0>R0a).astype(int)
    f['DCZ_up']=(f['DCZ']>f['DCZ'].shift(3)).astype(int)
    f['winner_pct']=(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+1e-4)*100
    vol20=V.rolling(20).mean()
    f['vol_normal']=((V>vol20*1.2)&(V<vol20*2.5)).astype(int)
    ema12=C.ewm(span=12,adjust=False).mean();ema26=C.ewm(span=26,adjust=False).mean()
    dif=ema12-ema26;dea=dif.ewm(span=9,adjust=False).mean()
    vol_low=V<vol20*0.8;diverg=(C>C.shift(5))&(dif<dif.shift(5))
    f['macd_true_golden']=((dif>dea)&(dif.shift(1)<=dea.shift(1))&(~vol_low)&(~diverg)&(f['vol_normal'].astype(bool))).astype(int)
    H30=H.rolling(30).max();H60=H.rolling(60).max();H120=H.rolling(120).max();H250=H.rolling(250).max()
    light=(C>=H30*0.95)&(C<H60*0.92);mmid=(C>=H60*0.92)&(C<H120*0.88)
    heavy=(C>=H120*0.88)|(C>=H250*0.85)
    f['pressure_safe']=~(heavy|(light&mmid)).astype(bool)
    long_sh=(H-C)/(H-L+1e-4)>0.6
    f['anti_dump_safe']=~(V>=vol20*3).astype(bool)&(~long_sh).astype(bool)
    upper=(H-C)/(C+1e-4);vol5=V.rolling(5).mean()
    f['anti_lure_safe']=((upper<=0.05)|(V>vol5*0.6)).astype(bool)
    f['close']=C
print(f'100只耗时: {time.time()-t:.1f}s')
# 测试全6278只单一只
print('全量因子计算中, 5分钟后检查...')
t0=time.time()
factors={}
all_codes=list(weekly.keys())
print(f'总{len(all_codes)}只')
