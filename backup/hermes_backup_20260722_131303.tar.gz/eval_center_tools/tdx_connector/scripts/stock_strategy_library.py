"""
stock_strategy_library.py — 选股公式解析库 + 因子映射
===========================================
12个选股公式（5周线 + 7日线）的核心因子提取与策略分类
"""

# ════════════════════════════════════════════
# 周线选股公式（5个）
# ════════════════════════════════════════════

WEEKLY_STRATEGIES = {
    "周线主进ATR共振": {
        "label": "周线1-ATR共振",
        "cycle": "周线",
        "type": "右侧趋势跟踪",
        "core_factors": ["主力进", "大盘多头", "DCZ>REF(DCZ,5)", "VOL>MA(VOL,5)*1.5",
                         "C>DCZ", "C>=MA20", "ATR周线抬升", "日线ATR低位突破"],
        "signals": {
            "A级": "主力进 + 大盘多头 + DCZ>REF(DCZ,5) + 放量1.5倍 + 站上DCZ",
            "B级": "主力进 + DCZ>=REF(DCZ,3) + 平均线<2.3 + 花神红",
        },
        "unique_condition": "ATR周线抬升 + 日线ATR低位收缩后突破",
        "factor_keywords": ["主力进", "ATR共振", "20周线", "DCZ"],
    },

    "周线主进": {
        "label": "周线2-主进",
        "cycle": "周线",
        "type": "右侧趋势跟踪（无ATR约束）",
        "core_factors": ["主力进", "DCZ>=REF(DCZ,3)", "C>=MA20", "C>=DCZ"],
        "signals": {
            "A级": "主力进 + 大盘多头 + DCZ>REF(DCZ,5) + 放量 + 站上DCZ",
            "B级": "主力进 + DCZ>=REF(DCZ,3) + 平均线<2.3 + 花神红",
        },
        "unique_condition": "与周线1相同但无ATR共振，范围更宽",
        "factor_keywords": ["主力进", "20周线", "DCZ"],
    },

    "周线战略伏击": {
        "label": "周线3-战略伏击",
        "cycle": "周线",
        "type": "左侧潜伏（洗盘后勾头）",
        "core_factors": ["DIF Z-score核心趋势<45", "量能摆动冰点(3周内<38)",
                         "核心趋势勾头", "WINNER>35%", "12周战略建仓(>8%+>5周量1.5倍)",
                         "C>MA45且>MA90", "C>MA30且>MA60"],
        "signals": {
            "战略引爆": "12周内出现周K线>8%涨幅 + 周量>5周均量1.5倍",
            "洗盘企稳": "核心趋势<45 + 量能冰点 + 趋势勾头",
        },
        "unique_condition": "DIF Z-score标准化模型 + 战略建仓雷达 + 筹码安全",
        "factor_keywords": ["DIF_Z", "WINNER", "战略建仓", "洗盘勾头"],
    },

    "周线普及版": {
        "label": "周线4-普及版",
        "cycle": "周线",
        "type": "底部反弹（放宽版）",
        "core_factors": ["个股趋势CROSS散户动能", "个股趋势<45",
                         "周换手>4%", "上市>30周"],
        "signals": {
            "TJ1": "CROSS(个股趋势,散户动能) AND 个股趋势<45",
            "TJ2": "周换手>4%",
            "TJ3": "上市>30周",
        },
        "unique_condition": "放宽版（趋势金叉从30放宽到45，取消换手上限）",
        "factor_keywords": ["趋势金叉", "换手4%", "上市30周"],
    },

    "周线价格波动线": {
        "label": "周线5-波动线",
        "cycle": "周线",
        "type": "右侧趋势（多指标共振）",
        "core_factors": ["周平均线拐头", "量能温和递增(VOL>MA5且<MA5*3)",
                         "MACD金叉(DIF>DEA且DIF<0.5)", "KDJ多头(K>D)",
                         "花神红", "C>MA20且MA5>MA10", "C>MA60",
                         "非高位(平均线<2.5)", "无长上影(<40%)", "实体占优(>50%)", "非ST"],
        "signals": {
            "拐头": "周平均线>=REF(周平均线,1) AND REF(周平均线,1)<REF(周平均线,2)",
            "量能递增": "本周放量且过去两周温和放大",
            "金叉共振": "MACD低位金叉 + KDJ多头",
        },
        "unique_condition": "MACD低位金叉 + KDJ顺向多头 + 多指标共振 + 形态过滤",
        "factor_keywords": ["平均线拐头", "MACD金叉", "KDJ多头", "60周线", "非高位"],
    },
}


# ════════════════════════════════════════════
# 日线选股公式（7个）
# ════════════════════════════════════════════

DAILY_STRATEGIES = {
    "手动挡控制台": {
        "label": "日线1-手动挡",
        "cycle": "日线",
        "type": "强势主线追踪（可调参数）",
        "core_factors": ["强势主线(RPS_S>5%或RPS_L>8%)", "筹码重叠<8%",
                         "MA20趋势", "C>MA20*0.98", "C>DCZ*0.98",
                         "L<=MA20*1.015且C>=DCZ*0.96",
                         "动态量比>0.9", "动态换手>0.9",
                         "分时均价支撑", "日线超短修复(EMA3>EMA5)",
                         "非ST非北交", "上市>30天", "股东人数未暴增"],
        "parameters": {
            "M_RPS_S": "0.05(5%)，轮动快调0.03，主线抱团调0.08",
            "M_RPS_L": "0.08(8%)，120日跑赢大盘阈值",
            "M_OVERLAP": "8.0(8%)，筹码重叠度，宽幅洗盘调12，窄幅调5",
            "M_LB": "0.9，动态量比门槛，极度缩量调0.7",
            "M_HS": "0.9，动态换手率门槛",
        },
        "unique_condition": "高速筹码算法(DCZ=天量K线CLOSE)替代COST，速度快百倍",
        "factor_keywords": ["RPS强势", "筹码重叠", "动态量比", "分时均价", "股东人数"],
    },

    "铁血精选": {
        "label": "日线2-铁血精选",
        "cycle": "日线",
        "type": "右侧爆发（大资金+资金攻击+主力进）",
        "core_factors": ["大资金多头(散户红+游资红+机构红+主力红+QX>0)",
                         "资金攻击(DF2>5%+DF3>4%+DCZ_UP+MA20_UP+C>MA20+VOL_UP)",
                         "主力进(R0+平均线拐点)", "行业主线", "大盘多头",
                         "A级/B级信号"],
        "signals": {
            "A级": "主力进 + 行业主线 + 大盘多头 + DCZ>REF(DCZ,5) + 放量 + 站上DCZ",
            "B级": "主力进 + 行业多头 + DCZ>=REF(DCZ,3) + 平均线<2.3 + 花神红",
        },
        "unique_condition": "四层均线全红 + 资金攻击 + 主力进A/B级",
        "factor_keywords": ["四层全红", "QX", "资金攻击", "主力进", "行业主线"],
    },

    "金牌狙击": {
        "label": "日线3-金牌狙击",
        "cycle": "日线",
        "type": "右侧爆发 + 左侧超跌反弹",
        "core_factors": ["大资金多头(机构红+主力红+QX>0)",
                         "资金攻击(DF2>5%+DF3>4%+DCZ_UP+MA20_UP+C>MA20+VOL_UP)",
                         "必涨(CROSS(LOW, BZTD=5日均线*89%))"],
        "signals": {
            "短线引爆": "资金攻击 OR 必涨(左侧超跌回踩BZTD触发)",
        },
        "unique_condition": "大资金多头 + (资金攻击 OR 必涨左侧超跌反弹)",
        "factor_keywords": ["大资金多头", "资金攻击", "必涨CROSS", "BZTD=5日均*89%"],
    },

    "四维共振起爆": {
        "label": "日线4-四维共振",
        "cycle": "日线",
        "type": "右侧趋势（四层均线+主力强入）",
        "core_factors": ["四层全红(散户+游资+机构+主力)",
                         "黄线上行(QX>REF(QX,1))",
                         "主力进(R0>0+平均线拐点)", "行业主线", "大盘多头",
                         "A级/B级信号"],
        "signals": {
            "A级": "主力进 + 行业主线 + 大盘多头 + DCZ>REF(DCZ,5) + 放量 + 站上DCZ",
            "B级": "主力进 + 行业多头 + DCZ>=REF(DCZ,3) + 平均线<2.3 + 花神红",
        },
        "unique_condition": "四层均线 + 黄线上行 + 主力强入A/B级",
        "factor_keywords": ["四层全红", "黄线上行", "主力强入", "行业主线"],
    },

    "底部控盘必胜版": {
        "label": "日线4-底部控盘(手机版)",
        "cycle": "日线",
        "type": "左侧超跌反弹（底部金叉）",
        "core_factors": ["相对价位", "个股趋势(60日相对趋势EMA3)",
                         "CROSS(个股趋势,散户动能) AND 个股趋势<35",
                         "半年价位<25%", "换手2.5%-8%", "上市>250天"],
        "signals": {
            "TJ1": "CROSS(个股趋势,散户动能) AND 个股趋势<35（底部金叉）",
            "TJ2": "半年价位<25%（处于半年低位）",
            "TJ3": "换手2.5%-8%（非地量非爆量）",
            "TJ4": "上市>250天（排除新股）",
        },
        "unique_condition": "60日相对趋势金叉 + 半年低位 + 适中换手",
        "factor_keywords": ["相对价位", "个股趋势金叉", "半年低位", "换手2.5-8%"],
    },

    "适度严格狙击": {
        "label": "日线5-适度严格狙击",
        "cycle": "日线",
        "type": "右侧爆发（铁血精选+主力进确认）",
        "core_factors": ["大资金多头(散户+游资+机构+主力+QX>0)",
                         "资金攻击(DF2>5%+DF3>4%+DCZ_UP+MA20_UP+C>MA20+VOL_UP)",
                         "主力进(R0+平均线拐点)", "平均线<2.5(防追高)", "花神红"],
        "signals": {
            "适度主力": "主力进 + 平均线<2.5 + 花神红",
        },
        "unique_condition": "铁血精选 + 主力进确认 + 平均线<2.5 + 花神红",
        "factor_keywords": ["大资金多头", "资金攻击", "主力进", "平均线<2.5", "花神红"],
    },

    "口袋支点": {
        "label": "日线6-口袋支点",
        "cycle": "日线",
        "type": "强势突破（RPS+放量阳线）",
        "core_factors": ["RPS120>=90 OR RPS250>=90 OR RPS50>=90",
                         "V>MA(V,10)*2（放量2倍）", "C>O（收阳）",
                         "MA多头(5>10>20>50)", "C>MA20"],
        "signals": {
            "口袋支点": "RPS强 + 放量2倍阳线 + 均线多头 + 站上20线",
        },
        "unique_condition": "RPS强者 + 放量阳线 + 均线多头 + 站上20线",
        "factor_keywords": ["RPS>=90", "放量2倍", "收阳", "MA多头", "站上20线"],
    },

    "强主进": {
        "label": "日线7-强主进",
        "cycle": "日线",
        "type": "右侧爆发（主力进+行业主线+大盘多头）",
        "core_factors": ["主力进(R0>0+平均线拐点)", "行业主线", "大盘多头",
                         "DCZ升(>REF(DCZ,5))", "站上DCZ", "放量", "花神红"],
        "signals": {
            "强主进": "主力进 + 行业主线 + 大盘多头 + DCZ升 + 放量 + 站上DCZ + 花神红",
        },
        "unique_condition": "主力进 + 行业主线 + 大盘多头 + DCZ升 + 放量 + 花神红",
        "factor_keywords": ["主力进", "行业主线", "大盘多头", "DCZ升", "放量", "花神红"],
    },
}


# ════════════════════════════════════════════
# 统一策略注册表
# ════════════════════════════════════════════

ALL_STRATEGIES = {}
ALL_STRATEGIES.update(WEEKLY_STRATEGIES)
ALL_STRATEGIES.update(DAILY_STRATEGIES)


# ════════════════════════════════════════════
# 因子→策略反向映射
# ════════════════════════════════════════════

def get_strategies_by_factor(keyword):
    """根据因子关键词查找包含该因子的所有策略"""
    results = []
    for name, info in ALL_STRATEGIES.items():
        for kw in info.get("factor_keywords", []):
            if keyword.lower() in kw.lower() or kw.lower() in keyword.lower():
                results.append((name, kw, info))
                break
    return results


def get_strategies_by_type(strategy_type):
    """按类型筛选策略"""
    return {n: v for n, v in ALL_STRATEGIES.items() if v.get("type", "") == strategy_type}


def get_weekly_strategies():
    return WEEKLY_STRATEGIES


def get_daily_strategies():
    return DAILY_STRATEGIES


# ════════════════════════════════════════════
# 判断标的属于哪个策略（基于因子特征匹配）
# ════════════════════════════════════════════

def classify_stock_by_factors(stock_factors, stock_market=None):
    """
    基于因子值判断股票最可能属于哪个选股策略。
    返回策略列表（按匹配度排序）。
    """
    matches = []
    
    for name, info in ALL_STRATEGIES.items():
        score = 0
        keywords = info.get("factor_keywords", [])
        
        for kw in keywords:
            # 因子名匹配
            if kw in stock_factors:
                val = stock_factors[kw]
                if val is not None and val > 50:
                    score += 2
                elif val is not None:
                    score += 1
            
            # 特征词匹配
            kw_lower = kw.lower()
            if "主力进" in kw_lower:
                if stock_factors.get("A1_big_net_ratio", 0) > 50 or stock_factors.get("A3_strength", 0) > 50:
                    score += 2
            if "DCZ" in kw_lower or "筹码" in kw_lower:
                if stock_factors.get("B3_gap", 0) > 40:
                    score += 1
            if "趋势" in kw_lower:
                if stock_factors.get("B5_trend", 0) > 50:
                    score += 2
            if "量" in kw_lower or "VOL" in kw_lower:
                if stock_factors.get("A1_big_net_ratio", 0) > 40:
                    score += 1
            if "相对强弱" in kw_lower or "RPS" in kw_lower:
                if stock_factors.get("B4_rel_strength", 0) > 50:
                    score += 2
            if "换手" in kw_lower:
                score += 0.5  # 需要成交量数据
            if "金叉" in kw_lower or "CROSS" in kw_lower:
                score += 0.5
            if "非高位" in kw_lower or "平均线<2" in kw_lower:
                score += 1
        
        if score > 0:
            matches.append((name, score, info))
    
    matches.sort(key=lambda x: -x[1])
    return matches


if __name__ == "__main__":
    print("选股公式库加载完成")
    print(f"周线策略: {len(WEEKLY_STRATEGIES)} 个")
    print(f"日线策略: {len(DAILY_STRATEGIES)} 个")
    print(f"合计: {len(ALL_STRATEGIES)} 个")
    
    # 测试因子匹配
    for keyword in ["主力进", "DCZ", "趋势", "RPS", "换手"]:
        results = get_strategies_by_factor(keyword)
        print(f"\n包含 [{keyword}] 的策略:")
        for name, kw, info in results:
            print(f"  {name}: {kw}")
