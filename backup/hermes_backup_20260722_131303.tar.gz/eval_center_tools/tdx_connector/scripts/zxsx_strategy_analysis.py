"""
zxsx_strategy_analysis.py — 周线手选策略因子对照分析
==================================================
用途：对比12个选股公式的核心因子 vs 实际有效因子，
     告诉用户哪个公式质量高、哪些因子该加进公式

使用方式：
  import zxsx_strategy_analysis as sa
  sa.analyze(snapshots_data, factor_correlation_results)
"""
import sys
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')

# 因子→公式映射表（每个公式的核心因子关键词）
STRATEGY_FACTORS = {
    # 周线公式
    "周线1-ATR共振": ["主力进", "DCZ", "20周线", "ATR", "大盘多头", "放量"],
    "周线2-主进": ["主力进", "DCZ", "20周线", "大盘多头", "放量", "花神红"],
    "周线3-战略伏击": ["DIF_Z", "WINNER", "战略建仓", "洗盘勾头", "趋势低位"],
    "周线4-普及版": ["趋势金叉", "换手4%", "上市30周"],
    "周线5-波动线": ["平均线拐头", "MACD金叉", "KDJ多头", "60周线", "非高位"],
    # 日线公式
    "日线1-手动挡": ["RPS", "筹码重叠", "动态量比", "分时均价", "股东人数"],
    "日线2-铁血精选": ["四层全红", "QX", "资金攻击", "主力进", "行业主线"],
    "日线3-金牌狙击": ["大资金多头", "资金攻击", "必涨CROSS", "BZTD"],
    "日线4-四维共振": ["四层全红", "黄线上行", "主力强入", "行业主线"],
    "日线4-底部控盘": ["相对价位", "趋势金叉", "半年低位", "换手2.5-8%"],
    "日线5-适度严格狙击": ["大资金多头", "资金攻击", "主力进", "平均线<2.5"],
    "日线6-口袋支点": ["RPS>=90", "放量2倍", "收阳", "MA多头"],
    "日线7-强主进": ["主力进", "行业主线", "大盘多头", "DCZ升", "放量", "花神红"],
}

# 因子名→因子库关键词映射
FACTOR_TO_KEYWORD = {
    "A1_big_net_ratio": ["主力进", "资金攻击", "放量"],
    "A2_consecutive_days": ["主力进"],
    "A3_strength": ["资金攻击", "主力进"],
    "A4_north_flow": [],
    "B1_divergence": ["趋势金叉", "筹码重叠", "量能"],
    "B2_limit_quality": [],
    "B3_gap": ["DCZ", "筹码", "放量"],
    "B4_rel_strength": ["RPS", "相对价位"],
    "B5_trend": ["趋势", "20周线", "MA多头", "60周线", "非高位"],
    "B6_volatility": ["ATR", "换手", "波动"],
}


def match_factor_to_strategies(factor_name):
    """找出哪个策略用了这个因子"""
    keyword = FACTOR_TO_KEYWORD.get(factor_name, [])
    matches = []
    for strategy, factors in STRATEGY_FACTORS.items():
        for f in factors:
            if f in keyword:
                matches.append((strategy, f))
                break
    return matches


def analyze_formula_quality(factor_correlation):
    """
    分析各选股公式的质量。
    方法：每个公式的核心因子在有效因子集合中的覆盖率。
    """
    if not factor_correlation:
        return {}

    # 找出所有有效因子（rho显著 or |rho|>0.1）
    effective_factors = {}
    for fk, days in factor_correlation.items():
        for d, info in days.items():
            rho = info.get('rho')
            if rho and abs(rho) > 0.1:
                effective_factors[fk] = info

    # 每个策略的因子在有效因子中的覆盖率
    results = {}
    for strategy, factor_keywords in STRATEGY_FACTORS.items():
        matched = 0
        for fk, days in factor_correlation.items():
            kw_match = FACTOR_TO_KEYWORD.get(fk, [])
            for fkw in factor_keywords:
                for kw in kw_match:
                    if fkw in kw or kw in fkw:
                        # 检查是否有显著相关性
                        for d, info in days.items():
                            if info.get('rho') and abs(info['rho']) > 0.1:
                                matched += 1
                                break
        total = len(factor_keywords)
        coverage = matched / total if total > 0 else 0
        results[strategy] = {
            'matched_factors': matched,
            'total_factors': total,
            'coverage': round(coverage * 100, 1),
            'keywords': factor_keywords,
        }

    return results


def suggest_new_factors(factor_correlation):
    """
    找出有效但未被任何公式使用的因子，建议加进选股公式。
    """
    if not factor_correlation:
        return []

    used_keywords = set()
    for keywords in STRATEGY_FACTORS.values():
        used_keywords.update(keywords)

    suggestions = []
    for fk, days in factor_correlation.items():
        # 检查这个因子是否已经在公式中
        kw_match = FACTOR_TO_KEYWORD.get(fk, [])
        is_used = False
        for kw in kw_match:
            for used in used_keywords:
                if kw in used or used in kw:
                    is_used = True
                    break
            if is_used:
                break

        if is_used:
            continue

        # 找这个因子的最强相关性
        best = None
        for d, info in days.items():
            rho = info.get('rho')
            if rho and (best is None or abs(rho) > abs(best)):
                best = info

        if best and abs(best.get('rho', 0)) > 0.1:
            suggestions.append({
                'factor': fk,
                'best_rho': best.get('rho'),
                'best_day': best.get('day', 'unknown'),
                'factor_keywords': kw_match,
            })

    return suggestions


def generate_report(factor_correlation, snapshots_data=None):
    """生成策略因子对照分析报告"""
    lines = []
    lines.append('# 周线手选 — 策略因子对照分析报告')
    lines.append('')

    # 1. 策略质量评估
    formula_quality = analyze_formula_quality(factor_correlation)
    if formula_quality:
        lines.append('## 选股公式质量评估')
        lines.append('')
        lines.append('（基于因子在有效因子集合中的覆盖率）')
        lines.append('')
        lines.append('| 公式 | 匹配因子/总因子 | 覆盖率 |')
        lines.append('|------|---------------|--------|')
        for name, info in sorted(formula_quality.items(),
                                 key=lambda x: -x[1]['coverage']):
            lines.append(f'| {name} | {info["matched_factors"]}/{info["total_factors"]} | {info["coverage"]}% |')
    else:
        lines.append('## 选股公式质量评估')
        lines.append('')
        lines.append('数据不足')
        lines.append('')

    # 2. 有效因子 vs 公式因子
    if factor_correlation:
        lines.append('')
        lines.append('## 当前有效因子（与收益相关）')
        lines.append('')
        lines.append('| 因子 | 有效策略 | 最强rho |')
        lines.append('|------|---------|---------|')
        for fk, days in sorted(factor_correlation.items(),
                               key=lambda x: max(abs(v.get('rho', 0) or 0) for v in x[1].values()),
                               reverse=True):
            best_rho = max(days.values(), key=lambda x: abs(x.get('rho', 0) or 0))
            best_day = best_rho.get('day', '?')
            best_val = best_rho.get('rho', 0)
            matched = match_factor_to_strategies(fk)
            if matched:
                matched_str = ', '.join([f'{n}({k})' for n, k in matched])
            else:
                matched_str = '无公式使用'
            lines.append(f'| {fk} | {matched_str} | {best_val:+.3f}({best_day}) |')

    # 3. 建议新增因子
    suggestions = suggest_new_factors(factor_correlation)
    if suggestions:
        lines.append('')
        lines.append('## 建议新增到选股公式的因子')
        lines.append('')
        for s in suggestions:
            lines.append(f'- **{s["factor"]}**: rho={s["best_rho"]:+.3f}({s["best_day"]})')

    return '\n'.join(lines)


if __name__ == '__main__':
    print("策略分析模块加载完成")
    print(f"策略数: {len(STRATEGY_FACTORS)}")
    print(f"因子映射: {len(FACTOR_TO_KEYWORD)}")
