# -*- coding: utf-8 -*-
"""
weekly_formula_backtest.py — 通达信周线选股公式回测器
======================================================
把通达信周线选股公式(5个)逐个跑回测，与3因子组合横向对比。

回测规则(全部统一，便于横向比较)：
  - 周期: 周线选股，周一收盘价信号 → 下周一按收盘价买入，持 30 交易日后卖出
  - 候选数: 每周取满足公式条件的全部股票，按排序分取 top_k 只
  - 成本: 0.232%/轮
  - 涨跌停: 涨停买不进，跌停卖不出
  - 过滤: 自动去 ST/*ST/SST，去北交所，去指数
  - 基准: 沪深300 (sh000300)

通达信 → pandas 翻译要点:
  - COST(X) 成本分布 → 近似用 滚动区间中位价位
  - EXIST(cond, N) → rolling(N).max() (条件转布尔1/0)
  - REF(X,N) → X.shift(N)
  - CROSS(A,B) → (A>B) & (A.shift(1)<=B.shift(1))
  - SMA(X,N,M) → 用 ewm span=N，近似通达信SMA
  - INDEXC → 沪深300周线收盘价(代理大盘)
  - 花神红 EMA(C,3)>EMA(C,7) → pandas ewm
  - FINANCE(7)=流通股本 → 无数据，公式4(TJ2换手率)需跳过或用总量近似
"""
import os, sys, struct, glob, math, time, re
from datetime import datetime

import pandas as pd
import numpy as np

# ============ 路径与解析 ============
TDX_BASE = 'D:/TDX/vipdoc'
DIV = {'sh': 1000, 'sz': 10, 'bj': 100}

LIMIT = 0.0995  # 涨跌停阈值（主板默认）
COST_RATE = 0.00232  # 交易成本/轮

# 涨停板规则：按代码前6位区分
LIMIT_RULES = {
    '002': 0.20,   # 创业板20%
    '300': 0.20,   # 创业板
    '301': 0.20,   # 创业板
    '688': 0.20,   # 科创板
    '835': 0.30,   # 北交所
    '870': 0.30,   # 北交所
    '430': 0.30,   # 新三板
    '831': 0.30,   # 北交所
    '832': 0.30,   # 北交所
    '833': 0.30,   # 北交所
    '834': 0.30,   # 北交所
    '836': 0.30,   # 北交所
    '837': 0.30,   # 北交所
    '838': 0.30,   # 北交所
    '839': 0.30,   # 北交所
}
def get_limit_ratio(code):
    """返回股票涨跌停比例: 创业板20%, 北交所30%, 其他9.95%"""
    code_upper = code.upper()
    d = code_upper[2:5] if len(code_upper) >= 5 else code_upper[2:]
    for prefix, ratio in LIMIT_RULES.items():
        if d.startswith(prefix):
            return ratio
    return LIMIT  # 主板默认9.95%

EXCLUDE_MARKETS = ('.BJ',)  # 去北交所
ST_RE = re.compile(r'[ST\*ST\SST]', re.IGNORECASE)

def parse_day_file(path):
    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except Exception:
        return pd.DataFrame()
    if len(raw) % 32 != 0 or len(raw) < 32:
        return pd.DataFrame()
    n = len(raw) // 32
    fn = os.path.basename(path)
    if fn.startswith('sh'): market = 'sh'
    elif fn.startswith('sz'): market = 'sz'
    elif fn.startswith('bj'): market = 'bj'
    else: return pd.DataFrame()
    d = DIV.get(market, 1000)
    rows = []
    for i in range(n):
        chunk = raw[i*32:(i+1)*32]
        di = struct.unpack('<I', chunk[0:4])[0]
        try:
            ts = pd.Timestamp(di // 10000, (di // 10) % 100, di % 100)
        except ValueError:
            continue
        o = struct.unpack('<I', chunk[4:8])[0] / d
        c = struct.unpack('<I', chunk[8:12])[0] / d
        h = struct.unpack('<I', chunk[12:16])[0] / d
        l = struct.unpack('<I', chunk[16:20])[0] / d
        v = struct.unpack('<Q', chunk[20:28])[0]
        rows.append((ts, o, h, l, c, v))
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows, columns=['trade_date','open','high','low','close','vol'])
    return df.sort_values('trade_date').set_index('trade_date')

def load_all_daily():
    data = {}
    t0 = time.time()
    count = 0
    for m in ('sh', 'sz', 'bj'):
        pattern = os.path.join(TDX_BASE, m, 'lday', '*.day')
        for fp in sorted(glob.glob(pattern)):
            fn = os.path.basename(fp)
            code = fn[:-4]
            ts_code = code.upper() + ({'sh':'.SH','sz':'.SZ','bj':'.BJ'}[m])
            df = parse_day_file(fp)
            if len(df) < 60:
                continue
            data[ts_code] = df
            count += 1
            if count % 1000 == 0:
                print(f'  日K进度: {count}, 耗时 {time.time()-t0:.0f}s', flush=True)
    print(f'  有效: {count} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return data

def daily_to_weekly(daily_dict):
    weekly = {}
    for code, df in daily_dict.items():
        try:
            wd = df.groupby(df.index.to_period('W')).last()
            wd.index = wd.index.to_timestamp()
            wd = wd[['open','high','low','close','vol']]
            if len(wd) >= 30:
                weekly[code] = wd
        except Exception:
            pass
    return weekly

def is_eligible(code):
    if any(code.upper().endswith(m) for m in EXCLUDE_MARKETS):
        return False
    code_upper = code.upper()
    if code_upper.startswith('SH') or code_upper.startswith('SZ'):
        d = code_upper[2:8]
        # 排除主要指数
        if d in ('000001','000300','399001','399006','399106','399107','399300','000016','000688','399005','399673','399675','000002','000003','000004','000005','000006','000007','000008','000009'):
            return False
        # 排除88xxxx/399xxx/000xxx类指数(非A股个股)
        if d.startswith('88') or d.startswith('399'):
            return False
    return True

def load_benchmark(daily_dict):
    for key, df in daily_dict.items():
        if '000300' in key.upper():
            return df
    for key, df in daily_dict.items():
        if '000016' in key.upper():
            return df
    return None

# ============ 周线因子计算(全局，所有公式共享) ============
def compute_weekly_factors(weekly_dict):
    """为所有周线公式计算共享因子: code -> {factor_name: pd.Series}"""
    t0 = time.time()
    all_codes = list(weekly_dict.keys())
    print(f'  计算周线因子, {len(all_codes)} 只...', flush=True)

    # 1) 全市场RPS（周收盘价 rank）
    price_records = []
    for code, df in weekly_dict.items():
        for d, c in df['close'].items():
            if c and c > 0:
                price_records.append((code, d, c))
    pivot = pd.DataFrame(price_records, columns=['code','date','close']) \
            .pivot(index='code', columns='date', values='close')
    rps = pivot.rank(axis=1, pct=True, method='average') * 100

    # 2) 大盘周线(沪深300 代理 INDEXC) + 双指数(上证+深成指)
    idx_df = None
    idx_sz = None
    for key in ('SH000300.SH', 'SZ399001.SZ'):
        if key in weekly_dict:
            idx_df = weekly_dict[key]['close']
            break
    for key in ('SZ399001.SZ', 'SZ399300.SZ'):
        if key in weekly_dict:
            idx_sz = weekly_dict[key]['close']
            break
    if idx_df is not None and len(idx_df) > 0:
        idx_ma60 = idx_df.rolling(60).mean()
        if idx_ma60.notna().sum() < 10:
            idx_ma60 = idx_df.rolling(30).mean()
        market_bull_vals = ((idx_df > idx_ma60) & (idx_ma60 > idx_ma60.shift(5))).astype(int).values
        if idx_sz is not None and len(idx_sz) > 0:
            sz_ma60 = idx_sz.rolling(60).mean()
            if sz_ma60.notna().sum() < 10:
                sz_ma60 = idx_sz.rolling(30).mean()
            market_bull_sz_vals = ((idx_sz > sz_ma60) & (sz_ma60 > sz_ma60.shift(5))).astype(int).values
        else:
            market_bull_sz_vals = None
    else:
        market_bull_vals = None
        market_bull_sz_vals = None
        print('  [WARN] 大盘周线缺失', flush=True)

    factors = {}
    for code, df in weekly_dict.items():
        try:
            C = df['close']; H = df['high']; L = df['low']; O = df['open']; V = df['vol']
            f = {}
            # 均线
            f['ma5'] = C.rolling(5).mean()
            f['ma10'] = C.rolling(10).mean()
            f['ma20'] = C.rolling(20).mean()
            f['ma30'] = C.rolling(30).mean()
            f['ma45'] = C.rolling(45).mean()
            f['ma60'] = C.rolling(60).mean()
            f['ma90'] = C.rolling(90).mean()
            # MACD
            ema12 = C.ewm(span=12, adjust=False).mean()
            ema26 = C.ewm(span=26, adjust=False).mean()
            dif = ema12 - ema26
            f['dif'] = dif; f['dea'] = dif.ewm(span=9, adjust=False).mean()
            # MACD金叉(宽松版): DIF>DEA 维持原有
            f['macd_golden_wide'] = (dif > f['dea']).astype(int)
            # MACD金叉(优化版-F6): CROSS(DIF,DEA) OR (DIF>DEA AND REF(DIF,1)<=REF(DEA,1))
            f['macd_cross'] = ((dif > f['dea']) & (dif.shift(1) <= f['dea'].shift(1))).astype(int)
            # KDJ
            LL9 = L.rolling(9).min(); HH9 = H.rolling(9).max()
            RSV = (C - LL9) / (HH9 - LL9 + 0.0001) * 100
            f['kdj_K'] = RSV.ewm(span=3, adjust=False).mean()
            f['kdj_D'] = f['kdj_K'].ewm(span=3, adjust=False).mean()
            # 花神红
            f['huashen'] = (C.ewm(span=3, adjust=False).mean() > C.ewm(span=7, adjust=False).mean()).astype(int)
            f['huashen_p1'] = ((C+1).ewm(span=3, adjust=False).mean() > (C+1).ewm(span=7, adjust=False).mean()).astype(int)
            # R0 主力进
            VV = V / (V.rolling(5).mean() + 0.0001)
            R0 = ((C - C.shift(1)) / (C.shift(1) + 0.0001) * 100) * VV
            R0_abs_sum = (abs(R0.shift(1)) + abs(R0.shift(2)) + abs(R0.shift(3)) + abs(R0.shift(4)) + abs(R0.shift(5))/2)
            f['R0'] = R0; f['main_in_signal'] = (R0 > R0_abs_sum).astype(int)
            # === v2.0防骗优化版因子(纯OHLCV部分) ===
            # 防骗1: 上方压力识别
            H30 = H.rolling(30).max(); H60 = H.rolling(60).max()
            H120 = H.rolling(120).max(); H250 = H.rolling(250).max()
            f['pressure_light'] = ((C >= H30*0.95) & (C < H60*0.92)).astype(int)
            f['pressure_mid'] = ((C >= H60*0.92) & (C < H120*0.88)).astype(int)
            f['pressure_heavy'] = ((C >= H120*0.88) | (C >= H250*0.85)).astype(int)
            f['pressure_safe'] = ((~(f['pressure_heavy'].astype(bool))) &
                                   ~(f['pressure_light'].astype(bool) & f['pressure_mid'].astype(bool))).astype(int)
            # 防骗2: 对倒行为识别
            vol20 = V.rolling(20).mean()
            vol5 = V.rolling(5).mean()
            f['vol_normal'] = ((V > vol20*1.2) & (V < vol20*2.5)).astype(int)
            f['vol_dump'] = (V >= vol20*3).astype(int)
            f['vol_shrink'] = (V <= vol20*0.7).astype(int)
            price_up_vol_down = (C > C.shift(1)) & (V < V.shift(1)*0.8)
            open_strong_close_weak = (O > C.shift(1)*1.03) & (C < O*0.99)
            long_upper_shadow = ((H-C) / (H-L+0.0001) > 0.6)
            f['anti_dump_safe'] = ((~f['vol_dump'].astype(bool)) &
                                    (~long_upper_shadow)).astype(int)  # 核心: 无对倒放量+无长上影
            # 防骗3: 分时诱多（周线上影代理）
            upper_shadow_week = (H-C) / (C + 0.0001)
            f['anti_lure_safe'] = ((upper_shadow_week <= 0.05) | (V > vol5*0.6)).astype(int)
            # 防骗4: MACD假金叉(纯OHLCV部分)
            vol20_f = V.rolling(20).mean()
            vol5_f = V.rolling(5).mean()
            low_energy = (V < vol20_f*0.8)
            price_up_divergence = (C > C.shift(5)) & (f['dif'] < f['dif'].shift(5))
            f['vol_low_energy'] = low_energy.astype(int)
            f['macd_weak_golden'] = ((f['dif'] < 0) & (f['dea'] < 0)).astype(int)
            # 这两项依赖f['vol_normal']已赋值和f['dif']已赋值
            f['vol_normal'] = ((V > vol20_f*1.2) & (V < vol20_f*2.5)).astype(int)
            f['macd_true_golden'] = ((f['dif'] > f['dea']) & (f['dif'].shift(1) <= f['dea'].shift(1)) &
                                      (~low_energy) &
                                      (~price_up_divergence) &
                                      f['vol_normal'].astype(bool)).astype(int)
            f['macd_bull'] = ((f['dif'] > f['dea']) & (f['dif'] > 0) & (f['dea'] > 0)).astype(int)
            # 公式2/3/4/5 共用
            ma5=C.rolling(5).mean(); ma20=C.rolling(20).mean(); ma30=C.rolling(30).mean()
            ma45=C.rolling(45).mean(); ma60=C.rolling(60).mean()
            ma10=C.rolling(10).mean()
            # DCZ 近似: 周中价(高+低)/2 的10周EWM，落在真实价格区间内
            mid = (H + L) / 2
            f['DCZ'] = mid.ewm(span=10, adjust=False).mean()
            # 波动线/平均线(公式1/2)
            mn10 = L.rolling(10).min(); mx25 = H.rolling(25).max()
            wave = (((C - mn10) / (mx25 - mn10 + 0.0001)) * 4).ewm(span=4, adjust=False).mean()
            f['avg_line'] = wave.ewm(span=3, adjust=False).mean()
            # 平均线拐头 (F1升级版+F5): 平均线>=REF(平均线,1) AND REF(平均线,1)<REF(平均线,2)
            f['avg_line_turn'] = ((f['avg_line'] >= f['avg_line'].shift(1)) &
                                  (f['avg_line'].shift(1) < f['avg_line'].shift(2))).astype(int)
            # 波动线
            f['wave_line'] = wave
            # 量能
            f['vol_ma5'] = V.rolling(5).mean()
            f['vol_ratio'] = V / (V.rolling(5).mean() + 0.0001)
            # ATR
            true_range = pd.concat([H-L, abs(H-C.shift(1)), abs(L-C.shift(1))], axis=1).max(axis=1)
            f['atr14'] = true_range.rolling(14).mean()
            # 周ATR抬升 (F1升级版): 周ATR>REF(周ATR,1)
            f['atr14_up'] = (f['atr14'] > f['atr14'].shift(1)).astype(int)
            # ATR低位收缩: REF(日ATR,1)<=LLV(日ATR,6) — 用周ATR代理(LLV(ATR14,6))
            atr_llv6 = f['atr14'].rolling(6).min()
            atr_prev = f['atr14'].shift(1)
            f['atr_low_compress'] = (atr_prev <= atr_llv6).astype(int)
            # ATR由低走高: 本周ATR>上周 且 上周ATR处于6周低点
            f['atr_low_to_high'] = ((f['atr14'] > atr_prev) & f['atr_low_compress'].astype(bool)).astype(int)
            # 战略伏击(公式3)
            SHORT, LONG, ZWIN, SCALE = 12, 26, 60, 20
            dif_all = C.ewm(span=SHORT, adjust=False).mean() - C.ewm(span=LONG, adjust=False).mean()
            dif_ma = dif_all.rolling(ZWIN).mean()
            dif_std = dif_all.rolling(ZWIN).std().fillna(0.0001)
            f['core_trend'] = 50 + SCALE * (dif_all - dif_ma) / (dif_std + 0.0001)
            f['core_trend_low'] = (f['core_trend'] < 45).astype(int)
            VOSC_RAW = 100 * (V.rolling(12).mean() - V.rolling(26).mean()) / (V.rolling(26).mean() + 0.0001)
            vosc_ma = VOSC_RAW.rolling(ZWIN).mean()
            vosc_std = VOSC_RAW.rolling(ZWIN).std().fillna(0.0001)
            f['vol_swing'] = 50 + SCALE * (VOSC_RAW - vosc_ma) / (vosc_std + 0.0001)
            f['vol_freeze'] = ((f['vol_swing'] < 38).astype(int).rolling(3).max() > 0).astype(int)
            f['winner_pct'] = (C - L.rolling(60).min()) / (H.rolling(60).max() - L.rolling(60).min() + 0.0001) * 100
            f['inst_ctrl'] = (C > f['ma45']).astype(int)
            f['main_lock'] = (C > f['ma30']).astype(int)
            wkret = (C / C.shift(1) - 1) * 100
            big = (wkret > 5) & (f['vol_ratio'] > 1.5)
            f['strat_ignition'] = (big.astype(int).rolling(12).max() > 0).astype(int)
            f['trend_turn'] = ((f['core_trend'] > f['core_trend'].shift(1)) & (f['core_trend'].shift(1) <= f['core_trend'].shift(2))).astype(int)
            # 公式5 价格波动线
            ww = (((C - L.rolling(3).min()) / (H.rolling(6).max() - L.rolling(3).min() + 0.0001)) * 4).ewm(span=4, adjust=False).mean()
            f['weekly_avg'] = ww.ewm(span=3, adjust=False).mean()
            f['weekly_avg_turn'] = ((f['weekly_avg'] >= f['weekly_avg'].shift(1)) & (f['weekly_avg'].shift(1) < f['weekly_avg'].shift(2))).astype(int)
            f['vol_inc'] = ((V > f['vol_ma5']) & (V < f['vol_ma5'] * 3)).astype(int)
            f['ma_bull'] = ((C > f['ma20']) & (f['ma5'] > f['ma10'])).astype(int)
            f['above_ma60'] = (C > f['ma60']).astype(int)
            f['not_high'] = (f['weekly_avg'] < 2.5).astype(int)
            crange = H - L + 0.0001
            f['no_long_shadow'] = ((H - C) < 0.4 * crange).astype(int)
            f['body_dom'] = ((C - O) > (H - L) * 0.5).astype(int)
            # 公式4 普及版
            AA = (C - L.rolling(20).min()) * 100 / (H.rolling(20).max() - L.rolling(20).min() + 0.0001)
            f['rel_pos'] = AA
            f['ind_trend'] = (100 * (C - L.rolling(60).min()) / (H.rolling(60).max() - L.rolling(60).min() + 0.0001)).ewm(span=3, adjust=False).mean()
            f['retail_mom'] = f['rel_pos'].rolling(6).mean()
            # 大盘（按位置对齐，避免 Timestamp 索引警告）
            f['market_bull'] = (pd.Series(market_bull_vals, index=C.index) if market_bull_vals is not None
                                else pd.Series(0, index=C.index, dtype=int))
            f['market_bull_sz'] = (pd.Series(market_bull_sz_vals, index=C.index) if market_bull_sz_vals is not None
                                   else pd.Series(0, index=C.index, dtype=int))
            # RPS
            f['rps50'] = rps.loc[code] if code in rps.index else pd.Series(np.nan, index=C.index)
            # === MACD分档版(F8)因子 ===
            # 主力入（放宽）: R0 > sum + (-5)
            f['main_enter'] = (R0 > (R0_abs_sum - 5)).astype(int)
            # chip spread代理: 20周价格std/均价，衡量筹码分散度
            f['chip_spread'] = C.rolling(20).std() / (C + 0.0001) * 100
            # MACD分档
            ema12 = C.ewm(span=12, adjust=False).mean()
            ema26 = C.ewm(span=26, adjust=False).mean()
            f['dif'] = ema12 - ema26
            f['dea'] = f['dif'].ewm(span=9, adjust=False).mean()
            sudden_golden = (f['dif'] > f['dea']) & (f['dif'].shift(1) <= f['dea'].shift(1))
            zero_up_golden = sudden_golden & (f['dif'] > 0)
            bull_divergent = (f['dif'] > 0) & (f['dea'] > 0) & (f['dif'] > f['dea'])
            bottom_div_golden = sudden_golden & (C > C.shift(5)) & (f['dif'] < f['dif'].shift(5)) & (~low_energy)
            macd1 = zero_up_golden & bull_divergent
            macd2 = zero_up_golden | bull_divergent
            macd3 = bottom_div_golden
            f['macd_tier1'] = macd1.astype(int)
            f['macd_tier2'] = (macd2 | macd3).astype(int)  # tier2 OR tier3 合并为通过
            # DCZ系统
            f['chip_concentrated'] = (f['chip_spread'] < 35).astype(int)  # 九十成<35
            f['DCZ_level'] = (C > f['DCZ']*0.90).astype(int)  # DCZ位
            f['DCZ_rise'] = (f['DCZ'] > f['DCZ'].shift(3)).astype(int)  # DCZ上
            f['chip_lock'] = (f['winner_pct'] < 70).astype(int)  # 筹码锁 WINNER<0.7
            # 趋势
            f['trend_mid'] = ((C > f['ma20']) & (f['ma20'] > f['ma20'].shift(5))).astype(int)  # 趋势中
            f['trend_hold'] = (C > f['ma20']*0.95).astype(int)  # 趋势守住
            # 放量防骗
            vol20b = V.rolling(20).mean()
            vol_ratio20 = V / (vol20b + 0.0001)
            f['vol_burst'] = (vol_ratio20 > 2).astype(int)  # 放量突
            f['vol_steady'] = (vol_ratio20 > 1.3).astype(int)  # 放量稳
            f['anti_dump2'] = (1 - ((vol_ratio20 > 3) & (C < C.shift(1))).astype(int)).astype(int)
            # 压力识别(30周*0.8)
            f['pressure_safe2'] = (C < H.rolling(30).max()*0.8).astype(int)  # 上方安
            # === v2.0防骗因子(依赖DCZ/ma_bull部分) ===
            f['chip_quality'] = (f['DCZ'].ewm(span=5, adjust=False).mean().rolling(3).std() < f['DCZ']*0.15).astype(int)
            f['trend_hold_loose'] = ((C >= f['ma20']*0.98) & (C >= f['DCZ']*0.98) &
                                      (f['ma20'] > f['ma60'])).astype(int)
            f['multi_cycle_ok'] = f['ma_bull'].astype(int)
            # === V4 周线主进健壮完善版因子 ===
            # 主力介入 = 主力流入(R0>0) AND 形态向上(平均线>REF(平均线,1))
            vol_main_in = (R0 > 0) & (f['avg_line'] > f['avg_line'].shift(1))
            f['v4_main_engage'] = vol_main_in.astype(int)
            # 板块识别(按代码前缀)
            code_prefix = str(code).upper()
            if code_prefix.startswith('30'):
                board = 1  # 创业板
            elif code_prefix.startswith('68'):
                board = 2  # 科创板
            elif code_prefix.startswith('43') or code_prefix.startswith('83'):
                board = 3  # 北交所
            else:
                board = 0  # 主板
            f['v4_board'] = board
            # 放量达标(按板块)——用条件逻辑选阈值，避免标量×Series
            vol_rat20b = V / (V.rolling(20).mean() + 0.0001)
            f['vol_ratio20b'] = vol_rat20b
            if board == 1:      thr = 1.8  # 创业板
            elif board == 2:    thr = 2.2  # 科创板
            elif board == 3:    thr = 2.5  # 北交所
            else:               thr = 2.0  # 主板
            f['v4_vol_pass'] = (vol_rat20b > thr).astype(int)
            f['v4_vol_steady'] = (vol_rat20b > 1.3).astype(int)  # 放量稳健
            # 异常巨量 > 3
            f['v4_abnormal_vol'] = (vol_rat20b > 3).astype(int)
            # 长上影线: (H-MAX(C,REF(C,1)))/幅度范围 > 0.6
            range_25 = H.rolling(25).max() - L.rolling(10).min() + 0.01
            upper_shadow = (H - np.maximum(C, C.shift(1))) / (range_25 + 0.0001)
            f['v4_long_upper'] = (upper_shadow > 0.6).astype(int)
            # 骗线识别 = 异常巨量 AND 长上影线
            f['v4_trick'] = (f['v4_abnormal_vol'] == 1) & (f['v4_long_upper'] == 1)
            f['v4_safe_vol'] = (~f['v4_trick']).astype(int)  # 安全放量
            # 趋势健康 = MA20>REF(MA20,5)
            f['v4_trend_healthy'] = (f['ma20'] > f['ma20'].shift(5)).astype(int)
            f['v4_trend_hold'] = (C > f['ma20'] * 0.95).astype(int)  # 趋势守住
            f['v4_trend_weak_hold'] = (C > f['ma20'] * 0.90).astype(int)  # 弱势守住(熊市)
            # MACD分档(零轴过滤)
            golden_cross = (f['dif'] > f['dea']) & (f['dif'].shift(1) <= f['dea'].shift(1))
            above_zero   = (f['dea'] > 0)
            below_zero   = (f['dea'] <= 0)
            f['v4_macd_strong'] = (golden_cross & above_zero & (f['dea'] > 0)).astype(int)  # MACD强档: 零轴上金叉+DEA>0
            f['v4_macd_mid']    = (golden_cross | above_zero).astype(int)  # MACD中等档: 零轴上金叉或金叉
            f['v4_macd_bear']   = (golden_cross & below_zero & (f['v4_vol_steady'] == 1)).astype(int)  # MACD熊市档
            # 压力识别
            h30 = H.rolling(30).max()
            f['v4_pressure1'] = (C < h30 * 0.75).astype(int)  # 标准压力
            f['v4_pressure2'] = (C < h30 * 0.80).astype(int)  # 熊市压力
            # 风险控制(简化: 排除ST/次新, 周线有量)
            f['v4_risk_ctrl'] = ((C.notna().cumsum() > 20) & (V > 0)).astype(int)
            # DCZ趋势 = DCZ>REF(DCZ,3)
            f['v4_DCZ_rise'] = (f['DCZ'] > f['DCZ'].shift(3)).astype(int)
            # 获利安全(放宽: F8 主进策略本就是追趋势，不要求低获利盘)
            f['v4_profit_safe'] = pd.Series(1, index=C.index, dtype=int)
            # 筹码集中 = chip_spread<35
            f['v4_chip_concentrated'] = (f['chip_spread'] < 35).astype(int)
            f['close'] = C
            factors[code] = f
        except Exception as e:
            if len(factors) < 1:
                import traceback
                traceback.print_exc()
                print(f'  FIRST FAIL code={code}: {e}', flush=True)
    print(f'  因子计算: {len(factors)} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return factors

# ============ 5个周线选股公式 ============
# 每个函数: f(code_factors, week_ts) -> True/False 是否触发选股
# code_factors: {factor_name: pd.Series}

def formula_1_main_atr(f, ts):
    """周线主进ATR共振: 主力进+A/B级+守住+ATR共振"""
    def g(name):
        return f.get(name, pd.Series(dtype=float)).loc[ts] if ts in (f.get(name, pd.Series(dtype=float)).index if f.get(name) is not None else pd.Series(dtype=float).index) else np.nan
    try:
        main_in = f['main_in_signal'].loc[ts]
        market_bull = f['market_bull'].loc[ts]
        DCZ = f['DCZ'].loc[ts]
        DCZ_prev5 = f['DCZ'].shift(5).loc[ts]
        vol_ratio = f['vol_ratio'].loc[ts]
        C = f['ma5'].loc[ts]  # close proxy
        close_val = f['ma5'].index.name if hasattr(f['ma5'].index,'name') else None
        C_close = f['ma5']  # 用close
        # 直接用close
        C_close = f['ma5']  # placeholder
        # 获取close
        close = f['main_in_signal']  # 借用index
        close = None
        # 简化: 直接取
        close = f['main_in_signal']  # 不是close
        # 取close: 在f中没有单独close → 用ma5近似(偏差)
        # 正确: close 存在? 不存在 → 用 f['DCZ']? 不
        # 修正: 加close到factor
        return False
    except Exception:
        return False

# 重构：统一用 _s() 获取因子值
def _s(f, name, ts):
    s = f.get(name)
    if s is None or not isinstance(s, pd.Series):
        return np.nan
    try:
        return s.loc[ts]
    except Exception:
        return np.nan

def add_close_to_factors(factors, weekly_dict):
    for code, f in factors.items():
        df = weekly_dict[code]
        f['close'] = df['close']

def formula_1_main_atr(f, ts):
    """F1 周线主进ATR共振【升级版】: 主力进+A/B级+守住+平均线拐头+ATR日周双周期共振"""
    try:
        main_in=_s(f,'main_in_signal',ts); market_bull=_s(f,'market_bull',ts)
        DCZ=_s(f,'DCZ',ts); C=_s(f,'close',ts)
        DCZ_s=f['DCZ']; vol_ratio=_s(f,'vol_ratio',ts)
        # 平均线拐头（核心升级）
        avg_line=_s(f,'avg_line',ts); wave_line=_s(f,'wave_line',ts)
        avg_turn = _s(f,'avg_line_turn',ts)
        # A/B级信号
        DCZ_gt_ref5 = pd.notna(DCZ) and pd.notna(DCZ_s.shift(5).loc[ts]) and DCZ>DCZ_s.shift(5).loc[ts]
        C_above_DCZ = C>DCZ if pd.notna(C) and pd.notna(DCZ) else False
        A = main_in==1 and market_bull==1 and DCZ_gt_ref5 and vol_ratio>1.5 and C_above_DCZ
        DCZ_s3=DCZ_s.shift(3).loc[ts] if ts in DCZ_s.shift(3).index else np.nan
        B = main_in==1 and (pd.notna(DCZ) and pd.notna(DCZ_s3) and DCZ>=DCZ_s3) \
            and pd.notna(avg_line) and avg_line<2.3 and (pd.notna(wave_line) and wave_line>0) and _s(f,'huashen',ts)==1 and not A
        # 新增：主力进必须伴随平均线拐头
        core = (A or B) and avg_turn==1
        # 趋势守住
        ma20=_s(f,'ma20',ts)
        trend_hold = pd.notna(C) and pd.notna(ma20) and C>=ma20 and C_above_DCZ
        # ATR日周双周期共振
        atr_up = _s(f,'atr14_up',ts)==1
        atr_low_high = _s(f,'atr_low_to_high',ts)==1
        atr_resonance = atr_up and atr_low_high
        return core and trend_hold and atr_resonance
    except Exception:
        return False

def formula_2_main(f, ts):
    """周线主进选股(公式2) — F2优化版: DCZ回看3周+量比1.2+持仓20天"""
    try:
        main_in=_s(f,'main_in_signal',ts); market_bull=_s(f,'market_bull',ts)
        DCZ=_s(f,'DCZ',ts); C=_s(f,'close',ts)
        DCZ_s=f['DCZ']
        # 强信号: DCZ回看3周(优化参数)
        DCZ_gt_ref3 = pd.notna(DCZ) and pd.notna(DCZ_s.shift(3).loc[ts]) and DCZ>DCZ_s.shift(3).loc[ts]
        C_above_DCZ = C>DCZ if pd.notna(C) and pd.notna(DCZ) else False
        vol_ratio=_s(f,'vol_ratio',ts)
        # 量比阈值1.2(优化参数)
        A = main_in==1 and market_bull==1 and DCZ_gt_ref3 and vol_ratio>1.2 and C_above_DCZ
        avg_line=_s(f,'avg_line',ts); huashen=_s(f,'huashen',ts)
        # 稳信号: DCZ>=REF3, avg_line<2.3
        DCZ_s3=DCZ_s.shift(3).loc[ts] if ts in DCZ_s.shift(3).index else np.nan
        B = main_in==1 and (pd.notna(DCZ) and pd.notna(DCZ_s3) and DCZ>=DCZ_s3) \
            and pd.notna(avg_line) and avg_line<2.3 and huashen==1 and not A
        core = A or B
        ma20=_s(f,'ma20',ts)
        trend_hold = pd.notna(C) and pd.notna(ma20) and C>=ma20 and C_above_DCZ
        return core and trend_hold
    except Exception:
        return False

def formula_3_strat(f, ts):
    """周线战略伏击: 长线底气 AND 战略引爆 AND 周筹码安全 AND 周趋势低位 AND 周量能冰点 AND 周趋势勾头"""
    try:
        inst=_s(f,'inst_ctrl',ts); main_lock=_s(f,'main_lock',ts)
        long_backbone = inst==1 and main_lock==1
        ignition=_s(f,'strat_ignition',ts)
        winner=_s(f,'winner_pct',ts)
        safe = pd.notna(winner) and winner>35
        low=_s(f,'core_trend_low',ts)
        freeze=_s(f,'vol_freeze',ts)
        turn=_s(f,'trend_turn',ts)
        return long_backbone and ignition==1 and safe and low==1 and freeze==1 and turn==1
    except Exception:
        return False

def formula_4_pop(f, ts):
    """周线普及版: 趋势金叉 AND 个股趋势<45 (换手需FINANCE跳过用总量>0)"""
    try:
        cross=_s(f,'ind_cross_retail',ts)
        trend=_s(f,'ind_trend',ts)
        retail=_s(f,'retail_mom',ts)
        # CROSS(个股趋势,散户动能) AND 个股趋势<45
        # 金叉: 个股趋势>散户动能 AND 上周<=
        cond1 = (pd.notna(trend) and pd.notna(retail) and trend>retail and
                 pd.notna(f['ind_trend'].shift(1).loc[ts]) and pd.notna(f['retail_mom'].shift(1).loc[ts]) and
                 f['ind_trend'].shift(1).loc[ts]<=f['retail_mom'].shift(1).loc[ts] and trend<45)
        # TJ2: 换手>4% (FINANCE=流通股本, 无数据 → 用vol_ratio>1.5近似)
        vol_r=_s(f,'vol_ratio',ts)
        cond2 = pd.notna(vol_r) and vol_r>1.5
        # TJ3: 上市>30周 (用 searchsorted 计数,避免 get_loc 返回 slice)
        idx = f['close'].index
        pos = idx.searchsorted(ts, side='left') if len(idx) > 0 else -1
        cond3 = pos>30
        return cond1 and cond2 and cond3
    except Exception:
        return False

def formula_5_price_wave(f, ts):
    """F5 周线价格波动线【优化版】: 拐头+量能+MACD金叉(CROSS OR)+KDJ顺向+花神+均线+60周+非高位+无长上影+实体占优"""
    try:
        turn=_s(f,'weekly_avg_turn',ts)
        vol_inc=_s(f,'vol_inc',ts)
        # MACD金叉(优化版): CROSS(DIF,DEA) OR (DIF>DEA AND REF(DIF,1)<=REF(DEA,1))
        macd_cross=_s(f,'macd_cross',ts)
        # K>D AND DIF<0.5
        K=_s(f,'kdj_K',ts); D=_s(f,'kdj_D',ts); dif=_s(f,'dif',ts)
        kdj_cond = (pd.notna(K) and pd.notna(D) and K>D and pd.notna(dif) and dif<0.5)
        golden = (macd_cross==1) and kdj_cond
        huashen=_s(f,'huashen_p1',ts)
        ma_bull=_s(f,'ma_bull',ts)
        above60=_s(f,'above_ma60',ts)
        not_high=_s(f,'not_high',ts)
        no_shadow=_s(f,'no_long_shadow',ts)
        body=_s(f,'body_dom',ts)
        return (turn==1 and vol_inc==1 and golden and huashen==1 and ma_bull==1
                and above60==1 and not_high==1 and no_shadow==1 and body==1)
    except Exception:
        return False

def formula_6_strict(f, ts):
    """F6 主进_周线共振严格版: 日线主进攻击+日线风控+周线双均线多头
    说明: 日线条件(主力攻击/涨幅/量比/换手)用周线代理近似；周线双均线多头严格判定
    日线代理映射:
      - 主力攻击: 用 main_in_signal==1 (周线R0主力进) + 平均线拐头 + 波动线上升
      - 收盘站稳20: C>MA20 (周线)
      - MA20趋势: MA20>=REF(MA20,1) (周线)
      - 涨幅区间: 周线涨幅>3且<9.5 (周线代理)
      - 标准量比/换手/非天量: vol_ratio在合理范围 (周线代理)
      - 周线多头: 周线收盘>周线5 AND 周线5>周线10"""
    try:
        # 周线双均线多头(严格判定)
        C=_s(f,'close',ts)
        ma5=_s(f,'ma5',ts); ma10=_s(f,'ma10',ts)
        weekly_bull = pd.notna(C) and pd.notna(ma5) and pd.notna(ma10) and C>ma5 and ma5>ma10
        if not weekly_bull:
            return False
        # 日线核心: 主力攻击
        main_in=_s(f,'main_in_signal',ts)
        avg_turn=_s(f,'avg_line_turn',ts)
        wave=_s(f,'wave_line',ts); wave_prev=_s(f,'wave_line',ts)
        wave_s=f['wave_line']
        wave_prev_v = wave_s.shift(1).loc[ts] if ts in wave_s.shift(1).index else np.nan
        wave_up = pd.notna(wave) and pd.notna(wave_prev_v) and wave>wave_prev_v
        main_attack = main_in==1 and avg_turn==1 and wave_up
        # 日线底线: 收盘站稳20 + MA20趋势
        ma20=_s(f,'ma20',ts)
        ma20_s=f['ma20']; ma20_prev=ma20_s.shift(1).loc[ts] if ts in ma20_s.shift(1).index else np.nan
        stand20 = pd.notna(C) and pd.notna(ma20) and C>ma20
        ma20_trend = pd.notna(ma20) and pd.notna(ma20_prev) and ma20>=ma20_prev
        # 日线风控(周线代理)
        wkret=(C/C.shift(1)-1)*100 if hasattr(C,'shift') else _s(f,'close',ts)/_s(f,'close',ts-7)-1
        # 用周线涨幅直接判定
        close_s=f['close']
        wkret_v = (close_s.loc[ts]/close_s.shift(1).loc[ts]-1)*100 if ts in close_s.shift(1).index else np.nan
        gain_range = pd.notna(wkret_v) and wkret_v>3 and wkret_v<9.5
        vol_r=_s(f,'vol_ratio',ts)
        vol_cond = pd.notna(vol_r) and vol_r>1.8 and vol_r<3.0  # 量比代理
        # 非天量: V < MA(V,5)*3  (周线)
        vol_ma5=_s(f,'vol_ma5',ts)
        not_heavy = pd.notna(vol_r) and vol_r < 3.0
        return main_attack and stand20 and ma20_trend and gain_range and vol_cond and not_heavy
    except Exception:
        return False

def formula_7_anti_fake_v2(f, ts):
    """F7 周线主进防骗优化版 v2.0: 8重防骗 + A/B级信号 (简化版)"""
    try:
        main_in=_s(f,'main_in_signal',ts); market_bull=_s(f,'market_bull',ts)
        DCZ=_s(f,'DCZ',ts); C=_s(f,'close',ts)
        if pd.isna(C) or pd.isna(DCZ) or pd.isna(main_in) or main_in!=1: return False
        DCZ_s=f['DCZ']; vol_ratio=_s(f,'vol_ratio',ts)
        avg_line=_s(f,'avg_line',ts)
        # 防骗因子
        pressure_safe=_s(f,'pressure_safe',ts)
        anti_dump=_s(f,'anti_dump_safe',ts)
        anti_lure=_s(f,'anti_lure_safe',ts)
        # MACD
        macd_true=_s(f,'macd_true_golden',ts)
        macd_bull=_s(f,'macd_bull',ts)
        dif_v=_s(f,'dif',ts); dea_v=_s(f,'dea',ts)
        macd_golden = (pd.notna(dif_v) and pd.notna(dea_v) and dif_v>dea_v)  # 金叉状态
        # 筹码
        chip_q=_s(f,'chip_quality',ts)
        chip_up = (ts in DCZ_s.shift(3).index and DCZ_s.shift(3).loc[ts] < DCZ)
        # 趋势
        trend_loose=_s(f,'trend_hold_loose',ts)
        multi_cycle=_s(f,'multi_cycle_ok',ts)
        # DCZ条件
        DCZ_gt_ref5 = (ts in DCZ_s.shift(5).index and DCZ_s.shift(5).loc[ts] < DCZ)
        C_above_DCZ = C>DCZ
        vol_normal=_s(f,'vol_normal',ts)
        # 获利盘低
        winner=_s(f,'winner_pct',ts); winner_low = pd.notna(winner) and winner<80
        # 压力
        pressure_mid=_s(f,'pressure_mid',ts)
        # A级强化
        A = (market_bull==1 and DCZ_gt_ref5 and vol_normal==1 and C_above_DCZ
             and chip_q==1 and chip_up and winner_low and macd_golden
             and pressure_safe==1 and anti_dump==1 and anti_lure==1
             and multi_cycle==1)
        # B级强化
        DCZ_ge_ref3 = (ts in DCZ_s.shift(3).index and DCZ_s.shift(3).loc[ts] <= DCZ)
        B = (DCZ_ge_ref3 and pd.notna(avg_line) and avg_line<2.2
             and not A and chip_q==1 and trend_loose==1 and (pressure_mid!=1)
             and anti_dump==1 and macd_golden)
        return A or B
    except Exception:
        return False

FORMULAS = {
    'F1_周线主进ATR共振[升级版]': formula_1_main_atr,
    'F2_周线主进': formula_2_main,
    'F3_周线战略伏击': formula_3_strat,
    'F4_周线普及版': formula_4_pop,
    'F5_周线价格波动线[优化版]': formula_5_price_wave,
    'F6_主进_周线共振严格版': formula_6_strict,
    'F7_周线主进防骗v2.0': formula_7_anti_fake_v2,
}

# ============ 回测引擎 ============
def run_formula_backtest(formula_fn, formula_name, weekly_dict, daily_dict, factors,
                         bench, hold_days=30, top_k=20, start=None, end=None,
                         realistic=False):
    """对单一周线选股公式跑回测
    realistic=True: 实盘模拟模式
      - 买入: 周一开盘价(模拟溢价)
      - 涨跌停: 按代码区分(创业板20%/北交所30%/主板9.95%)
      - 大盘: 双指数AND(沪深300+深成指)
      - 止损: 跌破MA20止损
      - 滑点: 0.2%/轮
      - 资金: 固定100万/20份
      - 年化: 复利资金曲线
    """
    bench = pd.Series(bench['close']).rename_axis('trade_date').sort_index()
    bench_index = bench.index
    all_dates = sorted(set(bench_index))
    if start: all_dates = [d for d in all_dates if d >= pd.Timestamp(start)]
    if end: all_dates = [d for d in all_dates if d <= pd.Timestamp(end)]
    # 周一
    all_dates = [d for d in all_dates if d.dayofweek == 0]
    def _has_enough(d):
        target = d + pd.Timedelta(days=hold_days + 15)
        return bench_index.searchsorted(target, side='left') < len(bench_index)
    all_dates = [d for d in all_dates if _has_enough(d)]
    print(f'  [{formula_name}] 候选周: {len(all_dates)}', flush=True)

    holdings = []
    skip = {'limit_up':0, 'limit_down':0, 'no_data':0}

    # 实盘模式: 资金池
    total_capital = 1000000  # 100万
    capital_per_share = total_capital / top_k  # 每份资金

    for T in all_dates:
        picked = []
        # 实盘: 双指数检查——仅当大盘数据足够时启用（至少10%的周一为多头）
        use_dual_index = False
        if realistic:
            # 采样检查market_bull是否有有效信号
            n_bull = 0; n_total = 0
            for code in list(factors.keys())[:100]:
                if T in factors[code].get('close', pd.Series()).index:
                    mb = _s(factors[code],'market_bull',T)
                    if pd.notna(mb):
                        n_total += 1
                        if mb == 1: n_bull += 1
            use_dual_index = (n_total > 0) and (n_bull / n_total > 0.05)
        for code in weekly_dict:
            if not is_eligible(code):
                continue
            if code not in factors:
                continue
            f = factors[code]
            if T not in f['close'].index:
                continue
            if not formula_fn(f, T):
                continue
            # 实盘: 双指数AND(仅当大盘数据足够)
            if realistic and use_dual_index:
                mb = _s(f,'market_bull',T)
                mbsz = _s(f,'market_bull_sz',T)
                if pd.notna(mb) and mb != 1: continue
                if pd.notna(mbsz) and mbsz != 1: continue
            # 排序分: RPS (高RPS优先)
            rps = _s(f,'rps50',T)
            rps = rps if pd.notna(rps) else 50
            picked.append((code, rps))
        picked.sort(key=lambda x: x[1], reverse=True)
        picked = picked[:top_k]
        if len(picked) < 2:
            continue
        for code, _ in picked:
            dd = daily_dict.get(code)
            if dd is None or T not in dd.index:
                skip['no_data']+=1; continue
            # 用 searchsorted 定位
            dd_sorted_idx = dd.index.searchsorted(T, side='left')
            if dd_sorted_idx >= len(dd) or dd.index[dd_sorted_idx] != T:
                skip['no_data']+=1; continue
            # 买入价: 实盘用下一交易日开盘价(模拟溢价),理想用收盘价
            entry_date = dd.index[dd_sorted_idx]
            if realistic and dd_sorted_idx < len(dd)-1:
                entry = dd.iloc[dd_sorted_idx+1]['open']  # 下一日开盘价(周一开盘)
            else:
                entry = dd.iloc[dd_sorted_idx]['close']
            if entry <= 0: skip['no_data']+=1; continue
            # 涨跌停检查: 按代码区分
            limit_r = get_limit_ratio(code)
            if dd_sorted_idx>0:
                prev = dd.iloc[dd_sorted_idx-1]['close']
                if prev>0 and entry >= prev*(1+limit_r):
                    skip['limit_up']+=1; continue
            # 卖出日 + 止损: 实盘模式下逐日检查MA20
            exit_ts = T + pd.Timedelta(days=hold_days)
            exit_close = None
            exit_date = None
            if realistic:
                # 实盘: 检查期间是否跌破MA20
                # 周线MA20索引是周一日期,日K用ffill前向填充到最近周线值
                ma20_s = factors[code].get('ma20')
                close_s = factors[code].get('close')
                if ma20_s is not None and close_s is not None:
                    # 构建: 周线日期->周线MA20值, 前向填充到日频
                    ma20_daily = ma20_s.reindex(dd.index).ffill().bfill()
                    close_daily = close_s.reindex(dd.index).ffill().bfill()
                    for ci in range(dd_sorted_idx + 1, len(dd)):
                        cd = dd.index[ci]
                        if cd > exit_ts: break
                        days_hold = (cd - T).days
                        if days_hold < 5: continue  # 至少持有5天才考虑止损
                        c = dd.iloc[ci]['close']
                        ma20_v = ma20_daily.iloc[ci]
                        if pd.notna(ma20_v) and c < ma20_v * 0.98:  # 允许2%缓冲
                            exit_close = c
                            exit_date = cd
                            break
            if exit_close is None:
                fut_idx = dd.index.searchsorted(exit_ts, side='left')
                if fut_idx<0 or fut_idx>=len(dd): continue
                exit_close = dd.iloc[fut_idx]['close']
                exit_date = dd.index[fut_idx]
            # 跌停检查
            if exit_close <= 0: skip['limit_down']+=1; continue
            # 计算收益
            gross = exit_close/entry - 1
            # 实盘: 加滑点0.2%
            if realistic:
                gross -= 0.002
            net = gross - COST_RATE
            # 基准
            try:
                bi = bench_index.searchsorted(exit_date, side='left')
                ti = bench_index.searchsorted(T, side='left')
                if 0 <= bi < len(bench) and 0 <= ti < len(bench) and bench.iloc[bi]>0 and bench.iloc[ti]>0:
                    b_ret = (bench.iloc[bi]/bench.iloc[ti]-1)
                else:
                    b_ret = np.nan
            except Exception:
                b_ret = np.nan
            holdings.append({'T':T,'code':code,'entry':entry,'exit':exit_close,
                             'gross':gross,'net':net,'bench':b_ret,
                             'excess':(net-b_ret) if not np.isnan(b_ret) else np.nan,
                             'exit_date':exit_date,'capital':capital_per_share})
    return holdings, skip

def summarize(name, holdings, skip, hold_days, realistic=False):
    if not holdings:
        return {'公式':name,'交易数':0,'胜率':np.nan,'单均净%':np.nan,'年化净%':np.nan,
                '单均超额%':np.nan,'战胜基准%':np.nan,'单均基准%':np.nan,'区间':'-',
                '涨停跳过':skip['limit_up'],'跌停跳过':skip['limit_down'],'无数据':skip['no_data']}
    df = pd.DataFrame(holdings)
    total = len(df)
    wins = (df['net']>0).sum()
    win_rate = wins/total*100
    net_mean = df['net'].mean()*100
    gross_mean = df['gross'].mean()*100
    excess_mean = df['excess'].fillna(0).mean()*100
    bench_mean = df['bench'].fillna(0).mean()*100
    beat = (df['excess'].fillna(0)>0).mean()*100
    start = df['T'].min(); end = df['T'].max()
    # 年化: 理想用算术均值,实盘用资金曲线复利
    if realistic:
        # 资金曲线复利: 每笔交易后本金更新
        capital = 1000000
        trades_per_day = {}  # 日期→交易列表
        for _, row in df.iterrows():
            ex = row['exit_date']
            if ex not in trades_per_day: trades_per_day[ex] = []
            trades_per_day[ex].append(row)
        for ex_date in sorted(trades_per_day.keys()):
            for row in trades_per_day[ex_date]:
                capital = capital + row['capital'] * (1 + row['net'])
        span_days = (end - start).days
        if span_days > 0 and capital > 0:
            annual = (capital/1000000)**(365/span_days) - 1
        else:
            annual = np.nan
        annual_pct = annual*100
    else:
        annual_pct = ((1+df['net'].mean())**(252/hold_days)-1)*100 if df['net'].mean()>-1 else np.nan
    return {'公式':name,'交易数':total,'胜率':round(win_rate,1),'单均净%':round(net_mean,2),
            '年化净%':round(annual_pct,1),'单均超额%':round(excess_mean,2),
            '战胜基准%':round(beat,1),'单均基准%':round(bench_mean,2),
            '区间':f'{start.date()}-{end.date()}',
            '涨停跳过':skip['limit_up'],'跌停跳过':skip['limit_down'],'无数据':skip['no_data']}

# ============ 3因子组合(对照) ============
def formula_3factor(f, ts, rps_thr=50, retail_thr=45):
    """3因子: RPS50>=阈值 AND MACD金叉(DIF>DEA) AND 散户动量>=阈值"""
    try:
        rps=_s(f,'rps50',ts); macd_g=_s(f,'macd_golden_wide',ts); rm=_s(f,'retail_mom',ts)
        if not all(pd.notna(x) for x in (rps,macd_g,rm)): return False
        return rps>=rps_thr and macd_g==1 and rm>=retail_thr
    except Exception:
        return False

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--start', default='20220101')
    ap.add_argument('--end', default='20260715')
    ap.add_argument('--hold-days', type=int, default=30)
    ap.add_argument('--top-k', type=int, default=20)
    ap.add_argument('--realistic', action='store_true',
                    help='实盘模拟: 周一开盘价买入+双指数AND+MA20止损+滑点0.2pct+复利年化')
    args = ap.parse_args()

    print('='*60)
    print('通达信周线选股公式回测器')
    print(f'时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    print(f'区间: {args.start}→{args.end}  持仓: {args.hold_days}交易日  top_k={args.top_k}')
    if args.realistic:
        print('模式: **实盘模拟** (周一开盘价买入+双指数AND+MA20止损+滑点0.2%+复利年化)')
    else:
        print('模式: 理想 (周一收盘价买入+固定持仓+算术均值年化)')
    print('='*60)

    print('\n加载日K...')
    daily = load_all_daily()
    print('\n聚合周K...')
    weekly = daily_to_weekly(daily)
    print(f'  周线: {len(weekly)} 只')

    print('\n计算周线因子...')
    factors = compute_weekly_factors(weekly)

    print('\n加载基准...')
    bench = load_benchmark(daily)
    if bench is None: sys.exit(1)
    bkey = list(daily.keys())[0] if bench is not None else ''
    for k in daily:
        if '000300' in k.upper(): bkey=k; break
    print(f'  基准: {bkey}')

    print('\n执行各公式回测...\n')
    t0=time.time()
    results = []

    mode_label = '[实盘]' if args.realistic else '[理想]'
    # 6个周线公式
    for name, fn in FORMULAS.items():
        print(f'\n--- {name} {mode_label} ---', flush=True)
        h, s = run_formula_backtest(fn, name, weekly, daily, factors, bench,
                                     hold_days=args.hold_days, top_k=args.top_k,
                                     start=args.start, end=args.end,
                                     realistic=args.realistic)
        results.append(summarize(name, h, s, args.hold_days, realistic=args.realistic))

    # 3因子对照
    label = f'3因子组合(对照){mode_label}'
    print(f'\n--- {label} ---', flush=True)
    h3, s3 = run_formula_backtest(lambda f,ts: formula_3factor(f,ts,50,45), label,
                                   weekly, daily, factors, bench, hold_days=args.hold_days,
                                   top_k=args.top_k, start=args.start, end=args.end,
                                   realistic=args.realistic)
    results.append(summarize(label, h3, s3, args.hold_days, realistic=args.realistic))

    # 表格
    print(f'\n{"="*80}')
    print(f'各公式横向对比  (模式={mode_label}, 耗时 {time.time()-t0:.0f}s)')
    print(f'{"="*80}')
    cols = ['公式','交易数','胜率','单均净%','年化净%','单均超额%','战胜基准%','单均基准%','区间','涨停跳过','跌停跳过','无数据']
    print(f'| {" | ".join(cols)} |')
    print(f'| {" | ".join(["---"]*len(cols))} |')
    for r in results:
        row = [str(r.get(c,'-')) for c in cols]
        print(f'| {" | ".join(row)} |')

    suffix = '_realistic' if args.realistic else ''
    out = f'weekly_formula_backtest_{datetime.now().strftime("%Y%m%d")}{suffix}.md'
    with open(out, 'w', encoding='utf-8') as f:
        f.write(f'# 通达信周线选股公式横向回测{"(实盘模拟)" if args.realistic else ""}\n\n')
        f.write(f'**区间**: {args.start}→{args.end}  **持仓**: {args.hold_days}交易日  **top_k**: {args.top_k}\n')
        f.write(f'**成本**: 0.232%/轮  **基准**: 沪深300  **模式**: {"实盘模拟" if args.realistic else "理想"}\n\n')
        f.write('| ' + ' | '.join(cols) + ' |\n')
        f.write('| ' + ' | '.join(['---']*len(cols)) + ' |\n')
        for r in results:
            f.write('| ' + ' | '.join(str(r.get(c,'-')) for c in cols) + ' |\n')
        f.write(f'\n*耗时 {time.time()-t0:.0f}s*\n')
    print(f'\n报告: {out}')
