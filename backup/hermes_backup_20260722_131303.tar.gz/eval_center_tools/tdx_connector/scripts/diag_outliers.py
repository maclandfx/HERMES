"""Find which codes produce huge net in 3-factor realistic full market."""
import pandas as pd, numpy as np, sys, os, time, struct
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)
bench = wf.load_benchmark(daily)

bench_code='SH000300.SH'
bweekly=wf.daily_to_weekly({bench_code:bench})
mbull=None;mbull_sz=None
if bench_code in bweekly:
    bw=bweekly[bench_code]
    if len(bw)>=60:
        ma60=bw['close'].rolling(60).mean()
        if pd.notna(ma60).sum()>=10:
            ref_idx=weekly[list(weekly.keys())[0]].index
            mbull=(bw['close']>ma60).map({True:1,False:0}).reindex(ref_idx).fillna(0)
            mbull_sz=mbull.copy()
price_records=[]
for code,df in weekly.items():
    for d,c in df['close'].items():
        if c and c>0: price_records.append((code,d,c))
pivot=pd.DataFrame(price_records,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True,method='average')*100

# Factors for first 300 eligible codes
sample=[c for c in weekly if wf.is_eligible(c)][:300]
factors={}
for code in sample:
    W=weekly[code];C=W['close'];H=W['high'];L=W['low'];O=W['open'];V=W['vol']
    try:
        f={}
        EMA12=C.ewm(span=12,adjust=False).mean();EMA26=C.ewm(span=26,adjust=False).mean()
        dif=EMA12-EMA26;dea=dif.ewm(span=9,adjust=False).mean()
        f['dif']=dif;f['dea']=dea;f['macd_golden_wide']=(dif>dea).astype(int)
        f['ma5']=C.rolling(5).mean();f['ma10']=C.rolling(10).mean()
        f['ma20']=C.rolling(20).mean();f['ma60']=C.rolling(60).mean()
        f['close']=C
        f['rps50']=rps.loc[code] if code in rps.index else pd.Series(np.nan,index=C.index)
        HH20=H.rolling(20).max();LL20=L.rolling(20).min()
        rel_pos=(C-LL20)*100/(HH20-LL20+0.0001);f['retail_mom']=rel_pos.rolling(6).mean()
        mid=(C+O+((H-L)/4))/2;f['DCZ']=mid.ewm(span=20,adjust=False).mean()
        hcl=pd.concat([H-L,(H-C.shift(1)).fillna(0),(C-L.shift(1)).fillna(0)],axis=1).max(axis=1)
        f['atr14']=hcl.rolling(14).mean()
        f['market_bull']=mbull if mbull is not None else pd.Series(1,index=C.index)
        f['market_bull_sz']=mbull_sz if mbull_sz is not None else pd.Series(1,index=C.index)
        f['avg_line']=V.ewm(span=3,adjust=False).mean()
        factors[code]=f
    except Exception: pass
print(f"Factors: {len(factors)}")

# Run realistic 3-factor on 300 stocks via run_formula_backtest
h3,s3=wf.run_formula_backtest(
    lambda f,ts: wf.formula_3factor(f,ts,50,45),'3f',
    {c:weekly[c] for c in sample},
    {c:daily[c] for c in sample if c in daily},
    factors,bench,hold_days=30,top_k=20,start='20230101',end='20251231',realistic=True)

df=pd.DataFrame(h3) if h3 else pd.DataFrame()
print(f"Total trades: {len(df)}")
if len(df)>0:
    df['net_pct']=df['net']*100
    print(f"Mean net: {df['net_pct'].mean():.2f}%")
    print(f"Median net: {df['net_pct'].median():.2f}%")
    print(f"Max net: {df['net_pct'].max():.2f}%")
    # Outlier analysis
    print("\nTrades with net>50%:")
    big=df[df['net_pct']>50].sort_values('net_pct',ascending=False)
    print(big[['code','T','entry','exit','net_pct']].to_string(index=False))
    # Entry distribution - check for abnormally low entries (price bug)
    print(f"\nEntry price stats: min={df['entry'].min():.3f} max={df['entry'].max():.3f}")
    print("Entries < 0.01:", (df['entry']<0.01).sum())
    print("Entries < 0.1:", (df['entry']<0.1).sum())
