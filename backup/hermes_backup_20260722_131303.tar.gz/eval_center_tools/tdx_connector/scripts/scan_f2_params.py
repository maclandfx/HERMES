"""F2 参数扫描: 先缓存因子到pickle, 再快速扫描公式变体."""
import pandas as pd, numpy as np, sys, time, itertools, pickle, os
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find('if __name__')], 'wf', 'exec'), wf.__dict__)
_s = wf._s

# Load or cache factors
cache_path = 'f2_factors.pkl'
t0 = time.time()
if not os.path.exists(cache_path):
    print('加载日K+周线+因子...')
    daily = wf.load_all_daily()
    weekly = wf.daily_to_weekly(daily)
    bench = wf.load_benchmark(daily)
    factors = wf.compute_weekly_factors(weekly)
    with open(cache_path, 'wb') as f:
        pickle.dump({'daily': daily, 'weekly': weekly, 'bench': bench, 'factors': factors}, f)
    print(f'缓存完成, 耗时 {time.time()-t0:.0f}s')
else:
    print('加载缓存...')
    with open(cache_path, 'rb') as f:
        data = pickle.load(f)
    daily = data['daily']; weekly = data['weekly']; bench = data['bench']; factors = data['factors']
    print(f'耗时 {(time.time()-t0):.1f}s')

def make_f2(dcz_ref_a, dcz_ref_b, vol_thr, avg_thr):
    """动态生成F2变体"""
    def f2_variant(f, ts):
        try:
            main_in = _s(f,'main_in_signal',ts)
            market_bull = _s(f,'market_bull',ts)
            DCZ = _s(f,'DCZ',ts); C = _s(f,'close',ts)
            DCZ_s = f['DCZ']
            DCZ_gt_ref = (pd.notna(DCZ) and pd.notna(DCZ_s.shift(dcz_ref_a).loc[ts])
                          and DCZ > DCZ_s.shift(dcz_ref_a).loc[ts])
            C_above_DCZ = (C > DCZ if pd.notna(C) and pd.notna(DCZ) else False)
            vol_ratio = _s(f,'vol_ratio',ts)
            A = (main_in == 1 and market_bull == 1 and DCZ_gt_ref
                 and vol_ratio > vol_thr and C_above_DCZ)
            avg_line = _s(f,'avg_line',ts)
            huashen = _s(f,'huashen',ts)
            DCZ_s_b = DCZ_s.shift(dcz_ref_b).loc[ts] if ts in DCZ_s.shift(dcz_ref_b).index else np.nan
            B = (main_in == 1 and (pd.notna(DCZ) and pd.notna(DCZ_s_b) and DCZ >= DCZ_s_b)
                 and pd.notna(avg_line) and avg_line < avg_thr and huashen == 1 and not A)
            core = A or B
            ma20 = _s(f,'ma20',ts)
            trend_hold = (pd.notna(C) and pd.notna(ma20) and C >= ma20 and C_above_DCZ)
            return core and trend_hold
        except Exception:
            return False
    return f2_variant

# 扫描网格: 持仓天数 + 量比(核心两个变量)
configs = list(itertools.product(
    [3],              # dcz_ref_a
    [3],              # dcz_ref_b
    [1.2, 1.5, 1.8],  # vol_thr
    [2.3],            # avg_thr
    [20, 30, 40],     # hold_days
))

print(f'\n扫描 {len(configs)} 个参数组合...')
results = []
t0 = time.time()
for i, (ref_a, ref_b, vol, avg, hold) in enumerate(configs):
    fn = make_f2(ref_a, ref_b, vol, avg)
    h, s = wf.run_formula_backtest(fn, 'F2_scan', weekly, daily, factors, bench,
        hold_days=hold, top_k=20, start='20230101', end='20251231', realistic=True)
    df = pd.DataFrame(h)
    if len(df) == 0:
        continue
    df['net'] = df['net'] * 100
    win = (df['net'] > 0).mean() * 100
    mn = df['net'].mean()
    n_years = (pd.Timestamp('20251231') - pd.Timestamp('20230101')).days / 252
    n_per_year = len(df) / n_years
    ann = ((1 + mn/100) ** n_per_year - 1) * 100
    results.append({
        'ref_a': ref_a, 'ref_b': ref_b, 'vol': vol, 'avg': avg, 'hold': hold,
        'trades': len(df), 'win': win, 'mean_net': mn, 'ann': ann,
        'score': mn * win
    })
    if (i + 1) % 10 == 0:
        print(f'  进度 {i+1}/{len(configs)}, 耗时 {time.time()-t0:.0f}s')

print(f'\n总耗时 {time.time()-t0:.0f}s, {len(results)} 个有效结果')

res = pd.DataFrame(results)
res = res.sort_values('score', ascending=False)
print(f'\n{"="*80}')
print('F2 参数扫描排名 (综合分=单均净%×胜率, 越高越优)')
print(f'{"="*80}')
print(f'{"排名":<4}{"DCZa":>5}{"DCZb":>5}{"量比":>5}{"avg":>5}{"持仓":>5}{"交易":>5}{"胜率":>7}{"单均净":>8}{"年化":>8}{"评分":>7}')
print('-'*80)
for idx, (orig_i, r) in enumerate(res.head(20).iterrows(), 1):
    print(f'{idx:<4}{r["ref_a"]:>5}{r["ref_b"]:>5}{r["vol"]:>5.1f}{r["avg"]:>5.1f}'
          f'{r["hold"]:>5}{r["trades"]:>5}{r["win"]:>6.1f}%{r["mean_net"]:>7.2f}%{r["ann"]:>7.1f}%{r["score"]:>7.1f}')

print(f'\n最优参数: ref_a={res.iloc[0]["ref_a"]}, ref_b={res.iloc[0]["ref_b"]}, '
      f'vol={res.iloc[0]["vol"]}, avg={res.iloc[0]["avg"]}, hold={res.iloc[0]["hold"]}')
