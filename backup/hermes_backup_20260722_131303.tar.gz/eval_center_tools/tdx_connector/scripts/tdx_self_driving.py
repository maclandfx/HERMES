"""
tdx_self_driving.py — 自驱进化引擎（纯本地TDX数据）
直接从D:/TDX/vipdoc读日K+周K，零网络依赖
"""
import sys, os, json, time, math, random, shutil
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

# ── 本地TDX数据读取 ──
TDVIPDOC = 'D:/TDX/vipdoc'

class _TdxReader:
    """通达信本地K线读取器"""
    def __init__(self, vipdoc=TDVIPDOC):
        self.vipdoc = vipdoc.replace('/', '\\')
        self._cache = {}
    
    def _path(self, code):
        ex = 'sh' if code[0] in '69' else 'sz'
        return os.path.join(self.vipdoc, ex, 'lday', f'{ex}{code}.day')
    
    def daily(self, code):
        """返回 DataFrame: date, open, high, low, close, volume"""
        if code in self._cache:
            return self._cache[code]
        path = self._path(code)
        if not os.path.exists(path):
            return pd.DataFrame()
        try:
            with open(path, 'rb') as f:
                data = f.read()
        except:
            return pd.DataFrame()
        
        records = []
        for i in range(0, len(data)-31, 32):
            chunk = data[i:i+32]
            dt = int.from_bytes(chunk[0:4], 'little')
            if not (20000000 < dt < 20300000):
                continue
            o = int.from_bytes(chunk[4:8], 'little') / 100.0
            h = int.from_bytes(chunk[8:12], 'little') / 100.0
            l = int.from_bytes(chunk[12:16], 'little') / 100.0
            c = int.from_bytes(chunk[16:20], 'little') / 100.0
            v = int.from_bytes(chunk[20:24], 'little')
            a = int.from_bytes(chunk[24:28], 'little')
            records.append((dt, o, h, l, c, v, a))
        
        if not records:
            self._cache[code] = pd.DataFrame()
            return self._cache[code]
        
        df = pd.DataFrame(records, columns=['date', 'open', 'high', 'low', 'close', 'volume', 'amount'])
        df['date'] = pd.to_datetime(df['date'].astype(str))
        df = df.sort_values('date').reset_index(drop=True)
        self._cache[code] = df
        return df
    
    def weekly(self, code):
        """从日K合成周K"""
        df = self.daily(code)
        if df.empty or len(df) < 5:
            return pd.DataFrame()
        df = df.copy()
        df['year'] = df['date'].dt.year
        df['week'] = df['date'].dt.isocalendar().week.astype(int)
        weekly = []
        for (yr, wk), grp in df.groupby(['year', 'week']):
            if len(grp) < 1:
                continue
            weekly.append({
                'date': grp['date'].iloc[-1],
                'open': grp['open'].iloc[0],
                'high': grp['high'].max(),
                'low': grp['low'].min(),
                'close': grp['close'].iloc[-1],
                'volume': grp['volume'].sum(),
                'amount': grp['amount'].sum(),
            })
        wdf = pd.DataFrame(weekly).sort_values('date').reset_index(drop=True)
        return wdf
    
    def list_codes(self):
        """获取全市场代码列表"""
        codes = set()
        for ex in ['sh', 'sz']:
            d = os.path.join(self.vipdoc, ex, 'lday')
            if not os.path.isdir(d):
                continue
            for fn in os.listdir(d):
                if fn.endswith('.day'):
                    c = fn[2:].replace('.day', '')
                    if len(c) == 6 and c.isdigit():
                        codes.add(c)
        return sorted(codes)


# ══════════════════════════════════════════════
# 因子计算（从DataFrame提取）
# ══════════════════════════════════════════════

def calc_weekly_factors_from_df(wdf):
    """从周K DataFrame计算所有周线因子"""
    if wdf is None or len(wdf) < 20:
        return None
    c = wdf['close'].astype(float)
    o = wdf['open'].astype(float)
    h = wdf['high'].astype(float)
    l = wdf['low'].astype(float)
    v = wdf['volume'].astype(float)
    
    try:
        # 1. MACD
        dif = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
        dea = dif.ewm(span=9, adjust=False).mean()
        macd_golden = bool((dif.iloc[-1] > dea.iloc[-1]) and (dif.shift(1).iloc[-1] <= dea.shift(1).iloc[-1]))
        macd_dif_above_dea = bool(dif.iloc[-1] > dea.iloc[-1])
        macd_dif = float(dif.iloc[-1])
        
        # 2. KDJ
        rsv = ((c - l.rolling(9, min_periods=1).min()) / (h.rolling(9, min_periods=1).max() - l.rolling(9, min_periods=1).min() + 0.0001) * 100).fillna(50)
        k = rsv.rolling(3, min_periods=1).mean().shift(1) * 0.67 + rsv * 0.33
        d = k.rolling(3, min_periods=1).mean()
        kdj_bull = bool(k.iloc[-1] > d.iloc[-1])
        
        # 3. 价格波动线
        llv3 = l.rolling(3, min_periods=1).min()
        hhv6 = h.rolling(6, min_periods=1).max()
        wave = ((c - llv3) / (hhv6 - llv3 + 0.0001) * 4).ewm(span=4, adjust=False).mean()
        avg_line = wave.ewm(span=3, adjust=False).mean()
        avg_turning = bool(avg_line.iloc[-1] >= avg_line.shift(1).iloc[-1] and avg_line.shift(1).iloc[-1] < avg_line.shift(2).iloc[-1])
        
        # 4. DIF Z-score
        dif_ma60 = dif.rolling(60, min_periods=1).mean()
        dif_std60 = dif.rolling(60, min_periods=1).std()
        dif_z = (dif - dif_ma60) / (dif_std60 + 0.0001)
        core_trend = 50 + 20 * dif_z
        core_trend_low = bool(core_trend.iloc[-1] < 40)
        
        # 5. 量能摆动
        vol_n1 = v.rolling(12, min_periods=1).mean()
        vol_n2 = v.rolling(26, min_periods=1).mean()
        vosc_raw = 100 * (vol_n1 - vol_n2) / (vol_n2 + 0.0001)
        vosc_ma60 = vosc_raw.rolling(60, min_periods=1).mean()
        vosc_std60 = vosc_raw.rolling(60, min_periods=1).std()
        vosc_z = (vosc_raw - vosc_ma60) / (vosc_std60 + 0.0001)
        vol_oscillation = 50 + 20 * vosc_z
        vol_freeze = bool(vosc_z.shift(1).iloc[-1] < -0.6 or vosc_z.shift(2).iloc[-1] < -0.6 or vosc_z.shift(3).iloc[-1] < -0.6)
        
        # 6. R0 资金流
        vol_ma5_w = v.rolling(5, min_periods=1).mean()
        vv = v / (vol_ma5_w + 0.0001)
        r0_w = ((c - c.shift(1)) / (c.shift(1) + 0.0001) * 100) * vv
        r0_sum_w = r0_w.abs().rolling(5, min_periods=1).sum()
        weekly_r0 = float(r0_w.iloc[-1])
        weekly_r0_ma5 = float(r0_w.rolling(5, min_periods=1).mean().iloc[-1])
        weekly_main_in_signal = bool((r0_w.iloc[-1] > r0_sum_w.iloc[-1] / 2) and avg_line.iloc[-1] >= avg_line.shift(1).iloc[-1] and avg_line.shift(1).iloc[-1] < avg_line.shift(2).iloc[-1])
        weekly_r0_ma5_cross = bool(r0_w.iloc[-1] > r0_w.rolling(5, min_periods=1).mean().iloc[-1])
        
        # 7. 四量（简化版）
        fv = np.array([0, 0, 0, 0])
        for i in range(len(c)-1):
            bar = 0.6 * o.iloc[i] + 0.4 * c.iloc[i] - l.iloc[i]
            if c.iloc[i] >= o.iloc[i]:
                bar = min(bar, h.iloc[i] - o.iloc[i])
            else:
                bar = min(bar, h.iloc[i] - c.iloc[i])
            idx = min(3, int(bar / (h.iloc[i] - l.iloc[i] + 0.0001) * 4)) if h.iloc[i] - l.iloc[i] > 0 else 0
            fv[idx] += v.iloc[i]
        total_v = fv.sum()
        four_vol_w = fv / (total_v + 1)
        four_vol_main_ratio = float(four_vol_w[3] + four_vol_w[2])  # 超大单+大单
        
        # 8. 筹码密集区
        last_c = c.iloc[-1]
        recent60 = c.tail(60)
        dense_lo, dense_hi = recent60.min(), recent60.max()
        dense_width = dense_hi - dense_lo
        dense_overlap = float(last_c > dense_lo and last_c < dense_hi)
        dense_price = float((dense_lo + dense_hi) / 2)
        
        # 9. 支撑压力
        ma6 = c.rolling(6, min_periods=1).mean().iloc[-1]
        ma12 = c.rolling(12, min_periods=1).mean().iloc[-1]
        ma20 = c.rolling(20, min_periods=1).mean().iloc[-1]
        support = float(min(ma6, ma12, ma20))
        resistance = float(max(ma6, ma12, ma20))
        
        # 10. ATR
        tr = np.maximum(np.maximum(h - l, np.abs(h - c.shift(1))), np.abs(l - c.shift(1)))
        atr14 = tr.rolling(14, min_periods=1).mean()
        atr_rising = bool(atr14.iloc[-1] > atr14.shift(1).iloc[-1])
        
        # 11. WINNER
        recent52 = wdf.tail(52).copy()
        recent52['amt'] = recent52['close'] * recent52['volume']
        total_amt = recent52['amt'].sum()
        if total_amt > 0:
            below = recent52[recent52['close'] <= last_c]['amt'].sum()
            winner_pct = below / total_amt * 100
        else:
            winner_pct = 50.0
        
        # 12. 战略建仓
        pct_13w = wdf.tail(13)['close'].pct_change().fillna(0)
        vol_13w = wdf.tail(13)['volume']
        vol_ma5_13w = vol_13w.rolling(5, min_periods=1).mean()
        build_weeks = 0
        for i in range(len(pct_13w)):
            if pct_13w.iloc[i] > 0.08 and vol_13w.iloc[i] > vol_ma5_13w.iloc[i] * 1.5:
                build_weeks += 1
        
        # 13. 筹码集中度
        recent60_df = wdf.tail(60).copy()
        recent60_df['amt'] = recent60_df['close'] * recent60_df['volume']
        total_a = recent60_df['amt'].sum()
        conc = 50.0
        if total_a > 0:
            s = recent60_df.sort_values('close')
            s['cum'] = s['amt'].cumsum()
            try:
                c5 = s.loc[s['cum'] >= total_a * 0.05, 'close'].iloc[0]
                c95 = s.loc[s['cum'] >= total_a * 0.95, 'close'].iloc[0]
                conc = (c95 - c5) / (c95 + c5) * 100
            except:
                pass
        
        # 14. 控盘
        ma45 = c.rolling(45, min_periods=1).mean().iloc[-1]
        ma90 = c.rolling(90, min_periods=1).mean().iloc[-1]
        ma30 = c.rolling(30, min_periods=1).mean().iloc[-1]
        inst_control = bool(ma30 > ma45 > ma90)
        
        # 15. 周线RPS（50周排名）
        recent50 = c.tail(50)
        rps_50 = float(np.sum(recent50 < last_c) / (len(recent50) - 1) * 100) if len(recent50) > 1 else 50.0
        
        # 16. 大盘多头（用上证指数000001）
        idx_c = _reader.daily('000001')['close']
        if len(idx_c) >= 60:
            idx_ma60 = idx_c.rolling(60, min_periods=1).mean()
            market_bull = bool(idx_c.iloc[-1] > idx_ma60.iloc[-1] and idx_ma60.iloc[-1] > idx_ma60.shift(5).iloc[-1] if len(idx_ma60) > 5 else False)
        else:
            market_bull = True
        
        # 17. C > MA60
        ma60 = c.rolling(60, min_periods=1).mean()
        c_above_ma60 = bool(last_c > ma60.iloc[-1])
        
        # 18. 趋势
        trend20 = (last_c / c.iloc[-20] - 1) * 100 if len(c) >= 20 else 0
        individual_trend = float(50 + 20 * (trend20 / 50) if abs(trend20) <= 50 else 100 * np.sign(trend20))
        
        # 19. 散户动能
        retail_momentum = float(50 + 20 * (np.log(last_c / c.iloc[-20] + 1e-9)) if len(c) >= 20 else 50)
        
        # 20. 行业趋势低位
        ind_trend_low = bool(last_c < c.rolling(20, min_periods=1).mean().iloc[-1])
        
        return {
            'weekly_macd_golden': int(macd_golden),
            'weekly_macd_dif_above_dea': int(macd_dif_above_dea),
            'weekly_macd_dif': macd_dif,
            'weekly_kdj_bull': int(kdj_bull),
            'weekly_avg_turning': int(avg_turning),
            'weekly_core_trend': float(core_trend.iloc[-1]),
            'weekly_core_trend_low': int(core_trend_low),
            'weekly_vol_oscillation': float(vol_oscillation.iloc[-1]),
            'weekly_vol_freeze': int(vol_freeze),
            'weekly_r0': weekly_r0,
            'weekly_r0_ma5': weekly_r0_ma5,
            'weekly_main_in_signal': int(weekly_main_in_signal),
            'weekly_r0_ma5_cross': int(weekly_r0_ma5_cross),
            'weekly_four_vol_main_ratio': four_vol_main_ratio,
            'weekly_dense_overlap': dense_overlap,
            'weekly_dense_price': dense_price,
            'weekly_support': support,
            'weekly_resistance': resistance,
            'weekly_atr_rising': int(atr_rising),
            'weekly_winner_pct': float(winner_pct),
            'weekly_build_weeks': build_weeks,
            'weekly_conc': conc,
            'weekly_inst_control': int(inst_control),
            'weekly_rps_50': rps_50,
            'weekly_market_bull': int(market_bull),
            'weekly_c_above_ma60': int(c_above_ma60),
            'weekly_individual_trend': individual_trend,
            'weekly_retail_momentum': retail_momentum,
            'weekly_ind_trend_low': int(ind_trend_low),
            'weekly_last_close': float(last_c),
        }
    
    except Exception as e:
        return {'_error': str(e)}


def calc_daily_factors_from_df(df):
    """从日K DataFrame计算所有日线因子"""
    if df is None or len(df) < 120:
        return None
    c = df['close'].astype(float)
    o = df['open'].astype(float)
    h = df['high'].astype(float)
    l = df['low'].astype(float)
    v = df['volume'].astype(float)
    last_c = c.iloc[-1]
    
    try:
        # 1. RPS（相对强度）
        def rps(d):
            n = min(d, len(c)-1)
            return float(np.sum(c.tail(n+1).iloc[1:] < last_c) / n * 100) if n > 0 else 50.0
        rps_50 = rps(50)
        rps_120 = rps(120)
        rps_250 = rps(250)
        rps_strong = int(rps_120 > 60 and rps_250 > 50)
        
        # 2. DCZ（追高指标）
        def dcz(d):
            n = min(d, len(c)-1)
            if n <= 0: return False
            recent = c.tail(n+1).iloc[1:]
            return bool(last_c > recent.max() * 0.95)
        dcz_up = int(dcz(5))
        
        # 3. 强势主线
        trend10 = (last_c / c.iloc[-10] - 1) * 100 if len(c) >= 10 else 0
        trend20 = (last_c / c.iloc[-20] - 1) * 100 if len(c) >= 20 else 0
        strong_main = int(trend10 > 3 and trend20 > 5)
        
        # 4. 半年低位
        half_year_n = min(120, len(c)-1)
        half_year_low = int(last_c < c.tail(half_year_n+1).iloc[1:].quantile(0.3) if half_year_n >= 60 else 0)
        
        # 5. 趋势（日）
        daily_trend = float(50 + 20 * (trend20 / 50) if abs(trend20) <= 50 else 100 * np.sign(trend20))
        
        # 6. 量能（日）
        vol_ma5 = v.rolling(5, min_periods=1).mean().iloc[-1]
        vol_ma20 = v.rolling(20, min_periods=1).mean().iloc[-1]
        vol_ratio = float(v.iloc[-1] / (vol_ma5 + 0.0001))
        vol_expansion = int(v.iloc[-1] > vol_ma5 * 1.5)
        
        # 7. 四量（日）
        fv = np.array([0, 0, 0, 0])
        n = min(20, len(c)-1)
        for i in range(len(c)-n, len(c)):
            if i < 1: continue
            bar = 0.6 * o.iloc[i] + 0.4 * c.iloc[i] - l.iloc[i]
            if c.iloc[i] >= o.iloc[i]:
                bar = min(bar, h.iloc[i] - o.iloc[i])
            else:
                bar = min(bar, h.iloc[i] - c.iloc[i])
            w = h.iloc[i] - l.iloc[i] + 0.0001
            idx = min(3, int(bar / w * 4))
            fv[idx] += v.iloc[i]
        total_v = fv.sum()
        four_vol_main_ratio = float((fv[3] + fv[2]) / (total_v + 1))
        
        # 8. MACD（日）
        dif = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
        dea = dif.ewm(span=9, adjust=False).mean()
        daily_macd_golden = int((dif.iloc[-1] > dea.iloc[-1]) and (dif.shift(1).iloc[-1] <= dea.shift(1).iloc[-1]))
        daily_macd_dif_above_dea = int(dif.iloc[-1] > dea.iloc[-1])
        
        # 9. WINNER（日）
        recent20 = df.tail(20).copy()
        recent20['amt'] = recent20['close'] * recent20['volume']
        total_a = recent20['amt'].sum()
        winner_pct = float(np.sum(recent20[recent20['close'] <= last_c]['amt']) / (total_a + 0.0001) * 100) if total_a > 0 else 50.0
        
        # 10. ATR（日）
        tr = np.maximum(np.maximum(h - l, np.abs(h - c.shift(1))), np.abs(l - c.shift(1)))
        atr14 = tr.rolling(14, min_periods=1).mean().iloc[-1]
        atr_rising = int(atr14 > tr.rolling(14, min_periods=1).mean().shift(1).iloc[-1])
        
        # 11. 大盘（日）
        idx_c = _reader.daily('000001')['close']
        if len(idx_c) >= 60:
            idx_ma60 = idx_c.rolling(60, min_periods=1).mean()
            daily_market_bull = int(idx_c.iloc[-1] > idx_ma60.iloc[-1])
        else:
            daily_market_bull = 1
        
        # 12. 半周低位
        daily_ind_trend_low = int(last_c < c.rolling(20, min_periods=1).mean().iloc[-1])
        
        return {
            'daily_rps_50': rps_50,
            'daily_rps_120': rps_120,
            'daily_rps_250': rps_250,
            'daily_rps_strong': rps_strong,
            'daily_dcz_up': dcz_up,
            'daily_strong_main': strong_main,
            'daily_half_year_low': half_year_low,
            'daily_trend': daily_trend,
            'daily_vol_ratio': vol_ratio,
            'daily_vol_expansion': vol_expansion,
            'daily_four_vol_main_ratio': four_vol_main_ratio,
            'daily_macd_golden': daily_macd_golden,
            'daily_macd_dif_above_dea': daily_macd_dif_above_dea,
            'daily_winner_pct': winner_pct,
            'daily_atr_rising': atr_rising,
            'daily_market_bull': daily_market_bull,
            'daily_ind_trend_low': daily_ind_trend_low,
            'daily_last_close': float(last_c),
        }
    
    except Exception as e:
        return {'_error': str(e)}


# ══════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════

def log(m):
    print(f'[{datetime.now().strftime("%H:%M:%S")}] {m}', flush=True)

def clear_log():
    open(LOG_FILE, 'w', encoding='utf-8').close()

def log_and_file(m):
    log(m)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f'[{datetime.now().strftime("%H:%M:%S")}] {m}\n')

LOG_DIR = 'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
LOG_FILE = os.path.join(LOG_DIR, 'tdx_self_driving_log.txt')
REPORT_DIR = LOG_DIR
os.makedirs(LOG_DIR, exist_ok=True)


def get_return_matrix(code, reader, days=180, max_f=30):
    """获取历史收益率矩阵（预计算）"""
    df = reader.daily(code)
    if df is None or len(df) < max_f + 5:
        return None
    closes = df['close'].astype(float).values
    n_wins = len(closes) - max_f
    if n_wins < 10:
        return None
    rets = {}
    for day in range(1, max_f + 1):
        base = closes[:n_wins]
        fut = closes[day:n_wins + day]
        mask = (base > 0) & (fut > 0)
        rets[day] = (fut[mask] / base[mask] - 1) * 100
    return rets


def build_rule(params):
    def rule_fn(wf_d, df_d):
        for prefix, key, op, t in params:
            if prefix == 'w':
                full_key = f'weekly_{key}'
                val = wf_d.get(full_key, None)
            else:
                full_key = f'daily_{key}'
                val = df_d.get(full_key, None)
            if val is None:
                return False
            if op == '>':
                if not (val > t):
                    return False
            elif op == '<':
                if not (val < t):
                    return False
            elif op == '==':
                if not (val == t):
                    return False
        return True
    return rule_fn


def label_of(params):
    return ' + '.join([f'{p[0]}_{p[1]}{p[2]}{p[3]}' for p in params])


def parse_params(label):
    """解析标签回参数列表。跳过变异碎片（如 _M_ / _ED0_ 等不含操作符的部分）"""
    params = []
    for part in label.split(' + '):
        def _t(v):
            try:
                return int(v)
            except:
                try:
                    return float(v)
                except:
                    return v
        # 只处理含操作符的规范片段：格式 {prefix}_{factor}{op}{threshold}
        if '>' in part:
            pk, t = part.split('>', 1)
            if not pk.startswith(('w_', 'd_')) or len(pk) < 4:
                continue
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '>', _t(t)))
        elif '<' in part:
            pk, t = part.split('<', 1)
            if not pk.startswith(('w_', 'd_')) or len(pk) < 4:
                continue
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '<', _t(t)))
        elif '==' in part:
            pk, t = part.split('==', 1)
            if not pk.startswith(('w_', 'd_')) or len(pk) < 4:
                continue
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '==', _t(t)))
    return params


def run_backtest(selected_codes, unselected_codes, return_cache, max_f=30):
    """用预计算收益率矩阵回测"""
    def agg(codes):
        rets = {}
        for day in range(1, max_f + 1):
            arrs = [return_cache[c][day] for c in codes if c in return_cache and day in return_cache[c]]
            rets[day] = np.concatenate(arrs) if arrs else np.array([])
        return rets
    
    sr = agg(selected_codes)
    ur = agg(unselected_codes)
    
    result = {
        'selected_n': len(selected_codes),
        'unselected_n': len(unselected_codes),
        'selected_pct': round(len(selected_codes) / max(1, len(selected_codes) + len(unselected_codes)) * 100, 2),
        'returns': {},
    }
    
    for d in range(1, max_f + 1):
        s = sr.get(d, np.array([]))
        u = ur.get(d, np.array([]))
        if len(s) < 100 or len(u) < 100:
            continue
        result['returns'][d] = {
            'win_s': round(float(np.sum(s > 0) / len(s) * 100), 1),
            'win_u': round(float(np.sum(u > 0) / len(u) * 100), 1),
            'avg_s': round(float(np.mean(s)), 2),
            'avg_u': round(float(np.mean(u)), 2),
            'excess': round(float(np.mean(s) - np.mean(u)), 2),
        }
    
    return result


def run_evolver(max_iterations=6):
    clear_log()
    log_and_file('=' * 60)
    log_and_file('TDX自驱进化引擎（纯本地数据）')
    log_and_file(f'启动: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    log_and_file(f'迭代: {max_iterations}代')
    log_and_file('=' * 60)
    
    global _reader
    _reader = _TdxReader()
    
    # 1. 获取全市场代码
    log_and_file('获取全市场代码...')
    all_codes = _reader.list_codes()
    log_and_file(f'总数: {len(all_codes)}')
    
    # 取前5000只（覆盖主要A股）
    sample_codes = all_codes[:5000]
    log_and_file(f'取样: {len(sample_codes)}只')
    
    # 2. 计算因子 + 收益率矩阵
    log_and_file('计算因子 + 收益率矩阵...')
    wf_all = {}      # code -> weekly factors
    df_all = {}      # code -> daily factors
    ret_cache = {}   # code -> {day: returns}
    valid_codes = []
    
    t0 = time.time()
    for i, code in enumerate(sample_codes):
        if i % 500 == 0:
            log_and_file(f'  进度: {i}/{len(sample_codes)}')
        
        # 日K
        ddf = _reader.daily(code)
        if ddf is None or len(ddf) < 180:
            continue
        
        # 周K
        wdf = _reader.weekly(code)
        if wdf is None or len(wdf) < 20:
            continue
        
        # 因子
        wf = calc_weekly_factors_from_df(wdf)
        df = calc_daily_factors_from_df(ddf)
        if wf is None or '_error' in wf or df is None or '_error' in df:
            continue
        
        # 收益率矩阵
        rets = get_return_matrix(code, _reader)
        if rets is None:
            continue
        
        wf_all[code] = wf
        df_all[code] = df
        ret_cache[code] = rets
        valid_codes.append(code)
        
        if len(valid_codes) % 500 == 0:
            log_and_file(f'  有效: {len(valid_codes)} ({len(valid_codes)/i*100:.0f}%)')
    
    log_and_file(f'因子计算完成: {len(valid_codes)}只有效, 耗时{time.time()-t0:.0f}s')
    
    # 3. 进化迭代
    log_and_file(f'\n{"="*40}')
    log_and_file(f'[进化开始] 基于{len(valid_codes)}只股票因子')
    
    core_factors = [
        ('w', 'rps_50', 'gt', [40, 50, 55, 60, 65, 70]),
        ('w', 'macd_golden', 'eq', [1]),
        ('w', 'macd_dif_above_dea', 'eq', [1]),
        ('w', 'individual_trend', 'gt', [50, 55, 60]),
        ('w', 'core_trend_low', 'lt', [30, 35, 40]),
        ('w', 'c_above_ma60', 'eq', [1]),
        ('w', 'winner_pct', 'gt', [30, 40, 50]),
        ('w', 'inst_control', 'eq', [1]),
        ('w', 'four_vol_main_ratio', 'gt', [0.50, 0.55, 0.60, 0.65]),
        ('w', 'main_in_signal', 'eq', [1]),
        ('w', 'r0_ma5_cross', 'eq', [1]),
        ('w', 'retail_momentum', 'gt', [50, 55, 60]),
        ('w', 'ind_trend_low', 'lt', [30, 35]),
        ('d', 'rps_120', 'gt', [40, 50, 55, 60, 65, 70]),
        ('d', 'rps_250', 'gt', [40, 50, 55, 60]),
        ('d', 'rps_50', 'gt', [40, 50, 55, 60]),
        ('d', 'dcz_up', 'eq', [0]),
        ('d', 'strong_main', 'eq', [1]),
        ('d', 'rps_strong', 'eq', [1]),
        ('d', 'half_year_low', 'eq', [1]),
        ('d', 'vol_expansion', 'eq', [1]),
        ('d', 'four_vol_main_ratio', 'gt', [0.50, 0.55, 0.60, 0.65]),
        ('d', 'macd_golden', 'eq', [1]),
        ('d', 'macd_dif_above_dea', 'eq', [1]),
    ]
    
    # 种子规则（含params，从combo测试结果）
    seeds = [
        (None, [('d', 'rps_120', '>', 40), ('d', 'dcz_up', '==', 0)]),       # RPS温和+DCZ不上行
        (None, [('d', 'rps_120', '>', 35), ('d', 'dcz_up', '==', 0)]),        # 更宽松RPS
        (None, [('w', 'four_vol_main_ratio', '>', 0.50), ('w', 'rps_50', '>', 40)]),  # 四量+RPS
        (None, [('w', 'rps_50', '>', 45), ('w', 'macd_dif_above_dea', '==', 1)]),     # RPS+MACD
        (None, [('d', 'rps_250', '>', 45), ('d', 'dcz_up', '==', 0)]),              # 长RPS+DCZ
        (None, [('w', 'individual_trend', '>', 48), ('d', 'dcz_up', '==', 0)]),      # 趋势+DCZ
        (None, [('w', 'macd_dif_above_dea', '==', 1), ('d', 'dcz_up', '==', 0)]),    # MACD+DCZ
        (None, [('w', 'c_above_ma60', '==', 1), ('d', 'rps_120', '>', 40)]),         # MA60+RPS
        (None, [('w', 'four_vol_main_ratio', '>', 0.45), ('d', 'rps_120', '>', 40)]),# 四量+RPS
        (None, [('w', 'retail_momentum', '>', 45), ('d', 'dcz_up', '==', 0)]),        # 散户动量+DCZ
    ]
    # 进化过程中维护 params 列表（不依赖 label 反解析）
    top5_params = None  # list of params tuples
    
    random.seed(42)
    all_best = {}
    
    # 种子
    log_and_file('\n[Generation 0] 种子规则...')
    for i, (plabel, params) in enumerate(seeds):
        label = plabel if plabel else label_of(params)
        rule_fn = build_rule(params)
        selected = [c for c in valid_codes if rule_fn(wf_all[c], df_all[c])]
        unselected = [c for c in valid_codes if c not in selected]
        r = run_backtest(selected, unselected, ret_cache)
        all_best[label] = {'result': r, 'params': params}
        log_and_file(f'  S{i}: {label} | 选{len(selected)} | 30日超额={r["returns"].get(30,{}).get("excess","+0.00")}%')
    
    ranked = sorted(all_best.items(), key=lambda x: x[1]['result']['returns'].get(30, {}).get('excess', 0), reverse=True)
    top5 = [(l, d) for l, d in ranked if d['result']['selected_n'] > 0][:5]
    if not top5:
        top5 = ranked[:5]
    top5_params = [d['params'] for _, d in top5]
    log_and_file(f'G0 TOP1: {top5[0][0]} excess={top5[0][1]["result"]["returns"].get(30,{}).get("excess","+0.00")}%')
    
    best_ever = top5[0][1]['result']['returns'].get(30, {}).get('excess', 0)
    
    # 进化
    for gen in range(1, max_iterations + 1):
        log_and_file(f'\n{"="*40}')
        log_and_file(f'[Generation {gen}]')
        all_best = {}
        
        for pidx, (parent_params) in enumerate(top5_params):
            if not parent_params:
                continue
            
            # 变异1: 调阈值
            for fidx in range(len(parent_params)):
                new = [list(p) for p in parent_params]
                ef, ek, eop, et = new[fidx]
                fi = next((f for f in core_factors if f[0]==ef and f[1]==ek), None)
                if fi:
                    tl = fi[3]
                    try:
                        ti = tl.index(et)
                    except:
                        ti = 0
                    nt = tl[(ti + (1 if random.random() > 0.5 else -1)) % len(tl)]
                    new[fidx][3] = nt
                    new = [tuple(p) for p in new]
                    l = label_of(new)
                    rfn = build_rule(new)
                    sel = [c for c in valid_codes if rfn(wf_all[c], df_all[c])]
                    un = [c for c in valid_codes if c not in sel]
                    r = run_backtest(sel, un, ret_cache)
                    all_best[l] = {'result': r, 'params': new}
                    if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                        best_ever = r['returns'].get(30, {}).get('excess', 0)
                        log_and_file(f'  ★ NEW BEST! {l} excess={best_ever:+.2f}%')
            
            # 变异2: 加条件
            new = parent_params.copy()
            ef, ek, eop, eth = random.choice(core_factors)
            nt = random.choice(eth)
            new.append((ef, ek, '==' if eop=='eq' else ('>' if eop=='gt' else '<'), nt))
            l = label_of(new)
            rfn = build_rule(new)
            sel = [c for c in valid_codes if rfn(wf_all[c], df_all[c])]
            un = [c for c in valid_codes if c not in sel]
            r = run_backtest(sel, un, ret_cache)
            all_best[l] = {'result': r, 'params': new}
            if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                best_ever = r['returns'].get(30, {}).get('excess', 0)
                log_and_file(f'  ★ NEW BEST! {l} excess={best_ever:+.2f}%')
            
            # 变异3: 删条件（仅3个以上）
            if len(parent_params) >= 3:
                ri = random.randint(0, len(parent_params)-1)
                new = parent_params[:ri] + parent_params[ri+1:]
                l = label_of(new)
                rfn = build_rule(new)
                sel = [c for c in valid_codes if rfn(wf_all[c], df_all[c])]
                un = [c for c in valid_codes if c not in sel]
                r = run_backtest(sel, un, ret_cache)
                all_best[l] = {'result': r, 'params': new}
                if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                    best_ever = r['returns'].get(30, {}).get('excess', 0)
                    log_and_file(f'  ★ NEW BEST! {l} excess={best_ever:+.2f}%')
        
        ranked = sorted(all_best.items(), key=lambda x: x[1]['result']['returns'].get(30, {}).get('excess', 0), reverse=True)
        top5 = [(l, d) for l, d in ranked if d['result']['selected_n'] > 0][:5]
        if not top5:
            top5 = ranked[:5]
        top5_params = [d['params'] for _, d in top5]
        log_and_file(f'G{gen} TOP1: {top5[0][0]} excess={top5[0][1]["result"]["returns"].get(30,{}).get("excess","+0.00")}% selected={top5[0][1]["result"]["selected_n"]}')
    
    # 4. 最终报告
    log_and_file('\n' + '='*60)
    log_and_file(f'进化完成！最优公式')
    
    lines = []
    lines.append(f'# TDX自驱进化报告 {datetime.now().strftime("%Y%m%d")}')
    lines.append('')
    lines.append(f'本地TDX数据 | 全市场{len(all_codes)}只 | 有效{len(valid_codes)}只 | 进化{max_iterations}代')
    lines.append('')
    lines.append('## 最优公式TOP10（30日超额收益）')
    lines.append('')
    
    for rank, (label, data) in enumerate(ranked[:10], 1):
        res = data['result']
        r30 = res['returns'].get(30, {})
        r10 = res['returns'].get(10, {})
        r5 = res['returns'].get(5, {})
        lines.append(f'#{rank} {label}')
        lines.append(f'  选出: {res["selected_n"]}只({res["selected_pct"]:.1f}%) | 30日超额: **{r30.get("excess","+0.00")}%** | 10日: {r10.get("excess","+0.00")}% | 5日: {r5.get("excess","+0.00")}%')
        lines.append(f'  30日胜率: {r30.get("win_s","-")}% vs {r30.get("win_u","-")}% | 平均: {r30.get("avg_s","-")}%(选) vs {r30.get("avg_u","-")}%(大盘)')
        lines.append('')
    
    report = '\n'.join(lines)
    log_and_file('\n' + report)
    
    # 保存
    report_path = os.path.join(REPORT_DIR, f'tdx_evolver_report_{datetime.now().strftime("%Y%m%d")}.txt')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report)
    log_and_file(f'\n报告: {report_path}')
    log_and_file('完成')
    
    return ranked[:10]


if __name__ == '__main__':
    run_evolver(max_iterations=6)
