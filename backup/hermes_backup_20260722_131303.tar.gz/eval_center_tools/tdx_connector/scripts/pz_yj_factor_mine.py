import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_telegram_token
"""
pz_yj_factor_mine.py — 盘中预警因子反推引擎（日线框架）
==================================================
只分析日线公式因子，不与综合评分因子混合。
每天15:30跑，追踪日线标的未来1/3/5/10/20日收益。
"""
import sys, os, json, time, math
sys.path.insert(0, r'D:/Hermes/评估中心/tools')
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')

import numpy as np
from datetime import datetime, timedelta

DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)
SNAPSHOT_FILE = os.path.join(DATA_DIR, 'pz_yj_snapshots.json')
RESULT_FILE = os.path.join(DATA_DIR, 'pz_yj_results.json')
CORR_FILE = os.path.join(DATA_DIR, 'pz_yj_factor_corr.json')
WEIGHT_FILE = os.path.join(DATA_DIR, 'pz_yj_weights.json')


def normalize(c):
    return c[1:] if len(c) == 7 and c[0] in '012' else c


def rank_data(x):
    arr = np.array(x, dtype=float)
    order = np.argsort(arr)
    ranks = np.empty(len(arr), dtype=float)
    i = 0
    while i < len(order):
        j = i
        while j < len(order) - 1 and np.abs(arr[order[j]] - arr[order[i]]) < 1e-12:
            j += 1
        avg = (i + j) / 2.0 + 1
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def spearmanr_np(x, y):
    rx, ry = rank_data(x), rank_data(y)
    sx, sy = np.std(rx), np.std(ry)
    if sx == 0 or sy == 0:
        return 0.0, 1.0
    rho = np.corrcoef(rx, ry)[0, 1]
    n = len(x)
    if n < 6:
        return float(rho), 1.0
    t_val = rho * math.sqrt((n - 2) / max(1e-10, 1 - rho * rho))
    p = math.erfc(abs(t_val) / math.sqrt(2))
    return float(rho), float(p)


def load_snapshots():
    if os.path.exists(SNAPSHOT_FILE):
        return json.load(open(SNAPSHOT_FILE, encoding='utf-8'))
    return {'entries': [], 'stats': {}}


def save_snapshots(data):
    json.dump(data, open(SNAPSHOT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)


def record_snapshot(codes_7, factors, market_data, end_date=None):
    if end_date is None:
        end_date = datetime.now().strftime('%Y%m%d')
    data = load_snapshots()
    stats = data.get('stats', {})
    new = 0
    for orig in codes_7:
        p = normalize(orig)
        if not p or len(p) != 6:
            continue
        f = factors.get(p, {})
        if 'error' in f:
            continue
        if any(e['code'] == p and e['date'] == end_date for e in data['entries']):
            continue
        data['entries'].append({
            'code': p, 'date': end_date, 'factors': f,
            'market': market_data.get(p, {}),
        })
        stats[p] = {'first_seen': end_date, 'count': stats.get(p, {}).get('count', 0) + 1}
        new += 1
    save_snapshots(data)
    print(f'[PZYJ] new={new} total={len(data["entries"])}')
    return new


def calc_future_return(start_date, code, forward_days):
    try:
        import tushare as ts
        pro = ts.pro_api(get_tushare_token())
        ts_code = code + '.SH' if code[0] in '69' else code + '.SZ'
        start_dt = datetime.strptime(start_date, '%Y%m%d')
        future_dt = start_dt + timedelta(days=forward_days)
        future_end = future_dt.strftime('%Y%m%d')
        df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=future_end)
        if df is None or df.empty or len(df) < 2:
            return None
        df = df.sort_values('trade_date').reset_index(drop=True)
        return round((df.iloc[-1]['close'] / df.iloc[0]['close'] - 1) * 100, 2)
    except Exception as e:
        print(f'  [WARN] {code} {forward_days}d: {e}')
        return None


def track_results(codes_list, days_check=[1, 3, 5, 10, 20]):
    """日线引擎用日级别跟踪"""
    data = load_snapshots()
    if not data['entries']:
        print('[PZYJ] no snapshots')
        return []
    results = []
    for entry in data['entries']:
        code, start = entry['code'], entry['date']
        elapsed = (datetime.now() - datetime.strptime(start, '%Y%m%d')).days
        for d in days_check:
            if elapsed < d:
                continue
            ret = calc_future_return(start, code, d)
            if ret is not None:
                results.append({
                    'code': code, 'start': start, 'days': d,
                    'return': ret, 'factors': entry['factors'],
                })
    json.dump(results, open(RESULT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    print(f'[PZYJ] {len(results)} records')
    return results


def compute_correlation(results):
    if not results:
        return {}
    import pandas as pd
    df = pd.DataFrame(results)
    corr = {}
    for d in sorted(df['days'].unique()):
        g = df[df['days'] == d]
        if len(g) < 5:
            continue
        fkeys = list(g['factors'].iloc[0].keys())
        for fk in fkeys:
            vals, rets = [], []
            for _, row in g.iterrows():
                fv = row['factors'].get(fk)
                if fv is not None and isinstance(fv, (int, float, np.floating)):
                    vals.append(float(fv))
                    rets.append(row['return'])
            if len(vals) < 5:
                continue
            rho, pval = spearmanr_np(vals, rets)
            corr.setdefault(fk, {})[f'day{d}'] = {
                'rho': round(rho, 3), 'pval': round(pval, 4),
                'n': len(vals), 'sig': pval < 0.05}
    json.dump(corr, open(CORR_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return corr


def recommend_weights(corr):
    if not corr:
        return {}
    names = {
        'daily_qx_bull': 'QX均线多头',
        'daily_four_layer_all_red': '四层全红',
        'daily_main_in': '主力进',
        'daily_r0': 'R0资金动量',
        'daily_avg_line': '平均线',
        'daily_avg_not_overbought': '平均线非超买',
        'daily_dcz_up': 'DCZ上行',
        'daily_c_above_dcz': '站上DCZ',
        'daily_market_bull': '大盘多头',
        'daily_capital_attack': '资金攻击',
        'daily_must_rise': '必涨信号',
        'daily_huashen_red': '花神红',
        'daily_rps_50': '50日RPS',
        'daily_rps_120': '120日RPS',
        'daily_rps_250': '250日RPS',
        'daily_rps_strong': 'RPS强者',
        'daily_vol_2x': '放量2倍',
        'daily_is_yang': '收阳',
        'daily_ma_bull_arrange': '均线多头排列',
        'daily_c_above_ma20': '站上20日线',
        'daily_relative_position': '相对价位',
        'daily_ind_trend': '个股趋势',
        'daily_ind_trend_low': '趋势低位',
        'daily_retail_momentum': '散户动能',
        'daily_trend_golden': '趋势金叉',
        'daily_half_year_low': '半年低位',
        'daily_turnover_ratio': '换手率',
        'daily_strong_main': '强势主线',
        'daily_ret_50': '50日涨幅',
        'daily_ret_120': '120日涨幅',
        'daily_dynamic_vol_ratio': '动态量比',
        'daily_yellow_rising': '黄线上行',
        'daily_qx': 'QX值',
        'daily_retail_red': '散户红',
        'daily_spec_red': '游资红',
        'daily_inst_red': '机构红',
        'daily_main_red': '主力红',
        'daily_dcz': 'DCZ筹码线',
    }
    w = {}
    for fk, days in corr.items():
        rhos = [abs(v['rho']) for v in days.values()]
        if not rhos:
            continue
        avg = sum(rhos) / len(rhos)
        sig = sum(1 for v in days.values() if v['sig'])
        weight = max(1.0, round(avg * 100, 1))
        w[fk] = {'weight': weight, 'avg_rho': round(avg, 3), 'sig_days': sig,
                 'name': names.get(fk, fk)}
    total = sum(v['weight'] for v in w.values())
    if total > 0:
        for k in w:
            w[k]['weight'] = round(w[k]['weight'] / total * 100, 1)
    json.dump(w, open(WEIGHT_FILE, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    return w


def run():
    from astock_bridge import tencent_quote
    from formula_factors import calc_daily_formula_factors

    print('=' * 50)
    print('盘中预警因子反推引擎（日线框架）')
    print('=' * 50)

    try:
        content = open(r'D:/TDX/T0002/blocknew/PZYJ.blk', encoding='gbk').read()
        codes_7 = [l.strip() for l in content.splitlines() if l.strip()]
    except Exception as e:
        print(f'[ERROR] PZYJ.blk: {e}')
        return

    pure = [normalize(c) for c in codes_7]
    if not pure:
        print('[WARN] 板块为空')
        return

    print(f'当前盘中预警: {len(pure)} 只')
    market_data = tencent_quote(pure)

    t0 = time.time()
    daily_factors = calc_daily_formula_factors(codes_7)
    print(f'日线公式因子计算: {time.time()-t0:.1f}s')

    today = datetime.now().strftime('%Y%m%d')
    new = record_snapshot(codes_7, daily_factors, market_data, today)

    results = track_results(pure, [1, 3, 5, 10, 20])
    corr = compute_correlation(results)
    weights = recommend_weights(corr)

    lines = []
    lines.append(f'# 盘中预警因子反推报告 {today}')
    lines.append('')
    data = load_snapshots()
    lines.append(f'## 快照统计')
    lines.append(f'累计: {len(data["entries"])} | 收益: {len(results)} | 新增: {new}')
    lines.append('')
    lines.append('## 因子相关性（日线框架）')
    lines.append('')

    if corr:
        lines.append('| 因子 | 1d | 3d | 5d | 10d | 20d | 显著 |')
        lines.append('|------|----|----|----|-----|-----|------|')
        for fk, days in sorted(corr.items(),
                               key=lambda x: max(abs(v['rho']) for v in x[1].values()),
                               reverse=True):
            info = days.get('day1', {})
            d3 = days.get('day3', {})
            d5 = days.get('day5', {})
            d10 = days.get('day10', {})
            d20 = days.get('day20', {})
            sig = sum(1 for v in days.values() if v['sig'])
            r1 = f'{info.get("rho",0):+.3f}' if 'rho' in info else '-'
            r3 = f'{d3.get("rho",0):+.3f}' if 'rho' in d3 else '-'
            r5 = f'{d5.get("rho",0):+.3f}' if 'rho' in d5 else '-'
            r10 = f'{d10.get("rho",0):+.3f}' if 'rho' in d10 else '-'
            r20 = f'{d20.get("rho",0):+.3f}' if 'rho' in d20 else '-'
            lines.append(f'| {fk} | {r1} | {r3} | {r5} | {r10} | {r20} | {sig} |')
    else:
        lines.append('数据不足（需≥5个有效样本）')

    lines.append('')
    lines.append('## 推荐权重（日线因子）')
    lines.append('')
    if weights:
        for fk, wv in sorted(weights.items(), key=lambda x: -x[1]['weight']):
            lines.append(f'- **{wv["name"]}**({fk}): {wv["weight"]:.1f}% rho={wv["avg_rho"]:+.3f}')
    else:
        lines.append('数据不足')

    report = '\n'.join(lines)
    print(report)

    try:
        import urllib.request
        TOKEN = get_telegram_token()
        CHAT_ID = '8673372605'
        handler = urllib.request.ProxyHandler({'http': 'http://127.0.0.1:7890',
                                               'https': 'http://127.0.0.1:7890'})
        opener = urllib.request.build_opener(handler)
        opener.timeout = 60
        url = f'https://api.telegram.org/bot{TOKEN}/sendMessage'
        data_tg = json.dumps({'chat_id': CHAT_ID, 'text': report,
                              'parse_mode': 'Markdown', 'disable_web_page_preview': True}).encode('utf-8')
        req = urllib.request.Request(url, data=data_tg, headers={'Content-Type': 'application/json'})
        resp = opener.open(req)
        result = json.loads(resp.read())
        print(f'[TG] {"ok" if result.get("ok") else result}')
    except Exception as e:
        print(f'[TG] 失败: {e}')


if __name__ == '__main__':
    run()
