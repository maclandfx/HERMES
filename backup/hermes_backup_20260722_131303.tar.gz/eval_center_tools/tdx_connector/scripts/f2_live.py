"""F2 周线主进策略 — 实盘执行脚本
功能：周一开盘前运行，输出本周买入清单（最多5只，一揽子买入）
用法：python3 f2_live.py [--date 20260720]
输出：本周应买入的股票列表（A级优先，按RPS50降序，最多5只）
"""
import pandas as pd, numpy as np, sys, time, argparse, os

sys.path.insert(0, '.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find('if __name__')], 'wf', 'exec'), wf.__dict__)
_s = wf._s

# ============ F2 公式（与回测一致）============
def formula_2_live(f, ts):
    try:
        main_in = _s(f,'main_in_signal',ts)
        market_bull = _s(f,'market_bull',ts)
        DCZ = _s(f,'DCZ',ts); C = _s(f,'close',ts)
        DCZ_s = f['DCZ']
        # 强信号: DCZ>REF(DCZ,3)
        DCZ_gt_ref3 = pd.notna(DCZ) and pd.notna(DCZ_s.shift(3).loc[ts]) and DCZ > DCZ_s.shift(3).loc[ts]
        C_above_DCZ = C > DCZ if pd.notna(C) and pd.notna(DCZ) else False
        vol_ratio = _s(f,'vol_ratio',ts)
        # A级信号
        is_A = (main_in == 1 and market_bull == 1 and DCZ_gt_ref3
                and vol_ratio > 1.2 and C_above_DCZ)
        # B级信号
        avg_line = _s(f,'avg_line',ts); huashen = _s(f,'huashen',ts)
        DCZ_s3 = DCZ_s.shift(3).loc[ts] if ts in DCZ_s.shift(3).index else np.nan
        is_B = (main_in == 1 and (pd.notna(DCZ) and pd.notna(DCZ_s3) and DCZ >= DCZ_s3)
                and pd.notna(avg_line) and avg_line < 2.3 and huashen == 1 and not is_A)
        # 趋势守住
        ma20 = _s(f,'ma20',ts)
        trend_hold = pd.notna(C) and pd.notna(ma20) and C >= ma20 and C_above_DCZ
        return is_A, is_B, trend_hold, C_above_DCZ
    except Exception:
        return False, False, False, False

def grade_code(code):
    """返回股票简称（去掉交易所后缀）"""
    return code.replace('.SH','').replace('.SZ','')

def is_bullish(bull_val, bull_sz_val=None):
    """双指数多头判断"""
    if pd.isna(bull_val): return True  # 无数据则通过
    if bull_val != 1: return False
    if bull_sz_val is not None and pd.notna(bull_sz_val):
        return bull_sz_val == 1
    return True

# ============ 主执行 ============
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--date', default=None, help='查询日期(YYYYMMDD), 默认当前周周一')
    args = ap.parse_args()

    print('='*60)
    print('F2 周线主进策略 — 实盘选股')
    print('='*60)

    # 加载数据
    print('\n加载数据...', flush=True)
    t0 = time.time()
    daily = wf.load_all_daily()
    weekly = wf.daily_to_weekly(daily)
    bench = wf.load_benchmark(daily)
    factors = wf.compute_weekly_factors(weekly)
    print(f'  加载完成: {len(daily)} 只日K, {len(weekly)} 只周线, 耗时 {time.time()-t0:.0f}s', flush=True)

    # 确定查询日期: 最近一个周一
    if args.date:
        target_date = pd.Timestamp(args.date)
    else:
        today = pd.Timestamp.now()
        # 找最近一个周一
        days_since_monday = today.dayofweek
        target_date = today - pd.Timedelta(days=days_since_monday)

    # 找到对应周线日期（最近一个 <= target_date 的周一）
    sample_close = list(weekly.values())[0]['close']
    weekly_dates = sample_close.index
    weekly_dates = [d for d in weekly_dates if d <= target_date]
    if not weekly_dates:
        print(f'  无可用周线数据（目标日期: {target_date.date()}）')
        sys.exit(1)
    ts = max(weekly_dates)  # 最近的周线日期
    print(f'\n  查询周线日期: {ts.date()} (周{["一","二","三","四","五","六","日"][ts.dayofweek]})')

    # 大盘判断
    sample_code = list(factors.keys())[0]
    mf = factors[sample_code]
    market_bull = _s(mf, 'market_bull', ts)
    market_bull_sz = _s(mf, 'market_bull_sz', ts)
    bullish = is_bullish(market_bull, market_bull_sz)
    print(f'  大盘状态: {"🟢 多头" if bullish else "🔴 弱势"} (沪深300 MA60: {market_bull}, 深成指: {market_bull_sz})')

    # 扫描所有股票
    print('\n扫描股票...', flush=True)
    candidates = []
    for code in weekly:
        if not wf.is_eligible(code):
            continue
        if code not in factors:
            continue
        f = factors[code]
        if ts not in f['close'].index:
            continue
        is_A, is_B, trend_hold, c_above_dcz = formula_2_live(f, ts)
        if not (is_A or is_B):
            continue
        if not trend_hold:
            continue

        # 获取 RPS
        C = _s(f,'close',ts)
        try:
            rps50 = _s(f,'rps50',ts)
        except:
            rps50 = 0
        # 板块分类
        code_str = str(code)
        board = '主板'
        if code_str.startswith('68'): board = '科创板'
        elif code_str.startswith('30'): board = '创业板'
        elif code_str.startswith(('43','83','92')): board = '北交所'

        signal_type = 'A' if is_A else 'B'
        candidates.append({
            'code': grade_code(code),
            'full_code': code,
            'grade': signal_type,
            'rps': float(rps50) if pd.notna(rps50) else 0,
            'close': float(C) if pd.notna(C) else 0,
            'board': board,
            'vol_ratio': float(_s(f,'vol_ratio',ts)) if pd.notna(_s(f,'vol_ratio',ts)) else 0,
        })

    print(f'\n  符合条件的股票: {len(candidates)} 只')

    # 排序: A级优先, 再按RPS降序
    candidates.sort(key=lambda x: (0 if x['grade']=='A' else 1, -x['rps']))

    # 大盘弱时只选A级前3只
    if not bullish:
        candidates = [c for c in candidates if c['grade']=='A'][:3]
        print('  ⚠️ 大盘弱势, 只选A级前3只')
    else:
        candidates = candidates[:5]

    # 输出买入清单
    print('\n' + '='*60)
    print('本周买入清单 (一揽子买入)')
    print('='*60)
    print(f'\n日期: {ts.date()}  买入价: 周一开盘价  持仓天数: 20个交易日')
    print(f'买入方式: {len(candidates)}只等权, 每只 {100/len(candidates):.0f}% 仓位' if candidates else '本周无符合条件的股票')
    print('\n')
    print(f'{"序号":<4}{"代码":<8}{"级别":>4}{"板块":>5}{"RPS50":>6}{"收盘价":>8}{"量比":>6}')
    print('-'*45)
    total_weight = 100 / len(candidates) if candidates else 0
    for i, c in enumerate(candidates, 1):
        print(f'{i:<4}{c["code"]:<8}{c["grade"]:>4}{c["board"]:>5}{c["rps"]:>6.0f}{c["close"]:>8.2f}{c["vol_ratio"]:>6.1f}  仓位{total_weight:.0f}%')

    print(f'\n合计: {len(candidates)}只, 总仓位100%')
    print('='*60)
