import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_telegram_token
"""
combo_backtest.py — 因子组合回测（真实历史持仓收益 v2）

核心逻辑：
- 用历史数据逐日滚动，每日用"昨日因子值"选股 → 持有 N 天 → 统计组合收益
- 基准：沪深300指数（000300.SH）同期收益
- 输出：超额收益、胜率、最大回撤、夏普比率、持仓明细

真实交易成本：
  - 佣金: 0.025%/次 (最低5元/笔，按市值估算)
  - 印花税: 0.05% (卖出时)
  - 过户费: 0.001%/次 (沪深)
  - 冲击成本: 0.03% (按市值估算)
  - 滑点: 0.05% (买卖各)

约束：
  - 严格避免未来数据泄露（T-1日因子选股，T日买入）
  - 涨跌停限制：涨停买不到、跌停卖不出
  - 排除北交所、ST、*ST、停牌股票
  - 样本池：沪深主板A股

使用方法：
    python combo_backtest.py              # 全量回测
    python combo_backtest.py --dry-run    # 只跑单日选股验证
"""
import sys, os, json, time, math, argparse, datetime as dt
from pathlib import Path
from collections import OrderedDict

sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
sys.path.insert(0, r'D:/Hermes/评估中心/tools')

import numpy as np
import pandas as pd
import tushare as ts
from factor_utils import normalize
from formula_factors import calc_weekly_formula_factors

TS_TOKEN = get_tushare_token()
PRO = ts.pro_api(TS_TOKEN)
DATA_DIR = Path(r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data')
OUT_DIR = DATA_DIR

# ════════════════════════════════════════════════════════════════════
# 交易成本配置
# ════════════════════════════════════════════════════════════════════
COST_CONFIG = {
    'commission_rate': 0.00025,   # 佣金 0.025%
    'commission_min': 5.0,        # 最低佣金 5元/笔
    'stamp_tax_rate': 0.0005,     # 印花税 0.05% (卖出)
    'transfer_fee_rate': 0.00001, # 过户费 0.001%
    'slippage_rate': 0.0005,      # 滑点 0.05%
    'impact_cost_rate': 0.0003,   # 冲击成本 0.03%
    # 小市值最低交易额（低于此值按比例调整最低佣金）
    'min_trade_notional': 10000,  # 假设每笔最小1万元
}

# 涨跌停判断参数
LIMIT_UP = 10.0   # 主板涨跌停 10%
LIMIT_DOWN = -10.0
ST_LIMIT_UP = 5.0  # ST涨跌停 5%
ST_LIMIT_DOWN = -5.0


# ════════════════════════════════════════════════════════════════════
# 1. 样本池（排除北交所/ST）
# ════════════════════════════════════════════════════════════════════
def get_sample(max_codes=None):
    """取沪深主板A股，排除北交所、ST、*ST、退市"""
    try:
        df = PRO.stock_basic(exchange='', list_status='L',
                             fields='ts_code,symbol,name,market_cap')
        if df is None or df.empty:
            return []
        # 排除北交所(BJ/83/87/88/43开头)
        df = df[~df['ts_code'].str.contains('BJ|83|87|88|43', regex=True)]
        # 排除ST、*ST、退市
        df = df[~df['name'].str.contains('ST|退市', case=False, na=False)]
        df = df.dropna(subset=['symbol'])
        # 按市值排序取大的票（避免限流+保证流动性）
        if 'market_cap' in df.columns:
            df = df[pd.to_numeric(df['market_cap'], errors='coerce') > 0]
            df = df.sort_values('market_cap', ascending=False)
        if max_codes:
            df = df.head(max_codes)
        codes = df['symbol'].tolist()
        print(f'  样本池: {len(codes)} 只（沪深A股，已排除北交所/ST/退市）', flush=True)
        return codes
    except Exception as e:
        print(f'  样本池获取失败: {e}', flush=True)
        return []


def to_ts_code(code):
    return code + '.SH' if code[0] in '69' else code + '.SZ'


# ════════════════════════════════════════════════════════════════════
# 2. 基准数据
# ════════════════════════════════════════════════════════════════════
def fetch_benchmark(start, end, ts_code='000300.SH'):
    """取基准指数历史收盘价"""
    try:
        df = PRO.index_daily(ts_code=ts_code, start_date=start, end_date=end)
        if df is None or df.empty:
            print(f'  基准 {ts_code} 数据为空，退化为上证指数', flush=True)
            df = PRO.index_daily(ts_code='000001.SH', start_date=start, end_date=end)
        df = df.sort_values('trade_date').reset_index(drop=True)
        df['close'] = pd.to_numeric(df['close'], errors='coerce')
        bench = df.set_index('trade_date')['close'].to_dict()
        print(f'  基准: {ts_code}, {len(bench)} 个交易日', flush=True)
        return bench
    except Exception as e:
        print(f'  基准获取失败: {e}', flush=True)
        return {}


# ════════════════════════════════════════════════════════════════════
# 3. 全市场日K 历史快照（OHLCV+pct_chg）
# ════════════════════════════════════════════════════════════════════
def fetch_all_daily(codes, start, end):
    """
    拉取全样本历史日K
    返回: dict[code] = pd.DataFrame(index=trade_date, columns=[open,high,low,close,pct_chg,pre_close])
    """
    print(f'  拉取全样本日K: {len(codes)} 只 [{start}, {end}] ...', flush=True)
    daily = {}
    t0 = time.time()
    for i, code in enumerate(codes):
        ts_code = to_ts_code(code)
        try:
            df = PRO.daily(ts_code=ts_code, start_date=start, end_date=end)
            if df is None or df.empty or len(df) < 60:
                continue
            df = df.sort_values('trade_date').reset_index(drop=True)
            for col in ['open', 'high', 'low', 'close', 'pct_chg', 'pre_close']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            df = df.set_index('trade_date')
            # 统一转为 DatetimeIndex
            df.index = pd.to_datetime(df.index)
            daily[code] = df
        except:
            continue
        if (i + 1) % 100 == 0:
            print(f'    进度: {i+1}/{len(codes)}', flush=True)
    print(f'  有效: {len(daily)} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return daily


# ════════════════════════════════════════════════════════════════════
# 4. 涨跌停/停牌检测
# ════════════════════════════════════════════════════════════════════
def is_st_patched(name_or_code):
    """判断是否ST（已通过样本池排除，这里作为兜底）"""
    s = str(name_or_code).upper()
    return 'ST' in s


def get_limit_bounds(daily_df, code):
    """
    根据最近交易日的涨跌幅判断涨跌停边界
    返回: (is_limit_up, is_limit_down, is_suspended, limit_pct)
    """
    # 检查是否停牌（连续多日无交易或pct_chg为0且无价格变化）
    # 实际由调用方通过索引判断
    return None  # 边界由调用方计算


def calc_trade_cost(entry_price, exit_price, trade_notional=10000, cost_cfg=None):
    """
    计算真实交易成本（买入+卖出全部）
    
    买入成本：
      - 佣金: max(entry * 佣金率, 5元)
      - 过户费: entry * 过户费率
      - 滑点: entry * 滑点率
    
    卖出成本：
      - 佣金: max(exit * 佣金率, 5元)
      - 印花税: exit * 印花税率
      - 过户费: exit * 过户费率
      - 滑点: exit * 滑点率
      - 冲击成本: exit * 冲击成本率
    
    返回: 总成本率（占交易金额的比例）
    """
    if cost_cfg is None:
        cost_cfg = COST_CONFIG
    
    entry_commission = max(entry_price * trade_notional * cost_cfg['commission_rate'],
                           cost_cfg['commission_min'])
    entry_transfer = entry_price * trade_notional * cost_cfg['transfer_fee_rate']
    entry_slippage = entry_price * trade_notional * cost_cfg['slippage_rate']
    
    exit_commission = max(exit_price * trade_notional * cost_cfg['commission_rate'],
                          cost_cfg['commission_min'])
    exit_stamp = exit_price * trade_notional * cost_cfg['stamp_tax_rate']
    exit_transfer = exit_price * trade_notional * cost_cfg['transfer_fee_rate']
    exit_slippage = exit_price * trade_notional * cost_cfg['slippage_rate']
    exit_impact = exit_price * trade_notional * cost_cfg['impact_cost_rate']
    
    total_cost = (entry_commission + entry_transfer + entry_slippage +
                  exit_commission + exit_stamp + exit_transfer +
                  exit_slippage + exit_impact)
    
    # 成本率（占买入金额比例）
    cost_rate = total_cost / (entry_price * trade_notional)
    return cost_rate


def calc_effective_slippage(entry_price):
    """
    计算买卖滑点综合影响（占收益百分比）
    买入滑点: 实际买入价 = close * (1 + 滑点率)  [买贵了]
    卖出滑点: 实际卖出价 = close * (1 - 滑点率)  [卖便宜了]
    综合: 净收益被双向侵蚀约 2*滑点率
    """
    return 2 * COST_CONFIG['slippage_rate']


def calc_total_cost_rate(entry_close, exit_close):
    """
    简化的总成本率（占交易金额的比例，按百分比）
    佣金双边: 0.025%*2 = 0.05% (忽略最低5元，假设成交>2万元)
    印花税: 0.05% (卖出)
    过户费: 0.001%*2 = 0.002%
    滑点: 0.05%*2 = 0.1%
    冲击成本: 0.03%
    合计: 约 0.232%
    """
    # 基础成本
    commission_bid = max(COST_CONFIG['commission_rate'], COST_CONFIG['commission_min'] / 10000)
    commission_ask = max(COST_CONFIG['commission_rate'], COST_CONFIG['commission_min'] / 10000)
    stamp = COST_CONFIG['stamp_tax_rate']
    transfer = 2 * COST_CONFIG['transfer_fee_rate']
    slippage = 2 * COST_CONFIG['slippage_rate']
    impact = COST_CONFIG['impact_cost_rate']
    
    total = commission_bid + commission_ask + stamp + transfer + slippage + impact
    return total  # 小数形式


# ════════════════════════════════════════════════════════════════════
# 5. 涨跌停与停牌判断
# ════════════════════════════════════════════════════════════════════
def check_tradeability(daily_df, code, T):
    """
    检查在日期 T 能否正常交易
    
    返回: (can_trade, reason, limit_info)
      - can_trade: True/False
      - reason: 不可交易原因（空串表示可交易）
      - limit_info: {'is_up': bool, 'is_down': bool, 'limit_pct': float}
    
    涨跌停判断逻辑：
      - pct_chg >= 9.8% (考虑四舍五入) → 涨停
      - pct_chg <= -9.8% → 跌停
      - ST: 5%
      - 成交量=0 或 pre_close=0 → 停牌
    """
    if T not in daily_df.index:
        return False, "停牌/无交易", {'is_up': False, 'is_down': False, 'limit_pct': LIMIT_UP}
    
    row = daily_df.loc[T]
    pre_close = row.get('pre_close', 0)
    close = row.get('close', 0)
    pct = row.get('pct_chg', 0)
    vol = row.get('vol', 0)
    ts_code = to_ts_code(code)
    
    # 停牌判断
    if pd.isna(close) or close <= 0 or pre_close <= 0:
        return False, "停牌/数据异常", {'is_up': False, 'is_down': False, 'limit_pct': LIMIT_UP}
    
    # 计算真实涨跌幅
    real_pct = (close / pre_close - 1) * 100
    
    # ST判断（5%）
    is_st = is_st_patched(code) or is_st_patched(ts_code)
    limit_pct = ST_LIMIT_UP if is_st else LIMIT_UP
    
    # 涨跌停判断（允许0.2%误差容差）
    is_up = real_pct >= limit_pct - 0.2
    is_down = real_pct <= -limit_pct + 0.2
    
    limit_info = {'is_up': is_up, 'is_down': is_down, 'limit_pct': limit_pct}
    
    return True, "", limit_info


def buy_entry_price(daily_df, T):
    """
    买入成交价：T日收盘价 * (1 + 滑点)
    涨停日买不到（返回None）
    """
    if T not in daily_df.index:
        return None, "停牌"
    row = daily_df.loc[T]
    pre_close = row.get('pre_close', 0)
    close = row.get('close', 0)
    if pd.isna(close) or close <= 0 or pre_close <= 0:
        return None, "停牌"
    
    real_pct = (close / pre_close - 1) * 100
    is_st = is_st_patched(to_ts_code(daily_df.name if hasattr(daily_df, 'name') else ''))
    limit_pct = ST_LIMIT_UP if is_st else LIMIT_UP
    
    if real_pct >= limit_pct - 0.2:
        return None, "涨停无法买入"
    
    # 买入价 = 收盘价 + 滑点
    entry = close * (1 + COST_CONFIG['slippage_rate'])
    return entry, ""


def sell_exit_price(daily_df, T):
    """
    卖出成交价：T日收盘价 * (1 - 滑点)
    跌停日卖不出（返回None）
    """
    if T not in daily_df.index:
        return None, "停牌"
    row = daily_df.loc[T]
    pre_close = row.get('pre_close', 0)
    close = row.get('close', 0)
    if pd.isna(close) or close <= 0 or pre_close <= 0:
        return None, "停牌"
    
    real_pct = (close / pre_close - 1) * 100
    is_st = is_st_patched(to_ts_code(daily_df.name if hasattr(daily_df, 'name') else ''))
    limit_pct = ST_LIMIT_UP if is_st else LIMIT_UP
    
    if real_pct <= -limit_pct + 0.2:
        return None, "跌停无法卖出"
    
    # 卖出价 = 收盘价 - 滑点
    exit_ = close * (1 - COST_CONFIG['slippage_rate'])
    return exit_, ""


# ════════════════════════════════════════════════════════════════════
# 6. 选股规则
# ════════════════════════════════════════════════════════════════════
def select_stocks(factors_dict, rule_params=None):
    """
    最优公式（进化引擎 6 代进化）
    AND 组合，全部满足才入选：
        周线 RPS50 > 55
        周线 MACD DIF > DEA（dif_above_dea == 1）
        散户动量 > 50
        周线 R0 资金流金叉 MA5（r0_ma5_cross == 1）
    """
    if rule_params is None:
        rule_params = {}
    threshold_rps = rule_params.get('threshold_rps', 55)
    threshold_retail = rule_params.get('threshold_retail', 50)
    top_k = rule_params.get('top_k', 30)

    selected = []
    for code, f in factors_dict.items():
        if '_error' in f:
            continue
        try:
            rps50 = float(f.get('weekly_rps_50', -999))
            dif_above = int(f.get('weekly_macd_dif_above_dea', 0))
            retail = float(f.get('weekly_retail_momentum', 0))
            r0_cross = int(f.get('weekly_r0_ma5_cross', 0))

            if (rps50 > threshold_rps
                    and dif_above == 1
                    and retail > threshold_retail
                    and r0_cross == 1):
                selected.append((code, rps50, retail))
        except (ValueError, TypeError):
            continue

    selected.sort(key=lambda x: x[1], reverse=True)
    return selected[:top_k]


# ════════════════════════════════════════════════════════════════════
# 7. 滚动回测引擎（核心）— 带完整交易成本
# ════════════════════════════════════════════════════════════════════
def run_backtest(daily_dict, factors_dict, benchmark, hold_days=30,
                 start_date=None, end_date=None, top_k=30, rule_params=None):
    """
    滚动式持仓回测：
    - 每个交易日 T：用 T 日因子选股 → T 日收盘后买入 → 持有 hold_days 天 → 卖出
    - 基准：沪深300同期收益
    - 完整交易成本：佣金、印花税、过户费、滑点、冲击成本
    - 涨跌停约束：涨停买不到、跌停卖不出
    - 停牌股跳过
    
    holdings: list of dict
      {T, codes, pick_codes, entry, exit, gross_ret, cost_rate, net_ret, 
       bench_ret, net_excess, beat, skip_reasons}
    """
    # 所有股票交易日的并集
    all_dates_list = []
    for code in daily_dict:
        for ts in daily_dict[code].index:
            all_dates_list.append(str(ts)[:10])  # 统一为 'YYYY-MM-DD' 字符串
    all_dates = sorted(set(all_dates_list))
    all_dates = [pd.Timestamp(d) for d in all_dates]
    # 基准统一为 DatetimeIndex
    bench_series = pd.Series(benchmark)
    bench_series.index = pd.to_datetime(bench_series.index)
    bench_index = bench_series.index

    # 限制回测区间
    if start_date:
        all_dates = [d for d in all_dates if d >= pd.Timestamp(start_date)]
    if end_date:
        all_dates = [d for d in all_dates if d <= pd.Timestamp(end_date)]

    all_dates = [d for d in all_dates if d in bench_index]
    
    # 过滤：留够 hold_days 后续 + 10天容差
    hold_dates = [d for d in all_dates
                  if d + pd.Timedelta(days=hold_days + 15) in bench_index]

    print(f'  候选交易日: {len(hold_dates)}', flush=True)

    holdings = []
    total_costs = []
    skip_count = {'limit_up_buy': 0, 'limit_down_sell': 0, 'suspended': 0,
                  'no_entry': 0, 'no_exit': 0}

    for T in hold_dates:
        # 每周一次（周一）
        if pd.Timestamp(T).dayofweek != 0:
            continue

        # 选股
        rp = rule_params or {}
        picked = select_stocks(factors_dict,
                               rule_params={'top_k': top_k, **rp})
        if len(picked) < 3:
            continue

        pick_codes = [c for c, _, _ in picked]
        
        # 计算个股收益（考虑成交约束和成本）
        ret_list = []
        gross_rets = []
        cost_list = []
        trade_details = []
        skipped = 0

        for code in pick_codes:
            if code not in daily_dict:
                skipped += 1
                continue
            dd = daily_dict[code]
            
            # 买入（T日）
            entry, buy_reason = buy_entry_price(dd, T)
            if entry is None:
                if "涨停" in buy_reason:
                    skip_count['limit_up_buy'] += 1
                elif "停牌" in buy_reason:
                    skip_count['suspended'] += 1
                else:
                    skip_count['no_entry'] += 1
                skipped += 1
                continue

            # 卖出（T+hold_days）
            fut_date = T + pd.Timedelta(days=hold_days)
            if fut_date not in dd.index:
                # 找下一个交易日
                future_idx = dd.index[dd.index > fut_date]
                if len(future_idx) == 0:
                    skipped += 1
                    continue
                fut_date = future_idx[0]
            
            exit_, sell_reason = sell_exit_price(dd, fut_date)
            if exit_ is None:
                if "跌停" in sell_reason:
                    skip_count['limit_down_sell'] += 1
                elif "停牌" in sell_reason:
                    skip_count['suspended'] += 1
                else:
                    skip_count['no_exit'] += 1
                skipped += 1
                continue

            # 毛收益
            gross_ret = exit_ / entry - 1
            gross_rets.append(gross_ret)

            # 交易成本率
            cost_rate = calc_total_cost_rate(entry, exit_)
            cost_list.append(cost_rate)

            # 净收益 = 毛收益 - 成本率
            net_ret = gross_ret - cost_rate
            ret_list.append(net_ret)

            trade_details.append({
                'code': code,
                'entry': round(entry, 2),
                'exit': round(exit_, 2),
                'gross_ret': round(gross_ret * 100, 2),
                'cost_rate': round(cost_rate * 100, 4),
                'net_ret': round(net_ret * 100, 2),
            })

        if not ret_list:
            continue

        # 等权组合
        avg_net_ret = float(np.mean(ret_list))
        avg_gross_ret = float(np.mean(gross_rets)) if gross_rets else avg_net_ret
        avg_cost = float(np.mean(cost_list)) if cost_list else 0

        # 基准同期收益（T → fut_date）
        # 用最后一支成交股票的实际卖出日期
        actual_exit_date = fut_date
        if T in bench_index and actual_exit_date in bench_index:
            bench_ret = float(bench_series[actual_exit_date] / bench_series[T] - 1)
        elif T in bench_index:
            # 找最近基准日期
            future_bench = bench_series.index[bench_series.index > actual_exit_date]
            if len(future_bench) > 0:
                bench_ret = float(bench_series[future_bench[0]] / bench_series[T] - 1)
            else:
                bench_ret = 0.0
        else:
            bench_ret = 0.0

        holdings.append({
            'T': T,
            'pick_count': len(pick_codes),
            'trade_count': len(ret_list),
            'avg_gross_ret': avg_gross_ret,
            'avg_net_ret': avg_net_ret,
            'avg_cost_rate': avg_cost,
            'bench_ret': bench_ret,
            'net_excess': avg_net_ret - bench_ret,
            'beat': avg_net_ret > bench_ret,
            'trade_details': trade_details,
            'skipped': skipped,
        })
        total_costs.append(avg_cost)

    # 汇总统计
    limit_stats = dict(skip_count)
    print(f'  跳过统计: 涨停无法买入{limit_stats["limit_up_buy"]}, '
          f'跌停无法卖出{limit_stats["limit_down_sell"]}, '
          f'停牌{limit_stats["suspended"]}, 其他{limit_stats["no_entry"]+limit_stats["no_exit"]}',
          flush=True)

    return holdings, limit_stats, total_costs


# ════════════════════════════════════════════════════════════════════
# 8. 统计分析
# ════════════════════════════════════════════════════════════════════
def analyze_holdings(holdings, total_costs, hold_days, limit_stats):
    """统计回测结果"""
    if not holdings:
        return None

    net_rets = [h['avg_net_ret'] / 100 for h in holdings]
    gross_rets = [h['avg_gross_ret'] / 100 for h in holdings]
    bench_rets = [h['bench_ret'] for h in holdings]
    cost_rates = [h['avg_cost_rate'] / 100 for h in holdings]
    n = len(holdings)

    avg_net = np.mean(net_rets)
    avg_gross = np.mean(gross_rets)
    avg_bench = np.mean(bench_rets)
    avg_cost = np.mean(cost_rates)
    avg_excess = avg_net - avg_bench
    total_excess = sum(net_rets[i] - bench_rets[i] for i in range(n))
    win_rate_net = sum(1 for r in net_rets if r > 0) / n
    outperform_rate = sum(1 for r, b in zip(net_rets, bench_rets) if r > b) / n

    # 最大回撤（基于滚动净值，用净收益）
    net_val = 1.0
    net_series = [net_val]
    for r in net_rets:
        net_val *= (1 + r)
        net_series.append(net_val)
    peak = net_series[0]
    max_dd = 0
    for v in net_series:
        if v > peak:
            peak = v
        dd = (v - peak) / peak
        if dd < max_dd:
            max_dd = dd

    # 夏普比率（年化，周频）
    if len(net_rets) > 1 and np.std(net_rets) > 0:
        sharpe_ratio = (avg_net / np.std(net_rets)) * math.sqrt(52)
    else:
        sharpe_ratio = 0

    # 基准夏普
    if len(bench_rets) > 1 and np.std(bench_rets) > 0:
        bench_sharpe = (avg_bench / np.std(bench_rets)) * math.sqrt(52)
    else:
        bench_sharpe = 0

    # 基准累计收益
    bench_cumul = (1 + np.mean(bench_rets)) ** n - 1 if n > 0 else 0

    return {
        'n_trades': n,
        'avg_gross_return': avg_gross * 100,
        'avg_net_return': avg_net * 100,
        'avg_cost_rate': avg_cost * 100,
        'avg_bench_return': avg_bench * 100,
        'avg_excess_return': avg_excess * 100,
        'cumulative_net_return': net_val * 100 - 100,
        'cumulative_excess': total_excess * 100,
        'win_rate_net': win_rate_net,
        'outperform_rate': outperform_rate,
        'max_drawdown': max_dd * 100,
        'sharpe_ratio': sharpe_ratio,
        'bench_sharpe': bench_sharpe,
        'best_trade': max(net_rets) * 100,
        'worst_trade': min(net_rets) * 100,
        'limit_stats': limit_stats,
    }


# ════════════════════════════════════════════════════════════════════
# 9. 报告生成
# ════════════════════════════════════════════════════════════════════
def build_report(stats, rule_name, hold_days, top_k,
                 start_date, end_date, all_holdings=None):
    lines = []
    lines.append(f"# 📊 因子组合回测报告")
    lines.append("")
    lines.append(f"**回测区间**: {start_date} → {end_date}")
    lines.append(f"**持仓周期**: {hold_days} 交易日（约 {hold_days//5} 周）")
    lines.append(f"**选股规则**: {rule_name}")
    lines.append(f"**每轮持仓数**: {top_k} 只（等权）")
    lines.append(f"**基准**: 沪深300指数")
    lines.append("")

    if not stats:
        lines.append("❌ 无有效回测记录（可能选股条件过严或数据不足）")
        return '\n'.join(lines)

    # 交易成本说明
    lines.append("## 💰 交易成本假设")
    lines.append("")
    lines.append("| 成本项 | 费率 | 说明 |")
    lines.append("|---|---|---|")
    lines.append("| 佣金(双边) | 0.025%/次 | 最低5元/笔 |")
    lines.append("| 印花税 | 0.05% | 仅卖出 |")
    lines.append("| 过户费(双边) | 0.001%/次 | 沪深 |")
    lines.append("| 滑点(双边) | 0.05%/次 | 买卖各 |")
    lines.append("| 冲击成本 | 0.03% | 小盘股估算 |")
    lines.append(f"| **合计平均** | **{stats['avg_cost_rate']:.3f}%** | 实测均值 |")
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 🏆 核心指标")
    lines.append("")
    lines.append("| 指标 | 选股组合 | 基准(沪深300) | 说明 |")
    lines.append("|---|---|---|---|")
    lines.append(f"| 有效交易次数 | {stats['n_trades']} | - | 滚动选股权重数 |")
    lines.append(f"| 平均毛收益 | {stats['avg_gross_return']:+.2f}% | {stats['avg_bench_return']:+.2f}% | 未扣成本 |")
    lines.append(f"| **平均净收益** | **{stats['avg_net_return']:+.2f}%** | {stats['avg_bench_return']:+.2f}% | 扣除全部成本 |")
    lines.append(f"| 平均交易成本 | **{stats['avg_cost_rate']:.3f}%** | - | 占交易金额 |")
    lines.append(f"| **平均超额收益** | **{stats['avg_excess_return']:+.2f}%** | - | 净收益 vs基准 |")
    lines.append(f"| 累计净值 | **{stats['cumulative_net_return']:+.2f}%** | - | 所有交易叠加 |")
    lines.append(f"| 累计超额收益 | **{stats['cumulative_excess']:+.2f}%** | - | 净超额叠加 |")
    lines.append(f"| 净收益胜率 | **{stats['win_rate_net']:.1%}** | - | 净收益>0占比 |")
    lines.append(f"| **跑赢基准比例** | **{stats['outperform_rate']:.1%}** | - | 净收益>基准 |")
    lines.append(f"| 最大回撤 | {stats['max_drawdown']:.2f}% | - | 滚动净值 |")
    lines.append(f"| **夏普比率** | **{stats['sharpe_ratio']:.2f}** | {stats['bench_sharpe']:.2f} | 年化(周频) |")
    lines.append(f"| 最佳单次 | {stats['best_trade']:+.2f}% | - | 净收益 |")
    lines.append(f"| 最差单次 | {stats['worst_trade']:+.2f}% | - | 净收益 |")
    lines.append("")

    # 涨跌停约束统计
    ls = stats.get('limit_stats', {})
    lines.append("---")
    lines.append("")
    lines.append("## ⛔ 涨跌停/停牌约束统计")
    lines.append("")
    lines.append(f"• 涨停无法买入: **{ls.get('limit_up_buy', 0)}** 次")
    lines.append(f"• 跌停无法卖出: **{ls.get('limit_down_sell', 0)}** 次")
    lines.append(f"• 停牌跳过: **{ls.get('suspended', 0)}** 次")
    lines.append(f"• 其他原因: **{ls.get('no_entry', 0)+ls.get('no_exit', 0)}** 次")
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## 📋 逐轮明细（前20轮）")
    lines.append("")
    lines.append("| 入场日期 | 持仓数 | 成交数 | 毛收益 | 净收益 | 成本 | 基准 | 超额 | 跑赢? |")
    lines.append("|---|---|---|---|---|---|---|---|---|")
    for i, h in enumerate(all_holdings[:20] if all_holdings else []):
        beat = "✅" if h['beat'] else "❌"
        lines.append(f"| {str(h['T'])[:10]} | {h['pick_count']} | {h['trade_count']} | "
                     f"{h['avg_gross_ret']:+.2f}% | {h['avg_net_ret']:+.2f}% | "
                     f"{h['avg_cost_rate']:.3f}% | {h['bench_ret']:+.2f}% | "
                     f"{h['net_excess']:+.2f}% | {beat} |")
    lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("## ⚠️ 风险说明")
    lines.append("")
    lines.append("• 回测为历史数据，不构成投资建议")
    lines.append(f"• 每轮持仓 {hold_days} 交易日，采用等权配置")
    lines.append("• 已扣除：佣金、印花税、过户费、滑点、冲击成本")
    lines.append("• 涨跌停约束：涨停无法买入、跌停无法卖出")
    lines.append("• 已排除：北交所、ST、*ST、停牌股票")
    lines.append("• 未考虑：融资利息、分红再投资、最小交易单位(100股)")
    lines.append("• 因子基于周线，周线数据更新频率较低（每周）")
    lines.append("")
    lines.append(f"**生成时间**: {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    return '\n'.join(lines)


# ════════════════════════════════════════════════════════════════════
# 10. Telegram 推送
# ════════════════════════════════════════════════════════════════════
def push_tg_brief(stats, rule_name, hold_days, report_path):
    """推送简报到Telegram（简报 + 附件说明）"""
    try:
        import urllib.request, json as _json
        token = get_telegram_token()
        chat_id = '8673372605'

        verdict = "✅ 有效" if stats['avg_excess_return'] > 0 and stats['outperform_rate'] > 0.5 else "⚠️ 需验证"
        
        lines = [
            "📊 <b>因子组合回测结果</b>",
            "",
            f"🎯 结论: {verdict}",
            "",
            f"• 有效交易: {stats['n_trades']} 轮",
            f"• 平均毛收益: {stats['avg_gross_return']:+.2f}%",
            f"• 平均交易成本: <b>{stats['avg_cost_rate']:.3f}%</b>",
            f"• 平均净收益: <b>{stats['avg_net_return']:+.2f}%</b>",
            f"• 基准(沪深300): {stats['avg_bench_return']:+.2f}%",
            f"• <b>平均超额: {stats['avg_excess_return']:+.2f}%</b>",
            f"• 累计净值: <b>{stats['cumulative_net_return']:+.2f}%</b>",
            f"• 跑赢基准比例: <b>{stats['outperform_rate']:.1%}</b>",
            f"• 最大回撤: {stats['max_drawdown']:.1f}%",
            f"• 夏普比率: <b>{stats['sharpe_ratio']:.2f}</b>",
            "",
            f"⛔ 涨停无法买入: {stats['limit_stats'].get('limit_up_buy',0)}次 | "
            f"跌停无法卖出: {stats['limit_stats'].get('limit_down_sell',0)}次",
            "",
            "📎 完整报告见 MD 附件",
        ]
        text = '\n'.join(lines)

        url = f'https://api.telegram.org/bot{token}/sendMessage'
        data = _json.dumps({
            'chat_id': chat_id,
            'text': text,
            'parse_mode': 'HTML',
        }).encode('utf-8')
        req = urllib.request.Request(url, data=data,
                                     headers={'Content-Type': 'application/json'})
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({
                'http': '127.0.0.1:7890',
                'https': '127.0.0.1:7890',
            })
        )
        opener.open(req, timeout=15)
        print('TG简报推送成功')
    except Exception as e:
        print(f'TG推送失败: {e}')


# ════════════════════════════════════════════════════════════════════
# 11. 主流程
# ════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true',
                        help='只跑单日选股验证，不跑全量回测')
    parser.add_argument('--hold-days', type=int, default=30,
                        help='持仓周期(交易日)，默认30')
    parser.add_argument('--top-k', type=int, default=30,
                        help='每轮持仓数，默认30')
    parser.add_argument('--sample', type=int, default=500,
                        help='样本池数量(市值排序取大票)，默认500')
    parser.add_argument('--start', default='20220101',
                        help='回测起始日期')
    parser.add_argument('--end', default='20260715',
                        help='回测结束日期')
    args = parser.parse_args()

    print("=" * 60)
    print("因子组合回测引擎 v2（含完整交易成本）")
    print(f"时间: {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # Step 1: 样本池
    codes = get_sample(max_codes=args.sample)
    if not codes:
        print("[FAIL] 无法获取样本")
        return
    codes = [normalize(c) for c in codes if normalize(c) and len(normalize(c)) == 6]
    print(f"  清洗后: {len(codes)} 只")

    # Step 2: 基准
    print("\n基准数据...")
    benchmark = fetch_benchmark(args.start, args.end)
    if not benchmark:
        print("[FAIL] 基准数据为空")
        return

    # Step 3: 计算当前因子（分批调用，避开tushare限流200次/分钟）
    print("\n计算周线因子（用于选股）...")
    import concurrent.futures as cf
    # 分批：每批50只，避免触发限流
    batch_size = 50
    factors = {}
    for start_idx in range(0, len(codes), batch_size):
        batch = codes[start_idx:start_idx+batch_size]
        try:
            batch_factors = calc_weekly_formula_factors(batch)
            factors.update(batch_factors)
        except Exception as e:
            print(f'  因子计算失败: {e}', flush=True)
        # 批次间等待，避开限流
        if start_idx + batch_size < len(codes):
            time.sleep(5)
    valid_f = {c: f for c, f in factors.items() if '_error' not in f}
    print(f"  有效因子: {len(valid_f)}/{len(codes)}")

    if args.dry_run:
        print("\n[DRY RUN] 当前选股结果:")
        picked = select_stocks(valid_f, rule_params={'top_k': args.top_k})
        print(f"  命中: {len(picked)} 只")
        for c, rps, retail in picked[:10]:
            print(f"    {c}  RPS50={rps}  retail_mom={retail}")
        return

    # Step 4: 拉全量历史日K
    print("\n拉取历史日K...")
    daily_dict = fetch_all_daily(codes, args.start, args.end)
    if len(daily_dict) < 100:
        print(f"[WARN] 历史数据不足 ({len(daily_dict)}只)，回测结果不可靠")

    # Step 5: 主回测
    print("\n执行滚动回测（含涨跌停约束+交易成本）...")
    t0 = time.time()
    holdings, limit_stats, total_costs = run_backtest(
        daily_dict, valid_f, benchmark,
        hold_days=args.hold_days,
        start_date=args.start,
        end_date=args.end,
        top_k=args.top_k,
    )
    print(f"  耗时 {time.time()-t0:.0f}s, 有效交易 {len(holdings)} 次")

    # Step 6: 分析
    stats = analyze_holdings(holdings, total_costs, args.hold_days, limit_stats)
    rule_name = "RPS50>55 AND MACD_DIF>DEA AND 散户动量>50 AND R0金叉MA5"

    report = build_report(
        stats, rule_name, args.hold_days, args.top_k,
        args.start, args.end, all_holdings=holdings
    )

    today = dt.datetime.now().strftime('%Y%m%d')
    out_path = OUT_DIR / f'combo_backtest_{today}.md'
    out_path.write_text(report, encoding='utf-8')
    print(f"\n报告已保存: {out_path}")

    # 写 JSON
    if stats:
        json_path = OUT_DIR / f'combo_backtest_{today}.json'
        json.dump(stats, open(json_path, 'w', encoding='utf-8'),
                  ensure_ascii=False, indent=2)

    print("\n" + report)

    # Telegram 推送
    if stats:
        push_tg_brief(stats, rule_name, args.hold_days, out_path)


if __name__ == '__main__':
    main()
