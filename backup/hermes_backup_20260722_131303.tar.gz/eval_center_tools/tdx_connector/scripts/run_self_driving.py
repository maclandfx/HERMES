"""Standalone self-driving backtest runner with file logging + flush"""
import sys, os, json, time, math, traceback, shutil
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from factor_utils import spearmanr_np, normalize
from formula_factors import calc_weekly_formula_factors, calc_daily_formula_factors
from self_driving_backtest import get_a_share_sample, compute_market_correlation, find_best_factors, compute_evolution, push_tg

LOG_FILE = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data/run_log.txt'
DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'

def log(msg):
    print(msg, flush=True)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f'[{datetime.now().strftime("%H:%M:%S")}] {msg}\n')

def main():
    # clear log
    open(LOG_FILE, 'w', encoding='utf-8').close()
    
    log('='*60)
    log(f'自驱回测引擎 — {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    log('='*60)
    
    codes = get_a_share_sample(max_codes=4259)
    if not codes:
        log('[FAIL] 无样本')
        return
    log(f'样本: {len(codes)} 只')
    
    today = datetime.now().strftime('%Y%m%d')
    
    # 周线
    log('\n[周线] 因子计算...')
    t0 = time.time()
    weekly_factors = calc_weekly_formula_factors(codes)
    w_time = time.time() - t0
    w_valid = sum(1 for f in weekly_factors.values() if '_error' not in f)
    log(f'[周线] 因子完成: {w_time:.0f}s | 有效:{w_valid}/{len(codes)}')
    
    # 相关性
    log('[周线] 相关性计算...')
    t0 = time.time()
    weekly_corr, w_n = compute_market_correlation(weekly_factors, codes, [7,14,21,30])
    log(f'[周线] 相关性完成: {time.time()-t0:.0f}s | {w_n}只有效, {len(weekly_corr)}因子')
    
    # 日线
    log('\n[日线] 因子计算...')
    t0 = time.time()
    daily_factors = calc_daily_formula_factors(codes)
    d_time = time.time() - t0
    d_valid = sum(1 for f in daily_factors.values() if '_error' not in f)
    log(f'[日线] 因子完成: {d_time:.0f}s | 有效:{d_valid}/{len(codes)}')
    
    # 相关性
    log('[日线] 相关性计算...')
    t0 = time.time()
    daily_corr, d_n = compute_market_correlation(daily_factors, codes, [1,3,5,10])
    log(f'[日线] 相关性完成: {time.time()-t0:.0f}s | {d_n}只有效, {len(daily_corr)}因子')
    
    # 报告
    w_best = find_best_factors(weekly_corr)
    d_best = find_best_factors(daily_corr)
    
    lines = []
    lines.append(f'# 自驱回测报告 {today}')
    lines.append('')
    lines.append(f'样本: {len(codes)}只 | 周线有效:{w_valid} | 日线有效:{d_valid}')
    lines.append(f'周线耗时:{w_time:.0f}s | 日线耗时:{d_time:.0f}s')
    lines.append(f'周线因子:{len(weekly_corr)}个 | 日线因子:{len(daily_corr)}个')
    lines.append('')
    lines.append('## 周线高预测力因子TOP10')
    for fname, avg_rho, sig_rate, days in w_best[:10]:
        lines.append(f'{avg_rho:.3f} sig={sig_rate:.0%} {fname}')
        for d, info in sorted(days.items()):
            lines.append(f'  {d}: rho={info["rho"]:+.3f} p={info["pval"]:.4f} n={info["n"]} {"*" if info["sig"] else ""}')
    lines.append('')
    lines.append('## 日线高预测力因子TOP10')
    for fname, avg_rho, sig_rate, days in d_best[:10]:
        lines.append(f'{avg_rho:.3f} sig={sig_rate:.0%} {fname}')
        for d, info in sorted(days.items()):
            lines.append(f'  {d}: rho={info["rho"]:+.3f} p={info["pval"]:.4f} n={info["n"]} {"*" if info["sig"] else ""}')
    report = '\n'.join(lines)
    
    report_path = os.path.join(DATA_DIR, f'self_driving_{today}.txt')
    open(report_path, 'w', encoding='utf-8').write(report)
    
    log('\n'+report)
    log(f'\n报告: {report_path}')
    log('推送TG...')
    push_tg(report)
    log('完成')

if __name__ == '__main__':
    main()
