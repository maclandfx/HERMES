# -*- coding: utf-8 -*-
"""
combo_backtest_local.py — 因子组合滚动回测（全量本地通达信数据）
─────────────────────────────────────────────────────
数据源: D:/TDX/vipdoc/{sh,sz,bj}/lday/*.day  (通达信本地二进制K线)
  沪市: .day 价格字字段 /1000
  深市: .day 价格字字段 /10
  北交所: 跳过
  格式: 每行32字节
    0-3:   日期(int, YYYYMMDD)
    4-7:   开盘  (uint)
    8-11:  收盘  (uint)
    12-15: 最高  (uint)
    16-19: 最低  (uint)
    20-27: 成交量(uint64)
    28-31: 成交额(uint)
选股规则: RPS50>55 AND MACD_DIF>DEA AND 散户动量>50 AND R0金叉MA5（周线）
回测窗口: 滚动式，每周一选，持仓 hold_days 交易日
基准: 沪深300 (sh000300)
成本: 佣金 0.025%*2 + 印花税 0.05%(卖) + 过户 0.002%*2 + 滑点 0.1%*2 + 冲击 0.03%*2
涨跌停: 涨停买不进，跌停卖不出
"""
import os, sys, struct, glob, math, time
from collections import defaultdict
from datetime import datetime, timedelta

import pandas as pd
import numpy as np

# ============ 路径 ============
TDX_BASE = 'D:/TDX/vipdoc'
DIV = {'sh': 1000, 'sz': 10, 'bj': 100}  # 价格 divisor

def parse_day_file(path):
    """解析通达信 .day 文件，返回 DataFrame"""
    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except Exception:
        return pd.DataFrame()
    if len(raw) % 32 != 0 or len(raw) < 32:
        return pd.DataFrame()
    n = len(raw) // 32
    market = os.path.basename(path).split('/')[0] if '/' in path else os.path.basename(os.path.dirname(path))
    # 从文件名提取 market
    fn = os.path.basename(path)
    if fn.startswith('sh'): market = 'sh'
    elif fn.startswith('sz'): market = 'sz'
    elif fn.startswith('bj'): market = 'bj'
    else: return pd.DataFrame()

    d = DIV.get(market, 1000)
    rows = []
    for i in range(n):
        chunk = raw[i*32:(i+1)*32]
        di = struct.unpack('<I', chunk[0:4])[0]
        try:
            ts = pd.Timestamp(di // 10000, (di // 100) % 100, di % 100)
        except ValueError:
            continue
        o = struct.unpack('<I', chunk[4:8])[0] / d
        c = struct.unpack('<I', chunk[8:12])[0] / d
        h = struct.unpack('<I', chunk[12:16])[0] / d
        l = struct.unpack('<I', chunk[16:20])[0] / d
        v = struct.unpack('<Q', chunk[20:28])[0]
        a = struct.unpack('<f', chunk[28:32])[0]
        rows.append((ts, o, h, l, c, v, a))
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows, columns=['trade_date','open','high','low','close','vol','amount'])
    df = df.sort_values('trade_date').reset_index(drop=True)
    return df.set_index('trade_date')

def load_all_daily(market='all'):
    """加载全部 A 股日线（返回 {code_ts_code: DataFrame}）"""
    data = {}
    dirs = []
    if market == 'all':
        dirs = ['sh', 'sz']
    elif market == 'sh':
        dirs = ['sh']
    elif market == 'sz':
        dirs = ['sz']
    t0 = time.time()
    count = 0
    for m in dirs:
        pattern = os.path.join(TDX_BASE, m, 'lday', '*.day')
        for fp in sorted(glob.glob(pattern)):
            fn = os.path.basename(fp)
            code = fn[:-4]  # sh000001
            ts_code = code.upper() + ('.SH' if m=='sh' else '.SZ')
            df = parse_day_file(fp)
            if len(df) < 60:
                continue
            data[ts_code] = df
            count += 1
            if (count % 1000) == 0:
                print(f'  日K进度: {count}, 耗时 {time.time()-t0:.0f}s', flush=True)
    print(f'  有效: {count} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return data

def load_weekly():
    """加载全量周线 .week 文件"""
    data = {}
    t0 = time.time()
    count = 0
    for m, d in [('sh',1000), ('sz',10)]:
        pattern = os.path.join(TDX_BASE, m, 'lday', '*.week')
        for fp in sorted(glob.glob(pattern)):
            fn = os.path.basename(fp)
            code = fn[:-5].upper() + ('.SH' if m=='sh' else '.SZ')
            df = parse_day_file(fp)
            if len(df) < 30:
                continue
            data[code] = df
            count += 1
    print(f'  周线: {count} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return data

# ============ 因子计算（周线） ============
def calc_rps50(df, all_weekly, topn=500):
    """RPS: 周K相对强弱百分位（全市场排名）"""
    def rank_row(idx):
        closes = {}
        for c, dd in all_weekly.items():
            if idx in dd.index:
                try:
                    cl = dd.loc[idx, 'close']
                    if cl > 0:
                        closes[c] = cl
                except Exception:
                    pass
        if len(closes) < 20:
            return np.nan
        val = df.loc[idx, 'close']
        if val <= 0:
            return np.nan
        pct = (sum(1 for v in closes.values() if v < val) / len(closes)) * 100
        return pct
    return df.index.map(rank_row)

def calc_macd_above_dea(df, fast=12, slow=26, sig=9):
    ema_f = df['close'].ewm(span=fast, adjust=False).mean()
    ema_s = df['close'].ewm(span=slow, adjust=False).mean()
    dif = ema_f - ema_s
    dea = dif.ewm(span=sig, adjust=False).mean()
    return (dif > dea).astype(int)

def calc_retail_momentum(df):
    return df['vol'].pct_change().fillna(0).clip(-5, 5) * 50 + 50

def calc_r0_ma5_cross(df):
    ma5 = df['close'].rolling(5).mean()
    ma5_prev = ma5.shift(1)
    cross = ((df['close'] > ma5) & (df['close'].shift(1) <= ma5_prev)).astype(int)
    return cross

def compute_factors(weekly_dict, topn=500):
    """计算全量周线因子（pandas rank 向量化RPS）"""
    t0 = time.time()
    factors = {}

    # 1) 构造 DataFrame: index=code, columns=周日期, values=收盘价
    print('  构造周收盘价矩阵...', flush=True)
    price_records = []
    for code, df in weekly_dict.items():
        for d, c in df['close'].items():
            if c and c > 0:
                price_records.append((code, d, c))
    price_df = pd.DataFrame(price_records, columns=['code','date','close'])
    pivot = price_df.pivot(index='code', columns='date', values='close')
    # 2) 按列(日期)计算 RPS 百分位：每列独立 rank
    print('  计算RPS (pandas rank)...', flush=True)
    rps = pivot.rank(axis=1, pct=True, method='average') * 100
    # 3) 转换 rps[code][date] -> rps_lookup
    print('  组装因子 DataFrame...', flush=True)
    rps_lookup = {c: {d: v for d, v in row.items() if not np.isnan(v)} for c, row in rps.iterrows()}
    for code, df in weekly_dict.items():
        try:
            f = pd.DataFrame(index=df.index)
            lookup = rps_lookup.get(code, {})
            f['rps50'] = df.index.map(lambda d: lookup.get(d, np.nan))
            f['macd_dif_above_dea'] = calc_macd_above_dea(df)
            f['retail_momentum'] = calc_retail_momentum(df)
            f['r0_ma5_cross'] = calc_r0_ma5_cross(df)
            factors[code] = f
        except Exception:
            continue
    print(f'  因子计算: {len(factors)} 只, 耗时 {time.time()-t0:.0f}s', flush=True)
    return factors

# ============ 选股 ============
def select_stocks(factors_dict, target_date, thresholds, top_k=30):
    """选股：3核心因子AND（去掉过于严苛的周级金叉条件）
    
    主筛选: RPS50>=阈值 AND MACD金叉 AND 散户动量>=阈值
    R0金叉MA5 作为加分条件，满足时提升排序优先级（非硬过滤）
    """
    picked = []
    for code, f in factors_dict.items():
        if target_date not in f.index:
            continue
        row = f.loc[target_date]
        rp = row.get('rps50', 0)
        md = row.get('macd_dif_above_dea', 0)
        rm = row.get('retail_momentum', 0)
        cr = row.get('r0_ma5_cross', 0)
        # 核心3条件
        if (isinstance(rp,(int,float)) and isinstance(md,(int,float)) and isinstance(rm,(int,float))
            and rp >= thresholds['rps50'] and md == 1 and rm >= thresholds['retail']):
            # 排序分：RPS为主 + 金叉加分
            score = rp + (5 if cr == 1 else 0)
            picked.append((code, score))
    picked.sort(key=lambda x: x[1], reverse=True)
    return picked[:top_k]

# ============ 回测 ============
LIMIT = 0.0995  # 涨跌停阈值

def run_backtest(daily_dict, factors_dict, bench, hold_days=30,
                 start=None, end=None, top_k=30, thresholds=None):
    thresholds = thresholds or {'rps50': 55, 'retail': 50}
    bench = pd.Series(bench['close']).rename_axis('trade_date').sort_index()
    bench_index = bench.index
    all_dates = sorted(set(bench_index))
    if start:
        all_dates = [d for d in all_dates if d >= pd.Timestamp(start)]
    if end:
        all_dates = [d for d in all_dates if d <= pd.Timestamp(end)]
    # 周一，留够持仓期（用searchsorted近似，避免精确时间戳不匹配）
    all_dates = [d for d in all_dates if d.dayofweek == 0]
    # 留够持仓期：用 searchsorted 找 N 个交易日后的大约日期
    def _has_enough(d, hold_days):
        target = d + pd.Timedelta(days=hold_days + 15)  # 给足日历缓冲
        try:
            idx = bench_index.searchsorted(target, side='left')
            return idx < len(bench_index)
        except Exception:
            return False
    all_dates = [d for d in all_dates if _has_enough(d, hold_days)]
    print(f'  候选交易周: {len(all_dates)}', flush=True)

    holdings = []
    skip = {'limit_up_buy':0, 'limit_down_sell':0, 'suspended':0, 'no_data':0}
    cost_rate = 0.00232  # 合计约 0.232%

    for T in all_dates:
        picked = select_stocks(factors_dict, T, thresholds, top_k)
        if len(picked) < 3:
            continue
        codes = [c for c, _ in picked]
        returns = []
        for code in codes:
            dd = daily_dict.get(code)
            if dd is None or T not in dd.index:
                skip['no_data'] += 1
                continue
            entry = dd.loc[T, 'close']
            # 涨跌停检查（用前一日涨停价判断能否买入）
            t_idx = dd.index.get_loc(T)
            if t_idx > 0:
                prev_close = dd.iloc[t_idx-1]['close']
                if prev_close > 0 and entry >= prev_close * (1 + LIMIT):
                    skip['limit_up_buy'] += 1
                    continue
            # 卖出日（找 hold_days 交易日后）
            exit_ts = T + pd.Timedelta(days=hold_days)
            try:
                fut_idx = dd.index.searchsorted(exit_ts, side='left')
                if fut_idx < len(dd) and fut_idx >= 0:
                    exit_date = dd.index[fut_idx]
                else:
                    continue
            except Exception:
                continue
            exit_close = dd.loc[exit_date, 'close']
            # 涨停卖出检查
            if t_idx < len(dd)-1:
                ex_idx = dd.index.get_loc(exit_date)
                if ex_idx > 0:
                    prev_ex = dd.iloc[ex_idx-1]['close']
                    if prev_ex > 0 and exit_close <= prev_ex * (1 - LIMIT):
                        skip['limit_down_sell'] += 1
                        continue
            gross_ret = (exit_close / entry - 1)
            net_ret = gross_ret - cost_rate
            # 基准同期
            try:
                b_ret = (bench.loc[exit_date] / bench.loc[T] - 1) if T in bench_index and exit_date in bench_index else np.nan
            except Exception:
                b_ret = np.nan
            holdings.append({
                'T': T, 'codes': codes, 'code': code,
                'entry': entry, 'exit': exit_close,
                'gross_ret': gross_ret, 'net_ret': net_ret,
                'bench_ret': b_ret, 'excess': (net_ret - b_ret) if not np.isnan(b_ret) else np.nan
            })
        if (len(all_dates) > 0 and all_dates.index(T) % 20 == 0):
            print(f'  进度: {all_dates.index(T)+1}/{len(all_dates)}', flush=True)

    return holdings, skip

def report(holdings, skip, hold_days, bench, out_path=None):
    if not holdings:
        print('\n❌ 无有效交易记录')
        return
    df = pd.DataFrame(holdings)
    df['beat'] = df['excess'].fillna(0) > 0
    gross = df['gross_ret'].mean()
    net = df['net_ret'].mean()
    excess = df['excess'].mean()
    beat_pct = df['beat'].mean() * 100
    wins = (df['net_ret'] > 0).sum()
    total = len(df)
    bench_mean = df['bench_ret'].mean()
    start = df['T'].min()
    end = df['T'].max()
    annual = (1 + net) ** (252 / hold_days) - 1 if net > -1 else np.nan
    win_rate = wins / total * 100 if total > 0 else 0
    avg_excess = excess * 100
    text = f"""# 📊 因子组合回测报告（本地数据）

**数据源**: 通达信本地 `D:/TDX/vipdoc/` 二进制K线
**回测区间**: {start.date()} → {end.date()}
**持仓周期**: {hold_days} 交易日
**交易成本**: 0.232% / 轮
**基准**: 沪深300

## 核心结果
- 有效交易: **{total}** 次
- 胜率: **{win_rate:.1f}%** ({wins}/{total})
- 单均毛收益: {gross*100:.2f}%
- 单均净收益: {net*100:.2f}%
- 单均基准收益: {bench_mean*100:.2f}%
- 单均超额收益: **{avg_excess:.2f}%**
- 年化净收益: **{annual*100:.1f}%**
- 战胜基准比例: **{beat_pct:.1f}%**

## 跳过统计
- 涨停买入失败: {skip['limit_up_buy']}
- 跌停卖出失败: {skip['limit_down_sell']}
- 停牌: {skip['suspended']}
- 无数据: {skip['no_data']}

## 结论
{'✅ 组合有效，具备正向超额收益' if excess > 0 else '⚠️ 组合未跑赢基准，需优化因子阈值'}
"""
    print('\n' + text)
    if out_path:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(text)
        print(f'\n报告已保存: {out_path}')
    return df

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--start', default='20220101')
    ap.add_argument('--end', default='20260715')
    ap.add_argument('--hold-days', type=int, default=30)
    ap.add_argument('--top-k', type=int, default=30)
    ap.add_argument('--rps50', type=float, default=55)
    ap.add_argument('--retail', type=float, default=50)
    ap.add_argument('--out', default=None)
    args = ap.parse_args()

    print('='*60)
    print('因子组合回测引擎（本地通达信数据）')
    print(f'时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    print('='*60)

    print('\n加载日K（沪深A股，本地）...')
    daily = load_all_daily()

    print('\n加载周线（本地）...')
    weekly = load_weekly()
    if len(weekly) < 100:
        print('[WARN] 周线数据不足，尝试从日K聚合', flush=True)
        # 用日K聚合周K（周一数据）
        print('  聚合日K为周K...')
        for code, df in daily.items():
            try:
                weekly_df = df.groupby(df.index.to_period('W')).last()
                weekly_df.index = weekly_df.index.to_timestamp()
                weekly_df = weekly_df[['open','high','low','close','vol','amount']]
                weekly[code] = weekly_df
            except Exception:
                continue
        print(f'  周线(聚合): {len(weekly)} 只', flush=True)

    print('\n计算因子...')
    factors = compute_factors(weekly)

    print('\n加载基准(沪深300)...')
    bench = None
    for key in daily:
        if '000300' in key.upper():
            bench = daily[key]
            print(f'  基准: {key}', flush=True)
            break
    if bench is None:
        print('[WARN] 沪深300日K缺失，用上证指数(000001)替代', flush=True)
        for key in daily:
            if '000001' in key.upper():
                bench = daily[key]
                break
    if bench is None:
        print('[FATAL] 无基准数据', flush=True)
        sys.exit(1)

    print('\n执行回测...')
    t0 = time.time()
    holdings, skip = run_backtest(
        daily, factors, bench,
        hold_days=args.hold_days,
        start=args.start, end=args.end,
        top_k=args.top_k,
        thresholds={'rps50': args.rps50, 'retail': args.retail}
    )
    print(f'  耗时 {time.time()-t0:.0f}s', flush=True)

    out = args.out or f'combo_backtest_local_{datetime.now().strftime("%Y%m%d")}.md'
    report(holdings, skip, args.hold_days, bench, out)
