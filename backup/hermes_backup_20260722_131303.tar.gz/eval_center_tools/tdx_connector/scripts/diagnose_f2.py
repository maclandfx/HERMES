"""诊断F2单均收益异常 + F3/F4/F5全零"""
import os, struct, glob, pandas as pd, numpy as np
TDX_BASE='D:/TDX/vipdoc'; DIV={'sh':1000,'sz':10,'bj':100}
LIMIT=0.10; COST_RATE=0.00232

def parse(path):
    try:
        with open(path,'rb') as f: raw=f.read()
    except: return pd.DataFrame()
    if len(raw)%32!=0: return pd.DataFrame()
    fn=os.path.basename(path)
    if fn.startswith('sh'): m='sh'
    elif fn.startswith('sz'): m='sz'
    else: return pd.DataFrame()
    d=DIV[m]; rows=[]
    for i in range(len(raw)//32):
        c=raw[i*32:(i+1)*32]
        di=struct.unpack('<I',c[0:4])[0]
        try: ts=pd.Timestamp(di//10000,(di//100)%100,di%100)
        except: continue
        o=struct.unpack('<I',c[4:8])[0]/d; cl=struct.unpack('<I',c[8:12])[0]/d
        h=struct.unpack('<I',c[12:16])[0]/d; lo=struct.unpack('<I',c[16:20])[0]/d
        v=struct.unpack('<Q',c[20:28])[0]
        rows.append((ts,o,h,lo,cl,v))
    if not rows: return pd.DataFrame()
    return pd.DataFrame(rows,columns=['date','open','high','low','close','vol']).sort_values('date').set_index('date')

# load all stocks
daily={}; cnt=0
for fp in sorted(glob.glob(os.path.join(TDX_BASE,'sh','lday','*.day'))+glob.glob(os.path.join(TDX_BASE,'sz','lday','*.day'))):
    fn=os.path.basename(fp); code=fn[:-4]
    ts=code.upper()+('.SH' if 'sh' in code else '.SZ')
    df=parse(fp)
    if len(df)>60: daily[ts]=df; cnt+=1
print(f'loaded {cnt} stocks')

# benchmark
bench=parse('D:/TDX/vipdoc/sh/lday/sh000300.day')
wb=bench.groupby(bench.index.to_period('W')).last(); wb.index=wb.index.to_timestamp()
wb=wb[['open','high','low','close','vol']]
idx_df=wb['close']; idx_ma60=idx_df.rolling(60).mean()
market_bull_vals=((idx_df>idx_ma60)&(idx_ma60>idx_ma60.shift(5))).astype(int).values

# weekly
weekly={}
for c,df in daily.items():
    wd=df.groupby(df.index.to_period('W')).last(); wd.index=wd.index.to_timestamp()
    wd=wd[['open','high','low','close','vol']]
    if len(wd)>=30: weekly[c]=wd

# rps
recs=[(c,d,v) for c,df in weekly.items() for d,v in df['close'].items() if v>0]
pivot=pd.DataFrame(recs,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True)*100

# factors
factors={}
for code,df in weekly.items():
    C=df['close']; H=df['high']; L=df['low']; O=df['open']; V=df['vol']
    try:
        f={}
        VV=V/(V.rolling(5).mean()+0.0001)
        R0=((C-C.shift(1))/(C.shift(1)+0.0001)*100)*VV
        R0_abs=abs(R0.shift(1))+abs(R0.shift(2))+abs(R0.shift(3))+abs(R0.shift(4))+abs(R0.shift(5))/2
        f['main_in_signal']=(R0>R0_abs).astype(int)
        mn10=L.rolling(10).min(); mx25=H.rolling(25).max()
        wave=(((C-mn10)/(mx25-mn10+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['avg_line']=wave.ewm(span=3,adjust=False).mean()
        mid=(H+L)/2
        f['DCZ']=mid.ewm(span=10,adjust=False).mean()
        f['vol_ratio']=V/(V.rolling(5).mean()+0.0001)
        f['huashen']=(C.ewm(span=3,adjust=False).mean()>C.ewm(span=7,adjust=False).mean()).astype(int)
        f['ma20']=C.rolling(20).mean()
        ma45=C.rolling(45).mean(); ma30=C.rolling(30).mean()
        # F3 factors
        SHORT,LONG,ZWIN,SCALE=12,26,60,20
        dif_all=C.ewm(span=SHORT,adjust=False).mean()-C.ewm(span=LONG,adjust=False).mean()
        dif_ma=dif_all.rolling(ZWIN).mean(); dif_std=dif_all.rolling(ZWIN).std().fillna(0.0001)
        f['core_trend']=50+SCALE*(dif_all-dif_ma)/(dif_std+0.0001)
        f['core_trend_low']=(f['core_trend']<45).astype(int)
        VOSC_RAW=100*(V.rolling(12).mean()-V.rolling(26).mean())/(V.rolling(26).mean()+0.0001)
        vosc_ma=VOSC_RAW.rolling(ZWIN).mean(); vosc_std=VOSC_RAW.rolling(ZWIN).std().fillna(0.0001)
        f['vol_swing']=50+SCALE*(VOSC_RAW-vosc_ma)/(vosc_std+0.0001)
        f['vol_freeze']=((f['vol_swing']<38).astype(int).rolling(3).max()>0).astype(int)
        f['winner_pct']=(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)*100
        f['inst_ctrl']=(C>ma45).astype(int); f['main_lock']=(C>ma30).astype(int)
        wkret=(C/C.shift(1)-1)*100
        big=(wkret>5)&(f['vol_ratio']>1.5)
        f['strat_ignition']=(big.astype(int).rolling(12).max()>0).astype(int)
        f['trend_turn']=((f['core_trend']>f['core_trend'].shift(1))&(f['core_trend'].shift(1)<=f['core_trend'].shift(2))).astype(int)
        # F4
        AA=(C-L.rolling(20).min())*100/(H.rolling(20).max()-L.rolling(20).min()+0.0001)
        f['ind_trend']=(100*(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)).ewm(span=3,adjust=False).mean()
        f['retail_mom']=AA.rolling(6).mean()
        # F5
        ma5=C.rolling(5).mean(); ma10=C.rolling(10).mean()
        ma60=C.rolling(60).mean()
        ww=(((C-L.rolling(3).min())/(H.rolling(6).max()-L.rolling(3).min()+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['weekly_avg']=ww.ewm(span=3,adjust=False).mean()
        f['weekly_avg_turn']=((f['weekly_avg']>=f['weekly_avg'].shift(1))&(f['weekly_avg'].shift(1)<f['weekly_avg'].shift(2))).astype(int)
        f['vol_inc']=((V>C.rolling(5).mean())&(V<C.rolling(5).mean()*3)).astype(int)
        f['ma_bull']=((C>C.rolling(20).mean())&(ma5>ma10)).astype(int)
        f['above_ma60']=(C>ma60).astype(int)
        f['not_high']=(f['weekly_avg']<2.5).astype(int)
        crange=H-L+0.0001; f['no_long_shadow']=((H-C)<0.4*crange).astype(int)
        f['body_dom']=((C-O)>(H-L)*0.5).astype(int)
        ema12=C.ewm(span=12,adjust=False).mean(); ema26=C.ewm(span=26,adjust=False).mean()
        dif=ema12-ema26; f['dif']=dif; f['dea']=dif.ewm(span=9,adjust=False).mean()
        f['macd_golden_wide']=(dif>f['dea']).astype(int)
        LL9=L.rolling(9).min(); HH9=H.rolling(9).max()
        RSV=(C-LL9)/(HH9-LL9+0.0001)*100
        f['kdj_K']=RSV.ewm(span=3,adjust=False).mean(); f['kdj_D']=f['kdj_K'].ewm(span=3,adjust=False).mean()
        f['huashen_p1']=((C+1).ewm(span=3,adjust=False).mean()>(C+1).ewm(span=7,adjust=False).mean()).astype(int)
        f['market_bull']=pd.Series(market_bull_vals,index=C.index) if market_bull_vals is not None else pd.Series(0,index=C.index,dtype=int)
        f['rps50']=rps.loc[code] if code in rps.index else pd.Series(np.nan,index=C.index)
        f['close']=C
        factors[code]=f
    except Exception as e:
        if code=='SH000043.SH': print(f'factor err on {code}: {e}')
        pass
print(f'factors: {len(factors)} stocks')

def s(f,n,ts):
    x=f.get(n); return x.loc[ts] if x is not None and ts in x.index else np.nan

# run F2 on all stocks all weeks, collect trades
all_weeks=sorted(set().union(*[set(f['close'].index) for f in factors.values()]))
trades=[]
for wk in all_weeks:
    if wk.dayofweek!=0: continue
    # F2 formula
    picked=[]
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        main=s(f,'main_in_signal',wk); bull=s(f,'market_bull',wk); DCZ=s(f,'DCZ',wk); C=s(f,'close',wk)
        DCZ5=f['DCZ'].shift(5).loc[wk] if wk in f['DCZ'].shift(5).index else np.nan
        A=main==1 and bull==1 and pd.notna(DCZ) and pd.notna(DCZ5) and DCZ>DCZ5 and s(f,'vol_ratio',wk)>1.5 and C>DCZ
        avg=s(f,'avg_line',wk); hu=s(f,'huashen',wk)
        DCZ3=f['DCZ'].shift(3).loc[wk] if wk in f['DCZ'].shift(3).index else np.nan
        B=main==1 and pd.notna(DCZ) and pd.notna(DCZ3) and DCZ>=DCZ3 and pd.notna(avg) and avg<2.3 and hu==1 and not A
        ma20=s(f,'ma20',wk)
        trend_hold=pd.notna(C) and pd.notna(ma20) and C>=ma20 and (C>DCZ if pd.notna(C) and pd.notna(DCZ) else False)
        if (A or B) and trend_hold:
            rps_val=s(f,'rps50',wk); rps_val=rps_val if pd.notna(rps_val) else 50
            picked.append((code,rps_val))
    picked.sort(key=lambda x:x[1],reverse=True)
    if len(picked)<2: continue
    for code,_ in picked[:20]:
        dd=daily.get(code)
        if dd is None or wk not in dd.index: continue
        idx_s=dd.index.searchsorted(wk,side='left')
        if idx_s>=len(dd) or dd.index[idx_s]!=wk: continue
        entry=dd.iloc[idx_s]['close']
        if idx_s>0:
            prev=dd.iloc[idx_s-1]['close']
            if prev>0 and entry>=prev*1.1: continue
        exit_ts=wk+pd.Timedelta(days=30)
        fi=dd.index.searchsorted(exit_ts,side='left')
        if fi<0 or fi>=len(dd): continue
        exit_close=dd.iloc[fi]['close']
        gross=exit_close/entry-1
        net=gross-COST_RATE
        # benchmark return: weekly close at wk -> weekly close at exit
        wb_idx=wb.index
        tb=wb_idx.searchsorted(wk,side='left'); eb=wb_idx.searchsorted(exit_ts,side='left')
        b_ret=(wb.iloc[eb]['close']/wb.iloc[tb]['close']-1) if tb<len(wb) and eb<len(wb) and wb.iloc[eb]>0 and wb.iloc[tb]>0 else np.nan
        trades.append({'code':code,'wk':wk,'entry':entry,'exit':exit_close,'gross':gross,'net':net,'b_ret':b_ret,'exit_date':dd.index[fi]})

if trades:
    df=pd.DataFrame(trades)
    print(f'\nF2 trades: {len(df)}')
    print(f'gross mean: {df["gross"].mean()*100:.2f}%')
    print(f'net mean: {df["net"].mean()*100:.2f}%')
    print(f'bench mean: {df["b_ret"].mean()*100:.2f}%')
    print(f'win rate: {(df["net"]>0).mean()*100:.1f}%')
    # show top 10 by net
    print('\nTop 10 biggest net trades:')
    top=df.nlargest(10,'net')[['code','wk','entry','exit','exit_date','gross','net','b_ret']]
    for _,r in top.iterrows():
        print(f'  {r["code"]} wk={r["wk"].date()} entry={r["entry"]:.2f} exit={r["exit"]:.2f} on {r["exit_date"].date()} gross={r["gross"]*100:.1f}% net={r["net"]*100:.1f}% bench={r["b_ret"]*100:.1f}%')
    print('\nTop 10 biggest losses:')
    bot=df.nsmallest(10,'net')[['code','wk','entry','exit','exit_date','gross','net','b_ret']]
    for _,r in bot.iterrows():
        print(f'  {r["code"]} wk={r["wk"].date()} entry={r["entry"]:.2f} exit={r["exit"]:.2f} gross={r["gross"]*100:.1f}% net={r["net"]*100:.1f}%')
    # benchmark analysis
    print(f'\nbench_ret stats: min={df["b_ret"].min()*100:.1f}% max={df["b_ret"].max()*100:.1f}% median={df["b_ret"].median()*100:.1f}%')
    print(f'how many trades have bench_ret>20%: {(df["b_ret"]>0.20).sum()}')
    print(f'how many trades have bench_ret>50%: {(df["b_ret"]>0.50).sum()}')
    # Is benchmark calculated correctly? Check exit_ts-wk in days
    df['hold_days']=(df['exit_date']-df['wk']).dt.days
    print(f'hold days stats: min={df["hold_days"].min()} max={df["hold_days"].max()} mean={df["hold_days"].mean():.0f}')
else:
    print('No F2 trades')

# F3/F4/F5 trigger count per week (last 20 weeks)
print('\n=== F3 trigger count (last 20 weeks) ===')
for wk in sorted(factors['SH000001.SH']['close'].index)[-20:]:
    cnt=0
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        inst=s(f,'inst_ctrl',wk); ml=s(f,'main_lock',wk)
        if inst==1 and ml==1: cnt+=1
    print(f'  {wk.date()}: inst_ctrl&main_lock: {cnt}')
