import os, struct, glob, pandas as pd, numpy as np
TDX_BASE='D:/TDX/vipdoc'; DIV={'sh':1000,'sz':10,'bj':100}
def parse(path):
    try:
        with open(path,'rb') as f: raw=f.read()
    except: return pd.DataFrame()
    if len(raw)%32!=0: return pd.DataFrame()
    fn=os.path.basename(path)
    if fn.startswith('sh'): m='sh'
    elif fn.startswith('sz'): m='sz'
    else: return pd.DataFrame()
    d=DIV[m]; rows=[]
    for i in range(len(raw)//32):
        c=raw[i*32:(i+1)*32]
        di=struct.unpack('<I',c[0:4])[0]
        try: ts=pd.Timestamp(di//10000,(di//100)%100,di%100)
        except: continue
        o=struct.unpack('<I',c[4:8])[0]/d; cl=struct.unpack('<I',c[8:12])[0]/d
        h=struct.unpack('<I',c[12:16])[0]/d; lo=struct.unpack('<I',c[16:20])[0]/d
        v=struct.unpack('<Q',c[20:28])[0]
        rows.append((ts,o,h,lo,cl,v))
    if not rows: return pd.DataFrame()
    return pd.DataFrame(rows,columns=['date','open','high','low','close','vol']).sort_values('date').set_index('date')

daily={}; cnt=0
for fp in sorted(glob.glob(os.path.join(TDX_BASE,'sh','lday','*.day'))+glob.glob(os.path.join(TDX_BASE,'sz','lday','*.day'))):
    fn=os.path.basename(fp); code=fn[:-4]
    ts=code.upper()+('.SH' if 'sh' in code else '.SZ')
    df=parse(fp)
    if len(df)>60: daily[ts]=df; cnt+=1
print(f'loaded {cnt} stocks')
weekly={}
for c,df in daily.items():
    wd=df.groupby(df.index.to_period('W')).last(); wd.index=wd.index.to_timestamp()
    wd=wd[['open','high','low','close','vol']]
    if len(wd)>=30: weekly[c]=wd
recs=[(c,d,v) for c,df in weekly.items() for d,v in df['close'].items() if v>0]
pivot=pd.DataFrame(recs,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True)*100
bench=parse('D:/TDX/vipdoc/sh/lday/sh000300.day')
wb=bench.groupby(bench.index.to_period('W')).last(); wb.index=wb.index.to_timestamp()
wb=wb[['open','high','low','close','vol']]
idx_df=wb['close']; idx_ma60=idx_df.rolling(60).mean()
market_bull_vals=((idx_df>idx_ma60)&(idx_ma60>idx_ma60.shift(5))).astype(int).values
factors={}
for code,df in weekly.items():
    C=df['close']; H=df['high']; L=df['low']; O=df['open']; V=df['vol']
    try:
        f={}
        VV=V/(V.rolling(5).mean()+0.0001)
        R0=((C-C.shift(1))/(C.shift(1)+0.0001)*100)*VV
        R0_abs=abs(R0.shift(1))+abs(R0.shift(2))+abs(R0.shift(3))+abs(R0.shift(4))+abs(R0.shift(5))/2
        f['main_in_signal']=(R0>R0_abs).astype(int)
        mn10=L.rolling(10).min(); mx25=H.rolling(25).max()
        wave=(((C-mn10)/(mx25-mn10+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['avg_line']=wave.ewm(span=3,adjust=False).mean()
        f['DCZ']=((H+L)/2).ewm(span=10,adjust=False).mean()
        f['vol_ratio']=V/(V.rolling(5).mean()+0.0001)
        f['huashen']=(C.ewm(span=3,adjust=False).mean()>C.ewm(span=7,adjust=False).mean()).astype(int)
        f['ma20']=C.rolling(20).mean()
        ma45=C.rolling(45).mean(); ma30=C.rolling(30).mean()
        SHORT,LONG,ZWIN,SCALE=12,26,60,20
        dif_all=C.ewm(span=SHORT,adjust=False).mean()-C.ewm(span=LONG,adjust=False).mean()
        dif_ma=dif_all.rolling(ZWIN).mean(); dif_std=dif_all.rolling(ZWIN).std().fillna(0.0001)
        f['core_trend']=50+SCALE*(dif_all-dif_ma)/(dif_std+0.0001)
        f['core_trend_low']=(f['core_trend']<45).astype(int)
        VOSC_RAW=100*(V.rolling(12).mean()-V.rolling(26).mean())/(V.rolling(26).mean()+0.0001)
        vosc_ma=VOSC_RAW.rolling(ZWIN).mean(); vosc_std=VOSC_RAW.rolling(ZWIN).std().fillna(0.0001)
        f['vol_swing']=50+SCALE*(VOSC_RAW-vosc_ma)/(vosc_std+0.0001)
        f['vol_freeze']=((f['vol_swing']<38).astype(int).rolling(3).max()>0).astype(int)
        f['winner_pct']=(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)*100
        f['inst_ctrl']=(C>ma45).astype(int); f['main_lock']=(C>ma30).astype(int)
        wkret=(C/C.shift(1)-1)*100
        big=(wkret>5)&(f['vol_ratio']>1.5)
        f['strat_ignition']=(big.astype(int).rolling(12).max()>0).astype(int)
        f['trend_turn']=((f['core_trend']>f['core_trend'].shift(1))&(f['core_trend'].shift(1)<=f['core_trend'].shift(2))).astype(int)
        AA=(C-L.rolling(20).min())*100/(H.rolling(20).max()-L.rolling(20).min()+0.0001)
        f['ind_trend']=(100*(C-L.rolling(60).min())/(H.rolling(60).max()-L.rolling(60).min()+0.0001)).ewm(span=3,adjust=False).mean()
        f['retail_mom']=AA.rolling(6).mean()
        ma5=C.rolling(5).mean(); ma10=C.rolling(10).mean(); ma60=C.rolling(60).mean()
        ww=(((C-L.rolling(3).min())/(H.rolling(6).max()-L.rolling(3).min()+0.0001))*4).ewm(span=4,adjust=False).mean()
        f['weekly_avg']=ww.ewm(span=3,adjust=False).mean()
        f['weekly_avg_turn']=((f['weekly_avg']>=f['weekly_avg'].shift(1))&(f['weekly_avg'].shift(1)<f['weekly_avg'].shift(2))).astype(int)
        f['vol_inc']=((V>V.rolling(5).mean())&(V<V.rolling(5).mean()*3)).astype(int)
        f['ma_bull']=((C>C.rolling(20).mean())&(ma5>ma10)).astype(int)
        f['above_ma60']=(C>ma60).astype(int)
        f['not_high']=(f['weekly_avg']<2.5).astype(int)
        crange=H-L+0.0001; f['no_long_shadow']=((H-C)<0.4*crange).astype(int)
        f['body_dom']=((C-O)>(H-L)*0.5).astype(int)
        ema12=C.ewm(span=12,adjust=False).mean(); ema26=C.ewm(span=26,adjust=False).mean()
        dif=ema12-ema26; f['dif']=dif; f['dea']=dif.ewm(span=9,adjust=False).mean()
        f['macd_golden_wide']=(dif>f['dea']).astype(int)
        LL9=L.rolling(9).min(); HH9=H.rolling(9).max()
        RSV=(C-LL9)/(HH9-LL9+0.0001)*100
        f['kdj_K']=RSV.ewm(span=3,adjust=False).mean(); f['kdj_D']=f['kdj_K'].ewm(span=3,adjust=False).mean()
        f['huashen_p1']=((C+1).ewm(span=3,adjust=False).mean()>(C+1).ewm(span=7,adjust=False).mean()).astype(int)
        f['market_bull']=pd.Series(market_bull_vals,index=C.index) if market_bull_vals is not None else pd.Series(0,index=C.index,dtype=int)
        f['rps50']=rps.loc[code] if code in rps.index else pd.Series(np.nan,index=C.index)
        f['close']=C
        factors[code]=f
    except: pass
print(f'factors: {len(factors)}')
def s(f,n,ts):
    x=f.get(n); return x.loc[ts] if x is not None and ts in x.index else np.nan

weeks=sorted(set().union(*[set(f['close'].index) for f in factors.values()]))[-10:]
print('\n=== F3 条件拆解 (最后10周) ===')
for wk in weeks:
    cnt=0
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        inst=s(f,'inst_ctrl',wk); ml=s(f,'main_lock',wk)
        ign=s(f,'strat_ignition',wk); win=s(f,'winner_pct',wk)
        low=s(f,'core_trend_low',wk); fr=s(f,'vol_freeze',wk); turn=s(f,'trend_turn',wk)
        if inst==1 and ml==1 and ign==1 and pd.notna(win) and win>35 and low==1 and fr==1 and turn==1:
            cnt+=1
    print(f'  {wk.date()}: {cnt}')

print('\n=== F4 条件拆解 (最后10周) ===')
for wk in weeks:
    cnt=0
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        trend=s(f,'ind_trend',wk); retail=s(f,'retail_mom',wk)
        trend1=f['ind_trend'].shift(1).loc[wk] if wk in f['ind_trend'].shift(1).index else np.nan
        retail1=f['retail_mom'].shift(1).loc[wk] if wk in f['retail_mom'].shift(1).index else np.nan
        cond1=(pd.notna(trend) and pd.notna(retail) and trend>retail and pd.notna(trend1) and pd.notna(retail1) and trend1<=retail1 and trend<45)
        vol_r=s(f,'vol_ratio',wk)
        cond2=pd.notna(vol_r) and vol_r>1.5
        idx=f['close'].index; pos=idx.searchsorted(wk, side='left')
        cond3=pos>30
        if cond1 and cond2 and cond3: cnt+=1
    print(f'  {wk.date()}: {cnt}')

print('\n=== F5 条件拆解 (最后10周) ===')
for wk in weeks:
    cnt=0
    for code,f in factors.items():
        if wk not in f['close'].index: continue
        turn=s(f,'weekly_avg_turn',wk); vol_inc=s(f,'vol_inc',wk)
        macd_g=s(f,'macd_golden_wide',wk)
        K=s(f,'kdj_K',wk); D=s(f,'kdj_D',wk); dif=s(f,'dif',wk)
        kdj=pd.notna(K) and pd.notna(D) and K>D and pd.notna(dif) and dif<0.5
        golden=(macd_g==1) and kdj
        hu=s(f,'huashen_p1',wk); mb=s(f,'ma_bull',wk); a60=s(f,'above_ma60',wk)
        nh=s(f,'not_high',wk); ns=s(f,'no_long_shadow',wk); bd=s(f,'body_dom',wk)
        if turn==1 and vol_inc==1 and golden and hu==1 and mb==1 and a60==1 and nh==1 and ns==1 and bd==1:
            cnt+=1
    print(f'  {wk.date()}: {cnt}')
