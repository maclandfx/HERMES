"""Quick diagnosis: which condition blocks F8 on 200 real stocks.
Uses the REAL factor computation to check each blocking condition."""
import pandas as pd, numpy as np, sys, os, time, struct
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)
sample = [c for c in weekly if wf.is_eligible(c)][:200]
print(f"Sampling {len(sample)} eligible stocks")

# Compute factors using real compute_weekly_factors
# Instead, compute them inline with real formulas
bench_code = 'SH000300.SH'
bench = wf.load_benchmark(daily)
bweekly = wf.daily_to_weekly({bench_code: bench})
mbull = None; mbull_sz = None
if bench_code in bweekly:
    bw = bweekly[bench_code]
    if len(bw) >= 60:
        ma60 = bw['close'].rolling(60).mean()
        if pd.notna(ma60).sum() >= 10:
            ref_idx = weekly[list(weekly.keys())[0]].index
            mbull = (bw['close'] > ma60).map({True:1, False:0}).reindex(ref_idx).fillna(0)
            mbull_sz = mbull.copy()

# RPS
price_records = []
for code, df in weekly.items():
    for d, c in df['close'].items():
        if c and c > 0:
            price_records.append((code, d, c))
pivot = pd.DataFrame(price_records, columns=['code','date','close']).pivot(index='code', columns='date', values='close')
rps = pivot.rank(axis=1, pct=True, method='average') * 100

# Compute real factors for sample
t0 = time.time()
factors = {}
for code in sample:
    W = weekly[code]
    C = W['close']; H = W['high']; L = W['low']; O = W['open']; V = W['vol']
    try:
        f = {}
        # EMA/MACD
        EMA12 = C.ewm(span=12, adjust=False).mean()
        EMA26 = C.ewm(span=26, adjust=False).mean()
        dif = EMA12 - EMA26; dea = dif.ewm(span=9, adjust=False).mean()
        f['dif'] = dif; f['dea'] = dea
        f['macd_golden_wide'] = (dif > dea).astype(int)
        # MA
        f['ma5'] = C.rolling(5).mean()
        f['ma10'] = C.rolling(10).mean()
        f['ma20'] = C.rolling(20).mean()
        f['ma60'] = C.rolling(60).mean()
        f['close'] = C
        # avg_line
        f['avg_line'] = V.ewm(span=3, adjust=False).mean()
        # main_engage (R0>0 & avg_line rising)
        R0 = (C - C.shift(1)) / C.shift(1)
        f['v4_main_engage'] = ((R0 > 0) & (f['avg_line'] > f['avg_line'].shift(1))).astype(int)
        # DCZ
        mid = (C + O + ((H - L) / 4)) / 2
        f['DCZ'] = mid.ewm(span=20, adjust=False).mean()
        # vol_ratio
        vol_ma20 = V.rolling(20).mean()
        vol_rat20b = V / (vol_ma20 + 0.01)
        f['vol_ratio20b'] = vol_rat20b
        # 板块
        code_str = str(code)
        if code_str.startswith('30'): thr = 1.8
        elif code_str.startswith('68'): thr = 2.2
        elif code_str.startswith(('43', '83', '92')): thr = 2.5
        else: thr = 2.0
        f['v4_vol_pass'] = (vol_rat20b > thr).astype(int)
        f['v4_vol_steady'] = (vol_rat20b > 1.3).astype(int)
        # 防骗
        f['v4_abnormal_vol'] = (vol_rat20b > 3).astype(int)
        upper_shadow = (H - np.maximum(C, C.shift(1))) / (H.rolling(25).max() - L.rolling(10).min() + 0.01)
        f['v4_long_upper'] = (upper_shadow > 0.6).astype(int)
        f['v4_safe_vol'] = (~((f['v4_abnormal_vol'] == 1) & (f['v4_long_upper'] == 1))).astype(int)
        # MACD
        golden_cross = (dif > dea) & (dif.shift(1) <= dea.shift(1))
        above_zero = (dea > 0); below_zero = (dea <= 0)
        f['v4_macd_strong'] = (golden_cross & above_zero & (dea > 0)).astype(int)
        f['v4_macd_mid'] = (golden_cross | above_zero).astype(int)
        f['v4_macd_bear'] = (golden_cross & below_zero & (f['v4_vol_steady'] == 1)).astype(int)
        # 趋势
        f['v4_trend_healthy'] = (f['ma20'] > f['ma20'].shift(5)).astype(int)
        f['v4_trend_hold'] = (C > f['ma20'] * 0.95).astype(int)
        f['v4_trend_weak_hold'] = (C > f['ma20'] * 0.90).astype(int)
        # 压力
        h30 = H.rolling(30).max()
        f['v4_pressure1'] = (C < h30 * 0.75).astype(int)
        f['v4_pressure2'] = (C < h30 * 0.80).astype(int)
        # 风控
        f['v4_risk_ctrl'] = ((C.notna().cumsum() > 20) & (V > 0)).astype(int)
        # winner_pct
        h60 = H.rolling(60).max(); l60 = L.rolling(60).min()
        f['winner_pct'] = (C - l60) / (h60 - l60 + 0.0001) * 100
        f['v4_profit_safe'] = (f['winner_pct'] < 70).astype(int)
        # chip_spread
        f['chip_spread'] = C.rolling(20).std() / (C + 0.0001) * 100
        f['v4_chip_concentrated'] = (f['chip_spread'] < 35).astype(int)
        # market_bull
        f['market_bull'] = mbull if mbull is not None else pd.Series(1, index=C.index)
        f['market_bull_sz'] = mbull_sz if mbull_sz is not None else pd.Series(1, index=C.index)
        factors[code] = f
    except Exception as e:
        if len(factors) < 1:
            import traceback; traceback.print_exc()
        pass

print(f"Factors: {len(factors)} in {time.time()-t0:.1f}s")

# Count conditions
from collections import Counter
bottleneck = Counter()
for code, f in factors.items():
    C = f['close']; N = len(C)
    bottleneck['weeks'] += N
    # Each blocking condition (as in formula_8_macd_tiered)
    bottleneck['main_engage'] += int((f['v4_main_engage'] == 1).sum())
    bottleneck['risk_ctrl'] += int((f['v4_risk_ctrl'] == 1).sum())
    bottleneck['profit_safe'] += int((f['v4_profit_safe'] == 1).sum())
    bottleneck['chip_conc'] += int((f['v4_chip_concentrated'] == 1).sum())
    bottleneck['safe_vol'] += int((f['v4_safe_vol'] == 1).sum())
    # Signal-specific
    bottleneck['macd_strong'] += int((f['v4_macd_strong'] == 1).sum())
    bottleneck['macd_mid'] += int((f['v4_macd_mid'] == 1).sum())
    bottleneck['macd_bear'] += int((f['v4_macd_bear'] == 1).sum())
    bottleneck['trend_healthy'] += int((f['v4_trend_healthy'] == 1).sum())
    bottleneck['trend_hold'] += int((f['v4_trend_hold'] == 1).sum())
    bottleneck['trend_weak'] += int((f['v4_trend_weak_hold'] == 1).sum())
    bottleneck['press1'] += int((f['v4_pressure1'] == 1).sum())
    bottleneck['press2'] += int((f['v4_pressure2'] == 1).sum())
    bottleneck['vol_pass'] += int((f['v4_vol_pass'] == 1).sum())
    bottleneck['vol_steady'] += int((f['v4_vol_steady'] == 1).sum())
    # Full signal paths
    # Strong: macd_strong + vol_pass + trend_healthy + (press1 if healthy else press2)
    strong = ((f['v4_macd_strong']==1)&(f['v4_vol_pass']==1)&(f['v4_trend_healthy']==1)&
              ((f['v4_trend_healthy']==1)&(f['v4_pressure1']==1))|((f['v4_trend_healthy']!=1)&(f['v4_pressure2']==1)))
    # Steady: macd_mid + vol_steady + trend_hold + avg_ok
    avg_ok = (f['avg_line'] < 2.5) & f['avg_line'].notna()
    steady = (f['v4_macd_mid']==1)&(f['v4_vol_steady']==1)&(f['v4_trend_hold']==1)&avg_ok
    # Attack: macd_bear + (vol_pass|vol_steady) + trend_weak
    attack = (f['v4_macd_bear']==1)&((f['v4_vol_pass']==1)|(f['v4_vol_steady']==1))&(f['v4_trend_weak_hold']==1)
    bottleneck['strong'] += int(strong.sum())
    bottleneck['steady'] += int(steady.sum())
    bottleneck['attack'] += int(attack.sum())
    # Full F8: all 5 base + any signal
    base5 = (f['v4_main_engage']==1)&(f['v4_risk_ctrl']==1)&(f['v4_profit_safe']==1)&(f['v4_chip_concentrated']==1)&(f['v4_safe_vol']==1)
    bottleneck['base5'] += int(base5.sum())
    bottleneck['f8'] += int((base5 & (strong | steady | attack)).sum())

N = bottleneck['weeks']
print(f"\nBottleneck ({len(factors)} stocks, {N} total weeks):")
print(f"{'condition':<22}{'count':>8}{'%':>8}")
for k in ['main_engage','risk_ctrl','profit_safe','chip_conc','safe_vol','base5',
          'macd_strong','macd_mid','macd_bear',
          'trend_healthy','trend_hold','trend_weak',
          'press1','press2','vol_pass','vol_steady',
          'strong','steady','attack','f8']:
    if N > 0:
        print(f"{k:<22}{bottleneck[k]:>8}{100*bottleneck[k]/N:>7.1f}%")
