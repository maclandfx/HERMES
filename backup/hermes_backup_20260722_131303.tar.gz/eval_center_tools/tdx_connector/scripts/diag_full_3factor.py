"""Run full backtest but dump holdings to diagnose 3-factor 275% anomaly.
Runs ONLY 3-factor on full weekly dict, dumps holdings to CSV."""
import pandas as pd, numpy as np, sys, os, time
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)
bench = wf.load_benchmark(daily)

# Compute factors for ALL eligible codes using the REAL compute_weekly_factors
print("Computing factors (full market)...")
t0 = time.time()
factors = wf.compute_weekly_factors(weekly)
print(f"Factors: {len(factors)} in {time.time()-t0:.1f}s")

# Run 3-factor realistic
print("\nRunning 3-factor realistic...")
h3, s3 = wf.run_formula_backtest(
    lambda f,ts: wf.formula_3factor(f,ts,50,45),
    '3factor', weekly, daily, factors, bench,
    hold_days=30, top_k=20, start='20230101', end='20251231', realistic=True)

df = pd.DataFrame(h3) if h3 else pd.DataFrame()
print(f"\nTotal trades: {len(df)}")
if len(df)>0:
    df['net_pct'] = df['net']*100
    print(f"Mean net: {df['net_pct'].mean():.2f}%")
    print(f"Std net: {df['net_pct'].std():.2f}%")
    print(f"Max net: {df['net_pct'].max():.2f}%")
    print(f"Min net: {df['net_pct'].min():.2f}%")
    # Check for extreme outliers
    print("\nTrades with net>100%:")
    big = df[df['net_pct']>100].sort_values('net_pct',ascending=False)
    if len(big)>0:
        print(big[['code','T','entry','exit','net_pct']].head(20).to_string(index=False))
        print(f"Count: {len(big)}")
    # Entry price sanity
    print(f"\nEntry price range: {df['entry'].min():.3f} ~ {df['entry'].max():.3f}")
    print(f"Entries < 1: {(df['entry']<1).sum()}")
    # Net distribution
    print(f"\nNet distribution:")
    print(f"  net>200%: {(df['net_pct']>200).sum()}")
    print(f"  net>100%: {(df['net_pct']>100).sum()}")
    print(f"  net>50%: {(df['net_pct']>50).sum()}")
    print(f"  net>20%: {(df['net_pct']>20).sum()}")
    print(f"  net<0%: {(df['net_pct']<0).sum()}")
    # Save for inspection
    df.to_csv('3factor_holdings.csv', index=False)
    print(f"\nSaved to 3factor_holdings.csv")
