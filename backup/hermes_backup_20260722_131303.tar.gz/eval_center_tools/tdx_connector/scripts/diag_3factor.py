"""Diagnose 3-factor realistic anomaly + F8 zero-trades.
Re-imports the module properly and samples real trades."""
import pandas as pd, numpy as np, sys, os, time, math
sys.path.insert(0,'.')
import importlib.util

spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
main_idx = src.find("if __name__")
exec(compile(src[:main_idx], 'weekly_formula_backtest.py', 'exec'), wf.__dict__)

# Build data
print("Loading data...")
daily = wf.load_all_daily()
print(f'Daily: {len(daily)}')
weekly = wf.daily_to_weekly(daily)
print(f'Weekly: {len(weekly)}')

# Compute factors
print("Computing factors (subset of 200 stocks for speed)...")
t0=time.time()
all_codes = list(weekly.keys())
price_records=[]
for code, df in weekly.items():
    for d, c in df['close'].items():
        if c and c>0:
            price_records.append((code,d,c))
pivot=pd.DataFrame(price_records,columns=['code','date','close']).pivot(index='code',columns='date',values='close')
rps=pivot.rank(axis=1,pct=True,method='average')*100
print(f'RPS done in {time.time()-t0:.1f}s')

# Compute factors for subset
factors={}
# Build market_bull (simplified: use HS300 MA60 check)
bench_code='SH000300.SH'
bdaily=wf.load_benchmark(daily)
bweekly=wf.daily_to_weekly({bench_code:bdaily})
bench_w = bweekly[bench_code] if bench_code in bweekly else None
mbull=None; mbull_sz=None
if bench_w is not None and len(bench_w)>=60:
    ma60=bench_w['close'].rolling(60).mean()
    if pd.notna(ma60).sum()>=10:
        mbull=(bench_w['close']>ma60).map({True:1,False:0}).reindex(weekly[list(weekly)[0]].index).fillna(0)

t0=time.time()
for code in list(weekly.keys())[:200]:
    W=weekly[code]
    C=W['close'];H=W['high'];L=W['low'];O=W['open'];V=W['vol']
    try:
        f={}
        # Core factors
        EMA12=C.ewm(span=12,adjust=False).mean();EMA26=C.ewm(span=26,adjust=False).mean()
        dif=EMA12-EMA26;dea=dif.ewm(span=9,adjust=False).mean()
        f['dif']=dif;f['dea']=dea
        f['macd_golden_wide']=(dif>dea).astype(int)
        ma5=C.rolling(5).mean();ma10=C.rolling(10).mean();ma20=C.rolling(20).mean();ma60=C.rolling(60).mean()
        f['ma20']=ma20;f['close']=C
        # RPS
        f['rps50']=rps.loc[code] if code in rps.index else pd.Series(np.nan,index=C.index)
        # retail_mom
        HH20=H.rolling(20).max();LL20=L.rolling(20).min()
        rel_pos=(C-LL20)*100/(HH20-LL20+0.0001)
        f['retail_mom']=rel_pos.rolling(6).mean()
        # DCZ
        mid=(C+O+((H-L)/4))/2;f['DCZ']=mid.ewm(span=20,adjust=False).mean()
        # ATR
        TR=pd.concat([(H-L),pd.concat([H-C.shift(1),C-L.shift(1)]).fillna(0).max(axis=0)],axis=1).max(axis=1)
        f['atr14']=TR.rolling(14).mean()
        # market_bull (simplified)
        f['market_bull']=pd.Series(1,index=C.index)
        f['market_bull_sz']=pd.Series(1,index=C.index)
        factors[code]=f
    except Exception as e:
        if len(factors)==0: import traceback;traceback.print_exc()
print(f'Factors: {len(factors)} in {time.time()-t0:.1f}s')

# --- Run 3-factor realistic trades on subset ---
print("\n--- Sampling 3-factor realistic trades ---")
formulas=lambda f,ts: wf.formula_3factor(f,ts,50,45)

sample_trades=[]
for code in list(factors.keys())[:100]:
    W=weekly[code]
    C=W['close'];f=factors[code]
    for ts in W.index:
        if wf._s(f,'rps50',ts) is None: continue
        if not formulas(f,ts): continue
        # Find buy/sell like real backtest
        dd=daily.get(code)
        if dd is None or len(dd)<60: continue
        T=ts.to_timestamp()
        if T < pd.Timestamp('20230101') or T > pd.Timestamp('20251231'): continue
        dd_sorted=dd.sort_index()
        idx_i=dd_sorted.index.searchsorted(T,side='left')
        if idx_i>=len(dd_sorted) or dd_sorted.index[idx_i]!=T: continue
        entry=dd_sorted.iloc[idx_i+1]['open'] if idx_i+1<len(dd_sorted) else None
        if entry is None or entry<=0: continue
        exit_ts=T+pd.Timedelta(days=30)
        fi=dd_sorted.index.searchsorted(exit_ts,side='left')
        if fi<0 or fi>=len(dd_sorted): continue
        exit_c=dd_sorted.iloc[fi]['close']
        if exit_c<=0: continue
        gross=exit_c/entry-1-0.002
        net=gross-0.00232
        sample_trades.append({'code':code,'T':str(T.date()),'entry':round(entry,2),
                              'exit':round(exit_c,2),'net':round(net*100,2)})

df=pd.DataFrame(sample_trades)
print(f'Total 3-factor subset trades: {len(df)}')
if len(df)>0:
    print(df.head(20).to_string(index=False))
    print(f"\nNet stats: mean={df['net'].mean():.2f}% median={df['net'].median():.2f}% max={df['net'].max():.2f}%")
    # Check for outliers
    print(f"\nTrades with net>50%: {(df['net']>50).sum()}")
    if (df['net']>50).any():
        print(df[df['net']>50].to_string(index=False))
