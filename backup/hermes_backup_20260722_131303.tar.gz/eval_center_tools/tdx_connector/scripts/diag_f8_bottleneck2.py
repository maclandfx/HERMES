"""Diagnose F8 zero trades by counting condition satisfaction on factor samples."""
import pandas as pd, numpy as np, sys, os, time, struct
sys.path.insert(0,'.')
import importlib.util
spec = importlib.util.spec_from_file_location('wf', 'weekly_formula_backtest.py')
wf = importlib.util.module_from_spec(spec)
src = open('weekly_formula_backtest.py').read()
exec(compile(src[:src.find("if __name__")], 'wf', 'exec'), wf.__dict__)

daily = wf.load_all_daily()
weekly = wf.daily_to_weekly(daily)

# Compute factors for ~300 eligible stocks
sample = [c for c in weekly if wf.is_eligible(c)][:300]
print(f"Sampling {len(sample)} eligible stocks")

# Load benchmark for market_bull
bench_code = 'SH000300.SH'
bench = wf.load_benchmark(daily)
bweekly = wf.daily_to_weekly({bench_code: bench})
mbull = None; mbull_sz = None
if bench_code in bweekly:
    bw = bweekly[bench_code]
    if len(bw) >= 60:
        ma60 = bw['close'].rolling(60).mean()
        if pd.notna(ma60).sum() >= 10:
            ref_idx = weekly[list(weekly.keys())[0]].index
            mbull = (bw['close'] > ma60).map({True:1, False:0}).reindex(ref_idx).fillna(0)
            mbull_sz = mbull.copy()

# RPS
price_records = []
for code, df in weekly.items():
    for d, c in df['close'].items():
        if c and c > 0:
            price_records.append((code, d, c))
pivot = pd.DataFrame(price_records, columns=['code','date','close']).pivot(index='code', columns='date', values='close')
rps = pivot.rank(axis=1, pct=True, method='average') * 100

# Compute factors for sample
t0 = time.time()
factors = {}
for code in sample:
    W = weekly[code]
    C = W['close']; H = W['high']; L = W['low']; O = W['open']; V = W['vol']
    AM = W.get('amount', pd.Series(1, index=W.index))
    try:
        f = {}
        # EMA/MACD
        EMA12 = C.ewm(span=12, adjust=False).mean()
        EMA26 = C.ewm(span=26, adjust=False).mean()
        dif = EMA12 - EMA26; dea = dif.ewm(span=9, adjust=False).mean()
        f['dif'] = dif; f['dea'] = dea
        f['macd_golden_wide'] = (dif > dea).astype(int)
        # MACD zero-axis tiering
        gc = (dif > dea) & (dif.shift(1) <= dea.shift(1))
        above_zero = (dea > 0)
        f['v4_macd_strong'] = (gc & above_zero).astype(int)
        f['v4_macd_mid'] = (gc | above_zero).astype(int)
        # MA
        f['ma5'] = C.rolling(5).mean()
        f['ma10'] = C.rolling(10).mean()
        f['ma20'] = C.rolling(20).mean()
        f['ma60'] = C.rolling(60).mean()
        # 趋势健康/守住
        f['v4_trend_healthy'] = (f['ma20'] > f['ma20'].shift(5)).astype(int)
        f['v4_trend_hold'] = (C > f['ma20'] * 0.95).astype(int)
        f['v4_trend_weak_hold'] = (C > f['ma20'] * 0.90).astype(int)
        f['close'] = C
        # DCZ
        mid = (C + O + ((H - L) / 4)) / 2
        f['DCZ'] = mid.ewm(span=20, adjust=False).mean()
        f['v4_DCZ_rise'] = (f['DCZ'] > f['DCZ'].shift(3)).astype(int)
        # 平均线
        f['avg_line'] = V.ewm(span=3, adjust=False).mean()
        f['v4_main_engage'] = (((C - C.shift(1)) / C.shift(1)) > 0).astype(int)
        # 板块放量
        vol_ma5 = V.rolling(5).mean()
        code_str = str(code)
        if code_str.startswith('30'): thr = 1.8
        elif code_str.startswith('68'): thr = 2.2
        elif code_str.startswith(('43', '83', '92')): thr = 2.5
        else: thr = 2.0
        f['v4_burst_main'] = (V > vol_ma5 * thr).astype(int)
        f['v4_burst_yb'] = (V > vol_ma5 * 1.8).astype(int)
        f['v4_burst_kc'] = (V > vol_ma5 * 2.2).astype(int)
        f['v4_burst_bj'] = (V > vol_ma5 * 2.5).astype(int)
        # 压力
        h30 = H.rolling(30).max()
        f['v4_pressure1'] = (C < h30 * 0.75).astype(int)
        f['v4_pressure2'] = (C < h30 * 0.80).astype(int)
        # 防骗
        v4_dump = ((V / AM.fillna(1).replace(0, 1) > 3) & (C < C.shift(1))).astype(int)
        f['v4_safe_vol'] = (~v4_dump).astype(int)
        # 风控
        f['v4_risk_ctrl'] = ((C.notna().cumsum() > 52) & (V > 0)).astype(int)
        # 获利安全
        f['v4_profit_safe'] = (0 < 70).astype(int)  # placeholder
        # 筹码集中
        f['v4_chip_concentrated'] = 1  # placeholder
        # market_bull
        f['market_bull'] = mbull if mbull is not None else pd.Series(1, index=C.index)
        f['market_bull_sz'] = mbull_sz if mbull_sz is not None else pd.Series(1, index=C.index)
        f['rps50'] = rps.loc[code] if code in rps.index else pd.Series(np.nan, index=C.index)
        # retail_mom
        HH20 = H.rolling(20).max(); LL20 = L.rolling(20).min()
        rel_pos = (C - LL20) * 100 / (HH20 - LL20 + 0.0001)
        f['retail_mom'] = rel_pos.rolling(6).mean()
        # atr14
        hcl = pd.concat([H - L, (H - C.shift(1)).fillna(0), (C - L.shift(1)).fillna(0)], axis=1).max(axis=1)
        f['atr14'] = hcl.rolling(14).mean()
        factors[code] = f
    except Exception as e:
        if len(factors) < 1:
            import traceback; traceback.print_exc()

print(f"Factors: {len(factors)} in {time.time()-t0:.1f}s")

# Now count F8 condition satisfaction
from collections import Counter
bottleneck = Counter()
for code, f in factors.items():
    C = f['close']
    N = len(C)
    bottleneck['weeks'] += N
    # Replicate F8 logic from formula_8_macd_tiered
    # Step 1: main_engage
    main = f.get('v4_main_engage', pd.Series(0, index=C.index))
    bottleneck['main_engage'] += int((main == 1).sum())
    # Step 2: risk_ctrl
    risk = f.get('v4_risk_ctrl', pd.Series(1, index=C.index))
    bottleneck['risk_ctrl'] += int((risk == 1).sum())
    # Step 3: profit_safe
    prof = f.get('v4_profit_safe', pd.Series(1, index=C.index))
    bottleneck['profit_safe'] += int((prof == 1).sum())
    # Step 4: chip_concentrated
    chip = f.get('v4_chip_concentrated', pd.Series(1, index=C.index))
    bottleneck['chip_conc'] += int((chip == 1).sum())
    # Step 5: safe_vol
    sv = f.get('v4_safe_vol', pd.Series(1, index=C.index))
    bottleneck['safe_vol'] += int((sv == 1).sum())
    # Step 6: MACD tiers
    ms = f.get('v4_macd_strong', pd.Series(0, index=C.index))
    mm = f.get('v4_macd_mid', pd.Series(0, index=C.index))
    mb = f.get('v4_macd_bear', pd.Series(0, index=C.index))
    bottleneck['macd_strong'] += int((ms == 1).sum())
    bottleneck['macd_mid'] += int((mm == 1).sum())
    bottleneck['macd_bear'] += int((mb == 1).sum())
    # Step 7: pressure + trend
    p1 = f.get('v4_pressure1', pd.Series(0, index=C.index))
    p2 = f.get('v4_pressure2', pd.Series(0, index=C.index))
    th = f.get('v4_trend_healthy', pd.Series(0, index=C.index))
    thh = f.get('v4_trend_hold', pd.Series(0, index=C.index))
    tw = f.get('v4_trend_weak_hold', pd.Series(0, index=C.index))
    bottleneck['press1'] += int((p1 == 1).sum())
    bottleneck['press2'] += int((p2 == 1).sum())
    bottleneck['trend_healthy'] += int((th == 1).sum())
    bottleneck['trend_hold'] += int((thh == 1).sum())
    bottleneck['trend_weak'] += int((tw == 1).sum())
    # Step 8: vol_pass/burst
    vm = f.get('v4_burst_main', pd.Series(0, index=C.index))
    bottleneck['vol_burst'] += int((vm == 1).sum())
    # F8 signals
    position_safe_strong = (p1 == 1)
    position_safe_steady = (p2 == 1)
    strong = (main == 1) & (risk == 1) & (prof == 1) & (chip == 1) & (sv == 1) & (ms == 1) & (vm == 1) & (th == 1) & position_safe_strong
    steady = (main == 1) & (risk == 1) & (prof == 1) & (chip == 1) & (sv == 1) & (mm == 1) & (thh == 1) & position_safe_steady
    attack = (main == 1) & (risk == 1) & (prof == 1) & (chip == 1) & (sv == 1) & (mb == 1) & (vm == 1) & (tw == 1)
    f8 = strong | steady | attack
    bottleneck['strong'] += int(strong.sum())
    bottleneck['steady'] += int(steady.sum())
    bottleneck['attack'] += int(attack.sum())
    bottleneck['f8'] += int(f8.sum())

N = bottleneck['weeks']
print(f"\nBottleneck ({len(factors)} stocks, {N} weeks):")
print(f"{'factor':<20}{'count':>8}{'%':>8}")
for k in ['main_engage','risk_ctrl','profit_safe','chip_conc','safe_vol',
          'macd_strong','macd_mid','macd_bear',
          'trend_healthy','trend_hold','trend_weak',
          'press1','press2','vol_burst',
          'strong','steady','attack','f8']:
    print(f"{k:<20}{bottleneck[k]:>8}{100*bottleneck[k]/N:>7.1f}%")
