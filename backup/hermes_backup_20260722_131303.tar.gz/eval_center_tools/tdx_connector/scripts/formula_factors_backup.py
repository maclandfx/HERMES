import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_tushare_token
"""
formula_factors.py — 12个选股公式的因子计算库
两个完全独立的因子体系：
  - calc_weekly_formula_factors(): 周线5公式的因子（周K数据）
  - calc_daily_formula_factors(): 日线7公式的因子（日K数据）

不调用综合评分因子引擎，与factor_engine.py完全解耦。
"""
import sys
import numpy as np
import pandas as pd
from datetime import datetime, timedelta


def normalize(c):
    return c[1:] if len(c) == 7 and c[0] in '012' else c


def to_ts_code(code):
    if code[0] in '69':
        return code + '.SH'
    return code + '.SZ'


# ════════════════════════════════════════════
# 周线公式因子（5个公式）
# ════════════════════════════════════════════

def calc_weekly_formula_factors(codes_list):
    """计算周线5个选股公式所需的全部因子"""
    import tushare as ts
    pro = ts.pro_api(get_tushare_token())
    results = {}
    
    for code_7 in codes_list:
        code = normalize(code_7)
        if not code or len(code) != 6:
            continue
        ts_code = to_ts_code(code)
        try:
            end = datetime.now().strftime('%Y%m%d')
            start = (datetime.now() - timedelta(days=7*120)).strftime('%Y%m%d')
            df = pro.weekly(ts_code=ts_code, start_date=start, end_date=end)
            if df is None or df.empty or len(df) < 20:
                results[code] = {'_error': f'数据不足'}
                continue
            df = df.sort_values('trade_date').reset_index(drop=True).copy()
            for col in ['close', 'open', 'high', 'low', 'vol', 'pct_chg']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            df = df.dropna(subset=['close', 'open', 'high', 'low', 'vol'])
            if len(df) < 20:
                results[code] = {'_error': '清洗后数据不足'}
                continue
            
            c = df['close']
            o = df['open']
            h = df['high']
            l = df['low']
            v = df['vol']
            last_close = c.iloc[-1]
            
            # 1. MACD
            dif = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()
            dea = dif.ewm(span=9, adjust=False).mean()
            macd = (dif - dea) * 2
            macd_golden = bool((dif.iloc[-1] > dea.iloc[-1]) and (dif.shift(1).iloc[-1] <= dea.shift(1).iloc[-1]))
            macd_dif_above_dea = bool(dif.iloc[-1] > dea.iloc[-1])
            
            # 2. KDJ
            rsv = ((c - l.rolling(9, min_periods=1).min()) / 
                   (h.rolling(9, min_periods=1).max() - l.rolling(9, min_periods=1).min() + 0.0001) * 100)
            rsv = rsv.fillna(50)
            k = rsv.rolling(3, min_periods=1).mean().shift(1) * 0.67 + rsv * 0.33
            d = k.rolling(3, min_periods=1).mean()
            kdj_bull = bool(k.iloc[-1] > d.iloc[-1])
            
            # 3. 价格波动线 & 平均线
            llv3 = l.rolling(3, min_periods=1).min()
            hhv6 = h.rolling(6, min_periods=1).max()
            wave = ((c - llv3) / (hhv6 - llv3 + 0.0001) * 4).ewm(span=4, adjust=False).mean()
            avg_line = wave.ewm(span=3, adjust=False).mean()
            avg_turning = bool(avg_line.iloc[-1] >= avg_line.shift(1).iloc[-1] and 
                               avg_line.shift(1).iloc[-1] < avg_line.shift(2).iloc[-1])
            
            # 4. DIF Z-score
            dif_ma60 = dif.rolling(60, min_periods=1).mean()
            dif_std60 = dif.rolling(60, min_periods=1).std()
            dif_z = (dif - dif_ma60) / (dif_std60 + 0.0001)
            core_trend = 50 + 20 * dif_z
            
            # 量能摆动
            vol_n1 = v.rolling(12, min_periods=1).mean()
            vol_n2 = v.rolling(26, min_periods=1).mean()
            vosc_raw = 100 * (vol_n1 - vol_n2) / (vol_n2 + 0.0001)
            vosc_ma60 = vosc_raw.rolling(60, min_periods=1).mean()
            vosc_std60 = vosc_raw.rolling(60, min_periods=1).std()
            vosc_z = (vosc_raw - vosc_ma60) / (vosc_std60 + 0.0001)
            vol_oscillation = 50 + 20 * vosc_z
            vol_freeze = bool(vosc_z.shift(1).iloc[-1] < 38 or vosc_z.shift(2).iloc[-1] < 38 or vosc_z.shift(3).iloc[-1] < 38)
            
            # 4.5. 周线级 R0 资金流（所有周线主进公式核心）
            # VV = VOL/MA(VOL,5), R0 = 涨跌幅% * VV
            vol_ma5_w = v.rolling(5, min_periods=1).mean()
            vv = v / (vol_ma5_w + 0.0001)
            r0_w = ((c - c.shift(1)) / (c.shift(1) + 0.0001) * 100) * vv
            r0_sum_w = r0_w.abs().rolling(5, min_periods=1).sum()
            weekly_r0 = round(float(r0_w.iloc[-1]), 2)
            weekly_r0_ma5 = round(float(r0_w.rolling(5, min_periods=1).mean().iloc[-1]), 2)
            weekly_main_in_signal = bool((r0_w.iloc[-1] > r0_sum_w.iloc[-1] / 2) and
                                          (avg_line.iloc[-1] >= avg_line.shift(1).iloc[-1]) and
                                          (avg_line.shift(1).iloc[-1] < avg_line.shift(2).iloc[-1]))
            weekly_r0_ma5_cross = bool(r0_w.iloc[-1] > r0_w.rolling(5, min_periods=1).mean().iloc[-1])

            # 5. ATR
            tr = np.maximum(np.maximum(h - l, np.abs(h - c.shift(1))), np.abs(l - c.shift(1)))
            atr14 = tr.rolling(14, min_periods=1).mean()
            atr_rising = bool(atr14.iloc[-1] > atr14.shift(1).iloc[-1])
            
            # 6. WINNER
            recent52 = df.tail(52).copy()
            recent52['amt'] = recent52['close'] * recent52['vol']
            total_amt = recent52['amt'].sum()
            if total_amt > 0:
                below = recent52[recent52['close'] <= last_close]['amt'].sum()
                winner_pct = below / total_amt * 100
            else:
                winner_pct = 50
            
            # 7. 战略建仓
            pct_13w = df.tail(13)['pct_chg'].fillna(0)
            vol_13w = df.tail(13)['vol']
            vol_ma5_13w = vol_13w.rolling(5, min_periods=1).mean()
            build_weeks = 0
            for i in range(len(pct_13w)):
                if pct_13w.iloc[i] > 8 and vol_13w.iloc[i] > vol_ma5_13w.iloc[i] * 1.5:
                    build_weeks += 1
            
            # 8. 筹码集中度
            recent60 = df.tail(60).copy()
            recent60['amt'] = recent60['close'] * recent60['vol']
            total_amt = recent60['amt'].sum()
            if total_amt > 0:
                s = recent60.sort_values('close')
                s['cum'] = s['amt'].cumsum()
                try:
                    c5 = s.loc[s['cum'] >= total_amt * 0.05, 'close'].iloc[0]
                    c95 = s.loc[s['cum'] >= total_amt * 0.95, 'close'].iloc[0]
                    conc = (c95 - c5) / (c95 + c5) * 100
                    cost_mid = (c95 + c5) / 2
                except:
                    conc = 50
                    cost_mid = last_close
            else:
                conc = 50
                cost_mid = last_close
            
            # 9. 控盘
            ma45 = c.rolling(45, min_periods=1).mean()
            ma90 = c.rolling(90, min_periods=1).mean()
            ma30 = c.rolling(30, min_periods=1).mean()
            ma60w = c.rolling(60, min_periods=1).mean()
            ma20w = c.rolling(20, min_periods=1).mean()
            inst_control = bool(last_close > max(ma45.iloc[-1], ma90.iloc[-1]))
            main_lock = bool(last_close > max(ma30.iloc[-1], ma60w.iloc[-1]))
            long_backbone = bool(inst_control and main_lock)
            c_above_ma20 = bool(last_close >= ma20w.iloc[-1])
            c_above_ma60 = bool(last_close > ma60w.iloc[-1])
            
            # 10. 花神红
            ema3 = c.ewm(span=3, adjust=False).mean()
            ema7 = c.ewm(span=7, adjust=False).mean()
            huashen_red = bool(ema3.iloc[-1] > ema7.iloc[-1])
            
            # 11. 量能递增
            vol_ma5 = v.rolling(5, min_periods=1).mean()
            vol_moderate = bool(v.iloc[-1] > vol_ma5.iloc[-1] and v.iloc[-1] < vol_ma5.iloc[-1] * 3)
            
            # 12. 均线多头
            ma5 = c.rolling(5, min_periods=1).mean()
            ma10 = c.rolling(10, min_periods=1).mean()
            ma_bull = bool(last_close > ma20w.iloc[-1] and ma5.iloc[-1] > ma10.iloc[-1])
            
            # 13. 相对价位
            llv20 = l.rolling(20, min_periods=1).min()
            hhv20 = h.rolling(20, min_periods=1).max()
            rel_pos = ((last_close - llv20.iloc[-1]) / (hhv20.iloc[-1] - llv20.iloc[-1] + 0.0001)) * 100
            rel_pos_series = ((c - llv20) / (hhv20 - llv20 + 0.0001) * 100)
            
            # 个股趋势
            llv60 = l.rolling(60, min_periods=1).min()
            hhv60 = h.rolling(60, min_periods=1).max()
            ind_trend = ((c - llv60) / (hhv60 - llv60 + 0.0001) * 100).ewm(span=3, adjust=False).mean()
            retail_mom = rel_pos_series.rolling(6, min_periods=1).mean()
            trend_golden = bool(ind_trend.iloc[-1] > retail_mom.iloc[-1] and 
                                ind_trend.shift(1).iloc[-1] <= retail_mom.shift(1).iloc[-1])
            
            # 14. 形态过滤
            body = abs(last_close - o.iloc[-1])
            shadow_up = h.iloc[-1] - max(last_close, o.iloc[-1])
            candle_range = h.iloc[-1] - l.iloc[-1]
            no_long_upper = bool(shadow_up / (candle_range + 0.0001) < 0.4)
            body_dominant = bool(body > candle_range * 0.5)
            
            # 15. RPS周线
            ret_50w = (last_close / c.iloc[-50] - 1) * 100 if len(c) >= 50 else 0
            ret_120w = (last_close / c.iloc[-120] - 1) * 100 if len(c) >= 120 else 0
            
            results[code] = {
                'weekly_macd_golden': 1 if macd_golden else 0,
                'weekly_macd_dif_above_dea': 1 if macd_dif_above_dea else 0,
                'weekly_macd_dif': round(float(dif.iloc[-1]), 3),
                'weekly_macd_dea': round(float(dea.iloc[-1]), 3),
                'weekly_macd_hist': round(float(macd.iloc[-1]), 3),
                'weekly_kdj_k': round(float(k.iloc[-1]), 1),
                'weekly_kdj_d': round(float(d.iloc[-1]), 1),
                'weekly_kdj_bull': 1 if kdj_bull else 0,
                'weekly_avg_line': round(float(avg_line.iloc[-1]), 2),
                'weekly_avg_turning': 1 if avg_turning else 0,
                'weekly_non_high': 1 if avg_line.iloc[-1] < 2.5 else 0,
                'weekly_wave': round(float(wave.iloc[-1]), 2),
                'weekly_dif_z': round(float(dif_z.iloc[-1]), 3),
                'weekly_core_trend': round(float(core_trend.iloc[-1]), 1),
                'weekly_core_trend_low': 1 if core_trend.iloc[-1] < 45 else 0,
                'weekly_vol_oscillation': round(float(vol_oscillation.iloc[-1]), 1),
                'weekly_vol_freeze': 1 if vol_freeze else 0,
                'weekly_atr14': round(float(atr14.iloc[-1]), 2),
                'weekly_atr_rising': 1 if atr_rising else 0,
                'weekly_winner_pct': round(float(winner_pct), 1),
                'weekly_winner_safe': 1 if winner_pct > 35 else 0,
                'weekly_strategic_build': 1 if build_weeks > 0 else 0,
                'weekly_strategic_build_weeks': build_weeks,
                'weekly_cost_concentration': round(float(conc), 1),
                'weekly_cost_conc_safe': 1 if conc < 30 else 0,
                'weekly_cost_mid': round(float(cost_mid), 2),
                'weekly_inst_control': 1 if inst_control else 0,
                'weekly_main_lock': 1 if main_lock else 0,
                'weekly_long_backbone': 1 if long_backbone else 0,
                'weekly_c_above_ma20': 1 if c_above_ma20 else 0,
                'weekly_c_above_ma60': 1 if c_above_ma60 else 0,
                'weekly_huashen_red': 1 if huashen_red else 0,
                'weekly_vol_moderate': 1 if vol_moderate else 0,
                'weekly_vol_ratio': round(float(v.iloc[-1] / (vol_ma5.iloc[-1] + 0.0001)), 2),
                'weekly_ma_bull': 1 if ma_bull else 0,
                'weekly_relative_position': round(float(rel_pos), 1),
                'weekly_individual_trend': round(float(ind_trend.iloc[-1]), 1),
                'weekly_individual_trend_low': 1 if ind_trend.iloc[-1] < 45 else 0,
                'weekly_retail_momentum': round(float(retail_mom.iloc[-1]), 1),
                'weekly_trend_golden': 1 if trend_golden else 0,
                'weekly_no_long_upper_shadow': 1 if no_long_upper else 0,
                'weekly_body_dominant': 1 if body_dominant else 0,
                'weekly_rps_50': round(float(ret_50w), 1),
                'weekly_rps_120': round(float(ret_120w), 1),
                # 周线R0资金流
                'weekly_r0': weekly_r0,
                'weekly_r0_ma5': weekly_r0_ma5,
                'weekly_main_in_signal': 1 if weekly_main_in_signal else 0,
                'weekly_r0_ma5_cross': 1 if weekly_r0_ma5_cross else 0,
            }
            
        except Exception as e:
            results[code] = {'_error': str(e)}
    return results


# ════════════════════════════════════════════
# 日线公式因子（7个公式）
# ════════════════════════════════════════════

def calc_daily_formula_factors(codes_list):
    """计算日线7个选股公式所需的全部因子"""
    import tushare as ts
    pro = ts.pro_api(get_tushare_token())
    results = {}
    
    for code_7 in codes_list:
        code = normalize(code_7)
        if not code or len(code) != 6:
            continue
        ts_code = to_ts_code(code)
        try:
            end = datetime.now().strftime('%Y%m%d')
            start = (datetime.now() - timedelta(days=400)).strftime('%Y%m%d')
            df = pro.daily(ts_code=ts_code, start_date=start, end_date=end)
            if df is None or df.empty or len(df) < 60:
                results[code] = {'_error': '数据不足'}
                continue
            df = df.sort_values('trade_date').reset_index(drop=True).copy()
            for col in ['open', 'high', 'low', 'close', 'vol', 'amount', 'pct_chg']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            df = df.dropna(subset=['close', 'open', 'high', 'low', 'vol'])
            if len(df) < 60:
                results[code] = {'_error': '清洗后数据不足'}
                continue
            
            c = df['close']
            o = df['open']
            h = df['high']
            l = df['low']
            v = df['vol']
            last_close = c.iloc[-1]
            
            # 1. QX均线矩阵
            ma5 = c.rolling(5, min_periods=1).mean()
            ma13 = c.rolling(13, min_periods=1).mean()
            ma21 = c.rolling(21, min_periods=1).mean()
            ma34 = c.rolling(34, min_periods=1).mean()
            ma55 = c.rolling(55, min_periods=1).mean()
            ma89 = c.rolling(89, min_periods=1).mean()
            ma144 = c.rolling(144, min_periods=1).mean()
            ma233 = c.rolling(233, min_periods=1).mean()
            qx = (sum([last_close > ma5.iloc[-1], last_close > ma13.iloc[-1],
                       last_close > ma21.iloc[-1], last_close > ma34.iloc[-1],
                       last_close > ma55.iloc[-1], last_close > ma89.iloc[-1],
                       last_close > ma144.iloc[-1], last_close > ma233.iloc[-1]]) - 3.8)
            
            # 2. 四层均线
            mid = (3*c + l + o + h) / 6
            nx_20 = mid.rolling(20, min_periods=1).mean()
            retail_red = bool(last_close > nx_20.iloc[-1])
            spec_red = bool(last_close >= max(c.rolling(60, min_periods=1).mean().iloc[-1],
                                               c.rolling(120, min_periods=1).mean().iloc[-1]))
            inst_red = bool(last_close > max(c.rolling(45, min_periods=1).mean().iloc[-1],
                                              c.rolling(90, min_periods=1).mean().iloc[-1]))
            main_red = bool(last_close > max(c.rolling(30, min_periods=1).mean().iloc[-1],
                                              c.rolling(60, min_periods=1).mean().iloc[-1]))
            four_layer_all = bool(retail_red and spec_red and inst_red and main_red)
            
            # 3. 主力进
            vol_ma5 = v.rolling(5, min_periods=1).mean()
            vv = v / (vol_ma5 + 0.0001)
            r0 = ((c - c.shift(1)) / (c.shift(1) + 0.0001) * 100) * vv
            r0_sum = r0.abs().rolling(5, min_periods=1).sum()
            llv10 = l.rolling(10, min_periods=1).min()
            hhv25 = h.rolling(25, min_periods=1).max()
            wave_d = ((c - llv10) / (hhv25 - llv10 + 0.0001) * 4).ewm(span=4, adjust=False).mean()
            avg_d = wave_d.ewm(span=3, adjust=False).mean()
            main_in = bool((r0.iloc[-1] > r0_sum.iloc[-1] / 2) and
                           (avg_d.iloc[-1] >= avg_d.shift(1).iloc[-1]) and
                           (avg_d.shift(1).iloc[-1] < avg_d.shift(2).iloc[-1]))
            
            # 4. DCZ
            recent60 = df.tail(60).copy()
            recent60['amt'] = recent60['close'] * recent60['vol']
            total_amt = recent60['amt'].sum()
            if total_amt > 0:
                s = recent60.sort_values('close')
                s['cum'] = s['amt'].cumsum()
                try:
                    dcz = s.loc[s['cum'] >= total_amt * 0.5, 'close'].iloc[0]
                except:
                    dcz = last_close
            else:
                dcz = last_close
            dcz_up = bool(dcz > c.shift(5).iloc[-1] if len(c) > 5 else True)
            
            # 5. 大盘多头
            try:
                idx_df = pro.index_daily(ts_code='000001.SH', start_date=start, end_date=end)
                if idx_df is not None and not idx_df.empty:
                    idx_df = idx_df.sort_values('trade_date').reset_index(drop=True)
                    idx_c = pd.to_numeric(idx_df['close'], errors='coerce')
                    idx_ma60 = idx_c.rolling(60, min_periods=1).mean()
                    market_bull = bool(idx_c.iloc[-1] > idx_ma60.iloc[-1] and
                                       idx_ma60.iloc[-1] > idx_ma60.shift(5).iloc[-1])
                else:
                    market_bull = True
            except:
                market_bull = True
            
            # 6. 资金攻击
            chg_1d = (last_close / c.shift(1).iloc[-1] - 1) * 100
            body_pct = (last_close - o.iloc[-1]) / (o.iloc[-1] + 0.0001) * 100
            ma20d = c.rolling(20, min_periods=1).mean()
            ma20_up = bool(ma20d.iloc[-1] > ma20d.shift(1).iloc[-1])
            vol_up = bool(v.iloc[-1] > vol_ma5.iloc[-1] * 1.5)
            capital_attack = bool(chg_1d > 5 and body_pct > 4 and dcz_up and
                                  ma20_up and last_close > ma20d.iloc[-1] and vol_up)
            
            # 7. 必涨
            hxjz = ((2*c + h + l) / 4).rolling(5, min_periods=1).mean()
            bztd = hxjz * 89 / 100
            must_rise = bool(l.iloc[-1] <= bztd.iloc[-1] and c.iloc[-1] > bztd.iloc[-1] and
                             (c.shift(1).iloc[-1] <= bztd.shift(1).iloc[-1] if len(bztd) > 1 else False))
            
            # 8. 花神红
            ema3 = c.ewm(span=3, adjust=False).mean()
            ema7 = c.ewm(span=7, adjust=False).mean()
            huashen_red = bool(ema3.iloc[-1] > ema7.iloc[-1])
            
            # 9. RPS
            ret_50d = (last_close / c.iloc[-50] - 1) * 100 if len(c) >= 50 else 0
            ret_120d = (last_close / c.iloc[-120] - 1) * 100 if len(c) >= 120 else 0
            ret_250d = (last_close / c.iloc[-250] - 1) * 100 if len(c) >= 250 else 0
            rps_strong = bool(ret_50d >= 90 or ret_120d >= 90 or ret_250d >= 90)
            
            # 10. 口袋支点
            vol_ma10 = v.rolling(10, min_periods=1).mean()
            vol_2x = bool(v.iloc[-1] > vol_ma10.iloc[-1] * 2)
            is_yang = bool(last_close > o.iloc[-1])
            ma10d = c.rolling(10, min_periods=1).mean()
            ma50d = c.rolling(50, min_periods=1).mean()
            ma_bull_arrange = bool(ma5.iloc[-1] > ma10d.iloc[-1] and
                                   ma10d.iloc[-1] > ma20d.iloc[-1] and
                                   ma20d.iloc[-1] > ma50d.iloc[-1])
            c_above_ma20d = bool(last_close > ma20d.iloc[-1])
            
            # 11. 相对价位
            llv20d = l.rolling(20, min_periods=1).min()
            hhv20d = h.rolling(20, min_periods=1).max()
            rel_pos_d = ((last_close - llv20d.iloc[-1]) / (hhv20d.iloc[-1] - llv20d.iloc[-1] + 0.0001)) * 100
            rel_pos_series_d = ((c - llv20d) / (hhv20d - llv20d + 0.0001) * 100)
            llv60d = l.rolling(60, min_periods=1).min()
            hhv60d = h.rolling(60, min_periods=1).max()
            ind_trend_d = ((c - llv60d) / (hhv60d - llv60d + 0.0001) * 100).ewm(span=3, adjust=False).mean()
            retail_mom_d = rel_pos_series_d.rolling(6, min_periods=1).mean()
            trend_golden_d = bool(ind_trend_d.iloc[-1] > retail_mom_d.iloc[-1] and
                                  ind_trend_d.shift(1).iloc[-1] <= retail_mom_d.shift(1).iloc[-1])
            ind_trend_low_d = bool(ind_trend_d.iloc[-1] < 35)
            half_year_low = bool(ret_120d < 25)
            
            # 12. 换手率
            turnover = v.iloc[-1] / (v.rolling(250, min_periods=1).mean().iloc[-1] + 0.0001)
            
            # 13. 强势主线
            strong_main = bool(ret_50d > 5 or ret_120d > 8)
            
            # 14. 黄线上行
            yellow_rising = False  # 简化
            
            # 15. 动态量比
            dynamic_vol = v.iloc[-1] / (vol_ma5.iloc[-1] + 0.0001)
            
            results[code] = {
                'daily_qx': round(float(qx), 1),
                'daily_qx_bull': 1 if qx > 0 else 0,
                'daily_four_layer_all_red': 1 if four_layer_all else 0,
                'daily_retail_red': 1 if retail_red else 0,
                'daily_spec_red': 1 if spec_red else 0,
                'daily_inst_red': 1 if inst_red else 0,
                'daily_main_red': 1 if main_red else 0,
                'daily_main_in': 1 if main_in else 0,
                'daily_r0': round(float(r0.iloc[-1]), 2),
                'daily_avg_line': round(float(avg_d.iloc[-1]), 2),
                'daily_avg_not_overbought': 1 if avg_d.iloc[-1] < 2.5 else 0,
                'daily_dcz': round(float(dcz), 2),
                'daily_dcz_up': 1 if dcz_up else 0,
                'daily_c_above_dcz': 1 if last_close >= dcz else 0,
                'daily_market_bull': 1 if market_bull else 0,
                'daily_capital_attack': 1 if capital_attack else 0,
                'daily_must_rise': 1 if must_rise else 0,
                'daily_huashen_red': 1 if huashen_red else 0,
                'daily_rps_50': round(float(ret_50d), 1),
                'daily_rps_120': round(float(ret_120d), 1),
                'daily_rps_250': round(float(ret_250d), 1),
                'daily_rps_strong': 1 if rps_strong else 0,
                'daily_vol_2x': 1 if vol_2x else 0,
                'daily_is_yang': 1 if is_yang else 0,
                'daily_ma_bull_arrange': 1 if ma_bull_arrange else 0,
                'daily_c_above_ma20': 1 if c_above_ma20d else 0,
                'daily_relative_position': round(float(rel_pos_d), 1),
                'daily_ind_trend': round(float(ind_trend_d.iloc[-1]), 1),
                'daily_ind_trend_low': 1 if ind_trend_low_d else 0,
                'daily_retail_momentum': round(float(retail_mom_d.iloc[-1]), 1),
                'daily_trend_golden': 1 if trend_golden_d else 0,
                'daily_half_year_low': 1 if half_year_low else 0,
                'daily_turnover_ratio': round(float(turnover), 2),
                'daily_strong_main': 1 if strong_main else 0,
                'daily_ret_50': round(float(ret_50d), 1),
                'daily_ret_120': round(float(ret_120d), 1),
                'daily_dynamic_vol_ratio': round(float(dynamic_vol), 2),
                'daily_yellow_rising': 0,
            }
            
        except Exception as e:
            results[code] = {'_error': str(e)}
    return results


if __name__ == '__main__':
    test = ['1603339', '0301516']
    w = calc_weekly_formula_factors(test)
    for code, f in w.items():
        print(f'{code} 周线因子: {len(f)}个')
    d = calc_daily_formula_factors(test)
    for code, f in d.items():
        print(f'{code} 日线因子: {len(f)}个')
