import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))); from env_loader import get_tushare_token
"""
formula_evolver.py — 自适应公式进化引擎
预计算收益率矩阵，6代进化迭代，找到最优选股公式
"""
import sys, os, json, time, math, shutil
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from factor_utils import spearmanr_np, normalize
from formula_factors import calc_weekly_formula_factors, calc_daily_formula_factors
from self_driving_backtest import get_a_share_sample, push_tg

DATA_DIR = r'D:/Hermes/评估中心/tools/tdx_connector/zxsx_data'
os.makedirs(DATA_DIR, exist_ok=True)
LOG_FILE = os.path.join(DATA_DIR, 'evolver_log.txt')

def clear_log():
    open(LOG_FILE, 'w', encoding='utf-8').close()

def log(m):
    print(f'[{datetime.now().strftime("%H:%M:%S")}] {m}', flush=True)
    with open(LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f'[{datetime.now().strftime("%H:%M:%S")}] {m}\n')

# 全局变量（供compute_backtest访问）
_WF = None
_DF = None
_STOCK_RETURNS = None
_VALID_CODES = None

def load_data(max_codes=4259):
    """拉全市场因子+预计算所有股票的历史收益率矩阵"""
    global _WF, _DF, _STOCK_RETURNS, _VALID_CODES
    
    log('拉取全市场样本...')
    codes = get_a_share_sample(max_codes=max_codes)
    if not codes:
        log('[FAIL] 无样本')
        return False
    log(f'样本: {len(codes)} 只')
    
    log('周线因子计算...')
    t0 = time.time()
    _WF = calc_weekly_formula_factors(codes)
    log(f'  完成: {time.time()-t0:.0f}s, 有效:{sum(1 for f in _WF.values() if "_error" not in f)}/{len(codes)}')
    
    log('日线因子计算...')
    t0 = time.time()
    _DF = calc_daily_formula_factors(codes)
    log(f'  完成: {time.time()-t0:.0f}s, 有效:{sum(1 for f in _DF.values() if "_error" not in f)}/{len(codes)}')
    
    # 拉历史日K + 预计算1~30日收益率
    log('拉历史日K + 预计算收益率...')
    pro = __import__('tushare').pro_api(get_tushare_token())
    end = datetime.now().strftime('%Y%m%d')
    start = (datetime.now()-timedelta(days=180)).strftime('%Y%m%d')
    
    MAX_F = 30
    _STOCK_RETURNS = {}
    _VALID_CODES = []
    
    for i, c7 in enumerate(codes):
        if i % 200 == 0:
            log(f'  日线进度: {i}/{len(codes)}')
        c = normalize(c7)
        if not c or len(c)!=6: continue
        try:
            tsc = c+'.SH' if c[0] in '69' else c+'.SZ'
            d = pro.daily(ts_code=tsc, start_date=start, end_date=end)
            if d is None or d.empty or len(d)<MAX_F+1: continue
            d = d.sort_values('trade_date').reset_index(drop=True)
            closes = pd.to_numeric(d['close'], errors='coerce').values
            n_c = len(closes)
            n_wins = n_c - MAX_F
            if n_wins < 10: continue
            rets = {}
            for day in range(1, MAX_F+1):
                base = closes[:n_wins]
                fut = closes[day:n_wins+day]
                mask = (base > 0) & (fut > 0)
                rets[day] = (fut[mask] / base[mask] - 1) * 100
            _STOCK_RETURNS[c] = rets
            _VALID_CODES.append(c)
        except: pass
    
    log(f'日K有效+预计算完成: {len(_VALID_CODES)} 只')
    return True

def compute_backtest(rule_fn, max_f=30):
    """用预计算收益率矩阵回测单个规则"""
    sel_codes = []
    for c in _VALID_CODES:
        wf_d = _WF.get(c, {})
        df_d = _DF.get(c, {})
        if not wf_d or not df_d: continue
        if '_error' in wf_d or '_error' in df_d: continue
        if rule_fn(wf_d, df_d):
            sel_codes.append(c)
    
    def agg(codes_list):
        rets = {}
        for day in range(1, max_f+1):
            arrs = [_STOCK_RETURNS[c][day] for c in codes_list if c in _STOCK_RETURNS and day in _STOCK_RETURNS[c]]
            rets[day] = np.concatenate(arrs) if arrs else np.array([])
        return rets
    
    sr = agg(sel_codes)
    ur = agg([c for c in _VALID_CODES if c not in sel_codes])
    
    result = {
        'selected_n': len(sel_codes),
        'unselected_n': len(_VALID_CODES) - len(sel_codes),
        'selected_pct': round(len(sel_codes) / max(1, len(_VALID_CODES)) * 100, 2),
        'returns': {}
    }
    
    for d in range(1, max_f+1):
        s = sr.get(d, np.array([]))
        u = ur.get(d, np.array([]))
        if len(s) < 100 or len(u) < 100: continue
        result['returns'][d] = {
            'win_s': round(float(np.sum(s > 0) / len(s) * 100), 1),
            'win_u': round(float(np.sum(u > 0) / len(u) * 100), 1),
            'avg_s': round(float(np.mean(s)), 2),
            'avg_u': round(float(np.mean(u)), 2),
            'excess': round(float(np.mean(s) - np.mean(u)), 2),
        }
    
    return result

def build_rule(params):
    def rule_fn(wf_d, df_d):
        for prefix, key, op, t in params:
            src = wf_d if prefix == 'w' else df_d
            val = src.get(key, None)
            if val is None: return False
            if op == '>':
                if not (val > t): return False
            elif op == '<':
                if not (val < t): return False
            elif op == '==':
                if not (val == t): return False
        return True
    return rule_fn

def label_of(params):
    return ' + '.join([f'{p[0]}_{p[1]}{p[2]}{p[3]}' for p in params])

def parse_params(label):
    params = []
    for part in label.split(' + '):
        def _try(v):
            try:
                return int(v)
            except:
                try:
                    return float(v)
                except:
                    return v
        if '>' in part:
            pk, t = part.split('>')
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '>', _try(t)))
        elif '<' in part:
            pk, t = part.split('<')
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '<', _try(t)))
        elif '==' in part:
            pk, t = part.split('==')
            params.append(('w' if pk.startswith('w_') else 'd', pk[2:], '==', _try(t)))
    return params

def eval_and_log(rule_fn, label, gen_prefix='C'):
    r = compute_backtest(rule_fn)
    r30 = r['returns'].get(30, {})
    r10 = r['returns'].get(10, {})
    log(f'  {label}: 选出{r["selected_n"]}({r["selected_pct"]:.1f}%) 30日超额={r30.get("excess","+0.00")}% 胜率={r30.get("win_s","-")}% 10日={r10.get("excess","+0.00")}%')
    return r

def run_evolver(max_iterations=6):
    clear_log()
    log('=' * 60)
    log('自适应公式进化引擎')
    log(f'启动: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    log(f'迭代: {max_iterations}代')
    log('=' * 60)
    
    if not load_data(max_codes=4259):
        return
    
    today = datetime.now().strftime('%Y%m%d')
    core_factors = [
        ('w', 'rps_50', 'gt', [40, 50, 55, 60, 65, 70]),
        ('w', 'macd_golden', 'eq', [1]),
        ('w', 'macd_dif_above_dea', 'eq', [1]),
        ('w', 'individual_trend', 'gt', [50, 55, 60]),
        ('w', 'core_trend_low', 'lt', [30, 35, 40]),
        ('w', 'c_above_ma60', 'eq', [1]),
        ('w', 'winner_safe', 'gt', [30, 40, 50]),
        ('w', 'inst_control', 'eq', [1]),
        ('w', 'four_vol_main_ratio', 'gt', [0.50, 0.55, 0.60, 0.65]),
        ('d', 'rps_120', 'gt', [40, 50, 55, 60, 65, 70]),
        ('d', 'rps_250', 'gt', [40, 50, 55, 60]),
        ('d', 'rps_50', 'gt', [40, 50, 55, 60]),
        ('d', 'dcz_up', 'eq', [0]),
        ('d', 'strong_main', 'eq', [1]),
        ('d', 'rps_strong', 'eq', [1]),
        ('d', 'half_year_low', 'eq', [1]),
        ('w', 'r0_ma5_cross', 'eq', [1]),
        ('w', 'main_in_signal', 'eq', [1]),
        ('w', 'retail_momentum', 'gt', [50, 55, 60]),
        ('w', 'ind_trend_low', 'lt', [30, 35]),
    ]
    
    import random as _random
    _random.seed(42)
    
    # 种子：从前次combo测试已知有效的组合开始
    seeds = [
        [('d', 'rps_120', '>', 55), ('d', 'dcz_up', '==', 0)],       # R2 冠军
        [('w', 'four_vol_main_ratio', '>', 0.60), ('w', 'rps_50', '>', 55), ('w', 'macd_dif_above_dea', '==', 1)],  # R4
        [('w', 'rps_50', '>', 50), ('w', 'macd_golden', '==', 1)],     # R5
        [('d', 'rps_250', '>', 60), ('d', 'dcz_up', '==', 0)],
        [('w', 'rps_50', '>', 60), ('d', 'rps_120', '>', 60)],
        [('w', 'individual_trend', '>', 55), ('d', 'dcz_up', '==', 0)],
        [('w', 'macd_dif_above_dea', '==', 1), ('d', 'dcz_up', '==', 0)],
        [('w', 'c_above_ma60', '==', 1), ('d', 'rps_120', '>', 60)],
        [('w', 'four_vol_main_ratio', '>', 0.60), ('d', 'rps_120', '>', 60)],
        [('w', 'retail_momentum', '>', 55), ('d', 'dcz_up', '==', 0)],
    ]
    
    all_best = {}
    
    # Generation 0: 种子规则 + 随机采样
    log('\n[Generation 0] 种子+随机采样...')
    
    # 先跑种子
    for i, params in enumerate(seeds):
        label = label_of(params)
        r = eval_and_log(build_rule(params), f'G0_SEED{i}', 'G0')
        all_best[f'G0_SEED_{label}'] = r
    
    # 随机采样（偏向2因子）
    for i in range(30):
        n = _random.choices([2, 3, 4], weights=[0.7, 0.25, 0.05])[0]  # 70%是2因子
        chosen = _random.sample(core_factors, n)
        params = []
        for prefix, key, op, thresholds in chosen:
            t = _random.choice(thresholds)
            if op == 'gt':
                params.append((prefix, key, '>', t))
            elif op == 'lt':
                params.append((prefix, key, '<', t))
            else:
                params.append((prefix, key, '==', t))
        label = label_of(params)
        r = eval_and_log(build_rule(params), f'G0_R{i}', 'G0')
        all_best[f'G0_R{i}_{label}'] = r
    
    ranked = sorted(all_best.items(), key=lambda x: x[1]['returns'].get(30, {}).get('excess', 0), reverse=True)
    # 过滤选出>0的规则
    ranked_with_results = [(l, d) for l, d in ranked if d['selected_n'] > 0]
    top5 = ranked_with_results[:5] if ranked_with_results else ranked[:5]
    log(f'G0 TOP1: {top5[0][0]} excess={top5[0][1]["returns"].get(30,{}).get("excess","+0.00")}% selected={top5[0][1]["selected_n"]}')
    
    best_ever = top5[0][1]['returns'].get(30, {}).get('excess', 0)
    
    # Generation 1~N: 进化
    for gen in range(1, max_iterations + 1):
        log(f'\n{"="*40}\n[Generation {gen}]')
        all_best = {}
        
        for pidx, (plabel, _presult) in enumerate(top5):
            parent_params = parse_params(plabel)
            if not parent_params: continue
            
            # 变异1: 调一个阈值
            for fidx in range(len(parent_params)):
                new = [list(p) for p in parent_params]
                prefix, key, op, t = new[fidx]
                fi = next((f for f in core_factors if f[0]==prefix and f[1]==key), None)
                if fi:
                    tl = fi[3]
                    t_idx = tl.index(t) if t in tl else 0
                    new_t = tl[(t_idx + (1 if _random.random() > 0.5 else -1)) % len(tl)]
                    new[fidx][3] = new_t
                    new = [tuple(p) for p in new]
                    l = label_of(new)
                    r = eval_and_log(build_rule(new), f'G{gen}_M{pidx}_{fidx}', f'G{gen}')
                    all_best[f'G{gen}_{l}'] = r
                    if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                        best_ever = r['returns'].get(30, {}).get('excess', 0)
                        log(f'  ★ NEW BEST! excess={best_ever:+.2f}%')
            
            # 变异2: 加一个条件
            new = parent_params.copy()
            extra = _random.choice(core_factors)
            ef, ek, eop, eth = extra
            t = _random.choice(eth)
            new.append((ef, ek, '==' if eop=='eq' else ('>' if eop=='gt' else '<'), t))
            l = label_of(new)
            r = eval_and_log(build_rule(new), f'G{gen}_A{pidx}', f'G{gen}')
            all_best[f'G{gen}_ADD_{l}'] = r
            if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                best_ever = r['returns'].get(30, {}).get('excess', 0)
                log(f'  ★ NEW BEST! excess={best_ever:+.2f}%')
            
            # 变异3: 删一个条件
            if len(parent_params) >= 3:
                ridx = _random.randint(0, len(parent_params)-1)
                new = parent_params[:ridx] + parent_params[ridx+1:]
                l = label_of(new)
                r = eval_and_log(build_rule(new), f'G{gen}_D{pidx}', f'G{gen}')
                all_best[f'G{gen}_DEL_{l}'] = r
                if r['returns'].get(30, {}).get('excess', 0) > best_ever:
                    best_ever = r['returns'].get(30, {}).get('excess', 0)
                    log(f'  ★ NEW BEST! excess={best_ever:+.2f}%')
        
        ranked = sorted(all_best.items(), key=lambda x: x[1]['returns'].get(30, {}).get('excess', 0), reverse=True)
        ranked_with_results = [(l, d) for l, d in ranked if d['selected_n'] > 0]
        top5 = ranked_with_results[:5] if ranked_with_results else ranked[:5]
        log(f'G{gen} TOP1: {top5[0][0]} excess={top5[0][1]["returns"].get(30,{}).get("excess","+0.00")}% selected={top5[0][1]["selected_n"]}')
    
    # 最终报告
    log('\n' + '='*60)
    log(f'进化完成！最优公式（30日超额收益排名）')
    log('='*60)
    
    lines = []
    lines.append(f'# 自适应公式进化报告 {today}')
    lines.append('')
    lines.append(f'全市场4259只 | 周线+日线因子 | 历史30日回测')
    lines.append(f'进化代数: {max_iterations}代')
    lines.append('')
    lines.append('## 最优公式TOP10')
    lines.append('')
    
    for rank, (label, data) in enumerate(ranked[:10], 1):
        r30 = data['returns'].get(30, {})
        r10 = data['returns'].get(10, {})
        r5 = data['returns'].get(5, {})
        r1 = data['returns'].get(1, {})
        lines.append(f'#{rank} {label}')
        lines.append(f'  选出率: {data["selected_pct"]:.1f}% | 30日超额: **{r30.get("excess","+0.00")}%** | 10日: {r10.get("excess","+0.00")}% | 5日: {r5.get("excess","+0.00")}% | 1日: {r1.get("excess","+0.00")}%')
        lines.append(f'  30日胜率: {r30.get("win_s","-")}% (选中) vs {r30.get("win_u","-")}% (大盘) | 平均: {r30.get("avg_s","-")}%(选中) vs {r30.get("avg_u","-")}%(大盘)')
        lines.append('')
    
    report = '\n'.join(lines)
    log('\n' + report)
    
    # 保存
    best_path = os.path.join(DATA_DIR, 'evolver_best.json')
    json.dump({'top10': [(l, d) for l, d in ranked[:10]], 'best_ever': best_ever, 'today': today},
              open(best_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    report_path = os.path.join(DATA_DIR, f'evolver_report_{today}.txt')
    open(report_path, 'w', encoding='utf-8').write(report)
    log(f'\n报告: {report_path}')
    log('推送TG...')
    push_tg(report)
    log('完成')

if __name__ == '__main__':
    run_evolver(max_iterations=6)
