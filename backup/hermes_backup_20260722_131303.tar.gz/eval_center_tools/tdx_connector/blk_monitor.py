#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通达信 blk 文件监控脚本 — 只读，不修改通达信任何文件

工作流程：
1. 读取 D:\\\\TDX\\\\T0002\\\\blocknew\\\\ 下的 blk 文件
2. 解析股票代码
3. 去重检查（tracked_YYYYMMDD.json）
4. 对新代码调用评估中心
5. 推送 Telegram

轮询间隔：盘中 2 分钟，其他时段 10 分钟，非交易时间暂停
"""

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os
import json
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from env_loader import get_telegram_token, get_chat_id, get_proxy

# === 配置 ===
TDX_BLK_DIR = Path(r"D:\TDX\T0002\blocknew")
# 只监用户通达信「盘中预警」板块，不读其他预警
MONITOR_FILES = ["PZYJ.blk"]  # 盘中预警板块
TRACKED_DIR = Path(__file__).parent  # tracked_YYYYMMDD.json 存储位置
EVAL_SCRIPT = Path(r"D:\Hermes\评估中心\tools\eval_smart.py")
PYTHON_PATH = "C:\\Python314\\python.exe"
QUEUE_DIR = Path(__file__).parent / "telegram_queue"

# === 去重文件操作 ===
def get_tracked_file() -> Path:
    """获取当天去重文件路径"""
    today = datetime.now().strftime("%Y%m%d")
    return TRACKED_DIR / f"tracked_{today}.json"

def load_tracked() -> dict:
    """加载去重记录"""
    tracked_file = get_tracked_file()
    if tracked_file.exists():
        try:
            with open(tracked_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            print(f"[WARN] 去重文件读取失败 {tracked_file}: {e}，回退空记录")
            return {}
    return {}

def save_tracked(tracked: dict):
    """保存去重记录"""
    tracked_file = get_tracked_file()
    with open(tracked_file, "w", encoding="utf-8") as f:
        json.dump(tracked, f, ensure_ascii=False, indent=2)

def is_already_tracked(code: str, tracked: dict) -> bool:
    """检查股票是否已追踪 — 兼容7位/6位代码"""
    # 7位代码去首位（市场标识），6位直接用
    norm = code[1:] if len(code)==7 and code[0] in "012" else code
    return norm in tracked

def mark_tracked(code: str, tracked: dict, condition: str):
    """标记股票为已追踪 — 统一存6位纯代码"""
    norm = code[1:] if len(code)==7 and code[0] in "012" else code
    tracked[norm] = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "condition": condition,
        "status": "analyzed"
    }
    save_tracked(tracked)

# === blk 文件解析 ===
def parse_blk_file(blk_path: Path) -> list:
    """解析 blk 文件，返回股票代码列表"""
    if not blk_path.exists():
        return []
    
    try:
        content = blk_path.read_text(encoding="gbk", errors="ignore").strip()
        if not content:
            return []
        # 通达信 blk 同时含 6 位和 7 位代码（首位=市场标识），都读取
        # 用通用换行分割，兼容 LF 和 CRLF
        codes = [line.strip() for line in content.splitlines() if line.strip() and len(line.strip()) in (6, 7)]
        return codes
    except Exception as e:
        print(f"[WARN] 解析 blk 文件失败 {blk_path}: {e}")
        return []

def get_all_codes() -> list:
    """获取所有 blk 文件中的股票代码（去重）"""
    all_codes = set()
    for fname in MONITOR_FILES:
        blk_path = TDX_BLK_DIR / fname
        codes = parse_blk_file(blk_path)
        all_codes.update(codes)
    return sorted(all_codes)

def get_condition_name(blk_path: Path) -> str:
    """根据 blk 文件名获取条件名称"""
    return blk_path.stem


# ═══════════════════════════════════════════════════
#  快速行情（~0.5s，不调用 eval_smart）
# ═══════════════════════════════════════════════════
def get_fast_quote(code: str) -> dict | None:
    """腾讯行情快速查询 — 0.5s 内返回基本数据"""
    try:
        # 6位纯代码 → 加交易所前缀
        import sys as _sys
        _sys.path.insert(0, str(Path(__file__).parent.parent))
        from astock_bridge import tencent_quote
        q = tencent_quote([code])
        if not q or code not in q:
            return None
        d = q[code]
        return {
            "name": d.get("name", ""),
            "code": code,
            "price": d.get("price", 0),
            "change_pct": d.get("change_pct", 0),
            "turnover_rate": d.get("turnover_pct", 0),
            "volume_ratio": d.get("vol_ratio", 0),
            "amplitude": d.get("amplitude_pct", 0),
            "pe_ttm": d.get("pe_ttm"),
            "pb": d.get("pb"),
            "limit_up": d.get("limit_up"),
            "limit_down": d.get("limit_down"),
        }
    except Exception as e:
        print(f"[WARN] 快速行情失败 {code}: {e}")
        return None


def _classify_signal(change_pct, volume_ratio, turnover_rate, amplitude):
    """根据量价信号分类"""
    if amplitude >= 9:
        return "🚀 大阳线/跌停风险"
    if change_pct >= 5 and volume_ratio >= 1.5:
        return "🟢 放量突破"
    if change_pct >= 2 and volume_ratio >= 1.2:
        return "🟡 温和放量"
    if change_pct >= 2 and volume_ratio < 0.8:
        return "⚪ 缩量上涨"
    if change_pct < -5:
        return "🔴 放量下跌"
    if change_pct < 0 and volume_ratio < 0.8:
        return "⚪ 缩量调整"
    if volume_ratio >= 2:
        return "⚡ 放量异动"
    return "⚪ 横盘整理"


def send_fast_tg(code: str, data: dict):
    """快速预警推送 — 只包含量价信号，3秒内发出"""
    import re as _re
    name = data.get("name", "")
    price = data.get("price", 0)
    change = data.get("change_pct", 0)
    vol_ratio = data.get("volume_ratio", 0)
    turnover = data.get("turnover_rate", 0)
    amp = data.get("amplitude", 0)
    pe = data.get("pe_ttm")
    pb = data.get("pb")
    limit_up = data.get("limit_up")
    limit_down = data.get("limit_down")

    # 信号分类
    signal = _classify_signal(change, vol_ratio, turnover, amp)

    # 情绪判断
    if change >= 5:
        emotion = "🟢 强势"
    elif change >= 0:
        emotion = "⚪ 偏强"
    else:
        emotion = "🔴 偏弱"

    # 构建消息
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    msg_lines = [
        f"# 🚨 盘中预警 — {name}(`{code}`) {ts}",
        f"",
        f"━━━━━━━━━━━━━━━━━━━━━━",
        f"",
        f"**¥{price:.2f} {change:+.2f}%** 振幅{amp:.1f}% 换手{turnover:.1f}% 量比{vol_ratio:.2f}",
        f"",
        f"📊 **信号**: {signal}",
        f"📈 **情绪**: {emotion}",
        f"",
        f"━━ 关键价 ━━",
        f"  涨停 ¥{limit_up:.2f}  跌停 ¥{limit_down:.2f}",
        f"",
        f"━━ 估值 ━━",
        f"  PE {pe:.1f}  PB {pb:.1f}" if pe and pb else "  PE/PB 暂无",
        f"",
        f"━━━━━━━━━━━━━━━━━━━━━━",
        f"",
        f"⚡ 快速预警（完整分析 16s 后补发）",
        f"",
    ]
    msg = "\n".join(msg_lines)
    try:
        _send_fast_tg_direct(msg)
        print(f"[PUSH] 快速预警已推送: {name}({code})")
    except Exception as e:
        # 退回到 queue 文件
        now = datetime.now().strftime("%H%M%S")
        msg_file = QUEUE_DIR / f"{code}_{now}.txt"
        msg_file.write_text(msg, encoding="utf-8")
        print(f"[PUSH] 退回到队列文件: {msg_file.name}")


def _send_fast_tg_direct(msg_text: str):
    """直接推 TG（不走 queue）"""
    import urllib.request, json as _json
    TOKEN = get_telegram_token()
    CHAT_ID = get_chat_id()
    PROXY = get_proxy()
    # get_proxy() 返回完整 URL 如 http://127.0.0.1:7890，ProxyHandler 需 host:port
    proxy_url = PROXY.replace("http://", "").replace("https://", "")
    handler = urllib.request.ProxyHandler({"http": f"http://{proxy_url}", "https": f"http://{proxy_url}"})
    opener = urllib.request.build_opener(handler)
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = _json.dumps({
        "chat_id": CHAT_ID, "text": msg_text,
        "parse_mode": "Markdown", "disable_web_page_preview": True,
    }).encode("utf-8")
    req = urllib.request.Request(url, data=data,
        headers={"Content-Type": "application/json"})
    resp = opener.open(req, timeout=20)
    result = _json.loads(resp.read())
    if not result.get("ok"):
        raise RuntimeError(f"TG API 拒绝: {result}")


def _async_eval(code: str):
    """异步启动完整 eval_smart（后台进程）"""
    import threading as _th
    def _run():
        try:
            result = run_eval(code)
            if not result or "[ERROR]" in result:
                return
            if "¥" not in result:
                return
            # 完整报告写入推送队列
            now = datetime.now().strftime("%H%M%S")
            full_file = QUEUE_DIR / f"{code}_full_{now}.txt"
            full_file.write_text(result, encoding="utf-8")
            print(f"[EVAL] 完整评估已写入: {full_file.name}")
            # 记录快照
            try:
                _record_snapshot(code, result)
            except Exception as e:
                print(f"[WARN] 快照记录失败: {e}")
        except Exception as e:
            print(f"[WARN] 异步评估失败 {code}: {e}")
    _th.Thread(target=_run, daemon=True).start()
    print(f"[EVAL] 异步评估已启动: {code}")


# === 评估中心调用 ===
def run_eval(code: str) -> str:
    """调用评估中心分析股票（传 --codes 参数）"""
    # 通达信 blk 7位代码：首位0=深市/1=沪市，需截取后6位传给评估
    if len(code) == 7 and code[0] in "01":
        code = code[1:]
    try:
        result = subprocess.run(
            [PYTHON_PATH, str(EVAL_SCRIPT), "--codes", code],
            capture_output=True,
            text=True,
            timeout=120,
        )
        out = result.stdout if result.returncode == 0 else result.stderr
        if "[ERROR]" in out or "Traceback" in out or "usage:" in out.lower():
            return f"[ERROR] 评估失败: {out[-300:]}"
        # eval_smart.py stdout 含进度日志，提取报告 md 路径并读回纯正文
        import re as _re
        m = _re.search(r"报告: (D:.+\.md)", out)
        if m:
            try:
                md_path = Path(m.group(1).strip())
                # 白名单校验：仅允许评估中心 reports 目录下的 md 文件
                allowed_root = Path(r"D:\Hermes\评估中心\reports")
                try:
                    md_path.resolve().relative_to(allowed_root.resolve())
                except ValueError:
                    return f"[ERROR] 评估报告路径越界: {md_path}"
                if md_path.exists():
                    return md_path.read_text(encoding="utf-8")
            except OSError as e:
                print(f"[WARN] 读取评估报告失败 {md_path}: {e}")
        return out
    except Exception as e:
        return f"[ERROR] 评估失败: {e}"

# === 主监控逻辑 ===
def check_and_notify():
    """检查 blk 文件并通知新预警"""
    import re as _re
    # 有效A股代码格式
    VALID_CODE_RE = _re.compile(r'^(6[01358]|00[0-9]|001|002|30[01])[0-9]{3}$')
    tracked = load_tracked()
    new_codes = []
    
    # 获取所有代码
    all_codes = get_all_codes()
    
    # 找出新代码
    for code in all_codes:
        if not is_already_tracked(code, tracked):
            new_codes.append(code)
    
    if not new_codes:
        print("[INFO] 无新预警")
        return
    
    # 处理新预警
    for code in new_codes:
        print(f"[ALERT] 新预警: {code}")
        
        # 6位纯代码（去市场标识）
        pure_code = code[1:] if len(code) == 7 and code[0] in "01" else code
        
        # ── 无效代码拦截：999999/880009等假代码 ──
        if not VALID_CODE_RE.match(pure_code):
            print(f"[SKIP] 无效代码 {pure_code}，跳过推送")
            continue
        
        # 标记为已追踪
        mark_tracked(code, tracked, "盘中预警")
        
        # ── 阶段1: 快速行情（~1s）──
        fast_summary = get_fast_quote(pure_code)
        if fast_summary and fast_summary.get("name"):
            send_fast_tg(pure_code, fast_summary)
        
        # ── 阶段2: 异步完整评估 ──
        _async_eval(pure_code)

def send_to_telegram(code: str, eval_result: str):
    """推送极简摘要到 Telegram（均线+资金净额+筹码数值+6维度）"""
    import re as _re

    def _gr(pattern, default=""):
        """从报告里按正则抽一行，取第一个匹配"""
        for line in eval_result.split("\n"):
            m = _re.search(pattern, line)
            if m:
                return m.group(1).strip()
        return default

    def _data_after(lines, keyword, skip=2):
        """取含 keyword 的表头后第 skip 行的数据行"""
        for i, l in enumerate(lines):
            if keyword in l and "|" in l:
                idx = i + skip
                if idx < len(lines) and "|" in lines[idx]:
                    return lines[idx]
        return None

    lines = eval_result.split("\n")

    # ── 空报告拦截：抽不到价格/评分=无效报告，不推送 ──
    price_test = _gr(r"现价\s*\|\s*¥([\d.]+)", "")
    has_score = any("综合评分" in l for l in lines)
    if not price_test or not has_score:
        print(f"[SKIP] {code} eval 报告缺价格/评分，跳过推送")
        return

    # ── 基础信息 ──
    name_m = _re.search(r"\*\*([\u4e00-\u9fff\w]{1,6})\*\*\s*\(\d{6}\.\w{2}\)", eval_result)
    name = name_m.group(1) if name_m else ""
    price = _gr(r"现价\s*\|\s*¥([\d.]+)", "")
    change = _gr(r"涨跌\s*\|\s*([+-]?[\d.]+%)", "")
    score = grade = ""
    for _line in lines:
        if "综合评分" in _line and "等级" in _line:
            score_m = _re.search(r"综合评分\s*\|\s*\*{0,2}([\d.]+)分", _line)
            if score_m:
                score = score_m.group(1)
            for m2 in _re.finditer(r"\*\*(.+?)\*\*", _line):
                if "分" not in m2.group(1):
                    grade = m2.group(1)
            break
    tech = _gr(r"\|\s*技术面\s*\|\s*(\d+)分\s*\|\s*资金面", "")
    capital = _gr(r"\|\s*资金面\s*\|\s*(\d+)分", "")
    sentiment = _gr(r"\|\s*情绪面\s*\|\s*(\d+)分", "")
    stop_loss = _gr(r"T\+1止损.*?¥([\d.]+)\(", "")
    target = _gr(r"目标价\s*\|\s*¥([\d.]+)\s*\|\s*盈亏比", "")
    chip_score = _gr(r"筹码面\s*\|\s*(\d+)分", "")

    # ── 均线形态（核心信号 + 趋势决策通道） ──
    # 核心信号含均线描述：远离20日线、5日偏强...
    core_signals = ""
    for _line in lines:
        if "**核心信号**:" in _line:
            m = _re.search(r"\*\*核心信号\*\*:\s*(.+)", _line)
            if m:
                core_signals = m.group(1).strip()
            break
    # 趋势决策通道：上穿上轨 等
    channel_pos = ""
    dl = _data_after(lines, "通道位置")
    if dl:
        m = _re.search(r"\|\s*[^|]+?\|\s*[^|]+\|\s*[^|]+\|\s*[^|]+\|\s*[^|]+\|\s*([^|]+?)\s*\|\s*(.+?)\s*\|", dl)
        if m:
            channel_pos = m.group(2).strip()

    # ── 资金净额（核心信号中的资金描述 + 环境共振） ──
    capital_flow = ""
    for s in core_signals.split("、"):
        if "资金" in s:
            capital_flow = s.strip()
            break
    # 用环境共振（大盘/行业多头）替代北向资金（太滞后）
    market_env = ""
    dl = _data_after(lines, "大盘多头")
    if dl:
        m = _re.search(
            r"\|\s*[^|]+?\|\s*([🟢🔴🟡⚪])\s*\|\s*([🟢🔴🟡⚪])\s*\|\s*([🟢🔴🟡⚪])\s*\|\s*([🟢🔴🟡⚪])\s*\|\s*(.+?)\s*\|",
            dl,
        )
        if m:
            huashen, hy, hyz, market = m.group(1), m.group(2), m.group(3), m.group(4)
            market_env = f"大盘{market} 行业{hy} 领涨{hyz}"

    # ── 风险信号（负面预警）──先声明变量，后面反身性填充 ──
    risks = []
    # 1. 资金持续流出
    for s in core_signals.split("、"):
        s = s.strip()
        if "流出" in s:
            risks.append("🔻资金持续流出")
            break
    # 2. 下跌概率偏高
    down_prob = ""
    for _line in lines:
        if "上涨概率" in _line and "下跌概率" in _line:
            m = _re.search(r"下跌概率\s*\|\s*(\d+)%", _line)
            if m:
                down_prob = m.group(1)
            break
    if down_prob and int(down_prob) >= 25:
        risks.append(f"⬇️下跌概率{down_prob}%")
    # 3. MACD 死叉
    for _line in lines:
        if "MACD死叉" in _line:
            risks.append("🔴MACD死叉区")
            break
    # 4. ⚠️ 风险提示
    for _line in lines:
        if "⚠️ 风险提示" in _line:
            m = _re.search(r"⚠️ 风险提示\*\*:\s*(.+)", _line)
            if m:
                risks.append("⚠️" + m.group(1).strip())
            break
    # 6. 估值泡沫/筹码分散（泡沫风险表）
    dl = _data_after(lines, "风险等级")
    if dl:
        m = _re.search(
            r"\|\s*[^|]+?\|\s*(.+?)\s*\|\s*([—A-Z🔴🟢🟡]+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|\s*(.+?)\s*\|",
            dl,
        )
        if m:
            topo, dry, bubble, scatter, risk_l = m.group(1), m.group(2), m.group(3), m.group(4), m.group(5)
            if topo not in ("无", "—", ""):
                risks.append(f"📈{topo}")
            if dry not in ("无", "—", ""):
                risks.append(f"🧯{dry}")
            if bubble not in ("无", "—", ""):
                risks.append(f"💸{bubble}")
            if scatter not in ("无", "—", ""):
                risks.append(f"🪙{scatter}")

    # ── ① 主进信号 ──
    main_signal = main_grade = env_res = atk = ""
    dl = _data_after(lines, "分级标签")
    if dl:
        m = _re.search(
            r"\|\s*[^|]+?\|\s*(✅|❌)?\s*(\S+)\s*\|\s*\*{0,2}([^*]+)\*{0,2}\s*\|\s*([^|]+?)\s*\|\s*(✅|❌)",
            dl,
        )
        if m:
            main_signal = (m.group(1) or "❌") + m.group(2)
            main_grade = m.group(3)
            env_res = m.group(4)
            atk = m.group(5)

    # ── ② 反身性 ──
    refx_stage = refx_quad = refx_sbi = ""
    dl = _data_after(lines, "反身性强度")
    if dl:
        m = _re.search(
            r"\|\s*[^|]+?\|\s*([^\|]+?)\|\s*(-?\d+)\s*\|\s*([+-]?\d+\.?\d*)\s*\|\s*([^\|]+?)\s*\|",
            dl,
        )
        if m:
            refx_stage = m.group(1).strip()
            refx_sbi = m.group(2)
            refx_quad = m.group(4)
    # 5. 反身性弱势/恐慌（风险信号 #5）
    if refx_stage and ("Q3" in refx_stage or "Q4" in refx_stage or "弱势" in refx_stage or "恐慌" in refx_stage):
        risks.append("🔄反身性弱势")
    risk_str = " ".join(risks) if risks else ""

    # ── ③ 筹码结构 ──
    chip_dczone = chip_trend = chip_retail = ""
    dl = _data_after(lines, "散户状态")
    if dl:
        m = _re.search(
            r"\|\s*[^|]+?\|\s*([\d.]+)\s*\|\s*(\w+)\s*\|\s*([^\|]+?)\s*\|\s*(\S+)\s*\|",
            dl,
        )
        if m:
            chip_dczone = m.group(1)
            chip_trend = m.group(2)
            chip_retail = m.group(4)

    # ── ④ 操作建议 + 目标/止损/盈亏比 ──
    advise = ""
    for _line in lines:
        if "**操作建议**:" in _line:
            m = _re.search(r"\*\*操作建议\*\*:\s*(.+)", _line)
            if m:
                advise = m.group(1).strip()
            break
    buy_tan = _gr(r"盈亏比\s*\|\s*([\d.]+):1", "")

    # ── ⑤ 周线信号 ──
    weekly_signal = ""
    weekly_ma = _gr(r"周均线\s*\|\s*(.+?)\s*\|", "")
    for _line in lines:
        if "周线·" in _line:
            weekly_signal = _line.replace("- **信号**: ", "").replace("**信号**: ", "").strip()
            if weekly_signal:
                break
    if not weekly_signal:
        weekly_signal = _gr(r"周线趋势.*?\*\*(.+?)\*\*", "")

    # 策略备注：当前单一策略（PZYJ=盘中异动预警），不显示；
    # 多策略时可通过 strategy_map 扩展。
    # strategy_map = {"PZYJ": "盘中异动预警"}  # 保留供扩展

    def fmt(x):
        return x if x else "—"

    if risk_str:
        msg = (
            f"# 🚨 盘中预警\n\n"
            f"**{name}**(`{code}`) ¥{fmt(price)} {fmt(change)}\n"
            f"**综合分 {fmt(score)} 分 ({fmt(grade)})**\n"
            f"📊 技术 {fmt(tech)} | 💰 资金 {fmt(capital)} | 📈 情绪 {fmt(sentiment)}\n\n"
            f"━━━━━━━━━━━━━━\n"
            f"📐 **均线**: {fmt(core_signals)}\n"
            f"     通道 {fmt(channel_pos)}\n"
            f"💰 **资金**: 资金面 {fmt(capital)} | {fmt(capital_flow)}\n"
            f"     环境 {fmt(market_env)}\n"
            f"🔵 **主进**: {fmt(main_signal)} 分级{fmt(main_grade)} {fmt(env_res)} 攻击{fmt(atk)}\n"
            f"🔄 **反身**: {fmt(refx_stage)} | 象限{fmt(refx_quad)} SBI={fmt(refx_sbi)}\n"
            f"🪙 **筹码**: DCZ {fmt(chip_dczone)} {fmt(chip_trend)} | 散户 {fmt(chip_retail)} | 筹码面{fmt(chip_score)}分\n"
            f"🎯 **操作**: {fmt(advise)}\n"
            f"     目标 ¥{fmt(target)} | 止损 ¥{fmt(stop_loss)} | 盈亏比 {fmt(buy_tan)}:1\n"
            f"📈 **周线**: {fmt(weekly_signal)} | 均线 {fmt(weekly_ma)}\n"
            f"🚩 **风险**: {fmt(risk_str)}\n"
            f"━━━━━━━━━━━━━━"
        )
    else:
        msg = (
            f"# 🚨 盘中预警\n\n"
            f"**{name}**(`{code}`) ¥{fmt(price)} {fmt(change)}\n"
            f"**综合分 {fmt(score)} 分 ({fmt(grade)})**\n"
            f"📊 技术 {fmt(tech)} | 💰 资金 {fmt(capital)} | 📈 情绪 {fmt(sentiment)}\n\n"
            f"━━━━━━━━━━━━━━\n"
            f"📐 **均线**: {fmt(core_signals)}\n"
            f"     通道 {fmt(channel_pos)}\n"
            f"💰 **资金**: 资金面 {fmt(capital)} | {fmt(capital_flow)}\n"
            f"     环境 {fmt(market_env)}\n"
            f"🔵 **主进**: {fmt(main_signal)} 分级{fmt(main_grade)} {fmt(env_res)} 攻击{fmt(atk)}\n"
            f"🔄 **反身**: {fmt(refx_stage)} | 象限{fmt(refx_quad)} SBI={fmt(refx_sbi)}\n"
            f"🪙 **筹码**: DCZ {fmt(chip_dczone)} {fmt(chip_trend)} | 散户 {fmt(chip_retail)} | 筹码面{fmt(chip_score)}分\n"
            f"🎯 **操作**: {fmt(advise)}\n"
            f"     目标 ¥{fmt(target)} | 止损 ¥{fmt(stop_loss)} | 盈亏比 {fmt(buy_tan)}:1\n"
            f"📈 **周线**: {fmt(weekly_signal)} | 均线 {fmt(weekly_ma)}\n"
            f"━━━━━━━━━━━━━━"
        )

    queue_dir = Path(__file__).parent / "telegram_queue"
    queue_dir.mkdir(exist_ok=True)

    msg_file = queue_dir / f"{code}_{datetime.now().strftime('%H%M%S')}.txt"
    with open(msg_file, "w", encoding="utf-8") as f:
        f.write(msg)
    print(f"[PUSH] 已写入推送队列: {msg_file}")


# ═══════════════════════════════════════════════════
#  记录预警快照（供回测追踪）
# ═══════════════════════════════════════════════════
def _record_snapshot(code: str, eval_result: str):
    """从 eval 报告中抽关键字段，写入回测快照"""
    import json as _json
    import re as _re
    from pathlib import Path as _Path

    snapshot_dir = Path(__file__).parent.parent / "partner_data"
    snapshot_dir.mkdir(parents=True, exist_ok=True)
    snapshot_file = snapshot_dir / "alerts_snapshot.json"

    def _gr(pattern):
        m = _re.search(pattern, eval_result)
        return m.group(1).strip() if m else ""

    # 标的 + 价格（用 md 报告里的 a-stock-data 行）
    # | **贝达药业** 300558.SZ | ¥70.72 | +1.32%
    m_name = _re.search(r"\|\s*\*\*([\u4e00-\u9fff\w]{1,6})\*\*\s+\d{6}\.\w{2}\s*\|\s*¥([\d.]+)\s*\|\s*([+-]?[\d.]+%)", eval_result)
    if m_name:
        name = m_name.group(1)
        price = float(m_name.group(2))
    else:
        # 回退: 综合评分表格行 | **贝达药业** | 85 | S | ¥69.80 | +8.2%
        m2 = _re.search(r"\|\s*\*\*([\u4e00-\u9fff\w]{1,6})\*\*\s*\|\s*\d+\.?\d*\s*\|\s*[SABCD]\s*\|\s*¥([\d.]+)", eval_result)
        if m2:
            name = m2.group(1)
            price = float(m2.group(2))
        else:
            name = ""
            price = 0.0

    # 综合评分 | **85.1分** | 等级 | **S级**
    score_m = _re.search(r"\|\s*综合评分\s*\|\s*\*\*([\d.]+)分\*\*\s*\|\s*等级\s*\|\s*\*\*([SABCD])级\*\*", eval_result)
    if score_m:
        score = float(score_m.group(1))
        grade = score_m.group(2) + "级"
    else:
        score = 0.0
        grade = ""

    # 主进信号: | 贝达药业 300558.SZ | ✅ 主力进 | **C级·主进.试** | 单一共振 | ❌ |
    main_signal = ""
    m_main = _re.search(r"\|\s*\S+\s+\d{6}\.\w{2}\s*\|\s*([✅❌]\s*\S+)\s*\|\s*\*\*([^*]+)\*\*\s*\|\s*([^|]+?)\s*\|\s*(✅|❌)", eval_result)
    if m_main:
        main_signal = m_main.group(1).strip()
        main_signal += " " + m_main.group(2).strip()
        main_signal += " " + m_main.group(3).strip()
        main_signal += " 攻击" + m_main.group(4).strip()

    # 反身性: | 贝达药业 300558.SZ | 🟢自我强化（中期趋势覆盖） | -9 | +0.76 | 🟢Q1
    refx = ""
    m_refx = _re.search(r"\|\s*\S+\s+\d{6}\.\w{2}\s*\|\s*([^|]+?)\s*\|\s*(-?\d+)\s*\|\s*([+-]?[\d.]+)\s*\|\s*([^|]+?)\s*\|", eval_result)
    if m_refx:
        refx = m_refx.group(1).strip()
        refx += f" SBI={m_refx.group(2)}"
        refx += f" 象限{m_refx.group(4).strip()}"

    # 操作建议: **操作建议**: ➡️ 震荡 | 仓位20% | 持有3-5日
    advise = _gr(r"\*\*操作建议\*\*:\s*(.+)")
    risk = _gr(r"\*\*⚠️ 风险提示\*\*:\s*(.+)") or _gr(r"\*\*风险\*\*:\s*(.+)")

    # 周线: | **贝达药业** 300558.SZ | **140**/200 | **S级** | 📈 周线强势 | ...
    weekly = ""
    # 匹配: | **名称** | **140**/200 | **S级** | 📈 周线强势
    m_weekly = _re.search(
        r"\|\s*\*\*[^*]+\*\*\s*\|\s*\*\*\d+\*\*/\d+\s*\|\s*\*\*[SABCD]级\*\*\s*\|\s*(.+?)\s*\|",
        eval_result,
    )
    if m_weekly:
        weekly = m_weekly.group(1).strip()
    if not weekly:
        weekly = _gr(r"\*\*周线\*\*:\s*(.+)")

    # 目标/止损: | 贝达药业 | ¥70.72 | ¥83.29 | ¥62.23 | ¥63.18 | ¥65.06 | 2.2:1 |
    target_str = stop_str = pos_str = ""
    if name:
        m_target = _re.search(
            rf"\|\s*{_re.escape(name)}\s*\|\s*¥[\d.]+\s*\|\s*¥([\d.]+)\s*\|\s*¥([\d.]+)\s*\|\s*¥[\d.]+\s*\|\s*¥[\d.]+\s*\|\s*([\d.]+):1",
            eval_result,
        )
        if m_target:
            target_str = m_target.group(1)
            stop_str = m_target.group(2)
            m_pos = _re.search(r"仓位(\d+)%", advise)
            pos_str = m_pos.group(1) if m_pos else ""
        else:
            target_str = _gr(r"目标价\s*\|\s*¥([\d.]+)")
            stop_str = _gr(r"T\+1止损.*?¥([\d.]+)\(")
            m_pos2 = _re.search(r"仓位(\d+)%", advise)
            pos_str = m_pos2.group(1) if m_pos2 else ""
    try:
        target = float(target_str) if target_str else 0
        stop_loss = float(stop_str) if stop_str else 0
        position_pct = float(pos_str) if pos_str else 0
    except Exception:
        target = stop_loss = position_pct = 0

    snapshot = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "time": datetime.now().strftime("%H:%M"),
        "code": code, "name": name,
        "alert_price": price,
        "score": score, "grade": grade,
        "main_signal": main_signal, "refx": refx,
        "risk": risk, "advise": advise,
        "weekly": weekly,
        "target": target, "stop_loss": stop_loss,
        "position_pct": position_pct,
    }

    # 追加（去重同只同天）
    if snapshot_file.exists():
        try:
            data = _json.loads(snapshot_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as e:
            print(f"[WARN] 快照文件读取失败 {snapshot_file}: {e}，新建记录")
            data = []
    else:
        data = []
    data = [d for d in data if not (d.get("code") == code and d.get("date") == snapshot["date"])]
    data.append(snapshot)
    snapshot_file.write_text(
        _json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[SNAPSHOT] 已记录预警快照: {code} {name} ¥{price} 评分{score}")


# === 轮询主循环 ===
def run_monitor():
    """监控主循环"""
    print(f"[START] blk 监控开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"[INFO] 监控目录: {TDX_BLK_DIR}")
    print(f"[INFO] 监控文件: {MONITOR_FILES}")
    
    # 检查是否在交易时间
    now = datetime.now()
    if not is_trading_time(now):
        print("[SKIP] 非交易时间，跳过监控")
        return
    
    # 执行一次检查
    check_and_notify()
    
    print("[DONE] 监控完成")

def is_trading_time(now: datetime) -> bool:
    """判断是否在交易时间"""
    hour = now.hour
    minute = now.minute
    total_minutes = hour * 60 + minute

    # 交易时间: 09:00-15:00
    return 9 * 60 <= total_minutes <= 15 * 60

if __name__ == "__main__":
    run_monitor()
