#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
决策总线信号写入工具 — _write_signal.py
==========================================
供 LLM cron agent 调用，将结构化信号写入 decision_bus.json。

用法（terminal 直调，参数都是字符串）:
    python _write_signal.py policy --direction BULL --confidence 0.7 --score 70 \\
        --events "发改委印发十五五规划征求意见" "大基金三期投HBM" \\
        --national buy --sources 3

    python _write_signal.py risk --temperature mid --icon "🟡" --score 55 \\
        --vix 18.5 --vix_change 5 --north_flow 23.5 --north_days 2 \\
        --margin_change 0.8 --up_down_ratio 0.35 --limit_up 120 \\
        --events "北向连续2日净流入" "VIX突破18"

    python _write_signal.py technical --env "🟢强" --limit_up_total 420 \\
        --top_scores "600118:82" "600406:78" "688981:75"
"""
import os, sys, json, argparse
from pathlib import Path

BUS_PATH = Path(__file__).parent / "decision_bus.json"
TODAY = __import__("datetime").datetime.now().strftime("%Y-%m-%d")


def load_bus():
    if BUS_PATH.exists():
        return json.loads(BUS_PATH.read_text(encoding="utf-8"))
    return {"signals": {}, "fusion": {}, "feedback": {}, "evolution": {},
            "last_updated": None, "status": "initialized"}


def save_bus(data):
    data["last_updated"] = __import__("datetime").datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    BUS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"✅ decision_bus.json 已写入 ({BUS_PATH})")


def cmd_policy(args):
    data = load_bus()
    signals = data.setdefault("signals", {})
    policy = signals.setdefault("policy", {})
    policy.update({
        "date": TODAY,
        "direction": args.direction.upper() if args.direction else policy.get("direction"),
        "confidence": float(args.confidence) if args.confidence else policy.get("confidence", 0),
        "score": int(args.score) if args.score else policy.get("score"),
        "key_events": args.events or [],
        "national_team_action": args.national or policy.get("national_team_action"),
        "sources_count": int(args.sources) if args.sources else policy.get("sources_count", 0),
        "updated_by": "6b951cec1ad5",
    })
    if args.report_path:
        policy["raw_report_path"] = args.report_path
    save_bus(data)


def cmd_risk(args):
    data = load_bus()
    signals = data.setdefault("signals", {})
    rs = signals.setdefault("risk_sentiment", {})
    updates = {"date": TODAY, "updated_by": "b770750250c8"}
    if args.temperature: updates["temperature"] = args.temperature
    if args.icon: updates["temperature_icon"] = args.icon
    if args.score is not None: updates["score"] = int(args.score)
    if args.vix is not None: updates["vix"] = float(args.vix)
    if args.vix_change is not None: updates["vix_change_pct"] = float(args.vix_change)
    if args.north_flow is not None: updates["north_flow_yesterday"] = float(args.north_flow)
    if args.north_days is not None: updates["north_consecutive_days"] = int(args.north_days)
    if args.margin_change is not None: updates["margin_balance_change_pct"] = float(args.margin_change)
    if args.up_down_ratio is not None: updates["up_down_ratio"] = float(args.up_down_ratio)
    if args.limit_up is not None: updates["limit_up_count"] = int(args.limit_up)
    if args.events: updates["key_events"] = args.events
    if args.sources: updates["sources_count"] = int(args.sources)
    rs.update(updates)
    save_bus(data)


def cmd_technical(args):
    data = load_bus()
    signals = data.setdefault("signals", {})
    tech = signals.setdefault("technical", {})
    tech.update({"date": TODAY, "updated_by": "technical"})
    if args.env: tech["market_env"] = args.env
    if args.limit_up_total: tech["limit_up_total"] = int(args.limit_up_total)
    if args.top_scores:
        top = []
        for s in args.top_scores:
            parts = s.rsplit(":", 1)
            if len(parts) == 2:
                top.append({"code": parts[0], "score": int(parts[1])})
        tech["top_scores"] = top
    if args.summary: tech["factors_summary"] = args.summary
    save_bus(data)


def cmd_read(args):
    data = load_bus()
    if args.signal:
        print(json.dumps(data.get("signals", {}).get(args.signal, {}), ensure_ascii=False, indent=2))
    elif args.fusion:
        print(json.dumps(data.get("fusion", {}), ensure_ascii=False, indent=2))
    elif args.feedback:
        print(json.dumps(data.get("feedback", {}).get("signal_source_performance", {}), ensure_ascii=False, indent=2))
    else:
        print(json.dumps(data, ensure_ascii=False, indent=2)[:2000])


def main():
    parser = argparse.ArgumentParser(description="决策总线信号写入工具")
    sub = parser.add_subparsers(dest="command")

    # policy
    p_pol = sub.add_parser("policy")
    p_pol.add_argument("--direction", default=None)
    p_pol.add_argument("--confidence", default=None)
    p_pol.add_argument("--score", default=None)
    p_pol.add_argument("--events", nargs="*", default=None)
    p_pol.add_argument("--national", default=None)
    p_pol.add_argument("--sources", default=None)
    p_pol.add_argument("--report_path", default=None)
    p_pol.set_defaults(func=cmd_policy)

    # risk
    p_risk = sub.add_parser("risk")
    p_risk.add_argument("--temperature", default=None)
    p_risk.add_argument("--icon", default=None)
    p_risk.add_argument("--score", default=None)
    p_risk.add_argument("--vix", default=None)
    p_risk.add_argument("--vix_change", default=None)
    p_risk.add_argument("--north_flow", default=None)
    p_risk.add_argument("--north_days", default=None)
    p_risk.add_argument("--margin_change", default=None)
    p_risk.add_argument("--up_down_ratio", default=None)
    p_risk.add_argument("--limit_up", default=None)
    p_risk.add_argument("--events", nargs="*", default=None)
    p_risk.add_argument("--sources", default=None)
    p_risk.set_defaults(func=cmd_risk)

    # technical
    p_tech = sub.add_parser("technical")
    p_tech.add_argument("--env", default=None)
    p_tech.add_argument("--limit_up_total", default=None)
    p_tech.add_argument("--top_scores", nargs="*", default=None)
    p_tech.add_argument("--summary", default=None)
    p_tech.set_defaults(func=cmd_technical)

    # read
    p_read = sub.add_parser("read")
    p_read.add_argument("--signal", default=None)
    p_read.add_argument("--fusion", action="store_true")
    p_read.add_argument("--feedback", action="store_true")
    p_read.set_defaults(func=cmd_read)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)
    args.func(args)


if __name__ == "__main__":
    main()
