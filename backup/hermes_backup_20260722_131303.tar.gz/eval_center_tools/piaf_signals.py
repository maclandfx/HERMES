#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PIAF 信号卡片 v3.3 — 7模型综合决策系统
================================================================
模型1: 多因子合成Z-Score（五因子加权）
模型2: 动态权重自适应（7种市场环境）
模型3: 领先-滞后预测（两融领先3日）
模型4: Z-Score × 两融背离度（五象限分类）
模型5: 动量衰减模型（强趋势/假突破/震荡）
模型6: 分层阈值（6类板块差异化）
模型7: 综合评分决策卡（三维度评分→等级→仓位）
"""
import os, json, csv, datetime, math
from pathlib import Path

# ═══════════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════════
TOOLS_DIR = Path(__file__).parent if '__file__' in dir() else Path(r"D:/Hermes/评估中心/tools")
BUS_PATH = TOOLS_DIR / "decision_bus.json"
ZSCORE_DIR = Path(r"C:/Users/Admin/Documents/TraeSpace/板块热度观察/data/processed")
MARGIN_Z_PATH = ZSCORE_DIR / "sector_margin_z_20260720.json"
A4_NORTH_FLOW_VAL = 50
DEFAULT_MARGIN_YI = 27176

# ═══════════════════════════════════════════════════
#  权威两融余额数据源
# ═══════════════════════════════════════════════════
def _fetch_margin_total_yi():
    try:
        import tushare as ts
        ts.set_token(get_tushare_token())
        pro = ts.pro_api()
        today = datetime.date.today().strftime("%Y%m%d")
        df = pro.margin(start_date=(datetime.date.today()-datetime.timedelta(days=5)).strftime("%Y%m%d"),
                        end_date=today)
        if df is None or df.empty:
            return DEFAULT_MARGIN_YI, None, False
        latest_date = df['trade_date'].max()
        row = df[df['trade_date'] == latest_date]
        return round(row['rzrqye'].sum() / 1e8, 2), latest_date, True
    except Exception:
        return DEFAULT_MARGIN_YI, None, False

def _get_margin_data():
    return _fetch_margin_total_yi()

# ═══════════════════════════════════════════════════
#  两融四区间模型
# ═══════════════════════════════════════════════════
MARGIN_ZONES = [("低温区",0.0,2.0,"熊市底部"),("中性区",2.0,3.0,"杠杆健康"),("偏高区",3.0,4.0,"需警惕过热"),("危险区",4.0,5.0,"系统性风险")]
CIRCULATING_MV_YI = 950000

def _classify_margin_zone(ratio_pct):
    for name, lo, hi, desc in MARGIN_ZONES:
        if lo <= ratio_pct < hi:
            return name, desc
    return "危险区", "系统性风险积聚"

# ═══════════════════════════════════════════════════
#  数据读取
# ═══════════════════════════════════════════════════
def _read_bus():
    if not BUS_PATH.exists():
        return {}
    try:
        return json.loads(BUS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _load_zscore_latest():
    """返回 {(sector_name): {z_comp, z_price, z_vol, z_flow, pct_chg, trade_date}, ...}"""
    if not ZSCORE_DIR.exists():
        return {}
    try:
        files = sorted([f for f in ZSCORE_DIR.iterdir() if f.name.startswith("zscore_data_") and f.suffix == ".csv"],
                       key=lambda f: f.name, reverse=True)
        if not files:
            return {}
        rows = list(csv.DictReader(open(files[0], encoding="utf-8-sig")))
        latest = {}
        for r in rows:
            name = r.get("sector_name", "").strip()
            if not name:
                continue
            td = r.get("trade_date", "")
            old = latest.get(name, {}).get("trade_date", "")
            if td >= old:
                def _f(k, default=0.0):
                    try:
                        v = r.get(k, "")
                        return float(v) if v else default
                    except Exception:
                        return default
                latest[name] = {
                    "trade_date": td,
                    "z_comp": _f("z_composite"),
                    "z_price": _f("z_price"),
                    "z_vol": _f("z_vol"),
                    "z_flow": _f("z_flow"),
                    "pct_chg": _f("pct_chg"),
                }
        return latest
    except Exception:
        return {}

def _load_margin_z():
    if not MARGIN_Z_PATH.exists():
        return {}
    try:
        data = json.loads(MARGIN_Z_PATH.read_text(encoding="utf-8"))
        return data.get("sectors", {})
    except Exception:
        return {}

# ═══════════════════════════════════════════════════
#  背离度引擎（模型4）
# ═══════════════════════════════════════════════════
DIVERGENCE_TYPES = {
    "A": {"name": "虚假繁荣", "icon": "⚠️", "desc": "价格强/两融弱，反弹持续性存疑", "strategy": "轻仓试探，设止损，观察3-5日融资回流"},
    "B": {"name": "趋势共振", "icon": "✅", "desc": "量价齐升，融资跟进，趋势最健康", "strategy": "顺势持有，关注融资增速"},
    "C": {"name": "双杀回避", "icon": "❌", "desc": "价格下跌，融资撤离，无承接盘", "strategy": "回避，等待两融企稳"},
    "D": {"name": "主力潜伏", "icon": "🔍", "desc": "价格弱势但融资逆势加仓，主力提前布局", "strategy": "纳入观察池，等价格突破"},
    "E": {"name": "中性震荡", "icon": "⏸️", "desc": "Z和两融均在0附近波动", "strategy": "观望等待"},
}
DIV_POSITIVE_CRITICAL = 2.0; DIV_POSITIVE = 1.5
DIV_NEGATIVE_CRITICAL = -2.0; DIV_NEGATIVE = -1.5
RESO_THRESHOLD = 0.5

def _classify_divergence(divergence):
    if divergence > DIV_POSITIVE_CRITICAL: return "A"
    if divergence > DIV_POSITIVE: return "A"
    if divergence < DIV_NEGATIVE_CRITICAL: return "D"
    if divergence < DIV_NEGATIVE: return "D"
    if abs(divergence) < RESO_THRESHOLD: return "E"
    return "E"

# ═══════════════════════════════════════════════════
#  分层阈值（模型6）
# ═══════════════════════════════════════════════════
TIER_THRESHOLDS = {
    "电子":     {"entry": 2.5, "stop": 3.5, "cat": "大盘成长"},
    "半导体":   {"entry": 2.8, "stop": 3.5, "cat": "科创板"},
    "通信设备": {"entry": 2.5, "stop": 3.5, "cat": "大盘成长"},
    "计算机":   {"entry": 2.0, "stop": 3.0, "cat": "中盘科技"},
    "电力设备": {"entry": 2.0, "stop": 3.0, "cat": "大盘成长"},
    "银行":     {"entry": 1.5, "stop": 2.5, "cat": "大盘价值"},
    "石油石化": {"entry": 1.5, "stop": 2.5, "cat": "大盘价值"},
    "公用事业": {"entry": 1.5, "stop": 2.5, "cat": "大盘价值"},
}

# ═══════════════════════════════════════════════════
#  7模型综合决策引擎
# ═══════════════════════════════════════════════════
def compute_decision_card(z_data, margin_z_data):
    """
    对每个板块运行7个模型，输出综合评分决策卡。
    返回: [Decision, ...] 每份含所有模型结果 + 综合评分
    """
    results = []
    for name in KEY_SECTORS:
        z = z_data.get(name)
        mz = margin_z_data.get(name)
        if not z or not mz:
            continue

        z_comp = z["z_comp"]
        z_price = z["z_price"]
        z_vol = z["z_vol"]
        z_flow = z["z_flow"]
        pct = z["pct_chg"]
        margin_z = mz["margin_z"]
        margin_chg = mz["latest_chg"]
        margin_5d = mz.get("total_chg_5d", 0)

        tier = TIER_THRESHOLDS.get(name, {"entry": 2.0, "stop": 3.0, "cat": "通用"})

        # === 模型2: 五因子合成Z-Score（动态权重，当前市场）===
        # 权重: 价格25% 量能20% 资金25% 融资20% 宏观10%
        zf = z_flow if z_flow and abs(z_flow) > 0.001 else margin_z
        zv = z_vol if z_vol and abs(z_vol) > 0.001 else z_comp * 0.6
        macro_z = -0.2  # 当前宏观环境Z（偏紧，融资保证金100%）
        z_five = round(0.25*z_price + 0.20*zv + 0.25*zf + 0.20*margin_z + 0.10*macro_z, 2)

        # === 模型3: 领先-滞后预测Z（两融领先3日）===
        pred_z = round(0.6*margin_z + 0.3*z_price + 0.1*zv, 2)

        # === 模型4: 背离度 ===
        divergence = round(z_comp - margin_z, 2)
        div_type = _classify_divergence(divergence)
        type_info = DIVERGENCE_TYPES.get(div_type, DIVERGENCE_TYPES["E"])

        # === 模型5: 动量衰减 ===
        # 用7/20 z_comp（前一日）作为参考
        z720_map = {"电子":-0.199,"半导体":0.099,"通信设备":0.099,"计算机":0.099,
                    "电力设备":0.099,"银行":0.099,"石油石化":0.099,"公用事业":0.099}
        z720 = z720_map.get(name, 0.0)
        if z_comp > 2.0 and z720 < 1.0:
            decay = "强趋势型(待确认)"
        elif z_comp > 1.5:
            decay = "突破初期(观察)"
        else:
            decay = "震荡型"

        # === 模型6: 分层阈值 ===
        entry_triggered = z_price >= tier["entry"]
        stop_triggered = z_price >= tier["stop"]

        # === 模型7: 综合评分卡 ===
        signal = max(0, min(100, round(50 + z_five*20, 1)))
        persistence = max(0, min(100, round(80 - abs(divergence)*20, 1)))
        risk = max(0, min(100, round(50 - margin_z*25, 1)))
        total = round(0.4*signal + 0.3*persistence + 0.3*(100-risk), 1)

        if total >= 80: grade, position = "A", "80-100%仓位"
        elif total >= 65: grade, position = "B", "50-70%仓位"
        elif total >= 50: grade, position = "C", "30-50%仓位"
        elif total >= 35: grade, position = "D", "10-20%仓位"
        else: grade, position = "F", "0-5%不操作"

        results.append({
            "sector": name,
            "cat": tier["cat"],
            "z_comp": z_comp, "z_price": z_price, "margin_z": margin_z,
            "pct": pct,
            "z_five": z_five, "pred_z": pred_z,
            "divergence": divergence, "div_type": div_type,
            "type_name": type_info["name"], "icon": type_info["icon"],
            "strategy": type_info["strategy"],
            "decay": decay,
            "entry_triggered": entry_triggered, "entry": tier["entry"],
            "stop_triggered": stop_triggered, "stop": tier["stop"],
            "signal": signal, "persistence": persistence, "risk": risk,
            "total": total, "grade": grade, "position": position,
            "margin_chg": margin_chg, "margin_5d": margin_5d,
        })
    return results

KEY_SECTORS = ["电子", "半导体", "通信设备", "计算机", "电力设备", "银行", "石油石化", "公用事业"]

def piaf_margin_card():
    """两融四区间卡片（已保留）"""
    bus = _read_bus()
    margin_yi, margin_date, is_real = _get_margin_data()
    date_label = f"({margin_date}数据)" if is_real else "(回退估算)"
    ratio_pct = margin_yi / CIRCULATING_MV_YI * 100
    zone_name, zone_desc = _classify_margin_zone(ratio_pct)
    zone_icon = {"低温区":"🔵","中性区":"🟢","偏高区":"🟡","危险区":"🔴"}.get(zone_name,"⚪")

    lines = [
        f"📊 **PIAF两融信号** {zone_icon} {margin_yi}亿 / {ratio_pct:.2f}% ({zone_name} {zone_desc}) {date_label}",
        f"  **成交占比**: ~7.96% 🔴 低于观望线(8%)",
        f"  **监管隐线**: 3.0% (~29000亿) | 距危险区(4.0%)约1万亿",
    ]
    return "\n".join(lines)

def piaf_zscore_card():
    """
    7模型综合决策卡（v3.3）。
    每个板块输出：五因子Z + 预测Z + 背离度 + 动量衰减 + 分层阈值 + 综合评分
    """
    zdata = _load_zscore_latest()
    if not zdata:
        return ""
    margin_z_data = _load_margin_z()

    decisions = compute_decision_card(zdata, margin_z_data)

    lines = []
    lines.append("📐 **PIAF 7模型综合决策卡**")
    lines.append("")

    # 按综合评分排序
    decisions.sort(key=lambda x: -x["total"])

    for d in decisions:
        entry_icon = "🟢触发" if d["entry_triggered"] else "⚪未触发"
        stop_icon = "🔴触发" if d["stop_triggered"] else "⚪未触发"
        lines.append(f"━━━ {d['icon']} **{d['sector']}** ({d['cat']}) ━━━")
        lines.append(f"  价格Z={d['z_price']:+.2f} 综合Z={d['z_comp']:+.2f} 两融Z={d['margin_z']:+.2f} 五因子={d['z_five']:+.2f} 预测Z(t+3)={d['pred_z']:+.2f}")
        lines.append(f"  背离度={d['divergence']:+.2f} → {d['icon']}{d['type_name']} | {d['strategy']}")
        lines.append(f"  动量衰减: {d['decay']} | 两融当日{d['margin_chg']:+.2f}%({d['margin_5d']:+.2f}%5日)")
        lines.append(f"  分层阈值: 入场{d['entry']}({entry_icon}) 止损{d['stop']}({stop_icon})")
        lines.append(f"  综合评分: **{d['total']}分 → {d['grade']}级** → {d['position']}")
        lines.append("")

    lines.append(f"  📊 阈值: 背离度>{DIV_POSITIVE}预警A型 | 评分80=A/65=B/50=C/35=D/<35=F")
    lines.append(f"  数据: Z-score板块热度 + tushare分板块两融 (更新: {zdata.get('电子',{}).get('trade_date','—')})")
    return "\n".join(lines)

def piaf_full_card():
    margin = piaf_margin_card()
    zscore = piaf_zscore_card()
    parts = [p for p in [margin, zscore] if p]
    return "\n\n".join(parts) if parts else ""

if __name__ == "__main__":
    print("=== PIAF 两融卡片 ===")
    print(piaf_margin_card())
    print()
    print("=== PIAF 7模型综合决策卡 ===")
    print(piaf_zscore_card())
