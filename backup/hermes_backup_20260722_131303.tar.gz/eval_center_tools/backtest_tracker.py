#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
回测追踪器 — 每日收盘后运行
=====================================
读取过去 30 天所有预警标的的后续表现，找出表现好的票的共性，
反馈给决策系统，让后续推荐越来越准。

数据来源：
1. 预警快照 — 每个标的预警时的综合分/主进/反身/风险信号
2. 收盘表现 — 预警后 N 日内的涨跌幅、是否涨停、是否创新高
"""
import os, sys, re, json, time, math
from pathlib import Path
from datetime import datetime as _dt, timedelta
from collections import defaultdict, Counter

# ═══════════════════════════════════════════════════
BASE = Path(__file__).parent
TOOLS_DIR = BASE / "tdx_connector" / "telegram_queue"
DONE_DIR = TOOLS_DIR / "done"
PARTNER_DIR = BASE / "partner_data"
PARTNER_DIR.mkdir(parents=True, exist_ok=True)
SNAPSHOT_LOG = PARTNER_DIR / "alerts_snapshot.json"   # 预警快照（含时间+评分）
BACKTEST_LOG = PARTNER_DIR / "backtest_results.json"   # 回测结果
INSIGHTS_LOG = PARTNER_DIR / "insights.json"            # 共性洞察

# 评估报告目录（用来查最新价格）
REPORTS_DIR = (BASE / ".." / "reports" / "粗评").resolve()

# 已追踪的标的代码（避免重复快照）
TRACKED_FILE = PARTNER_DIR / "tracked_codes.json"


def load_json(path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ═══════════════════════════════════════════════════
#  1. 记录预警快照（在 blk_monitor 或 push_runner 中调用）
# ═══════════════════════════════════════════════════
def snapshot_alert(code: str, name: str, price: float, score: float,
                   grade: str, main_signal: str, refx: str,
                   risk: str, advise: str, weekly: str,
                   target: float, stop_loss: float, position_pct: float) -> dict:
    """记录一次预警快照——用于后续回测"""
    tracked = load_json(TRACKED_FILE, {})
    # 每天每个标的只记一次（取最新）
    today = _dt.now().strftime("%Y-%m-%d")
    key = f"{code}_{today}"
    if key in tracked:
        # 已追踪今天，只更新分数
        return {}

    snapshot = {
        "date": today,
        "time": _dt.now().strftime("%H:%M"),
        "code": code, "name": name,
        "alert_price": round(price, 2),
        "score": score,
        "grade": grade,
        "main_signal": main_signal,
        "refx": refx,
        "risk": risk,
        "advise": advise,
        "weekly": weekly,
        "target": target,
        "stop_loss": stop_loss,
        "position_pct": position_pct,
    }
    snapshots = load_json(SNAPSHOT_LOG, [])
    # 去重同只同天：保留最新
    snapshots = [s for s in snapshots if not (s.get("code") == code and s.get("date") == today)]
    snapshots.append(snapshot)
    save_json(SNAPSHOT_LOG, snapshots)
    tracked[key] = True
    save_json(TRACKED_FILE, tracked)
    return snapshot


# ═══════════════════════════════════════════════════
#  2. 获取标的收盘价（从最新 eval 报告里抽）
# ═══════════════════════════════════════════════════
def get_latest_price(code: str) -> float | None:
    """从最近 3 份 md 报告中抽该标的现价"""
    if not REPORTS_DIR.exists():
        return None
    files = sorted(REPORTS_DIR.glob("*.md"), reverse=True)
    for fpath in files[:3]:
        try:
            content = fpath.read_text(encoding="utf-8")
            # 查找: | **XXX** 股票代码 | ¥XX.XX | +X.XX%
            m = re.search(rf"\*\*[^*]+\*\*{code}\.\w{{2}}\s*\|\s*¥([\d.]+)", content)
            if not m:
                m = re.search(rf"贝达药业.*?\*\*\s*\|\s*¥([\d.]+)", content)
            if m:
                return float(m.group(1))
            # 更宽泛匹配
            m2 = re.search(rf"{code}\.\w{{2}}\s*\|\s*¥([\d.]+)", content)
            if m2:
                return float(m2.group(1))
        except Exception:
            continue
    return None


# ═══════════════════════════════════════════════════
#  3. 读取历史快照，计算回测结果
# ═══════════════════════════════════════════════════
def run_backtest(days: int = 30) -> list:
    """
    对过去 N 天的预警快照，查最新价格，计算回测表现。
    返回每只标的的回测记录。
    """
    snapshots = load_json(SNAPSHOT_LOG, [])
    if not snapshots:
        return []

    cutoff = (_dt.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    recent = [s for s in snapshots if s.get("date", "") >= cutoff]
    results = []

    for s in recent:
        code = s.get("code", "")
        name = s.get("name", "")
        alert_price = s.get("alert_price", 0)
        if alert_price <= 0:
            continue
        # 查最新价
        latest_price = get_latest_price(code)
        if latest_price is None:
            latest_price = alert_price  # 未知，标记为无数据

        # 计算表现
        pnl_pct = round((latest_price - alert_price) / alert_price * 100, 2) if alert_price else 0
        is_up = pnl_pct > 0
        is_win = pnl_pct >= 3  # 涨超3%算成功

        result = {
            "code": code, "name": name,
            "alert_date": s.get("date", ""),
            "alert_price": alert_price,
            "latest_price": latest_price,
            "pnl_pct": pnl_pct,
            "is_win": is_win,
            "is_up": is_up,
            # 预警时的特征
            "score": s.get("score", 0),
            "grade": s.get("grade", ""),
            "main_signal": s.get("main_signal", ""),
            "risk": s.get("risk", ""),
            "refx": s.get("refx", ""),
            "weekly": s.get("weekly", ""),
            "advise": s.get("advise", ""),
        }
        results.append(result)

    # 排序：按 pnl_pct 降序
    results.sort(key=lambda x: -x["pnl_pct"])
    return results


# ═══════════════════════════════════════════════════
#  4. 提取共性洞察
# ═══════════════════════════════════════════════════
def extract_insights(results: list) -> dict:
    """从回测结果中找表现好的票的共性"""
    if not results:
        return {"note": "无数据"}

    winners = [r for r in results if r["is_win"]]
    losers = [r for r in results if not r["is_win"]]

    insights = {
        "total": len(results),
        "win_count": len(winners),
        "win_rate": round(len(winners) / len(results), 2) if results else 0,
        "avg_pnl": round(sum(r["pnl_pct"] for r in results) / len(results), 2),
        "top3_winners": [],
        "features": {},
    }

    # TOP3 赢家
    for r in sorted(winners, key=lambda x: -x["pnl_pct"])[:3]:
        insights["top3_winners"].append({
            "code": r["code"], "name": r["name"],
            "pnl_pct": r["pnl_pct"], "score": r["score"],
        })

    # 特征分析
    if winners:
        insights["features"]["avg_score"] = round(sum(r["score"] for r in winners) / len(winners), 1)
        insights["features"]["main_signal_rate"] = round(
            sum(1 for r in winners if "✅" in r.get("main_signal", "")) / len(winners), 2
        )
        insights["features"]["no_risk_rate"] = round(
            sum(1 for r in winners if not r.get("risk")) / len(winners), 2
        )
        insights["features"]["weekly_up_rate"] = round(
            sum(1 for r in winners if "上涨" in r.get("weekly", "")) / len(winners), 2
        )
    if losers:
        insights["features"]["loser_avg_score"] = round(sum(r["score"] for r in losers) / len(losers), 1)
        insights["features"]["loser_no_risk_rate"] = round(
            sum(1 for r in losers if not r.get("risk")) / len(losers), 2
        )

    # 关键发现（文本描述）
    findings = []
    if winners and losers:
        if insights["features"]["avg_score"] > insights["features"]["loser_avg_score"]:
            findings.append(
                f"赢家平均分({insights['features']['avg_score']}) > 输家平均分({insights['features']['loser_avg_score']})，"
                f"高分标的表现更优"
            )
        if insights["features"]["main_signal_rate"] >= 0.5:
            findings.append(
                f"赢家中有 {insights['features']['main_signal_rate']*100:.0f}% 有主进信号，"
                f"主进信号是正相关因素"
            )
        if insights["features"]["no_risk_rate"] >= 0.5:
            findings.append(
                f"赢家中有 {insights['features']['no_risk_rate']*100:.0f}% 无风险信号，"
                f"避开风险标的能提高胜率"
            )
    insights["findings"] = findings
    return insights


# ═══════════════════════════════════════════════════
#  5. 更新约束（根据回测结果动态调整）
# ═══════════════════════════════════════════════════
def update_constraints_from_insights(insights: dict):
    """根据回测洞察调整约束参数"""
    wr = insights.get("win_rate", 0)
    if wr >= 0.6:
        return {
            "max_daily_position": 30,
            "max_single_position": 20,
            "max_holding_days": 5,
            "buy_time": "14:30后",
            "stop_loss_required": True,
            "note": f"胜率 {wr*100:.0f}% 较好，适度放宽仓位",
        }
    elif wr <= 0.25:
        return {
            "max_daily_position": 10,
            "max_single_position": 5,
            "max_holding_days": 2,
            "buy_time": "14:30后",
            "stop_loss_required": True,
            "note": f"胜率 {wr*100:.0f}% 偏低，大幅收紧",
        }
    else:
        return {
            "max_daily_position": 20,
            "max_single_position": 10,
            "max_holding_days": 3,
            "buy_time": "14:30后",
            "stop_loss_required": True,
            "note": f"胜率 {wr*100:.0f}% 中性，维持当前约束",
        }


# ═══════════════════════════════════════════════════
#  6. 打印报告
# ═══════════════════════════════════════════════════
def print_report(results: list, insights: dict):
    print(f"\n{'='*60}")
    print(f"📊 回测追踪 — {_dt.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*60}")
    print(f"\n过去 {insights['total']} 只预警标的，赢家 {insights['win_count']} 只，"
          f"胜率 {insights['win_rate']*100:.0f}%，平均盈亏 {insights['avg_pnl']:.1f}%")
    print(f"\n{'#':<3} {'标的':<8} {'代码':<8} {'盈亏%':<7} {'预警分':<6} {'评级':<5} {'风险':<10} {'主进':<6}")
    print(f"{'-'*55}")
    for i, r in enumerate(results[:10], 1):
        flag = "🟢" if r["is_win"] else ("🔴" if r["pnl_pct"] < 0 else "⚪")
        risk_short = r.get("risk", "")[:8] if r.get("risk") else "—"
        main_short = "✅" if "✅" in r.get("main_signal", "") else "❌"
        print(f"{flag} {i:<2} {r['name']:<6} {r['code']:<8} {r['pnl_pct']:>+6.1f}% "
              f"{r['score']:<6} {r.get('grade','—'):<5} {risk_short:<10} {main_short}")

    print(f"\n━━━━━━━━━━━━━━")
    print(f"💡 共性洞察:")
    for f in insights.get("findings", []):
        print(f"  • {f}")
    if not insights.get("findings"):
        print(f"  • 数据不足，暂无法提取共性")

    print(f"\n💰 TOP3 赢家:")
    for r in insights.get("top3_winners", []):
        print(f"  🥇 {r['name']}({r['code']}) +{r['pnl_pct']:.1f}% (预警分{r['score']})")

    # 建议调整
    adj = update_constraints_from_insights(insights)
    print(f"\n🔧 建议约束调整:")
    print(f"  单日≤{adj['max_daily_position']}% | 单只≤{adj['max_single_position']}% | 持仓≤{adj['max_holding_days']}日")
    print(f"  {adj['note']}")
    print(f"\n{'='*60}\n")


# ═══════════════════════════════════════════════════
#  主流程
# ═══════════════════════════════════════════════════
def run_backtest_full(days: int = 30):
    print(f"🔄 回测追踪器启动 — {_dt.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"统计窗口: 过去 {days} 天")

    # 清理过期追踪记录
    tracked = load_json(TRACKED_FILE, {})
    cutoff = (_dt.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    tracked = {k: v for k, v in tracked.items() if k.split("_")[-1] >= cutoff}
    save_json(TRACKED_FILE, tracked)

    # 跑回测
    results = run_backtest(days)
    if not results:
        print("⚠️ 无历史快照数据（先运行几场预警才能积累）")
        return

    # 提取洞察
    insights = extract_insights(results)

    # 保存
    save_json(BACKTEST_LOG, results)
    save_json(INSIGHTS_LOG, insights)

    # 打印
    print_report(results, insights)

    # 更新约束建议到 partner_log 的约束建议
    adj = update_constraints_from_insights(insights)
    suggested = load_json(PARTNER_DIR / "constraint_suggestion.json", {})
    suggested.update(adj)
    suggested["updated_at"] = _dt.now().strftime("%Y-%m-%d %H:%M")
    save_json(PARTNER_DIR / "constraint_suggestion.json", suggested)


if __name__ == "__main__":
    run_backtest_full()
