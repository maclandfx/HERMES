#!/usr/bin/env python3
"""
factor_reporter.py — 因子日报
综合: 因子引擎得分 + 自适应权重 → 综合评分 + 行动建议
"""
import os, sys, json, datetime

TOOLS = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, TOOLS)
from _stock_names import STOCK_NAMES, get_name

# 因子代码 → 中文信号名（报告统一用名称，不用代码）
FACTOR_CN = {
    "A1_big_net_ratio":   "大单净流入比",
    "A2_consecutive_days":"资金持续天数",
    "A3_strength":        "主力强度",
    "A4_north_flow":      "北向资金",
    "B1_divergence":      "量价背离",
    "B2_limit_quality":   "封板质量",
    "B3_gap":             "跳空缺口",
    "B4_rel_strength":    "相对强弱",
    "B5_trend":           "趋势强度",
    "B6_volatility":      "波动率",
    "C_market_up_ratio":  "市场涨跌比",
    "C_limit_up_count":   "涨停家数",
    "F1_is_monday":       "周一效应",
    "F1_is_friday":       "周五效应",
    "F1_is_thursday":     "周四效应",
    "F2_is_month_end":    "月末效应",
    "F3_is_earnings_season":"业绩窗口",
}
FACTOR_DIR = os.path.join(os.path.dirname(TOOLS), "reports", "追踪")
FACTOR_DATA = os.path.join(FACTOR_DIR, "factors_raw.json")
WEIGHT_FILE = os.path.join(FACTOR_DIR, "factor_weights.json")
REPORT_FILE = os.path.join(FACTOR_DIR, "factor_report_daily.md")


def load_data():
    with open(FACTOR_DATA, "r", encoding="utf-8") as f:
        factors = json.load(f)
    if os.path.exists(WEIGHT_FILE):
        with open(WEIGHT_FILE, "r", encoding="utf-8") as f:
            weights = json.load(f)
    else:
        weights = {}
    return factors, weights


def compute_composite(factors, weights):
    """加权综合评分（支持 _RISK_MULTI 降权 + 排除内部 _ 字段）"""
    scores = {}
    for code, f_dict in factors.items():
        if "error" in f_dict:
            scores[code] = {"error": f_dict["error"], "total": 0}
            continue
        total = 0
        weight_sum = 0
        details = {}
        for f_name, f_val in f_dict.items():
            if f_name.startswith("_"):
                continue
            w = weights.get(f_name, {}).get("weight", 0)
            total += f_val * w
            weight_sum += w
            details[f_name] = {"value": f_val, "weight": w}
        total = total / weight_sum if weight_sum > 0 else 0
        # 实时行情风险降权：跌停×0.3 / 大跌×0.6
        multi = f_dict.get("_RISK_MULTI", 1.0)
        total = total * multi
        scores[code] = {
            "total": round(total, 1),
            "details": details,
            "risk_tag": f_dict.get("_RISK_TAG", ""),
            "realtime_pct": f_dict.get("_REALTIME_PCT"),
            "risk_multi": multi,
        }
    return scores


def factor_analysis(factors, weights):
    """截面分析：找出今日真实区分涨跌的有效因子/组合"""
    # 分健康组(无降权) vs 降权组(今日跌)
    good = {c for c in factors if not factors[c].get("_RISK_TAG")}
    bad  = {c for c in factors if factors[c].get("_RISK_TAG")}

    factor_keys = [k for k in weights.keys() if not k.startswith("_")]
    diffs = []
    for k in factor_keys:
        gv = [factors[c][k] for c in good if isinstance(factors[c].get(k), (int, float))]
        bv = [factors[c][k] for c in bad  if isinstance(factors[c].get(k), (int, float))]
        if not gv or not bv:
            continue
        gm, bm = sum(gv)/len(gv), sum(bv)/len(bv)
        diffs.append((k, gm, bm, gm - bm))

    # 健康组内部 top/bottom 分化
    good_scores = {c: (sum(factors[c].get(k, 0) * weights.get(k, {}).get("weight", 0) for k in factor_keys if isinstance(factors[c].get(k), (int, float)))
                       / sum(weights.get(k, {}).get("weight", 0) for k in factor_keys)
                      ) for c in good}
    top3 = [c for c, _ in sorted(good_scores.items(), key=lambda x: -x[1])[:3]]
    bot3 = [c for c, _ in sorted(good_scores.items(), key=lambda x: x[1])[:3]]
    good_top = {c for c in top3}

    # 健康 TOP3 共同因子（均值最高的）
    combo = []
    if top3:
        for k in factor_keys:
            vals = [factors[c].get(k) for c in top3 if isinstance(factors[c].get(k), (int, float))]
            if vals:
                combo.append((k, sum(vals)/len(vals)))
        combo.sort(key=lambda x: -x[1])

    # 结论组装
    lines = []
    lines.append("## 🔎 因子分析观察\n")

    # 关键发现1：哪个因子今日真正区分涨跌
    best_separators = sorted(diffs, key=lambda x: -abs(x[3]))[:5]
    lines.append("**① 今日涨跌的因子分化（健康组 vs 降权组均值差）**\n")
    lines.append("| 因子 | 健康组 | 降权组 | 差 | 判断 |\n")
    lines.append("|------|:------:|:------:|:---:|------|\n")
    for k, gm, bm, diff in best_separators:
        if abs(diff) < 3:
            continue
        direction = "🔼健康高=有效信号" if diff > 0 else "🔽降权高=反信号(陷阱)"
        cn = FACTOR_CN.get(k, k)
        lines.append(f"| {cn} | {gm:.1f} | {bm:.1f} | {diff:+.1f} | {direction} |\n")

    # 关键发现2：B2 封板质量反信号警告
    b2_diff = next((x for x in diffs if x[0] == "B2_limit_quality"), None)
    if b2_diff and b2_diff[3] > 0:
        lines.append("\n⚠️ **封板质量呈反信号**：降权组封板质量均值反而更高（昨日涨停→今日低开跌停），"
                     "说明**昨日封板质量高 = 次日抛压重**，封板质量不应作为次日买入依据。\n")

    # 关键发现3：A3 反信号
    a3_diff = next((x for x in diffs if x[0] == "A3_strength"), None)
    if a3_diff and a3_diff[3] < 0:
        lines.append("\n⚠️ **主力强度呈反信号**：降权组主力强度均值高于健康组，昨日主力大举买入的票次日反而易跌，"
                     "警惕**高位接盘陷阱**（主力建仓后次日低开套人）。\n")

    # 有效组合推荐
    if combo and top3:
        top_combo = [FACTOR_CN.get(k, k) for k, v in combo[:3]]
        lines.append("\n**② 今日健康 TOP3 的共同高信号组合**\n")
        top3_names = [f"{get_name(c)}({c})" for c in top3]
        lines.append(f"  标的：{'、'.join(top3_names)}\n")
        lines.append(f"  共同高信号：{' + '.join(top_combo)}\n")
        lines.append(f"  组合含义：{top_combo[0]}、{top_combo[1]}、{top_combo[2]} 同时高分 → 当前最稳健信号\n")

    # 综合结论
    true_signal = [FACTOR_CN.get(k, k) for k, gm, bm, diff in diffs if diff > 5]
    if true_signal:
        lines.append(f"\n**✅ 结论：今日真正有效的正信号 = {', '.join(true_signal)}**\n")
        lines.append("  （健康组均值比降权组高 ≥5 分，代表今日真实区分强弱）\n")
    else:
        lines.append("\n**⚡ 结论：今日因子有效性普遍偏弱，多数高信号被当日跌停证伪。"
                     "建议降低整体仓位、以相对强弱 + 实时风险覆盖为主。**\n")

    return lines


def run():
    print(f"\n{'='*60}")
    print(f"📊 因子日报 — {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*60}\n")

    factors, weights = load_data()
    scores = compute_composite(factors, weights)

    # 排序
    sorted_scores = sorted(scores.items(), key=lambda x: x[1]["total"], reverse=True)

    # 生成报告
    md = f"# 📊 因子引擎日报\n\n"
    md += f"**{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}**  |  因子数: {len(weights)}  |  标的: {len(scores)}只\n\n"

    # ── 分析观察（报告开头，结论先行） ──
    analysis_lines = factor_analysis(factors, weights)
    for line in analysis_lines:
        md += line
    md += "\n---\n\n"

    # 综合排名
    md += "## 🏆 综合因子排名\n\n"
    md += "| 排名 | 代码 | 名称 | 综合分 | 风险 | 核心因子 |\n"
    md += "|------|------|------|--------|------|----------|\n"
    for i, (code, s) in enumerate(sorted_scores):
        if "error" in s:
            continue
        name = get_name(code)
        risk = s.get("risk_tag", "")
        realtime = s.get("realtime_pct")
        if realtime is not None:
            pct_str = f"{realtime:+.1f}%"
            risk = (risk + " " + pct_str) if risk else pct_str
        risk_col = risk if risk else ""
        # 找前3大贡献因子（用中文信号名）
        top3 = sorted(s["details"].items(), key=lambda x: x[1]["value"] * x[1]["weight"], reverse=True)[:3]
        top3_str = ", ".join([f"{FACTOR_CN.get(k, k)}({v['value']})" for k, v in top3])
        md += f"| {i+1} | {code} | {name} | **{s['total']:.0f}** | {risk_col} | {top3_str} |\n"

    # 权重排名
    md += "\n## ⚖️ 当前因子权重\n\n"
    md += "| 排名 | 信号 | 权重 | 置信度 | 近20日相关性 | 说明 |\n"
    md += "|------|------|------|--------|-------------|------|\n"
    sorted_w = sorted(weights.items(), key=lambda x: x[1]["weight"], reverse=True)
    for i, (k, v) in enumerate(sorted_w):
        corr = f"{v.get('correlation', 0):+.3f}" if "correlation" in v else "N/A"
        cn = FACTOR_CN.get(k, k)
        md += f"| {i+1} | {cn} | {v['weight']:.1f}% | {v['confidence']:.2f} | {corr} | {v['description']} |\n"

    # 各因子详细得分（表头用中文信号名）
    md += "\n## 🔍 各因子详细得分\n\n"
    md += "| 股票 | 综合 |"
    f_names = sorted(weights.keys(), key=lambda k: weights[k]["weight"], reverse=True)
    for f in f_names:
        md += f" {FACTOR_CN.get(f, f)} |"
    md += "\n|------|------|"
    for f in f_names:
        md += "------|"
    md += "\n"

    for code, s in sorted_scores:
        if "error" in s:
            continue
        name = get_name(code)
        md += f"| {code} {name} | {s['total']:.0f} |"
        for f in f_names:
            val = s["details"].get(f, {}).get("value", "—")
            md += f" {val} |"
        md += "\n"

    md += f"\n\n*生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}*\n"
    md += "*因子引擎 v1 — 自适应权重滚动校准*\n"

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"📄 因子日报: {REPORT_FILE}")

    # 打印摘要
    print("\n📊 TOP 5:")
    for i, (code, s) in enumerate(sorted_scores[:5]):
        if "error" not in s:
            name = get_name(code)
            print(f"  {i+1}. {name} {s['total']:.0f}分")
    print("✅ 完成")


if __name__ == "__main__":
    run()