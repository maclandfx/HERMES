#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
安全 Telegram 推送共用模块 — _safe_tg.py
==========================================
替代所有脚本中的硬编码 TOKEN。
从环境变量 TELEGRAM_BOT_TOKEN / TG_BOT_TOKEN / .env 文件三级兜底读取。
所有推送脚本改为此模块，消除硬编码风险。

用法:
    from _safe_tg import send_tg, send_tg_file
    send_tg("消息文本")
    send_tg("消息文本", file_path="/path/to/report.md")  # 消息+附件
"""
import os, sys, json, time, urllib.request, urllib.error
from pathlib import Path

MAX_MSG = 3500
CHAT_ID = "8673372605"
PROXY = "127.0.0.1:7890"
ENV_FILE = Path("C:/Users/Admin/AppData/Local/hermes/.env")


def _load_token() -> str:
    """三级兜底读取 Telegram Bot Token"""
    # 1. 环境变量
    for var in ("TELEGRAM_BOT_TOKEN", "TG_BOT_TOKEN"):
        v = os.environ.get(var, "")
        if v and len(v) > 30:
            return v
    # 2. .env 文件
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if line.startswith("TELEGRAM_BOT_TOKEN=") or line.startswith("TG_BOT_TOKEN="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v and len(v) > 30:
                    return v
    raise RuntimeError("Telegram Bot Token 未配置：设置 TELEGRAM_BOT_TOKEN 环境变量或写入 .env 文件")


def _build_opener():
    proxy = urllib.request.ProxyHandler(
        {"http": f"http://{PROXY}", "https": f"http://{PROXY}"}
    )
    return urllib.request.build_opener(proxy)


def _chunk(text: str) -> list[str]:
    """按 MAX_MSG 切分消息"""
    lines = text.split("\n")
    chunks, current, length = [], [], 0
    for line in lines:
        if length + len(line) > MAX_MSG and current:
            chunks.append("\n".join(current))
            current, length = [line], len(line)
        else:
            current.append(line)
            length += len(line)
    if current:
        chunks.append("\n".join(current))
    return chunks


def send_tg(text: str, parse_mode: str = "HTML",
            max_attempts: int = 3) -> int:
    """
    发送 Telegram 消息，返回成功发送的分段数。
    自动切分超长消息，支持重试。
    """
    token = _load_token()
    opener = _build_opener()
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    chunks = _chunk(text)
    sent = 0
    for chunk in chunks:
        data = json.dumps({
            "chat_id": CHAT_ID, "text": chunk,
            "parse_mode": parse_mode, "disable_web_page_preview": True,
        }).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        for attempt in range(max_attempts):
            try:
                result = json.loads(opener.open(req, timeout=20).read())
                if result.get("ok"):
                    sent += 1
                    break
                else:
                    print(f"  ⚠️ TG API 拒绝: {result.get('description')}")
            except Exception as e:
                if attempt < max_attempts - 1:
                    time.sleep(2)
                else:
                    print(f"  ❌ 发送失败: {e}")
        time.sleep(1)
    return sent


def send_tg_file(text: str, file_path: str,
                 parse_mode: str = "HTML") -> bool:
    """
    先发消息，再发文件（Markdown 报告附件）。
    文件上传用 sendDocument（避免 Markdown 在消息中被截断）。
    返回 True = 文件成功发送。
    """
    token = _load_token()
    opener = _build_opener()
    file_path = Path(file_path)
    if not file_path.exists():
        print(f"  ⚠️ 文件不存在: {file_path}")
        return False

    # 先发文本消息
    send_tg(text, parse_mode=parse_mode)

    # 再发文件
    url = f"https://api.telegram.org/bot{token}/sendDocument"
    try:
        import mimetypes
        mime = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
        from urllib import request as urllib_request
        with open(file_path, "rb") as f:
            # Telegram sendDocument 用 multipart/form-data 较复杂，
            # 用 Python 标准库手动构造
            import uuid, io
            boundary = f"----HermesBoundary{uuid.uuid4().hex}"
            body_parts = []
            # chat_id
            body_parts.append(f"--{boundary}".encode())
            body_parts.append(b'Content-Disposition: form-data; name="chat_id"')
            body_parts.append(b"\r\n" + str(CHAT_ID).encode())
            # file
            fname = file_path.name
            body_parts.append(f"--{boundary}".encode())
            body_parts.append(
                f'Content-Disposition: form-data; name="document"; filename="{fname}"'.encode()
            )
            body_parts.append(f"Content-Type: {mime}".encode())
            body_parts.append(b"\r\n" + f.read())
            body_parts.append(f"--{boundary}--".encode())
            body_parts.append(b"\r\n")
            body = b"\r\n".join(body_parts)

            req = urllib_request.Request(
                url, data=body,
                headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
                method="POST"
            )
            result = json.loads(opener.open(req, timeout=60).read())
            if result.get("ok"):
                print(f"  ✅ 文件发送成功: {fname}")
                return True
            else:
                print(f"  ⚠️ 文件发送 API 拒绝: {result.get('description')}")
                return False
    except Exception as e:
        print(f"  ❌ 文件发送失败: {e}")
        return False


if __name__ == "__main__":
    # 自检
    try:
        t = _load_token()
        print(f"✅ Token 加载成功: {t[:10]}... (len={len(t)})")
    except RuntimeError as e:
        print(f"❌ {e}")
        sys.exit(1)
