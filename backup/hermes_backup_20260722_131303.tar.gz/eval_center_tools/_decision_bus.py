#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
决策总线读写模块 — _decision_bus.py
=====================================
所有任务共享的决策融合中枢。提供文件锁安全读写。

职责:
  - 读取/写入 decision_bus.json
  - 安全文件锁 (fcntl) 防并发冲突
  - 信号写入、推荐写入、反馈写入的原子操作

用法:
    from _decision_bus import Bus
    bus = Bus()

    # 读
    data = bus.read()

    # 写政策信号
    bus.write_signal("policy", {
        "direction": "bull", "confidence": 0.7,
        "key_events": ["发改委印发..."]
    })

    # 写推荐
    bus.write_fusion({
        "recommendations": [{"code":"600118", "action":"buy", ...}]
    })

    # 写反馈
    bus.write_accuracy_log(date, predictions, actuals)
"""
import os, json, time, sys
from pathlib import Path
from datetime import datetime as _dt, timedelta
from typing import Optional

BUS_PATH = Path(__file__).parent / "decision_bus.json"

# ─── 跨平台文件锁 ───
_USE_FCNTL = sys.platform != "win32"
if _USE_FCNTL:
    import fcntl
_LOCK_PATH = BUS_PATH.with_suffix(".lock")

def _acquire_lock():
    if _USE_FCNTL:
        return open(_LOCK_PATH, "w")
    # Windows: 用锁文件 + 重试
    max_wait = 5
    for _ in range(max_wait * 10):
        try:
            if _LOCK_PATH.exists() and time.time() - _LOCK_PATH.stat().st_mtime < max_wait:
                time.sleep(0.1)
                continue
        except Exception:
            pass
        with open(_LOCK_PATH, "w") as f:
            f.write(str(time.time()))
            f.flush()
            os.fsync(f.fileno())
        break
    return _LOCK_PATH

def _release_lock(fd):
    if _USE_FCNTL:
        fcntl.flock(fd, fcntl.LOCK_UN)
        fd.close()
    else:
        try:
            _LOCK_PATH.unlink()
        except Exception:
            pass


class Bus:
    def __init__(self, path: Optional[Path] = None):
        self.path = path or BUS_PATH

    # ─── 读写 ──────────────────────────────────────
    def read(self) -> dict:
        """读取决策总线，不存在则返回初始化结构"""
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data
        except (FileNotFoundError, json.JSONDecodeError):
            return self._init()

    def _init(self) -> dict:
        """初始化决策总线结构"""
        data = {
            "bus_version": "1.0",
            "last_updated": _dt.now().strftime("%Y-%m-%dT%H:%M:%S"),
            "status": "initialized",
            "signals": {
                "policy": {
                    "date": None, "direction": None, "confidence": 0.0,
                    "score": None, "key_events": [], "national_team_action": None,
                    "sources_count": 0, "raw_report_path": None,
                },
                "risk_sentiment": {
                    "date": None, "temperature": None, "temperature_icon": None,
                    "score": None, "vix": None, "vix_change_pct": None,
                    "north_flow_yesterday": None, "north_consecutive_days": None,
                    "margin_balance_change_pct": None, "up_down_ratio": None,
                    "limit_up_count": None, "triggered_thresholds": [],
                    "key_events": [], "sources_count": 0, "raw_report_path": None,
                },
                "technical": {
                    "date": None, "top_scores": [], "market_env": None,
                    "limit_up_total": None, "factors_summary": None,
                },
            },
            "fusion": {
                "date": None, "overall_direction": None, "overall_confidence": 0.0,
                "environment_verdict": None, "recommendations": [],
                "observations": [], "risk_warnings": [],
                "generated_by": None, "generated_at": None,
            },
            "feedback": {
                "accuracy_log": [],
                "last_hit_rate": None,
                "last_window_days": 30,
                "signal_source_performance": {
                    "policy": {"hits": 0, "total": 0, "hit_rate": 0.0},
                    "technical": {"hits": 0, "total": 0, "hit_rate": 0.0},
                    "sentiment": {"hits": 0, "total": 0, "hit_rate": 0.0},
                    "fusion": {"hits": 0, "total": 0, "hit_rate": 0.0},
                },
                "error_patterns": [],
                "last_feedback_update": None,
            },
            "evolution": {
                "last_weight_adjustment": None,
                "weight_history": [],
                "next_evolution_run": None,
            },
        }
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return data

    def write(self, data: dict):
        """原子写入，带文件锁"""
        lock_fd = _acquire_lock()
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                try:
                    original = json.load(f)
                except (json.JSONDecodeError, ValueError):
                    original = {}
        except FileNotFoundError:
            original = {}

        # 保留 history 但只在"写入方没有提供"时才覆盖（防 _write_accuracy_log 被还原）
        old_fb = original.get("feedback", {})
        new_fb = data.get("feedback", {})
        for key in ("accuracy_log", "weight_history", "error_patterns"):
            if key in old_fb and key not in new_fb:
                data.setdefault("feedback", {})[key] = old_fb[key]

        with open(self.path, "w", encoding="utf-8") as f:
            data["last_updated"] = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        _release_lock(lock_fd)

    # ─── 信号写入 ──────────────────────────────────
    def write_signal(self, name: str, payload: dict):
        """写入某维度信号 (policy / risk_sentiment / technical)"""
        data = self.read()
        if name not in data["signals"]:
            return
        data["signals"][name].update(payload)
        data["signals"][name]["date"] = _dt.now().strftime("%Y-%m-%d")
        self.write(data)

    # ─── 推荐写入 ──────────────────────────────────
    def write_fusion(self, payload: dict):
        """写入融合推荐"""
        data = self.read()
        data["fusion"].update(payload)
        data["fusion"]["date"] = _dt.now().strftime("%Y-%m-%d")
        data["fusion"]["generated_at"] = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")
        self.write(data)

    # ─── 反馈写入 ──────────────────────────────────
    def write_accuracy_log(self, date: str, predictions: list,
                           actuals: list, source: str = "fusion"):
        """
        写入准确率日志。
        predictions: [{"code":..., "action":..., "confidence":...}]
        actuals: [{"code":..., "actual_change_pct":..., "hit": true/false}]
        """
        data = self.read()
        fb = data["feedback"]

        # 计算命中率
        hit_count = sum(1 for a in actuals if a.get("hit"))
        total = len(actuals)
        hit_rate = round(hit_count / total, 2) if total else None

        # 追加日志
        entry = {
            "date": date,
            "predictions_count": len(predictions),
            "actuals_count": len(actuals),
            "hit_count": hit_count,
            "total": total,
            "hit_rate": hit_rate,
            "predictions": predictions,
            "actuals": actuals,
        }
        fb["accuracy_log"].append(entry)

        # 截断只保留最近 90 天
        if len(fb["accuracy_log"]) > 90:
            fb["accuracy_log"] = fb["accuracy_log"][-90:]

        # 更新命中率
        fb["last_hit_rate"] = hit_rate
        fb["last_feedback_update"] = _dt.now().strftime("%Y-%m-%dT%H:%M:%S")

        # 更新信号源性能
        perf = fb.setdefault("signal_source_performance", {})
        src = perf.get(source, {"hits": 0, "total": 0, "hit_rate": 0.0})
        src["hits"] += hit_count
        src["total"] += total
        src["hit_rate"] = round(src["hits"] / src["total"], 2) if src["total"] else 0.0
        perf[source] = src

        self.write(data)

    # ─── 便捷读取 ──────────────────────────────────
    def get_signal(self, name: str) -> dict:
        return self.read().get("signals", {}).get(name, {})

    def get_fusion(self) -> dict:
        return self.read().get("fusion", {})

    def get_recent_accuracy(self, days: int = 7) -> list:
        data = self.read()
        cutoff = (_dt.now() - __import__("datetime").timedelta(days=days)).strftime("%Y-%m-%d")
        return [e for e in data["feedback"]["accuracy_log"] if e.get("date", "") >= cutoff]

    def get_signal_performance(self) -> dict:
        return self.read().get("feedback", {}).get("signal_source_performance", {})


if __name__ == "__main__":
    bus = Bus()
    # 自检
    data = bus.read()
    print(f"✅ decision_bus.json 路径: {bus.path}")
    print(f"   状态: {data.get('status')}")
    print(f"   最后更新: {data.get('last_updated')}")

    # 测试写入
    bus.write_signal("risk_sentiment", {
        "temperature": "mid", "temperature_icon": "🟡",
        "score": 55, "vix": 18.5,
    })
    print(f"✅ 测试写入 risk_sentiment 信号成功")

    # 测试读取
    rs = bus.get_signal("risk_sentiment")
    print(f"✅ 读取验证: temperature={rs.get('temperature')}, score={rs.get('score')}")
