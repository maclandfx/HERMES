#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘前政策弹药包 — morning_policy_brief.py
========================================
用途: 交易日盘前推送，30 秒读完，告诉实操者"今天盯哪几个方向"

数据流: 复用 cn_policy_report 的数据源（HTML + 巨潮JSON），
        加"关键词→板块"映射，压缩输出

用法 (cron no-agent 直投 Telegram):
    python morning_policy_brief.py

输出格式示例:
📅 7月15日 盘前政策弹药包
🔥 今日必看3条政策: 标题 + [命中关键词] + → 对应板块
💎 国家队动向: 巨潮权益变动公告
📊 因子引擎 TOP5: 标的 + 综合分 + 资金面/量价维度
📋 关键词热度 TOP5
⚡ 行动暗示: 一句话总结
"""
import os, sys, json, datetime, re, time, urllib.request
from pathlib import Path

# ═══════════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════════
TMP = Path(r"C:/Users/Admin/tmp")
TOOLS_DIR = Path(__file__).parent
ROOT_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))

# 导入 cn_policy_report 的解析函数（复用）
from cn_policy_report import (
    extract_html_titles, score_titles, extract_cninfo_hits, PRIORITY,
    _audit_sources,
)

# 导入决策总线（读取政策/情绪信号做融合）
try:
    from _decision_bus import Bus
    _BUS_AVAILABLE = True
except ImportError:
    _BUS_AVAILABLE = False

# 导入 PIAF 信号卡片模块（两融四区间 + Z-score 背离）
try:
    from piaf_signals import piaf_full_card
    _PIAF_AVAILABLE = True
except ImportError:
    _PIAF_AVAILABLE = False
    piaf_full_card = lambda: ""


def _read_decision_bus_summary() -> dict:
    """读取决策总线，返回融合摘要供盘前推送使用"""
    if not _BUS_AVAILABLE:
        return {}
    try:
        bus = Bus()
        data = bus.read()
        policy = data.get("signals", {}).get("policy", {})
        risk = data.get("signals", {}).get("risk_sentiment", {})
        fusion = data.get("fusion", {})
        fb = data.get("feedback", {}).get("signal_source_performance", {})
        return {
            "policy": policy,
            "risk": risk,
            "fusion": fusion,
            "feedback": fb,
        }
    except Exception:
        return {}


def _build_bus_section() -> list[str]:
    """生成决策总线融合信号段落（插到盘前推送中）"""
    lines = []
    bus_data = _read_decision_bus_summary()
    if not bus_data:
        return lines

    policy = bus_data.get("policy", {})
    risk = bus_data.get("risk", {})
    fb = bus_data.get("feedback", {})

    has_signal = bool(policy.get("direction") or risk.get("temperature"))
    if not has_signal:
        lines.append("🧠 **决策总线**: 信号尚未写入（等待07:30政策日报/08:50情绪雷达运行）")
        lines.append("")
        return lines

    # 构建融合温度
    temp_icon = risk.get("temperature_icon", "⚪")
    temp_label = {"low": "🟢低", "mid": "🟡中", "high": "🔴高", "extreme": "🚨极端"}.get(
        risk.get("temperature"), "⚪未知"
    )
    pol_dir = {"bull": "📈看多", "neutral": "⚪中性", "bear": "📉看空"}.get(
        policy.get("direction", "").lower(), "⚪"
    )
    conf = policy.get("confidence", 0)
    conf_str = f"{conf*100:.0f}%" if conf else ""

    lines.append("🧠 **决策总线融合信号**")
    lines.append("")
    lines.append(f"  **政策面**: {pol_dir} (置信度{conf_str}, 评分{policy.get('score', '—')})")
    if policy.get("national_team_action"):
        nt = {"buy": "💎买入", "sell": "⚠️卖出", "neutral": "⚪观望"}.get(policy.get("national_team_action"), "⚪")
        lines.append(f"  **国家队动作**: {nt}")
    if policy.get("key_events"):
        for evt in policy["key_events"][:2]:
            lines.append(f"  🔑 {evt}")
    lines.append(f"  **市场情绪**: {temp_icon} {temp_label} (评分{risk.get('score', '—')})")
    if risk.get("vix"):
        lines.append(f"  **VIX**: {risk.get('vix')} ({risk.get('vix_change_pct', 0):+.1f}%)")
    if risk.get("north_flow_yesterday"):
        nf = risk.get("north_flow_yesterday")
        lines.append(f"  **北向**: {'+' if nf>0 else ''}{nf:.1f}亿 (连续{risk.get('north_consecutive_days', 0)}日)")
    lines.append("")

    # 反馈命中率
    if fb:
        hit_lines = []
        for src, perf in fb.items():
            rate = perf.get("hit_rate", 0)
            total = perf.get("total", 0)
            if total > 0:
                hit_lines.append(f"{src}:{rate*100:.0f}%({perf.get('hits',0)}/{total})")
        if hit_lines:
            lines.append(f"  📊 **信号命中率(30日)**: {' | '.join(hit_lines)}")
            lines.append("")

    return lines

# ═══════════════════════════════════════════════════
#  关键词 → 板块映射（实操者最关心"这政策利好谁"）
# ═══════════════════════════════════════════════════
SECTOR_MAP = {
    # 新能源 / 电力
    "新型电力系统": "🔌 新型电力系统(电网/调度)",
    "虚拟电厂":      "🔌 虚拟电厂/智能电网",
    "源网荷储":      "🔌 源网荷储一体化",
    "车网互动":      "🔌 V2G车网互动",
    "西电东送":      "🔌 西电东送/跨省输电",
    "需求响应":      "🔌 需求侧响应",
    "分布式":        "🔌 分布式能源/光伏",
    "海上风电":      "🌊 海上风电",
    "核电":          "☢️ 核电",
    "特高压":        "⚡ 特高压输电",
    "储能":          "🔋 新型储能",
    "氢能":          "⛽ 氢能",
    "非化石":        "🌿 非化石能源/清洁能源",
    "碳达峰":        "🌿 碳达峰/碳中和",
    "能源":          "🔋 能源",
    # AI / 算力
    "算力":          "🖥️ 算力/AI基础设施",
    "超算":          "🖥️ 超算中心",
    "人工智能":      "🤖 AI/人工智能",
    "大模型":        "🤖 AI大模型",
    "工业互联网":    "🏭 工业互联网",
    "智能制造":      "🏭 智能制造/工业母机",
    "机器人":        "🤖 人形机器人/机器视觉",
    # 半导体 / 芯片
    "EDA":           "💾 EDA/芯片设计",
    "光刻":          "💾 光刻机/设备",
    "先进制程":      "💾 先进制程",
    "集成电路":      "💾 集成电路/芯片",
    "半导体":        "💾 半导体",
    "芯片":          "💾 芯片",
    "自主可控":      "🛡️ 自主可控/国产化",
    "国产化":        "🛡️ 国产化替代",
    # 低空 / 航天
    "低空":          "✈️ 低空经济/通航",
    "商业航天":      "🚀 商业航天",
    "低轨星座":      "🛰️ 低轨卫星互联网",
    "卫星":          "🛰️ 卫星/航天",
    "航天":          "🚀 航天军工",
    "国防":          "🛡️ 国防军工",
    # 国家资本 / 大基金
    "大基金":        "💰 国家大基金/半导体",
    "汇金":          "🏦 汇金增持",
    "证金":          "🏦 证金持股",
    "诚通":          "🏦 诚通/国新",
    "国新":          "🏦 国新/国家队",
    "国家队":        "🏦 国家队(大基金/汇金/证金)",
    "央企":          "🏢 央企/国企改革",
    # 通用利好
    "十五五":        "📋 十五五规划(全市场)",
    "改革":          "📋 改革",
    "投资":          "📈 投资拉动",
    "战略":          "📋 国家战略",
    "建设":          "🏗️ 基础设施建设",
    "标准":          "📏 行业标准/规范",
}

# ═══════════════════════════════════════════════════
#  板块标签去重 + 排序（去泛化"能源"等）
# ═══════════════════════════════════════════════════
def kw_to_sectors(kw_list):
    """将命中关键词列表转为去重排序的板块标签。"""
    # 去泛化：如果一个关键词有更具体的派生关键词已命中，不输出泛化词
    # e.g. "储能"在时，不额外输出"能源"
    concrete_set = {
        "新型电力系统", "虚拟电厂", "源网荷储", "车网互动", "西电东送",
        "海上风电", "核电", "特高压", "储能", "氢能",
        "EDA", "光刻", "先进制程", "集成电路", "算力", "超算",
        "低空", "商业航天", "低轨星座", "卫星",
        "大基金", "汇金", "证金", "诚通", "国新", "国家队",
    }
    concrete_hit = any(k in kw_list for k in concrete_set)
    filtered = [k for k in kw_list if k not in ("能源", "发展", "产业", "意见", "办法", "通知") or k in kw_list]
    # 只保留具体关键词对应板块
    sectors = []
    seen_sec = set()
    for kw in kw_list:
        sec = SECTOR_MAP.get(kw)
        if sec and sec not in seen_sec:
            seen_sec.add(sec)
            sectors.append(sec)
    return sectors


# ═══════════════════════════════════════════════════
#  读取因子 TOP5
# ═══════════════════════════════════════════════════
FACTORS_PATH = ROOT_DIR / "reports" / "追踪" / "factors_raw.json"
WEIGHTS = {"A1_big_net_ratio": 15, "A3_strength": 13, "A2_consecutive_days": 12,
           "A4_north_flow": 10, "B4_rel_strength": 10, "B1_divergence": 8,
           "B3_gap": 8, "B5_trend": 8, "B2_limit_quality": 5, "B6_volatility": 5}
STOCK_NAMES = {
    "600118": "中国卫星", "300418": "昆仑万维", "600288": "大恒科技",
    "688135": "利扬芯片", "688175": "高凌信息", "603296": "华勤技术",
    "603893": "瑞芯微", "688802": "沐曦股份", "000518": "四环生物",
    "301516": "中远通", "300454": "深信服", "688722": "同益中",
    "688039": "当虹科技", "001395": "亚联机械", "600992": "贵绳股份",
    "300649": "杭州园林", "002414": "高德红外", "002490": "山东墨龙",
    "000779": "甘咨询", "603339": "四方科技",
}


def load_factors_top(n=5):
    """从 factors_raw.json 加载 TOP-N 标的综合分。"""
    if not FACTORS_PATH.exists():
        return []
    try:
        factors = json.loads(FACTORS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []
    scores = []
    for code, f in factors.items():
        if "error" in f:
            continue
        total = sum(f.get(k, 50) * w for k, w in WEIGHTS.items()) / sum(WEIGHTS.values())
        name = STOCK_NAMES.get(code, code)
        # 维度得分：资金面(A组) vs 技术面(B组)
        a_scores = [f.get(a, 50) for a in ["A1_big_net_ratio", "A2_consecutive_days", "A3_strength", "A4_north_flow"]]
        b_scores = [f.get(b, 50) for b in ["B1_divergence", "B2_limit_quality", "B3_gap", "B4_rel_strength", "B5_trend"]]
        fund_face = round(sum(a_scores) / len(a_scores), 1)
        tech_face = round(sum(b_scores) / len(b_scores), 1)
        scores.append((name, code, round(total, 1), fund_face, tech_face))
    scores.sort(key=lambda x: x[2], reverse=True)
    return scores[:n]


# ═══════════════════════════════════════════════════
#  生成弹药包
# ═══════════════════════════════════════════════════
def generate_brief():
    now = datetime.datetime.now()
    now_str = now.strftime("%Y-%m-%d")
    is_weekday = now.weekday() < 5

    lines = []
    lines.append(f"# 📅 {now_str} 盘前政策弹药包")
    lines.append(f"⏰ {now.strftime('%H:%M')}  |  {'交易日' if is_weekday else '非交易日(参考用)'}")
    lines.append("")

    # ===== P0 数据源审计 =====
    sources_ok, missing_files = _audit_sources()
    if not sources_ok:
        missing_str = ", ".join(missing_files)
        lines.append("🚨 **数据源缺失**: 政策HTML未到位 (`" + missing_str + "`)，今日弹药包不完整")
        lines.append("")
        lines.append("---")
        lines.append("")

    # ===== 1. 今日必看政策 =====
    lines.append("## 🔥 今日必看政策")
    lines.append("")
    sources = [("ndrc_d.html", "📋 发改委"), ("miit_d.html", "📋 工信部"), ("nea_d.html", "📋 能源局")]
    all_scored = []
    for fname, label in sources:
        titles = extract_html_titles(TMP / fname)
        scored = score_titles(titles)
        for title, score, kws in scored:
            sectors = kw_to_sectors(kws)
            all_scored.append((title, score, kws, sectors, label))

    all_scored.sort(key=lambda x: -x[1])
    top_n = 5

    if all_scored:
        lines.append(f"> {len(all_scored)} 条政策触达 · 命中最高: {', '.join(all_scored[0][2][:4])}")
        lines.append("")
        lines.append("| # | 政策 | 触达板块 | 来源 |")
        lines.append("|--:|------|----------|------|")
        for idx, (title, score, kws, sectors, label) in enumerate(all_scored[:top_n], 1):
            t = (title[:42] + "…") if len(title) > 42 else title
            sec = "、".join(sectors[:3]) if sectors else "—"
            lines.append(f"| {idx} | **{t}** | {sec} | {label} |")
    else:
        lines.append("📭 今日无政策更新（或数据源缺失）")
    lines.append("")

    # ===== 2. 板块热度排行 =====
    lines.append("## 📊 板块热度排行（按政策关键词命中）")
    lines.append("")
    # 汇总所有板块出现次数
    sector_count = {}
    for _, _, _, sectors, _ in all_scored:
        for s in sectors:
            sector_count[s] = sector_count.get(s, 0) + 1
    if sector_count:
        hot = sorted(sector_count.items(), key=lambda x: -x[1])
        lines.append("| 板块 | 政策触达次数 |")
        lines.append("|------|:----------:|")
        for sec, cnt in hot[:5]:
            lines.append(f"| {sec} | {cnt} |")
    else:
        lines.append("📭 无板块触达数据")
    lines.append("")

    # ===== 3. 国家队动向 =====
    lines.append("## 💎 国家队动向")
    lines.append("")
    cninfo_hits = extract_cninfo_hits()
    if cninfo_hits:
        for h in cninfo_hits[:3]:
            action = "💎" if "权益变动" in str(h.get("title", "")) else "📊"
            title = h.get("title", "")
            code = h.get("code", "")
            name = h.get("name", "")
            date = h.get("date", "")
            lines.append(f"- {action} **{name}**({code}) — {title[:50]} ({date})")
    else:
        lines.append("📭 暂无巨潮权益变动公告")
    lines.append("")

    # ===== 4. 因子引擎 TOP5 =====
    lines.append("## 📈 因子引擎 TOP5（收盘数据）")
    lines.append("")
    top_factors = load_factors_top(5)
    if top_factors:
        lines.append("| 排名 | 标的 | 综合分 | 资金面 | 技术面 |")
        lines.append("|:----:|------|:-----:|:------:|:------:|")
        for i, (name, code, total, ff, tf) in enumerate(top_factors):
            emoji = "🟢" if total >= 70 else "🟡" if total >= 55 else "⚪"
            lines.append(f"| {i+1} | **{name}**({code}) | {total} {emoji} | {ff} | {tf} |")
    else:
        lines.append("📭 因子数据未更新")
    lines.append("")

    # ===== 5. 决策总线融合信号（读 07:30 政策日报 + 情绪雷达的产物）=====
    bus_section = _build_bus_section()
    if bus_section:
        lines.append("## 🧠 决策总线融合信号")
        lines.append("")
        lines.extend(bus_section)
        lines.append("")

    # ===== 6. PIAF 信号卡片（两融四区间 + Z-score 背离）=====
    piaf_card = piaf_full_card()
    if piaf_card:
        lines.append("## 📊 PIAF 两融与Z-score信号")
        lines.append("")
        lines.append(piaf_card)
        lines.append("")

    # ===== 7. 行动暗示（结合决策总线信号）=====
    lines.append("## ⚡ 行动暗示")
    lines.append("")
    # 读取决策总线的融合推荐
    bus_data = _read_decision_bus_summary()
    fusion = bus_data.get("fusion", {})
    if fusion.get("recommendations"):
        rec = fusion["recommendations"][0]
        lines.append(f"> 💎 **决策建议**: {rec.get('name', rec.get('code','?'))}({rec.get('code','?')}) — {rec.get('action','?')}")
        lines.append(f"> 理由: {rec.get('reason','?')[:80]}")
    elif fusion.get("risk_warnings"):
        for w in fusion["risk_warnings"][:2]:
            lines.append(f"> ⚠️ {w}")
    else:
        # 回退：基于政策+因子给出 1-2 句话
        hot_sectors = list(sector_count.keys())[:3] if sector_count else []
        if hot_sectors and top_factors:
            sec_str = "、".join(hot_sectors)
            lines.append(f"> 🔍 今日重点盯 {sec_str} 板块方向")
            best_name = top_factors[0][0]
            lines.append(f"> 📊 因子评分最高标的: **{best_name}** (综合分{top_factors[0][2]})")
        elif all_scored and not top_factors:
            sec_str = "、".join(kw_to_sectors(all_scored[0][2])[:3])
            lines.append(f"> 🔍 政策面看 {sec_str}，因子数据待盘后更新")
        else:
            lines.append("> ⚪ 今日政策面平静，无明确方向，维持观望")
    lines.append("")
    lines.append("---")
    lines.append(f"*数据: 发改委/工信部/能源局官网 + 巨潮资讯网 + 因子引擎 + 决策总线*")
    lines.append(f"*生成: {now.strftime('%Y-%m-%d %H:%M:%S')}*")

    return "\n".join(lines)


if __name__ == "__main__":
    print(generate_brief())
