#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
伙伴日志 — 决策追踪 + 学习反馈
=================================
记录每次操作的理由、止损止盈、结果；
用于月末复盘 + 约束动态调整 + 纠偏提醒。
"""
import os, json
from pathlib import Path
from datetime import datetime as _dt

LOG_DIR = Path(__file__).parent / "partner_data"
LOG_DIR.mkdir(parents=True, exist_ok=True)
DECISION_LOG = LOG_DIR / "decisions.json"
LEARNING_LOG = LOG_DIR / "learning.json"


def load_json(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default


def save_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ═══════════════════════════════════════════════════
#  记录一次操作决策
# ═══════════════════════════════════════════════════
def log_decision(code: str, name: str, action: str, reason: str,
                 entry_price: float, stop_loss: float, target: float,
                 position_pct: float = 0, result: str = "") -> dict:
    """
    action: buy / sell / hold / skip
    result: 可选，填"已止损/已止盈/观望/..."
    """
    record = {
        "date": _dt.now().strftime("%Y-%m-%d"),
        "time": _dt.now().strftime("%H:%M"),
        "code": code, "name": name,
        "action": action,
        "reason": reason,
        "entry": entry_price,
        "stop_loss": stop_loss,
        "target": target,
        "position_pct": position_pct,
        "result": result,
    }
    decisions = load_json(DECISION_LOG, [])
    decisions.append(record)
    save_json(DECISION_LOG, decisions)
    return record


# ═══════════════════════════════════════════════════
#  记录学习反馈（用户告诉我对错）
# ═══════════════════════════════════════════════════
def log_feedback(decision_index: int, correct: bool, comment: str = ""):
    """
    decision_index: decisions 数组里的索引
    correct: True=我对了 / False=我错了
    comment: 用户补充说明
    """
    learning = load_json(LEARNING_LOG, [])
    learning.append({
        "date": _dt.now().strftime("%Y-%m-%d"),
        "decision_index": decision_index,
        "correct": correct,
        "comment": comment,
    })
    save_json(LEARNING_LOG, learning)


# ═══════════════════════════════════════════════════
#  读取近期记录
# ═══════════════════════════════════════════════════
def recent_decisions(days: int = 30) -> list:
    decisions = load_json(DECISION_LOG, [])
    cutoff = (_dt.now() - _dt(days=days)).strftime("%Y-%m-%d")
    return [d for d in decisions if d.get("date", "") >= cutoff]


def win_rate() -> float:
    """返回近期正确率"""
    learning = load_json(LEARNING_LOG, [])
    if not learning:
        return 0.0
    recent = [l for l in learning if l.get("date", "") >= (_dt.now() - _dt(days=30)).strftime("%Y-%m-%d")]
    if not recent:
        return 0.0
    correct = sum(1 for l in recent if l["correct"])
    return correct / len(recent)


# ═══════════════════════════════════════════════════
#  自我迭代：根据反馈动态调整约束
# ═══════════════════════════════════════════════════
DEFAULT_CONSTRAINTS = {
    "max_daily_position": 30,
    "max_single_position": 15,
    "max_holding_days": 3,
    "buy_time": "14:30后",
    "stop_loss_required": True,
}

def adaptive_constraints() -> dict:
    """根据历史准确率调整约束强度"""
    wr = win_rate()
    rules = dict(DEFAULT_CONSTRAINTS)
    if wr >= 0.7:
        # 准确率高，可适度放松
        rules["max_single_position"] = 20
    elif wr <= 0.3:
        # 准确率低，收紧
        rules["max_daily_position"] = 15
        rules["max_single_position"] = 8
    return rules


if __name__ == "__main__":
    print("=== 伙伴日志状态 ===")
    decisions = load_json(DECISION_LOG, [])
    learning = load_json(LEARNING_LOG, [])
    print(f"决策记录: {len(decisions)} 条")
    print(f"学习反馈: {len(learning)} 条")
    print(f"近期正确率: {win_rate():.0%}")
    print(f"自适应约束: {adaptive_constraints()}")
