#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盘中预警推送引擎 — tdx_push_runner.py
=======================================
用途: 读取 blk_monitor 写入 telegram_queue/ 的预警文件，
     逐条推送到 Telegram，处理后移入 done/

数据流:
  blk_monitor.py → telegram_queue/XXX_HHMMSS.txt → tdx_push_runner.py → Telegram

用法 (cron 定期调用，盘中每 5 分钟):
    python tdx_push_runner.py
"""
import os, sys, json, time, urllib.request
from pathlib import Path
from datetime import datetime as _dt

# ═══════════════════════════════════════════════════
#  Telegram 配置（与 push_all_reports.py 一致）
# ═══════════════════════════════════════════════════
TOKEN = get_telegram_token()
CHAT_ID = "8673372605"
PROXY = "127.0.0.1:7890"
MAX_MSG = 3500

# ═══════════════════════════════════════════════════
#  路径
# ═══════════════════════════════════════════════════
TOOLS_DIR = Path(__file__).parent
QUEUE_DIR = TOOLS_DIR / "tdx_connector" / "telegram_queue"
DONE_DIR = QUEUE_DIR / "done"
DONE_DIR.mkdir(parents=True, exist_ok=True)

# 解析股票代码 → 中文名（与 tracker 一致）
STOCK_NAMES = {
    "600118": "中国卫星", "300418": "昆仑万维", "600288": "大恒科技",
    "688135": "利扬芯片", "688175": "高凌信息", "603296": "华勤技术",
    "603893": "瑞芯微", "688802": "沐曦股份", "000518": "四环生物",
    "301516": "中远通", "300454": "深信服", "688722": "同益中",
    "688039": "当虹科技", "001395": "亚联机械", "600992": "贵绳股份",
    "300649": "杭州园林", "002414": "高德红外", "002490": "山东墨龙",
    "000779": "甘咨询", "603339": "四方科技",
}


def is_valid_alert(content: str) -> bool:
    """判断预警内容是否有效（过滤空模板/错误堆栈/fallback 废卡片）"""
    if not content or len(content) < 100:
        return False
    # 无效模板特征：名称=未知 + N级 + 0分 + ¥0.00（批量评估失败 fallback 产物）
    if "未知" in content and "N级" in content:
        return False
    if "0分" in content and "¥0.00" in content and "观望为主" in content:
        return False
    # fallback 废卡片：整段是 eval_smart 报错堆栈
    if "[ERROR] 评估失败" in content and "Traceback" in content:
        return False
    if "[ERROR] 未获取到" in content:
        return False
    # 必须有中文字符（真实股票名称）才算有效
    import re
    if not re.search(r"[\u4e00-\u9fff]", content):
        return False
    return True


def build_opener():
    """带代理的 urllib opener"""
    proxy = urllib.request.ProxyHandler({
        "http": f"http://{PROXY}",
        "https": f"http://{PROXY}",
    })
    return urllib.request.build_opener(proxy)


def send_tg(msg_text):
    """发送消息到 Telegram，支持自动分块 + 重试"""
    opener = build_opener()
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"

    # 按行分块，每块 ≤ MAX_MSG
    lines = msg_text.split("\n")
    chunks = []
    current, length = [], 0
    for line in lines:
        if length + len(line) > MAX_MSG and current:
            chunks.append("\n".join(current))
            current, length = [line], len(line)
        else:
            current.append(line)
            length += len(line)
    if current:
        chunks.append("\n".join(current))

    sent = 0
    for i, chunk in enumerate(chunks):
        for attempt in range(3):
            try:
                data = json.dumps({
                    "chat_id": CHAT_ID,
                    "text": chunk,
                    "parse_mode": "Markdown",
                    "disable_web_page_preview": True,
                }).encode("utf-8")
                req = urllib.request.Request(
                    url, data=data,
                    headers={"Content-Type": "application/json"},
                )
                resp = opener.open(req, timeout=20)
                result = json.loads(resp.read())
                if result.get("ok"):
                    sent += 1
                    break
                else:
                    print(f"  ❌ TG API 拒绝: {result}")
            except Exception as e:
                if attempt < 2:
                    time.sleep(2)
                else:
                    print(f"  ❌ 发送失败: {e}")
        time.sleep(1)
    return sent


def enrich_message(content, code):
    """给预警消息加表头（标的名称 + 时间戳），提升可读性"""
    name = STOCK_NAMES.get(code, "")
    ts = _dt.now().strftime("%Y-%m-%d %H:%M")

    # 如果原内容已有完整标题（含标的名称），直接保留
    if content.startswith("#") and code in content and "(" in content and ")" in content:
        # 已有 name(code) 格式，跳过替换
        return content

    header = f"# 🚨 盘中预警\n\n**{name}**(`{code}`) — {ts}\n\n"
    if content.startswith("#"):
        lines = content.split("\n")
        lines[0] = header.rstrip()
        return "\n".join(lines)
    return header + content


def _is_today_file(fpath: Path) -> bool:
    """判断文件是否为当天生成（用文件名 HHMMSS 后缀 vs 当前时间，避免 mtime 被 WSL 假时间污染）"""
    stem = fpath.stem
    # 文件名格式: CODE_HHMMSS 或 CODE_v2_HHMMSS
    import re as _re
    # 文件名格式: CODE_HHMMSS(6位) 或 CODE_HHMMSSNN(8位+序号)
    m = _re.search(r"(\d{6,8})$", stem)
    if not m:
        return False
    hms = m.group(1)
    h, mi, s = int(hms[:2]), int(hms[2:4]), int(hms[4:6])
    if h < 0 or h > 23 or mi < 0 or mi > 59 or s < 0 or s > 59:
        return False
    now = _dt.now()
    now_min = now.hour * 60 + now.minute
    file_min = h * 60 + mi
    # 当日新预警：文件时间戳 ≤ 当前时间（盘中滚动生成），±5 分钟容差
    return file_min <= now_min + 5


def process_queue():
    """扫描队列、推送、归档。无预警时不输出（避免 cron 推送空消息）。"""
    if not QUEUE_DIR.exists():
        return

    files = sorted(f for f in QUEUE_DIR.glob("*.txt") if f.parent == QUEUE_DIR)
    if not files:
        return

    # 分离：当天新预警 vs 历史积压
    today_files = [f for f in files if _is_today_file(f)]
    history_files = [f for f in files if not _is_today_file(f)]

    # 历史积压：静默归档，不推送
    if history_files:
        for fpath in history_files:
            try:
                done_path = DONE_DIR / fpath.name
                fpath.rename(done_path)
            except Exception:
                pass

    if not today_files:
        return

    # 有预警：输出标题 + 处理
    now = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"📡 盘中预警推送引擎 — {now}")
    print("=" * 50)

    processed = 0
    for fpath in today_files:
        code = fpath.stem.split("_")[0]
        try:
            content = fpath.read_text(encoding="utf-8")
        except Exception as e:
            print(f"  ⚠️ 读取失败 {fpath.name}: {e}")
            continue

        # 无效内容过滤：跳过空模板 / eval_smart 报错堆栈 / fallback 废卡片
        if not is_valid_alert(content):
            try:
                done_path = DONE_DIR / fpath.name
                fpath.rename(done_path)
            except Exception:
                pass
            continue

        # 富化消息
        enriched = enrich_message(content, code)

        # 推送
        sent = send_tg(enriched)
        if sent > 0:
            print(f"  ✅ {fpath.name}: 推送完成 ({sent} 条消息)")
            processed += 1
        else:
            print(f"  ❌ {fpath.name}: 推送失败")

        # 归档
        try:
            done_path = DONE_DIR / fpath.name
            fpath.rename(done_path)
        except Exception as e:
            print(f"  ⚠️ 归档失败: {e}")

    print(f"\n✅ 本轮处理 {processed} 条预警")


if __name__ == "__main__":
    process_queue()
