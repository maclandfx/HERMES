from env_loader import get_tushare_token
"""
统一评估函数 — 全息宇宙降维投影的如实观照

核心原则：
- 一个统一函数，不分阶段、不分层级
- 所有数据平等进入，不偏任何维度
- 权重由 accuracy_log 自动修正，不由设计师决定
- 输出：P(上涨)概率 + 共振连续值 + 湮灭信号 + 振动周期状态
- 进化内嵌在每次调用中，不需要外部脚本

不做"解读"，只输出数字。用户自己升维还原。
"""
import os
import sys
import json
import time
import numpy as np
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)

import tushare as ts
ts.set_token(get_tushare_token())
pro = ts.pro_api()

from astock_bridge import tencent_quote
from weekly_analysis import analyze_weekly
from tdx_core import calc_all_tdx_signals

# 进化权重持久化路径
WEIGHT_PATH = os.path.join(HERE, 'evolution_weights.json')
ACCURACY_PATH = os.path.join(HERE, 'decision_bus.json')


# ═══════════════════════════════════════════════════
#  进化权重系统 — 内嵌在每次调用中
# ═══════════════════════════════════════════════════

def load_weights() -> dict:
    """加载进化权重（accuracy_log 自动修正后的结果）"""
    if os.path.exists(WEIGHT_PATH):
        try:
            with open(WEIGHT_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    # 默认权重（五行对称，金水50%, 火20%, 土木30%）
    return {
        "version": 1,
        "weights": {
            "price_momentum":    0.25,   # 金 — 量价动量
            "turnover_premium":  0.20,   # 火 — 换手活跃度
            "capital_inflow":    0.25,   # 水 — 资金流入
            "sentiment_diffusion":0.15,  # 土 — 情绪扩散（居中）
            "vol_price_divergence":0.15, # 木 — 技术背离
        },
        "resonance_decay": 0.95,   # 共振衰减系数（高维信念）
        "cycle_sensitivity": 0.3,  # 振动周期敏感度
        "last_updated": datetime.now().strftime('%Y-%m-%dT%H:%M:%S'),
    }


def save_weights(w: dict):
    w["last_updated"] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
    with open(WEIGHT_PATH, 'w', encoding='utf-8') as f:
        json.dump(w, f, ensure_ascii=False, indent=2)


def load_accuracy_log() -> list:
    """加载 accuracy_log（进化循环的燃料）"""
    if not os.path.exists(ACCURACY_PATH):
        return []
    try:
        with open(ACCURACY_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get("feedback", {}).get("accuracy_log", [])
    except Exception:
        return []


def write_accuracy_log(entry: dict):
    """写入 accuracy_log（进化循环的数据）"""
    log = load_accuracy_log()
    log.append(entry)
    # 保留最近200条
    if len(log) > 200:
        log = log[-200:]
    if os.path.exists(ACCURACY_PATH):
        with open(ACCURACY_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
        data.setdefault("feedback", {})["accuracy_log"] = log
        with open(ACCURACY_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


def adjust_weights_from_history():
    """根据 accuracy_log 历史，自动调整权重（进化引擎内嵌）"""
    log = load_accuracy_log()
    if len(log) < 10:
        return  # 数据不足，不调整
    w = load_weights()
    # 简单进化：统计每个因子在过去准确预测中的贡献，微调权重
    # 如果某因子多次出现在高准确率记录中，适度提升其权重
    hit_count = {k: 0 for k in w["weights"]}
    total_evals = 0
    for entry in log:
        total_evals += 1
        if entry.get("is_correct"):
            for factor in entry.get("contributing_factors", []):
                if factor in hit_count:
                    hit_count[factor] += 1
    if total_evals == 0:
        return
    # 归一化调整
    adjustment = {}
    for k in w["weights"]:
        if hit_count[k] > 0:
            ratio = hit_count[k] / total_evals
            # 小幅调整（防止震荡）
            adjustment[k] = w["weights"][k] * (1 + ratio * 0.1)
        else:
            adjustment[k] = w["weights"][k] * 0.99  # 无贡献的因子小幅衰减
    # 重归一化
    total = sum(adjustment.values())
    for k in adjustment:
        w["weights"][k] = round(adjustment[k] / total, 4)
    save_weights(w)


# ═══════════════════════════════════════════════════
#  统一评估函数
# ═══════════════════════════════════════════════════

def unified_eval(codes: list, end_date: str = None) -> dict:
    """
    统一评估：一个函数，所有数据平等进入，输出概率 + 共振 + 湮灭 + 周期状态
    输入：纯数字代码列表 ["000608", "300209"]
    输出：{code: {P(上涨), 共振, 湮灭, 周期, ...}}
    """
    if end_date is None:
        end_date = _get_last_trade_date()

    weights = load_weights()
    w = weights["weights"]

    # 并行拉取所有数据（不分阶段，所有数据平等）
    results = {}
    for code in codes:
        pure = code.split('.')[0] if '.' in code else code
        ts_code = f"{pure}{'SH' if pure.startswith(('60','68','90','11','13')) else 'SZ'}"

        result = {"code": pure, "ts_code": ts_code}

        # 拉取每日数据
        try:
            d = pro.daily(ts_code=ts_code, start_date='20240101', end_date=end_date)
            if d is not None and not d.empty:
                d = d.sort_values('trade_date').reset_index(drop=True)
                result["daily"] = d
        except Exception:
            result["daily"] = None

        # 拉取资金流
        try:
            mf = pro.moneyflow(ts_code=ts_code, start_date='20240101', end_date=end_date)
            result["moneyflow"] = mf if mf is not None and not mf.empty else None
        except Exception:
            result["moneyflow"] = None

        # 拉取股东户数
        try:
            h = pro.stk_holdernumber(ts_code=ts_code, start_date="20250101", end_date=end_date)
            if h is not None and not h.empty:
                h = h.sort_values("ann_date", ascending=False)
                result["holders"] = {
                    "count": int(h.iloc[0].get("holder_num", 0)),
                    "change_pct": float(h.iloc[0].get("change_pct", 0)) if len(h) > 1 else 0,
                }
        except Exception:
            result["holders"] = None

        # 拉取周线
        try:
            result["weekly"] = analyze_weekly(ts_code, end_date=end_date)
        except Exception:
            result["weekly"] = None

        # 拉取通达信
        if result.get("daily") is not None:
            try:
                result["tdx"] = calc_all_tdx_signals(result["daily"])
            except Exception:
                result["tdx"] = None
        else:
            result["tdx"] = None

        # 拉取腾讯实时行情（最后获取，实时性最强）
        try:
            q = tencent_quote([pure])
            result["tencent"] = q.get(pure, None)
        except Exception:
            result["tencent"] = None

        results[pure] = result

    # 对每只股票计算统一评分（一个函数，不分维度）
    for pure, r in results.items():
        _compute_scores(r, w, weights)

    return results


def _get_last_trade_date() -> str:
    try:
        cal = pro.trade_cal(exchange='SSE',
            start_date=(datetime.now() - timedelta(days=10)).strftime('%Y%m%d'),
            end_date=datetime.now().strftime('%Y%m%d'), is_open='1')
        if cal is not None and not cal.empty:
            return sorted(cal['cal_date'].tolist())[-1]
    except Exception:
        pass
    return datetime.now().strftime('%Y%m%d')


def _to_series(df, col):
    """安全转 pandas 数值序列"""
    if df is None or df.empty:
        return None
    import pandas as pd
    return pd.to_numeric(df[col], errors='coerce')


def _normalize(x):
    """归一化到 [-1, 1]"""
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return 0.0
    return max(-1.0, min(1.0, float(x)))


def _compute_scores(r: dict, weights: dict, meta: dict):
    """
    统一评分计算 — 所有数据平等进入，一个函数
    输出：P(上涨)概率 + 共振连续值 + 湮灭信号强度 + 振动周期状态
    """
    d = r.get("daily")
    mf = r.get("moneyflow")
    q = r.get("tencent") or {}
    tdx = r.get("tdx") or {}
    weekly = r.get("weekly") or {}

    if d is None or d.empty:
        r["P_up"] = 0.5
        r["resonance"] = 0.0
        r["annihilation"] = 0.0
        r["cycle_state"] = "无数据"
        r["factors"] = {}
        return

    import pandas as pd
    close = _to_series(d, 'close')
    vol = _to_series(d, 'vol')
    pct_chg = _to_series(d, 'pct_chg')

    # ══ 5个平等因子（无维度之分，无层级之分）══
    factors = {}

    # 因子1：价格动量
    ret_5d = pct_chg.head(5).sum() if len(pct_chg) >= 5 else 0
    ret_20d_avg = pct_chg.head(20).mean() * 5 if len(pct_chg) >= 20 else ret_5d
    if abs(ret_20d_avg) > 0.1:
        pm = (ret_5d - ret_20d_avg) / abs(ret_20d_avg)
    else:
        pm = ret_5d / 10
    factors["price_momentum"] = _normalize(pm)

    # 因子2：换手率溢价
    turnover = vol / (close * 1e8) if len(close) > 0 else None
    if turnover is not None and len(turnover) >= 20:
        to_avg = turnover.head(20).mean()
        to_latest = turnover.iloc[0]
        to_premium = (to_latest - to_avg) / to_avg if to_avg > 0 else 0
    else:
        to_premium = 0
    factors["turnover_premium"] = _normalize(to_premium)

    # 因子3：资金流入（moneyflow 缺失用价格动量兜底，不伪造）
    if mf is not None and not mf.empty and 'net_mf_amount' in mf.columns:
        mf_5d = mf.head(5)
        net_mf = mf_5d['net_mf_amount'].sum()
        amt_5d = (mf_5d['buy_amount'].sum() + mf_5d['sell_amount'].sum()
                  if 'buy_amount' in mf_5d.columns and 'sell_amount' in mf_5d.columns else 0)
        capital = net_mf / amt_5d if amt_5d > 0 else factors["price_momentum"]
    else:
        capital = factors["price_momentum"]
    factors["capital_inflow"] = _normalize(capital)

    # 因子4：情绪扩散
    if vol is not None and len(vol) >= 10:
        vol_ma10 = vol.head(10).mean()
        high_vol_days = sum(vol.head(10) > vol_ma10 * 1.5)
        diffusion = (high_vol_days / 10) * 2 - 1
    else:
        diffusion = 0
    factors["sentiment_diffusion"] = _normalize(diffusion)

    # 因子5：量价背离
    latest_pct = pct_chg.iloc[0] if len(pct_chg) > 0 else 0
    vol_5avg = vol.head(5).mean() if len(vol) >= 5 else 1
    vol_ratio_latest = vol.iloc[0] / vol_5avg if vol_5avg > 0 else 1
    if latest_pct > 1 and vol_ratio_latest > 1.2:
        vp = 1.0
    elif latest_pct > 1 and vol_ratio_latest < 0.8:
        vp = -0.5
    elif latest_pct < -1 and vol_ratio_latest > 1.5:
        vp = -1.0
    else:
        vp = 0
    factors["vol_price_divergence"] = _normalize(vp)

    r["factors"] = factors

    # ══ 统一评分（SBI）：5个因子 × 进化权重 ══
    sbi = sum(weights[k] * factors[k] for k in weights) * 100
    r["sbi"] = round(max(-100, min(100, sbi)), 1)

    # ══ 共振连续值（0~1，不是0/1/2/3/4档位）══
    # 共振 = 多层数据一致性
    resonance_signals = []
    # 周线趋势
    wk = weekly.get('trend', {}) if weekly else {}
    wk_score = wk.get('score', 0)
    if wk_score > 0:
        resonance_signals.append(min(1, wk_score / 55))
    else:
        resonance_signals.append(0)
    # 通达信环境共振
    env = tdx.get('env_resonance', {})
    lv = env.get('resonance_level', 0)
    if lv > 0:
        resonance_signals.append(lv / 4.0)
    else:
        resonance_signals.append(0)
    # SBI 方向
    if abs(sbi) > 20:
        resonance_signals.append(min(1, abs(sbi) / 50))
    else:
        resonance_signals.append(0)
    # 量价一致性
    vol_sig = 1 if factors["turnover_premium"] > 0 and factors["price_momentum"] > 0 else 0
    resonance_signals.append(vol_sig)

    resonance = np.mean(resonance_signals) if resonance_signals else 0
    # 应用进化衰减系数（高维信念：共振不是永久的）
    decay = meta.get("resonance_decay", 0.95)
    r["resonance"] = round(resonance * decay, 3)

    # ══ 湮灭信号强度 ══
    vol_ratio = q.get("vol_ratio", 1.0)
    amplitude = q.get("amplitude_pct", 0)
    # B6 波动率近似 = 振幅
    annihil = abs(vol_ratio - 1) * max(0.01, amplitude / 5.0)
    r["annihilation"] = round(annihil, 3)

    # ══ 振动周期状态 ══
    # 判断：重生中 / 运动中 / 终结中
    cycle_params = meta.get("cycle_sensitivity", 0.3)
    holder = r.get("holders") or {}
    holder_chg = holder.get("change_pct", 0) if holder else 0

    if annihil > 0.8:
        cycle_state = "湮灭临界"
    elif annihil > 0.5 and factors["vol_price_divergence"] < -0.3:
        cycle_state = "周期终结中"
    elif factors["price_momentum"] > 0.3 and holder_chg < -5:
        cycle_state = "重生中（筹码集中）"
    elif resonance > 0.6:
        cycle_state = "共振运动中"
    else:
        cycle_state = "震荡等待"
    r["cycle_state"] = cycle_state

    # ══ P(上涨)概率 ══
    # 物质因子 vs 反物质因子
    positive_factors = [
        factors.get("price_momentum", 0),
        factors.get("capital_inflow", 0),
        factors.get("resonance", 0) * 2,  # 共振放大
    ]
    negative_factors = [
        -min(0, factors.get("vol_price_divergence", 0)),
        -min(0, factors.get("turnover_premium", 0)),
        annihil * 0.5,  # 湮灭风险
    ]
    positive_sum = sum(max(0, f) for f in positive_factors)
    negative_sum = sum(max(0, f) for f in negative_factors)
    denominator = positive_sum + negative_sum
    p_up = positive_sum / denominator if denominator > 0 else 0.5
    # 边界：SBI 极端值拉回
    if sbi > 80:
        p_up = max(p_up, 0.85)
    elif sbi < -80:
        p_up = min(p_up, 0.15)
    r["P_up"] = round(p_up, 3)


# ═══════════════════════════════════════════════════
#  格式化输出（如实观照：只输出数字，不输出解读）
# ═══════════════════════════════════════════════════

def format_probability_card(code: str, r: dict, name: str = None) -> str:
    """渲染概率卡片 — 只输出数字，不注入主观期待"""
    p = r.get("P_up", 0.5)
    resonance = r.get("resonance", 0)
    annihil = r.get("annihilation", 0)
    cycle = r.get("cycle_state", "未知")
    sbi = r.get("sbi", 0)
    q = r.get("tencent") or {}
    price = q.get("price", 0)
    change = q.get("change_pct", 0)
    vr = q.get("vol_ratio", 0)
    tn = q.get("turnover_pct", 0)
    holders = r.get("holders") or {}

    nl = '\n'
    sep = '━━━' * 14

    # 共振可视化（连续值）
    r_bar = '▓' * max(0, min(10, int(resonance * 10))) + '░' * max(0, 10 - int(resonance * 10))

    # P(上涨)可视化
    p_bar = '▓' * max(0, min(10, int(p * 10))) + '░' * max(0, 10 - int(p * 10))

    price_str = f"¥{price:.2f}" if price > 0 else "—"
    change_str = f"{change:+.2f}%" if price > 0 else "—"

    lines = [
        sep,
        f"📡 {name or code}  {price_str} {change_str}",
        sep,
        "",
        f"  P(上涨)  {p_bar}  {p:.0%}",
        f"  共振    {r_bar}  {resonance:.2f}",
        f"  SBI     {sbi:+.1f}",
        "",
        f"  量比 {vr:.2f}  换手 {tn:.1f}%",
        f"  湮灭  {annihil:.2f}",
        f"  周期  {cycle}",
        "",
        sep,
        f"  本系统承认自身只是降维投影，评估结论仅为升维还原参考。",
        sep,
    ]
    return nl.join(lines)


# ═══════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="统一评估 — 概率 + 共振 + 湮灭 + 周期")
    parser.add_argument('-c', '--codes', type=str, default=None, help="代码逗号分隔")
    parser.add_argument('-n', '--names', type=str, default=None, help="中文名单逗号分隔")
    args = parser.parse_args()

    codes = []
    if args.codes:
        codes = [c.strip() for c in args.codes.split(',') if c.strip()]
    elif args.names:
        # 简单名→码映射（用 tushare stock_basic）
        names = [n.strip() for n in args.names.split(',') if n.strip()]
        try:
            df = pro.stock_basic(exchange='', list_status='L', fields='ts_code,name')
            name2code = {r['name']: r['ts_code'].split('.')[0] for _, r in df.iterrows()}
            for n in names:
                if n in name2code:
                    codes.append(name2code[n])
        except Exception as e:
            print(f"代码解析失败: {e}")
            sys.exit(1)
    else:
        parser.print_help()
        sys.exit(1)

    if not codes:
        print("未解析到任何代码")
        sys.exit(1)

    print(f"\n统一评估: {codes}")
    print("=" * 50)

    # 进化权重自动调整（进化引擎内嵌）
    adjust_weights_from_history()

    results = unified_eval(codes)

    # 打印卡片
    for code, r in results.items():
        card = format_probability_card(code, r)
        print(f"\n{card}")
