#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
报告渲染器 — _render_report.py
=================================
供 LLM cron agent 调用，生成「简报+MD附件」标准输出。
解决 Telegram 直接发长文被截断/排版丢失的问题。

用法:
    # 渲染政策简报 + 生成MD附件
    C:/Python314/python.py _render_report.py policy \\
        --title "2026中国全维度政策与国家队资本动向" \\
        --date "2026-07-20" \\
        --direction BULL --confidence 0.78 --score 74 \\
        --events "发改委印发十五五能源规划" "大基金三期投HBM" \\
        --national buy \\
        --strategic "大基金三期聚焦HBM/EDA，硬科技资源配置加速" \\
        --fiscal "央企市值管理持续推进，股权财政替代率提升" \\
        --livelihood "分红回购规模扩大，长期资金入市渠道拓宽" \\
        --signals "大基金投HBM:Q3看封测设备 | 发改委能源规划:Q3看电网改造" \\
        --risks "外部风险:美对华制裁加码 | 制度堵点:退市执行力度待观察" \\
        --watch "7/21政治局会议 | 7/25大基金三期投决会" \\
        --sources "发改委官网 2026-07-18" "大基金官网 2026-07-19" "上交所公告 2026-07-17" \\
        --full-report "C:/Users/Admin/tmp/policy_report_20260720.md" \\
        --send-to 8673372605

    # 渲染风险简报 + 生成MD附件
    C:/Python314/python.py _render_report.py risk \\
        --title "A股市场风险与情绪雷达" \\
        --date "2026-07-20" \\
        --temperature mid --icon "🟡" --score 56 \\
        --vix 19.5 --vix_change 7.0 \\
        --north_flow 32.0 --north_days 3 \\
        --margin_change 1.1 --up_down_ratio 0.35 --limit_up 140 \\
        --alerts "VIX单日+7%突破19,警戒线接近" "北向连续3日净流入32亿,关注可持续性" \\
        --watch "美债利率:观察美联储7月会议 | 地缘风险:中东局势" \\
        --sources "CBOE 2026-07-18" "东方财富 2026-07-18" "上交所 2026-07-17" \\
        --full-report "C:/Users/Admin/tmp/risk_report_20260720.md" \\
        --send-to 8673372605

输出:
    - stdout: Telegram 简报正文（≤800字,纯文本）
    - 文件: 完整MD附件
    - 返回: {"ok": true, "brief_len": N, "md_path": "..."}
"""
import os, sys, json, argparse, urllib.request, urllib.error, time, mimetypes
from pathlib import Path
from datetime import datetime as _dt

TOOLS_DIR = Path(__file__).parent

# 导入 PIAF 信号卡片模块
try:
    from piaf_signals import piaf_full_card
    _PIAF_AVAILABLE = True
except ImportError:
    _PIAF_AVAILABLE = False
    piaf_full_card = lambda: ""


def _load_token() -> str:
    for var in ("TELEGRAM_BOT_TOKEN", "TG_BOT_TOKEN"):
        v = os.environ.get(var, "")
        if v and len(v) > 30:
            return v
    env_file = Path("C:/Users/Admin/AppData/Local/hermes/.env")
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if line.startswith("TELEGRAM_BOT_TOKEN="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v and len(v) > 30:
                    return v
    raise RuntimeError("Telegram Token 未配置")


def _proxy():
    return urllib.request.build_opener(urllib.request.ProxyHandler({
        "http": "http://127.0.0.1:7890",
        "https": "http://127.0.0.1:7890",
    }))


def _send_message(token, chat_id, text):
    """发送TG消息，返回 ok 状态"""
    opener = _proxy()
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    data = json.dumps({
        "chat_id": chat_id, "text": text,
        "parse_mode": "HTML", "disable_web_page_preview": True,
    }).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    for attempt in range(3):
        try:
            resp = json.loads(opener.open(req, timeout=20).read())
            return resp.get("ok", False), resp
        except Exception:
            time.sleep(2)
    return False, None


def _send_document(token, chat_id, file_path):
    """发送文件附件，返回 ok 状态"""
    opener = _proxy()
    url = f"https://api.telegram.org/bot{token}/sendDocument"
    file_path = Path(file_path)
    if not file_path.exists():
        return False, f"文件不存在: {file_path}"
    fname = file_path.name
    try:
        import uuid, mimetypes
        mime = mimetypes.guess_type(str(file_path))[0] or "text/markdown"
        boundary = f"----HermesBoundary{uuid.uuid4().hex}"
        body_parts = []
        body_parts.append(f"--{boundary}".encode())
        body_parts.append(b'Content-Disposition: form-data; name="chat_id"')
        body_parts.append(b"\r\n" + str(chat_id).encode())
        body_parts.append(f"--{boundary}".encode())
        body_parts.append(f'Content-Disposition: form-data; name="document"; filename="{fname}"'.encode())
        body_parts.append(f"Content-Type: {mime}".encode())
        with open(file_path, "rb") as f:
            body_parts.append(b"\r\n" + f.read())
        body_parts.append(f"--{boundary}--".encode())
        body_parts.append(b"\r\n")
        body = b"\r\n".join(body_parts)
        req = urllib.request.Request(
            url, data=body,
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
            method="POST",
        )
        resp = json.loads(opener.open(req, timeout=60).read())
        return resp.get("ok", False), resp
    except Exception as e:
        return False, str(e)


def render_policy(args) -> dict:
    """渲染政策简报+MD附件"""
    now = _dt.now().strftime("%H:%M")
    date = args.date or _dt.now().strftime("%Y-%m-%d")

    # ─── 简报正文（≤800字, 纯文本, HTML标签用于格式）───
    direction_map = {"BULL": "📈看多", "NEUTRAL": "⚪中性", "BEAR": "📉看空"}
    dir_label = direction_map.get(args.direction.upper(), "⚪")
    conf = args.confidence
    conf_str = f"{conf*100:.0f}%" if conf else ""

    events_text = "\n".join([f"  • {e}" for e in (args.events or [])])

    brief_lines = [
        f"<b>📋 {args.title}</b>（{date}）",
        f"",
        f"⏰ {now}  |  <b>核心判断</b>: {args.judgment or '政策面稳中偏多，国家队布局硬科技'}",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"📈 <b>政策面</b>: {dir_label} (置信度{conf_str}, 评分{args.score})",
        f"🔑 <b>关键事件</b>:",
        events_text,
        f"💎 <b>国家队</b>: {'💎买入' if args.national=='buy' else '⚠️卖出' if args.national=='sell' else '⚪观望'}",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"🌡️ <b>三维框架</b>:",
        f"  • 战略层: {args.strategic or '—'}",
        f"  • 财政层: {args.fiscal or '—'}",
        f"  • 民生层: {args.livelihood or '—'}",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"🚩 <b>风险</b>: {args.risks or '—'}",
        f"🔭 <b>关注</b>: {args.watch or '—'}",
        f"",
        f"━━━━━━━━━━━━━━",
        f"",
        f"<i>AI生成内容仅供参考，不构成投资建议</i>",
    ]
    brief = "\n".join(brief_lines)

    # ─── MD 附件 ───
    md_lines = [
        f"# {args.title}（{date}）",
        f"",
        f"⏰ {_dt.now().strftime('%Y-%m-%d %H:%M')} 生成",
        f"",
        f"---",
        f"",
        f"## 本期核心判断",
        f"",
        f"{args.judgment or '—'}",
        f"",
        f"---",
        f"",
        f"## 关键事件",
        f"",
    ]
    for e in (args.events or []):
        md_lines.append(f"- **{e}**")
    md_lines.extend([f"---", f""])

    md_lines.extend([
        f"## 三维框架总览",
        f"",
        f"| 维度 | 要点 |",
        f"|---|---|",
        f"| 🎯 战略层 | {args.strategic or '—'} |",
        f"| 💰 财政层 | {args.fiscal or '—'} |",
        f"| 👥 民生层 | {args.livelihood or '—'} |",
        f"",
        f"---",
        f"",
        f"## 关键信号与监控指标",
        f"",
    ])
    for s in (args.signals or []):
        md_lines.append(f"- {s}")
    md_lines.extend([
        f"",
        f"---",
        f"",
        f"## 潜在风险与传导堵点",
        f"",
        f"{args.risks or '—'}",
        f"",
        f"---",
        f"",
        f"## 后续关注节点",
        f"",
        f"{args.watch or '—'}",
        f"",
        f"---",
        f"",
        f"## 来源索引",
        f"",
    ])
    for s in (args.sources or []):
        md_lines.append(f"- {s}")
    md_lines.extend([
        f"",
        f"---",
        f"",
        f"AI生成内容仅供参考，不构成投资建议；投资有风险，决策请结合自身情况并咨询专业人士。",
    ])

    md_content = "\n".join(md_lines)

    # 保存 MD 文件
    md_path = Path(args.full_report)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text(md_content, encoding="utf-8")

    # 发送简报消息
    token = _load_token()
    ok_msg, _ = _send_message(token, args.send_to, brief)
    # 发送 MD 附件
    ok_doc, doc_result = _send_document(token, args.send_to, str(md_path))

    return {
        "ok": ok_msg and ok_doc,
        "brief_ok": ok_msg,
        "doc_ok": ok_doc,
        "brief_len": len(brief),
        "md_path": str(md_path),
    }


def render_risk(args) -> dict:
    """渲染风险简报+MD附件"""
    now = _dt.now().strftime("%H:%M")
    date = args.date or _dt.now().strftime("%Y-%m-%d")

    # ─── 温度图标 ───
    temp_map = {
        "low": ("🟢", "低风险"), "mid": ("🟡", "中风险"),
        "high": ("🔴", "高风险"), "extreme": ("🚨", "极端风险"),
    }
    icon, label = temp_map.get(args.temperature, ("⚪", "未知"))

    # ─── 阈值判断 ───
    vix_flag = "🔴" if (args.vix and args.vix >= 25) else "🟡" if (args.vix and args.vix >= 18) else "🟢"
    north_flag = "🔴" if (abs(args.north_flow) > 80) else "🟡" if (abs(args.north_flow) > 30) else "🟢"
    margin_flag = "🔴" if (abs(args.margin_change) > 2) else "🟡" if (abs(args.margin_change) > 1) else "🟢"
    ratio_flag = "🔴" if (args.up_down_ratio and args.up_down_ratio < 0.2) else "🟡" if (args.up_down_ratio and args.up_down_ratio < 0.4) else "🟢"

    alerts_text = "\n".join([f"  ⚠️ {a}" for a in (args.alerts or [])])
    alerts_str = alerts_text if args.alerts else "  ✅ 无异常触发"

    brief_lines = [
        f"<b>📡 {args.title}</b>（{date}）",
        f"⏰ {now}  |  <b>{icon} {label}</b> (评分{args.score})",
        f"",
        f"<b>📊 三维速览</b>",
        f"🌍 <b>中美联动</b>: VIX {args.vix or '—'} ({args.vix_change:+.1f}%) {vix_flag} | 隔夜纳指 {args.nasdaq:+.2f}%",
        f"💰 <b>市场杠杆</b>: 两融日变 {args.margin_change:+.1f}% {margin_flag} | 两融占比 {args.margin_ratio or '—'}%",
        f"🌏 <b>跨境资金</b>: 北向 {'+' if args.north_flow>0 else ''}{args.north_flow}亿 (连{args.north_days}日) {north_flag}",
        f"📈 <b>市场广度</b>: 涨跌比 {args.up_down_ratio} {ratio_flag} | 涨停 {args.limit_up}家",
        f"",
        f"<b>🚨 触发预警</b>:",
        alerts_str,
        f"",
        f"🔭 <b>关注</b>: {args.watch or '—'}",
    ]
    brief = "\n".join(brief_lines)

    # ─── MD 附件 ───
    md_lines = [
        f"# {args.title}（{date}）",
        f"",
        f"⏰ {_dt.now().strftime('%Y-%m-%d %H:%M')} 生成",
        f"",
        f"---",
        f"",
        f"## 风险温度评级 {icon} {label} (评分{args.score})",
        f"",
        f"{args.judgment or '—'}",
        f"",
        f"---",
        f"",
        f"## 三维度数据表",
        f"",
        f"| 维度 | 指标 | 当前值 | 变化幅度 | 阈值 |",
        f"|---|---|---|---|---|",
        f"| 中美联动 | VIX | {args.vix or '—'} | {args.vix_change:+.1f}% | {vix_flag} |",
        f"| 中美联动 | 隔夜纳指 | {args.nasdaq or '—'}% | — | — |",
        f"| 市场杠杆 | 两融日变 | {args.margin_change:+.1f}% | — | {margin_flag} |",
        f"| 市场杠杆 | 两融占比 | {args.margin_ratio or '—'}% | — | — |",
        f"| 跨境资金 | 北向日流入 | {'+' if args.north_flow>0 else ''}{args.north_flow}亿 | 连续{args.north_days}日 | {north_flag} |",
        f"| 市场广度 | 涨跌比 | {args.up_down_ratio} | — | {ratio_flag} |",
        f"| 市场广度 | 涨停家数 | {args.limit_up}家 | — | — |",
        f"",
        f"---",
        f"",
    ]
    if args.alerts:
        md_lines.append("## 触发预警项详细归因")
        md_lines.append("")
        for a in args.alerts:
            md_lines.append(f"- {a}")
        md_lines.append("")
        md_lines.extend([f"---", f""])

    # PIAF 两融四区间 + Z-score 背离卡片
    if _PIAF_AVAILABLE:
        piaf_card = piaf_full_card()
        if piaf_card:
            md_lines.append("## 📊 PIAF 两融与Z-score信号")
            md_lines.append("")
            md_lines.append(piaf_card)
            md_lines.append("")
            md_lines.extend([f"---", f""])

    md_lines.extend([
        f"## 潜在风险传导路径",
        f"",
        f"{args.watch or '—'}",
        f"",
        f"---",
        f"",
        f"## 来源索引",
        f"",
    ])
    for s in (args.sources or []):
        md_lines.append(f"- {s}")
    md_lines.extend([
        f"",
        f"---",
        f"",
        f"AI生成内容仅供参考，不构成投资建议；投资有风险，决策请结合自身情况并咨询专业人士。",
    ])

    md_content = "\n".join(md_lines)
    md_path = Path(args.full_report)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.write_text(md_content, encoding="utf-8")

    # 发送
    token = _load_token()
    ok_msg, _ = _send_message(token, args.send_to, brief)
    ok_doc, doc_result = _send_document(token, args.send_to, str(md_path))

    return {
        "ok": ok_msg and ok_doc,
        "brief_ok": ok_msg,
        "doc_ok": ok_doc,
        "brief_len": len(brief),
        "md_path": str(md_path),
    }


def main():
    parser = argparse.ArgumentParser(description="报告渲染器: 简报+MD附件")
    sub = parser.add_subparsers(dest="command")

    # policy
    p_pol = sub.add_parser("policy")
    p_pol.add_argument("--title", default="2026中国全维度政策与国家队资本动向")
    p_pol.add_argument("--date", default=None)
    p_pol.add_argument("--judgment", default="政策面稳中偏多，国家队布局硬科技")
    p_pol.add_argument("--direction", default="NEUTRAL")
    p_pol.add_argument("--confidence", type=float, default=0.0)
    p_pol.add_argument("--score", type=int, default=0)
    p_pol.add_argument("--events", nargs="*", default=[])
    p_pol.add_argument("--national", default="neutral")
    p_pol.add_argument("--strategic", default=None)
    p_pol.add_argument("--fiscal", default=None)
    p_pol.add_argument("--livelihood", default=None)
    p_pol.add_argument("--signals", nargs="*", default=[])
    p_pol.add_argument("--risks", default=None)
    p_pol.add_argument("--watch", default=None)
    p_pol.add_argument("--sources", nargs="*", default=[])
    p_pol.add_argument("--full-report", default="C:/Users/Admin/tmp/policy_report_{}.md".format(_dt.now().strftime("%Y%m%d")))
    p_pol.add_argument("--send-to", default="8673372605")
    p_pol.set_defaults(func=render_policy)

    # risk
    p_risk = sub.add_parser("risk")
    p_risk.add_argument("--title", default="A股市场风险与情绪雷达")
    p_risk.add_argument("--date", default=None)
    p_risk.add_argument("--judgment", default=None)
    p_risk.add_argument("--temperature", default="mid")
    p_risk.add_argument("--icon", default="🟡")
    p_risk.add_argument("--score", type=int, default=0)
    p_risk.add_argument("--vix", type=float, default=0)
    p_risk.add_argument("--vix_change", type=float, default=0)
    p_risk.add_argument("--nasdaq", type=float, default=0)
    p_risk.add_argument("--north_flow", type=float, default=0)
    p_risk.add_argument("--north_days", type=int, default=0)
    p_risk.add_argument("--margin_change", type=float, default=0)
    p_risk.add_argument("--margin_ratio", type=float, default=0)
    p_risk.add_argument("--up_down_ratio", type=float, default=0)
    p_risk.add_argument("--limit_up", type=int, default=0)
    p_risk.add_argument("--alerts", nargs="*", default=[])
    p_risk.add_argument("--watch", default=None)
    p_risk.add_argument("--sources", nargs="*", default=[])
    p_risk.add_argument("--full-report", default="C:/Users/Admin/tmp/risk_report_{}.md".format(_dt.now().strftime("%Y%m%d")))
    p_risk.add_argument("--send-to", default="8673372605")
    p_risk.set_defaults(func=render_risk)

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(1)

    result = args.func(args)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if not result["ok"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
