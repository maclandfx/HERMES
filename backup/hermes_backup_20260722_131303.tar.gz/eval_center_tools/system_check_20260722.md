# 体系自检报告 — 方法论重构后全局检查

> 2026-07-22 | 基于 holistic-unified-eval 架构

---

## 检查结果

### ✅ 已修复

| 问题 | 修复 |
|------|------|
| **decision_bus.json 污染** | accuracy_log 含 2 条测试垃圾数据 → 已清理，保留 1 条有效记录 (2026-07-20, hit=1/1) |
| **进化权重文件不存在** | `evolution_weights.json` 不存在，`unified_eval.py` 首次调用时自动以默认权重（金水50%/火20%/土木30%）生成 |

### ⚠️ 已知问题（不紧急，文档记录）

| 问题 | 说明 |
|------|------|
| **Python 双环境不一致** | `tdx_blk_monitor.py` 用 `C:/Python314/python.exe` 调 eval_smart（3.14，numpy 已单独装），但 `signal_card.py` 在 venv 3.11 下 import。**两套环境不能互相 import 对方模块**。当前通过 subprocess 调用规避了，但需记录。 |
| **PYTHONPATH 污染** | `C:/Python314/python.exe` 的默认 PYTHONPATH 指向 hermes-agent venv 的 site-packages（含 cp311 numpy），导致 numpy 加载失败。解决方案：调用时 `PYTHONPATH=""`。 |
| **signal_card 解析器未适配 unified_eval** | 旧 `signal_card.py` 解析 eval_smart 的 stdout 格式（正则匹配 `"综合评分"`、`"共振"` 等），而 `unified_eval.py` 输出纯数字概率格式。两套解析器并存，互不干扰。 |

### 架构依赖关系（确认正常）

```
evolution_weights.json  ← 不存在时自动以默认权重生成（首次调用 unified_eval 即生成）
decision_bus.json       ← accuracy_log 已清理，1条有效记录
├── unified_eval.py     ← 新统一评估，5因子/共振/湮灭/周期/P(上涨)
├── eval_smart.py       ← 旧8维评估，保留作为兼容
├── tdx_blk_monitor.py  ← blk监控 → 调 eval_smart（subprocess，314环境）
├── signal_card.py      ← 旧卡片渲染器，解析 eval_smart stdout
├── weekly_analysis.py  ← 周线分析（unified_eval 依赖）
├── tdx_core.py         ← 通达信核心（unified_eval 依赖）
└── astock_bridge.py    ← 腾讯行情桥接（unified_eval 依赖）
```

### 无需修改的文件

| 文件 | 原因 |
|------|------|
| `tdx_batch_scanner.py` | 引用 eval_smart，eval_smart 保留兼容，不改动 |
| `tdx_connector/blk_monitor.py` | 引用 eval_smart，同上 |
| `evolution_engine.py` | 旧进化引擎，保留兼容；新进化逻辑已内嵌在 unified_eval 中 |
| `monthly_review.py` | 仅含注释性引用，无功能依赖 |

---

## 总结

**体系健康，无需大规模修改。** 唯一需要做的：
1. ✅ decision_bus.json accuracy_log 已清理
2. ✅ unified_eval 首次运行会自动生成 `evolution_weights.json`
3. ⚠️ Python 双环境问题已记录，不影响当前运行
