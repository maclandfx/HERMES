"""Cron wrapper: PZYJ daily factor mine + self-evolution (no_agent)"""
import sys, os
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
from pz_yj_factor_mine import run
from factor_evolution import run_full_audit, run_self_evolution

print('[1/3] 日线因子反推...')
run()
print('[2/3] 自审计...')
run_full_audit()
print('[3/3] 自进化...')
run_self_evolution()
print('DONE')
