#!/usr/bin/env python3
"""
每周系统清理 — 删除过期垃圾/冗余文件，保持清洁高效。
运行: 每周日 03:00 (cron)

清理原则: 安全第一 — 宁可多留，不误删
  - 有价值文件先归档到 trash/（可恢复），不直接删除
  - Hermes venv / scripts 目录完全跳过（绝不影响运行）
  - 阈值保守，宁可多留不要少留

清理规则:
  1. cron output .md  → 归档 > 30 天
  2. 评估粗评报告      → 归档 > 90 天前 / 数量超 150 个
  3. telegram_queue    → 归档 > 14 天
  4. tracked_*.json    → 归档 > 7 天前
  5. /tmp 临时文件      → 归档 > 7 天
  6. __pycache__       → 全删（自动生成，可恢复，排除 venv/scripts）
  7. .DS_Store / Thumbs.db → 全删
"""
import os
import sys
import time
import shutil
import logging
from pathlib import Path
from datetime import datetime

log = logging.getLogger("weekly_cleanup")

# 清理结果
archived = 0    # 已归档文件数
removed = 0     # 已删除文件数
archived_bytes = 0
removed_bytes = 0

# 安全区域：这些目录完全不动
SAFE_PREFIXES = (
    str(Path(r"C:/Users/Admin/AppData/Local/hermes/hermes-agent/venv").resolve()),
    str(Path(r"C:/Users/Admin/AppData/Local/hermes/scripts").resolve()),
)

# 归档目录
TRASH_DIR = Path(r"D:/Hermes/评估中心/trash")
TRASH_DIR.mkdir(parents=True, exist_ok=True)

def fmt_size(n: int) -> str:
    if n < 1024: return f"{n}B"
    if n < 1024**2: return f"{n/1024:.1f}KB"
    return f"{n/1024**2:.1f}MB"

def safe_remove(path: str):
    """安全删除（仅用于 pycache/系统垃圾等可恢复文件）"""
    global removed, removed_bytes
    try:
        p = Path(path)
        if not p.exists(): return
        # 安全检查：不碰安全区域
        cp = str(p.resolve())
        if any(cp.startswith(s) for s in SAFE_PREFIXES):
            return
        size = p.stat().st_size if p.is_file() else sum(
            f.stat().st_size for f in p.rglob("*") if f.is_file())
        if p.is_file(): p.unlink()
        else: shutil.rmtree(p)
        removed += 1
        removed_bytes += size
        log.info(f"  🗑️  {p.name}")
    except Exception as e:
        log.warning(f"  ⚠️  跳过 {path}: {e}")

def archive_to(path: str, label: str):
    """归档到 trash/ 目录（可恢复），按类别分文件夹"""
    global archived, archived_bytes
    try:
        p = Path(path)
        if not p.exists(): return
        # 安全检查：不碰安全区域
        cp = str(p.resolve())
        if any(cp.startswith(s) for s in SAFE_PREFIXES):
            return
        size = p.stat().st_size if p.is_file() else sum(
            f.stat().st_size for f in p.rglob("*") if f.is_file())
        dest = TRASH_DIR / label / p.name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(p), str(dest))
        archived += 1
        archived_bytes += size
        log.info(f"  📦 {p.name}")
    except Exception as e:
        log.warning(f"  ⚠️  归档失败 {path}: {e}")

def run():
    global archived, removed, archived_bytes, removed_bytes
    log.info("=" * 50)
    log.info(f"🧹 系统清理开始 — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    log.info("=" * 50)

    now_ts = time.time()
    TODAY = datetime.now().strftime("%Y%m%d")

    # 1. cron output — 归档 > 30 天
    log.info(f"\n[1/7] cron output (归档 > 30 天)")
    cron_dir = Path(r"C:/Users/Admin/AppData/Local/hermes/cron/output")
    cutoff = now_ts - 30 * 86400
    if cron_dir.exists():
        for md in sorted(cron_dir.glob("**/*.md"), key=lambda p: p.stat().st_mtime):
            if md.stat().st_mtime < cutoff:
                archive_to(str(md), f"cron_{TODAY}")

    # 2. 评估粗评 — 归档 > 90 天前 / 超 150 个
    log.info(f"\n[2/7] 评估粗评报告 (归档 > 90 天前 / 超 150 个)")
    report_dir = Path(r"D:/Hermes/评估中心/reports/粗评")
    if report_dir.exists():
        all_files = sorted(report_dir.glob("*"), key=lambda p: p.stat().st_mtime)
        # 归档 90 天前
        old_cutoff = now_ts - 90 * 86400
        for f in all_files:
            if f.stat().st_mtime < old_cutoff:
                archive_to(str(f), f"report_{TODAY}")
        # 归档多余的（只保留最近 150 个）
        all_files = sorted(report_dir.glob("*"), key=lambda p: p.stat().st_mtime)
        for f in all_files[:-150]:
            archive_to(str(f), f"report_{TODAY}")

    # 3. telegram_queue — 归档 > 14 天
    log.info(f"\n[3/7] telegram_queue (归档 > 14 天)")
    tq_dir = Path(r"D:/Hermes/评估中心/tools/tdx_connector/telegram_queue")
    cutoff = now_ts - 14 * 86400
    if tq_dir.exists():
        for f in sorted(tq_dir.glob("*.txt"), key=lambda p: p.stat().st_mtime):
            if f.stat().st_mtime < cutoff:
                archive_to(str(f), f"telegram_{TODAY}")

    # 4. tracked_*.json — 归档 > 7 天前
    log.info(f"\n[4/7] tracked JSON (归档 > 7 天前)")
    td = Path(r"D:/Hermes/评估中心/tools/tdx_connector")
    cutoff = now_ts - 7 * 86400
    if td.exists():
        for f in sorted(td.glob("tracked_*.json"), key=lambda p: p.stat().st_mtime):
            if f.stat().st_mtime < cutoff:
                archive_to(str(f), f"tracked_{TODAY}")

    # 5. /tmp 临时文件 — 归档 > 7 天
    log.info(f"\n[5/7] /tmp 临时文件 (归档 > 7 天)")
    cutoff = now_ts - 7 * 86400
    for pattern in ["*.txt", "*.log", "*.json", "*.tmp"]:
        for f in sorted(Path("/tmp").glob(pattern), key=lambda p: p.stat().st_mtime):
            if f.stat().st_mtime < cutoff:
                archive_to(str(f), f"tmp_{TODAY}")

    # 6. __pycache__ — 全删（自动生成，可恢复）
    log.info(f"\n[6/7] __pycache__ (全删, 排除venv/scripts)")
    for base in [Path(r"D:/Hermes/评估中心"), Path(r"C:/Users/Admin/AppData/Local/hermes")]:
        if base.exists():
            for cache in base.rglob("__pycache__"):
                cp = str(cache.resolve())
                if any(cp.startswith(p) for p in SAFE_PREFIXES):
                    continue
                safe_remove(str(cache))

    # 7. 系统垃圾文件
    log.info(f"\n[7/7] .DS_Store / Thumbs.db (全删)")
    for base in [Path(r"D:/Hermes"), Path(r"C:/Users/Admin/AppData/Local/hermes")]:
        if base.exists():
            for f in base.rglob("Thumbs.db"):
                safe_remove(str(f))
            for f in base.rglob(".DS_Store"):
                safe_remove(str(f))

    # 汇总
    log.info("\n" + "=" * 50)
    log.info(f"📦 已归档: {archived} 个 → {fmt_size(archived_bytes)}  (→ D:/Hermes/评估中心/trash/)")
    log.info(f"🗑️  已删除: {removed} 个 → {fmt_size(removed_bytes)}  (__pycache__ 等)")
    log.info(f"💾 总释放: {fmt_size(archived_bytes + removed_bytes)}")
    log.info("=" * 50)

    return (f"🧹 每周清理完成\n"
            f"📦 已归档: {archived} 个 → {fmt_size(archived_bytes)}\n"
            f"🗑️  已删除: {removed} 个 → {fmt_size(removed_bytes)}\n"
            f"💾 总释放: {fmt_size(archived_bytes + removed_bytes)}\n"
            f"📂 归档位置: D:/Hermes/评估中心/trash/（可恢复）")

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )
    result = run()
    print(result)
