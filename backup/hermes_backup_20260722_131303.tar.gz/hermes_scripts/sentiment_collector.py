#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
A股热帖交易情报系统 v3.0 — 工业化版
数据源: 淘股论坛(m.tgb.cn) + 东方财富公开API
输出: posts_YYYYMMDD.jsonl + reports/report_YYYYMMDD.md
推送: Telegram (自动分条)

v3.0 修复/改进:
  [P0] 作者提取正则双反斜杠bug修复
  [P0] 正文清洗字符类bug修复(改为非捕获分组)
  [P0] 情绪emoji语义反转修复(A股:红涨绿跌)
  [P0] 情绪分类加入否定词上下文判断
  [P0] 交易逻辑提取加入否定词过滤
  [P1] 合并三套重复词典(TRADE_LOGIC_KW/ACTION_KWS/STRATEGY_KWS)→统一词典
  [P1] 移除废弃parse_tgb()
  [P1] Playwright正文提取改为取正文区域(非整页)
  [P2] 报告加入执行摘要(EXECUTIVE SUMMARY)
  [P2] 东财数据reads/语义修正
  [P2] Telegram消息按换行智能分条(不断词)
"""
import os, sys, json, re, hashlib, subprocess, time, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime
from collections import Counter, OrderedDict

OUTPUT_DIR = Path.home() / "AppData" / "Local" / "hermes" / "data" / "sentiment_collector"
REPORT_DIR = OUTPUT_DIR / "reports"
PW_DIR = Path.home() / "AppData" / "Roaming" / "npm" / "node_modules" / "playwright"

TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID", "8673372605")

# ════════════════════════════════════════════════
# 情绪词典 v3 — 修复 emoji 语义(A股: 红涨绿跌)
# ════════════════════════════════════════════════
# emoji 映射: 看多=🔴(红涨), 看空=🟢(绿跌), 中性=⚪
SENTIMENT_EMOJI = {"看多": "🔴", "看空": "🟢", "中性": "⚪"}

# 否定词：用于过滤"不建议买入""禁止上车"等反向语境
NEGATION_KW = {"不", "别", "没", "没有", "不要", "无法", "切勿", "严禁", "避免", "禁止",
               "不该", "不宜", "勿", "不必", "难", "很难", "几乎不"}

# 情绪词（POS=正向/看多, NEG=负向/看空）
POS = [
    "暴涨", "涨停", "强势", "突破", "新高", "主升", "加仓", "满仓", "机会", "利好",
    "底部", "抄底", "牛市", "翻倍", "大肉", "吃肉", "大妖", "龙头", "连板", "放量上涨",
    "资金流入", "净流入", "上车", "踏准", "趋势向上", "多头", "做多", "看好",
    "超预期", "强于预期", "产业", "国产替代", "大基金", "央企改革", "放量突破",
    "买入", "增持", "推荐", "强于大盘", "放量拉升", "放量封板", "放量涨停",
    "强势反弹", "强势上涨", "强势突破", "强势整理", "强势拉升", "强势封板",
    "放量上攻", "放量抢筹", "放量进场", "放量介入", "放量布局",
]
NEG = [
    "暴跌", "跌停", "大跌", "杀跌", "清仓", "空仓", "割肉", "套牢", "被套", "亏损",
    "止损", "出局", "离场", "跑路", "见顶", "拐点", "调整", "回调", "走弱",
    "利空", "监管", "减持", "解禁", "破位", "资金流出", "净流出", "踩踏", "冰点",
    "退潮", "核按钮", "一字跌停", "放量下跌", "放量杀跌", "恐慌", "恐高",
    "失望", "绝望", "垃圾", "韭菜", "被杀", "亏惨", "套牢盘", "A杀", "阴跌",
    "放量跳水", "放量暴跌", "放量砸盘", "放量出逃", "放量减仓", "放量派发",
    "放量出货", "放量破位", "放量退潮",
]

# ════════════════════════════════════════════════
# 统一交易词典（合并原三套词典）
# ════════════════════════════════════════════════
# KEY: 标签名
# VALUE: [关键词列表]
# 分类: "action"(操作动作), "strategy"(策略), "rhythm"(节奏), "logic"(逻辑)
UNIFIED_TRADE = OrderedDict([
    # ---- 操作动作 ----
    ("买入", {"kws": ["买入", "建仓", "进场", "上车", "布局", "潜伏", "抄底", "低吸", "吸筹", "低吸买入"], "cat": "action"}),
    ("卖出", {"kws": ["卖出", "清仓", "离场", "出局", "跑路", "割肉", "减仓", "止盈"], "cat": "action"}),
    # ---- 策略 ----
    ("潜伏", {"kws": ["潜伏", "埋伏", "提前布局"], "cat": "strategy"}),
    ("低吸", {"kws": ["低吸", "逢低", "接盘", "接回", "接筹码"], "cat": "strategy"}),
    ("打板", {"kws": ["打板", "追板", "封板", "首板", "二板", "连板"], "cat": "strategy"}),
    ("止损", {"kws": ["止损", "认错", "纠错"], "cat": "strategy"}),
    ("空仓", {"kws": ["空仓", "休息", "管住手", "观望"], "cat": "strategy"}),
    ("主升", {"kws": ["主升", "主升浪", "主升段"], "cat": "strategy"}),
    ("逃顶", {"kws": ["逃顶", "高点", "高位", "兑现"], "cat": "strategy"}),
    ("调仓", {"kws": ["调仓", "切换", "高低切换", "换仓"], "cat": "strategy"}),
    # ---- 节奏 ----
    ("快进快出", {"kws": ["快进快出", "快闪", "短打", "一日游"], "cat": "rhythm"}),
    ("攻守兼备", {"kws": ["攻守兼备", "攻守", "均衡"], "cat": "rhythm"}),
    ("分批", {"kws": ["分批", "分仓", "分批买入"], "cat": "rhythm"}),
    ("重仓", {"kws": ["重仓", "重仓持有", "满仓"], "cat": "rhythm"}),
    ("轻仓", {"kws": ["轻仓", "小仓", "试探"], "cat": "rhythm"}),
    # ---- 逻辑 ----
    ("逻辑清晰", {"kws": ["逻辑清晰", "逻辑正确", "逻辑成立"], "cat": "logic"}),
    ("预期差", {"kws": ["预期差", "超预期", "预期提升"], "cat": "logic"}),
    ("趋势", {"kws": ["趋势向上", "趋势向下", "趋势反转", "趋势线"], "cat": "logic"}),
    ("技术面", {"kws": ["技术面", "技术形态", "形态突破", "形态整理"], "cat": "logic"}),
    ("基本面", {"kws": ["基本面", "业绩", "财报", "估值", "低估"], "cat": "logic"}),
    ("主线", {"kws": ["主线", "主线方向", "主线逻辑"], "cat": "logic"}),
    ("题材", {"kws": ["题材", "题材股", "题材逻辑", "题材炒作"], "cat": "logic"}),
])

# 操作动作标签集合（用于"操作动作"显示）
ACTION_LABELS = {k for k, v in UNIFIED_TRADE.items() if v["cat"] == "action"}
# 策略标签集合
STRATEGY_LABELS = {k for k, v in UNIFIED_TRADE.items() if v["cat"] in ("strategy", "rhythm")}
# 逻辑标签集合
LOGIC_LABELS = {k for k, v in UNIFIED_TRADE.items() if v["cat"] == "logic"}

# 帖子类型分类词
POST_TYPE_KW = {
    "实盘": ["实盘", "长征", "分仓", "交割单", "晒单", "战绩", "实盘记录", "实盘日记"],
    "推荐": ["推荐", "推荐关注", "标的", "攻守兼备", "标的", "可关注", "值得关注"],
    "分析": ["分析", "复盘", "拆解", "逻辑", "心法", "策略", "判断", "结论", "验证", "应验", "盘解"],
    "大赛": ["大赛", "比赛", "PK", "对决", "争霸"],
}

# ════════════════════════════════════════════════
# 股票/概念关键词表
# ════════════════════════════════════════════════
# 设计: 用 set 存储，支持动态扩展
# 覆盖范围: A股热门概念 + 个股名称 + 行业板块
STOCK_KW = {
    # 热门个股
    "埃斯顿", "万邦医药", "有研硅", "东微半导", "沐曦股份", "上海合晶",
    "正帆科技", "芯海科技", "先锋精科", "甬矽电子", "亚虹医药", "理工导航",
    "华立科技", "万润科技", "瑞可达", "华丰科技", "沃尔核材", "胜宏科技",
    "华海清科", "江丰电子", "沪硅产业", "立昂微", "华虹", "中芯国际",
    "北方华创", "中微公司", "盛美上海", "拓荆科技", "华峰测控", "长电科技",
    "通富微通", "华天科技", "晶方科技", "寒武纪", "海光信息", "龙芯中科",
    "兆易创新", "韦尔股份", "圣邦股份", "北京君正", "景嘉微", "紫光国微",
    "复旦微电", "国科微", "汇顶科技", "卓胜微", "格科微", "TCL科技",
    "京东方", "维信诺", "华星光电", "立讯精密", "歌尔股份", "蓝思科技",
    "信维通信", "舜宇光学", "汇川技术", "科大讯飞", "海康威视", "大华股份",
    "宁德时代", "比亚迪", "隆基绿能", "通威股份", "阳光电源", "亿纬锂能",
    "中创新航", "鹏辉能源", "欣旺达", "盛和资源", "晋拓股份", "大元泵业",
    "多氟多", "万丰奥威", "宗申动力", "中信海直", "深城交", "四川九洲",
    "莱斯信息", "长川科技", "东山精密", "铖昌科技", "航天电子", "太极实业",
    # 热门概念/板块
    "机器人", "商业航天", "卫星互联网", "固态电池", "储能", "光伏",
    "储能电源", "钠离子电池", "液冷", "高带宽内存", "HBM", "光刻胶",
    "半导体", "芯片", "芯片制造", "IC", "集成电路", "人工智能", "AI", "算力",
    "GPU", "英伟达", "华为", "麒麟", "新能源车", "锂电", "动力电池",
    "磷酸铁锂", "创新药", "CXO", "医药", "中药", "军工", "航空", "无人机",
    "低空经济", "核电", "风电", "氢能", "绿电", "地产", "基建", "水泥",
    "钢铁", "消费", "白酒", "食品饮料", "传媒", "游戏", "影视", "短剧",
    "农业", "种业", "养殖", "猪周期", "化工", "石化", "煤化工", "精细化工",
    # 新增(2026热门)
    "碳纳米管", "光通信", "CPO", "光模块", "卫星导航", "北斗", "卫星通信",
    "智能驾驶", "自动驾驶", "车路云", "V2X", "固态存储", "HBM3", "HBM4",
    "先进封装", "Chiplet", "异构计算", "液冷服务器", "AI服务器", "GPU租赁",
    "算力租赁", "数据中心", "云计算", "国资云", "鸿蒙", "国产替代",
    "稀土", "钨", "锑", "钴", "锂矿", "钠电", "固态电池", "钠电池",
    "机器人", "人形机器人", "伺服电机", "谐波减速器", "RV减速器", "行星减速器",
    "灵巧手", "六自由度", "机器视觉", "具身智能", "AI+机器人",
    # 热门板块细分
    "储能", "新型储能", "抽水蓄能", "压缩空气储能", "飞轮储能", "钠离子电池",
    "光伏", "钙钛矿", "HJT", "TOPCon", "BC电池", "光储一体",
    "风电", "海上风电", "陆上风电", "深远海风电",
    "氢能", "绿氢", "制氢", "储氢", "运氢", "氢燃料电池",
    "核电", "核电重启", "核聚变", "核电设备",
    "军工", "军工信息化", "军工材料", "军工电子", "航空发动机",
    "卫星互联网", "低轨卫星", "星链", "卫星通信", "卫星导航",
    "商业航天", "航天发射", "运载火箭", "卫星制造", "火箭回收",
    "低空经济", "eVTOL", "无人机物流", "无人机配送", "通航",
    "芯片", "模拟芯片", "数字芯片", "存储芯片", "功率半导体", "射频芯片",
    "IGBT", "MOSFET", "碳化硅", "SiC", "氮化镓", "GaN",
    "半导体设备", "刻蚀设备", "沉积设备", "光刻机", "离子注入",
    "晶圆制造", "先进封装", "Chiplet", "3D封装", "TSV", "FCBGA",
    "AI芯片", "GPU", "FPGA", "ASIC", "NPU", "AI加速器",
    "光通信", "光模块", "CPO", "硅光", "共封装光学", "相干光模块",
    "数据中心", "液冷", "风冷", "冷板式液冷", "浸没式液冷",
    "云计算", "国资云", "信创云", "边缘计算",
    "算力", "算力租赁", "智算中心", "超算", "AI算力", "算力基础设施",
    "机器人", "人形机器人", "工业机器人", "协作机器人", "服务机器人",
    "谐波减速器", "RV减速器", "行星减速器", "滚珠丝杠", "无框力矩电机",
    "伺服系统", "运动控制", "机器视觉", "激光雷达", "深度相机",
    "储能", "锂电池", "钠离子电池", "液流电池", "铁铬液流", "全钒液流",
    "光伏", "TOPCon", "HJT", "BC电池", "钙钛矿", "HJT-BC",
    "风电", "海上风电", "深远海风电", "漂浮式风电",
    "氢能", "绿氢", "制氢", "储氢", "运氢", "加氢站", "氢燃料电池",
    "新能源车", "固态电池", "钠电", "换电", "800V", "高压快充",
    "低空经济", "eVTOL", "电动垂直起降", "无人机物流", "通航",
    "商业航天", "卫星互联网", "低轨卫星", "星链", "火箭回收",
    "军工", "航空发动机", "军工信息化", "军工电子", "军工材料",
    "半导体", "先进封装", "Chiplet", "异构计算", "3D封装",
    "AI", "人工智能", "大模型", "多模态", "具身智能", "自动驾驶",
    "液冷", "数据中心", "算力租赁", "智算中心",
    "机器人", "人形机器人", "谐波减速器", "无框力矩电机",
    "固态电池", "钠离子电池", "液冷", "高带宽内存",
    # 核心热门标的(2026)
    "华天科技", "长电科技", "通富微电", "晶方科技", "华虹", "中芯国际",
    "北方华创", "中微公司", "拓荆科技", "盛美上海", "华峰测控", "华海清科",
    "兆易创新", "韦尔股份", "北京君正", "寒武纪", "海光信息", "龙芯中科",
    "紫光国微", "复旦微电", "圣邦股份", "汇顶科技", "卓胜微",
    "沪硅产业", "立昂微", "晶盛机电", "江丰电子", "安集科技",
    "浪潮信息", "中科曙光", "浪潮", "曙光", "新华三", "紫光股份",
    "工业富联", "浪潮", "高新发展", "拓维信息", "科大讯飞",
    "比亚迪", "宁德时代", "亿纬锂能", "欣旺达", "国轩高科", "中创新航",
    "隆基绿能", "通威股份", "阳光电源", "晶澳科技", "天合光能", "协鑫集成",
    "华大九天", "国微集团", "国微集团", "景嘉微", "兆易创新",
    "寒武纪", "海光信息", "龙芯中科", "景嘉微", "复旦微电",
    "芯原股份", "芯动联科", "芯原", "芯动联科", "芯联集成",
    "中际旭创", "天孚通信", "光迅科技", "新易盛", "华工科技",
    "英维克", "申菱环境", "高澜股份", "曙光数创", "数据港", "光环新网",
}

# ════════════════════════════════════════════════
# 核心函数
# ════════════════════════════════════════════════

def _has_negation(text, idx):
    """检查关键词位置前 N 字符内是否有否定词"""
    window = text[max(0, idx-3):idx]
    for n in NEGATION_KW:
        if n in window:
            return True
    return False


def classify_sentiment(title, content=""):
    """
    情绪分类 v3 — 加入否定词上下文判断
    返回: ("看多"/"看空"/"中性", 置信度0-1, 关键词列表)
    emoji: 看多=🔴(红涨), 看空=🟢(绿跌)
    """
    text = (title + " " + content).lower()
    ph, nh = [], []
    for k in POS:
        if k in text:
            ph.append(k)
    for k in NEG:
        if k in text:
            nh.append(k)
    # 否定词过滤: 在否定语境下的词不计入
    ph_valid = []
    for k in ph:
        idx = text.find(k)
        if idx >= 0 and _has_negation(text, idx):
            continue  # 否定语境下跳过
        ph_valid.append(k)
    nh_valid = []
    for k in nh:
        idx = text.find(k)
        if idx >= 0 and _has_negation(text, idx):
            continue
        nh_valid.append(k)
    if len(ph_valid) > len(nh_valid):
        return "看多", round(min(len(ph_valid) * 0.25, 1.0), 2), ph_valid
    elif len(nh_valid) > len(ph_valid):
        return "看空", round(min(len(nh_valid) * 0.25, 1.0), 2), nh_valid
    else:
        return "中性", 0.0, ph_valid + nh_valid


def classify_post_type(title, content=""):
    """分类帖子类型"""
    text = (title + " " + content).lower()
    types = []
    for ttype, kws in POST_TYPE_KW.items():
        if any(kw.lower() in text for kw in kws):
            types.append(ttype)
    return types if types else ["普通"]


def extract_trade_logic(title, content=""):
    """
    从帖子内容中提取交易逻辑 v3 — 加入否定词过滤
    返回: {actions, strategies, stock_actions, rationale, strategy_sentences}
    """
    text = (title + " " + content).lower()
    text_orig = (title + " " + content)  # 保留原文用于 rationale

    # 1. 提取操作动作（过滤否定词）
    actions = []
    for label, v in UNIFIED_TRADE.items():
        if v["cat"] != "action":
            continue
        for kw in v["kws"]:
            idx = text.find(kw)
            if idx >= 0 and not _has_negation(text, idx):
                actions.append(label)
                break

    # 2. 提取策略标签（过滤否定词）
    strategies = []
    for label, v in UNIFIED_TRADE.items():
        if v["cat"] in ("strategy", "rhythm"):
            for kw in v["kws"]:
                idx = text.find(kw)
                if idx >= 0 and not _has_negation(text, idx):
                    strategies.append(label)
                    break

    # 3. 提取逻辑标签（不过滤否定词，因为"逻辑清晰"是正向判断）
    logic_labels = []
    for label, v in UNIFIED_TRADE.items():
        if v["cat"] != "logic":
            continue
        for kw in v["kws"]:
            if kw in text:
                logic_labels.append(label)
                break

    # 4. 股票×操作关联（带否定词过滤）
    stock_actions = []
    for kw in sorted(STOCK_KW, key=len, reverse=True):
        kw_lower = kw.lower()
        idx = text.find(kw_lower)
        if idx < 0:
            continue
        ctx_start = max(0, idx - 80)
        ctx_end = min(len(text), idx + 80)
        ctx = text[ctx_start:ctx_end]
        matched = None
        # 优先匹配操作动作
        for label, v in UNIFIED_TRADE.items():
            if v["cat"] != "action":
                continue
            for act_kw in v["kws"]:
                if act_kw in ctx and not _has_negation(ctx, ctx.find(act_kw)):
                    matched = label
                    break
            if matched:
                break
        if matched:
            if (kw, matched) not in stock_actions:
                stock_actions.append((kw, matched))
        else:
            # 次选匹配策略
            for label, v in UNIFIED_TRADE.items():
                if v["cat"] not in ("strategy", "rhythm"):
                    continue
                for strat_kw in v["kws"]:
                    if strat_kw in ctx and not _has_negation(ctx, ctx.find(strat_kw)):
                        matched = label
                        break
                if matched:
                    break
            if matched:
                if (kw, matched) not in stock_actions:
                    stock_actions.append((kw, matched))

    # 5. 核心逻辑摘要（从原文取包含"逻辑"的上下文）
    rationale = title[:100] if len(title) > 100 else title
    logic_idx = text.find("逻辑")
    if logic_idx >= 0:
        seg_s = max(0, logic_idx - 50)
        seg_e = min(len(text_orig), logic_idx + 50)
        rationale += " | " + text_orig[seg_s:seg_e].strip()
    elif text_orig:
        # fallback: 取正文前150字
        rationale += " | " + text_orig[:150].strip()

    # 6. 策略相关句子
    strategy_sentences = []
    for kw in ["策略", "逻辑", "节奏", "理由", "原因", "判断", "核心"]:
        idx = text.find(kw)
        if idx >= 0:
            seg_s = max(0, idx - 60)
            seg_e = min(len(text_orig), idx + 60)
            seg = text_orig[seg_s:seg_e].strip()
            if seg and len(seg) > 10 and seg not in strategy_sentences:
                strategy_sentences.append(seg)

    return {
        "actions": list(set(actions)),
        "strategies": list(set(strategies)) + list(set(logic_labels)),
        "stock_actions": stock_actions,
        "rationale": rationale[:300],
        "strategy_sentences": strategy_sentences[:3],
    }


def extract_stocks(title, content=""):
    """从标题和内容提取股票名称和股票代码"""
    text = (title + " " + content)
    found = []
    for kw in STOCK_KW:
        if kw in text and kw not in found:
            found.append(kw)
    # 提取股票代码（6位数字），过滤噪声
    raw_codes = re.findall(r'([0-9]{6})', text)
    for c in raw_codes:
        if c in found:
            continue
        suffix = text[text.find(c) + 6:text.find(c) + 12]
        if '浏览' in suffix or '阅读' in suffix or '评论' in suffix:
            continue
        prefix = text[max(0, text.find(c) - 8):text.find(c)]
        # 排除日期型(2026xx)和年份+数字
        if re.match(r'^\s*(20|24|25|26)\s*$', prefix) and len(prefix.strip()) <= 6:
            continue
        found.append(c)
    return found[:10]


def extract_realtrade_amount(title, content=""):
    """提取实盘金额（万元单位）"""
    text = (title + " " + content)
    matches = re.findall(r'([\d.]+)\s*[万Ww万元元]', text)
    if matches:
        try:
            return float(matches[0])
        except Exception:
            pass
    return 0


def _clean_nav_noise(body):
    """清理淘股论坛详情页的导航噪声（v3: 非捕获分组，不伤正文）"""
    body = re.sub(r'^[\u4e00-\u9fa5a-zA-Z0-9\s/·•.，,、\n]{0,3}下载[\s\n]*', '', body)
    # 非捕获分组，避免把"评论"拆成单字符误删
    body = re.sub(r'(?:登录|注册|主页|论坛|视频|热股|可转债|下载|更多|搜索)\s*[\+\n]*', ' ', body)
    body = re.sub(r'\n{3,}', '\n\n', body).strip()
    return body


def parse_tgb_full(raw):
    """
    解析详情页版原始数据（每行 JSON: {url, title, body}）
    body 已通过 Playwright 取正文区域，但仍需清洗尾部导航
    """
    posts = []
    for line in raw.strip().split('\n'):
        line = line.strip()
        if not line or not line.startswith('{'):
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        title = (obj.get('title') or '').strip()
        body = (obj.get('body') or '').strip()
        if not title:
            continue
        body = _clean_nav_noise(body)

        # 提取作者: 详情页结构 = 标题\n时间\n浏览数\n作者\n+关注\n正文
        author = ''
        lines_raw = body.split('\n')
        # 找"浏览"行后的下一行(用户名)
        for i, ln in enumerate(lines_raw[:12]):
            if '浏览' in ln and i + 1 < len(lines_raw):
                cand = lines_raw[i + 1].strip()
                if re.fullmatch(r'[\u4e00-\u9fa5a-zA-Z0-9]{2,20}', cand):
                    author = cand
                    break
        if not author:
            # fallback: 找 +关注 前面的行
            for i, ln in enumerate(lines_raw[:12]):
                if '+关注' in ln and i > 0:
                    cand = lines_raw[i - 1].strip()
                    if re.fullmatch(r'[\u4e00-\u9fa5a-zA-Z0-9]{2,20}', cand):
                        author = cand
                        break
        if not author:
            author = title[:20]  # 最后回退到标题

        # 读取量: 支持 "449223次浏览" 和 "2.5万浏览"
        rm = re.search(r'(\d{1,7}(?:\.\d+)?)\s*(?:万|次)?\s*浏览', body)
        reads = 0
        if rm:
            val = float(rm.group(1))
            reads = int(val * 10000) if '万' in rm.group(0) else int(val)

        # 评论数: 支持 "评论(60)"、"评论 60"、"60评论"
        cm = re.search(r'评论\s*[\(（]?\s*(\d+)\s*[\)）]?', body) or \
             re.search(r'(\d+)\s*评论', body)
        comments = int(cm.group(1)) if cm else 0

        s, sc, kw = classify_sentiment(title, body)
        types = classify_post_type(title, body)
        stocks = extract_stocks(title, body)
        amount = extract_realtrade_amount(title, body)
        trade_logic = extract_trade_logic(title, body)
        # 正文摘要（取前800字核心段落）
        summary = re.split(r'\n.{4,6}操作模式', body)[0][:800].strip()

        posts.append({
            'author': author,
            'title': title,
            'content': body,
            'summary': summary,
            'stats': f'{reads}浏览 {comments}评论',
            'reads': reads,
            'comments': comments,
            'sentiment': s,
            'score': sc,
            'keywords': kw,
            'post_types': types,
            'stocks': stocks,
            'realtrade_amount': amount,
            'trade_logic': trade_logic,
        })
    return posts


# ════════════════════════════════════════════════
# 东方财富 API
# ════════════════════════════════════════════════
EM_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
    'Referer': 'https://quote.eastmoney.com/',
}


def em_fetch(url, timeout=10, retries=3):
    last_err = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=EM_HEADERS)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return data.get('data', {}).get('diff', [])
        except Exception as e:
            last_err = e
            if attempt < retries - 1:
                time.sleep(1)
    print(f'❌ 东财API请求失败 ({url[:60]}...): {last_err}')
    return []


def fetch_em_concept_top():
    url = ('https://push2.eastmoney.com/api/qt/clist/get?'
           'pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa'
           '&fid=f3&fs=m:90+t:3')
    items = em_fetch(url)
    results = []
    for it in items:
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                'name': name,
                'change_pct': change / 100.0,
                'turnover': money / 1e8,
                'source': '概念板块',
            })
    return results


def fetch_em_industry_top():
    url = ('https://push2.eastmoney.com/api/qt/clist/get?'
           'pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa'
           '&fid=f3&fs=m:90+t:2')
    items = em_fetch(url)
    results = []
    for it in items:
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                'name': name,
                'change_pct': change / 100.0,
                'turnover': money / 1e8,
                'source': '行业板块',
            })
    return results


def fetch_em_stock_top():
    url = ('https://push2.eastmoney.com/api/qt/clist/get?'
           'pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa'
           '&fid=f3&fs=m:0+t:6+m:0+t:80+m:1+t:2+m:1+t:23')
    items = em_fetch(url)
    results = []
    for it in items:
        code = it.get('f12', '')
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                'code': code,
                'name': name,
                'change_pct': change / 100.0,
                'turnover': money / 1e8,
                'source': '个股',
            })
    return results


# ════════════════════════════════════════════════
# Telegram 推送
# ════════════════════════════════════════════════
def send_telegram(text, retries=3):
    if not TG_BOT_TOKEN:
        print('⚠️  未配置TG_BOT_TOKEN，跳过Telegram推送')
        return
    url = f'https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage'
    payload = json.dumps({
        'chat_id': TG_CHAT_ID,
        'text': text,
        'parse_mode': 'HTML',
    }).encode('utf-8')
    for attempt in range(retries):
        req = urllib.request.Request(url, data=payload, headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                result = json.loads(resp.read().decode('utf-8'))
                if result.get('ok'):
                    print('✅ Telegram推送成功')
                    return
                else:
                    print(f"❌ Telegram推送失败: {result.get('description', 'unknown')}")
                    return
        except Exception as e:
            if attempt < retries - 1:
                print(f'⚠️  Telegram推送第{attempt+1}次失败({e})，3秒后重试...')
                time.sleep(3)
            else:
                print(f'❌ Telegram推送失败(已重试{retries}次): {e}')


def _send_split(text):
    """Telegram 单条上限 4096 字符，按段落智能分条"""
    limit = 4000
    # 按段落分割，每个段落不超过 limit
    paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
    buf = ''
    for p in paragraphs:
        if not buf:
            buf = p
        elif len(buf) + len(p) + 2 <= limit:
            buf += '\n\n' + p
        else:
            # 段落太大就切
            while len(buf) > limit:
                cut = buf.rfind('\n', 0, limit)
                if cut < limit - 200:
                    cut = limit
                send_telegram(buf[:cut])
                buf = buf[cut:].strip()
            send_telegram(buf)
            buf = p
    if buf:
        send_telegram(buf)


# ════════════════════════════════════════════════
# Telegram 消息构建（信号排序 + 智能分条）
# ════════════════════════════════════════════════
def build_telegram_message(records, date_str):
    tgb = [r for r in records if r.get('site') == '淘股论坛']
    if not tgb:
        return f'🔥 <b>A股热帖交易情报</b>\\n📅 {date_str}\\n⚠️ 暂无淘股论坛数据'

    # 情绪统计
    sc = Counter(r['sentiment'] for r in tgb)
    bull, bear, neu = sc.get('看多', 0), sc.get('看空', 0), sc.get('中性', 0)
    total = len(tgb)

    # 排序: 优先高阅读+有交易逻辑的帖子
    def signal_score(r):
        tl = r.get('trade_logic', {})
        sa = len(tl.get('stock_actions', []))
        actions = len(tl.get('actions', []))
        return (r.get('reads', 0), sa + actions)

    tgb_sorted = sorted(tgb, key=signal_score, reverse=True)

    lines = [
        f"🔥 <b>A股热帖交易情报</b>",
        f"📅 {date_str} | 📊 淘股论坛{len(tgb)}条 + 东财{len(records)-len(tgb)}条",
        f"",
        f"📊 <b>情绪</b> 🔴看多{bull} 🟢看空{bear} ⚪中性{neu}",
        f"",
    ]

    # ── 执行摘要: 今天最重要的3条信号 ──
    top3 = tgb_sorted[:3]
    if top3:
        lines.append("🎯 <b>今日TOP3信号</b>")
        for i, r in enumerate(top3, 1):
            tl = r.get('trade_logic', {})
            sa = tl.get('stock_actions', [])[:2]
            sa_str = " | ".join(f"{s}→{a}" for s, a in sa) if sa else tl.get('strategies', [''])[0]
            lines.append(f"  {i}. <b>{r['title'][:40]}</b>")
            if sa_str:
                lines.append(f"     📈 {sa_str}")
            lines.append(f"     🔖 {r['stats']}")
        lines.append("")

    # ── 交易逻辑详情（深度，最多6条） ──
    logic_posts = [r for r in tgb_sorted if r.get('trade_logic', {}).get('stock_actions') or
                   r.get('trade_logic', {}).get('actions')]
    if logic_posts:
        lines.append("🧠 <b>交易逻辑（深度）</b>")
        for r in logic_posts[:6]:
            tl = r.get('trade_logic', {})
            sa = tl.get('stock_actions', [])[:3]
            sa_str = " | ".join(f"{s}→{a}" for s, a in sa) if sa else "—"
            rationale = (tl.get('rationale', '')[:60]).replace('\n', ' ').strip()
            lines.append(f"  · <b>{r['title'][:35]}</b>")
            lines.append(f"    📈 {sa_str}")
            if rationale:
                lines.append(f"    💡 {rationale}")
        lines.append("")

    # ── 被提及的热门股票 ──
    all_stocks = Counter()
    for r in tgb:
        for s in r.get('stocks', []):
            all_stocks[s] += 1
        for stock, _ in r.get('trade_logic', {}).get('stock_actions', []):
            all_stocks[stock] += 1
    if all_stocks:
        lines.append("🎯 <b>热门股票/概念 TOP8</b>")
        top8 = all_stocks.most_common(8)
        lines.append("  · " + " | ".join(f"<b>{s}</b>×{c}" for s, c in top8))
        lines.append("")

    # ── 概念板块 TOP5 ──
    em_concepts = sorted([r for r in records if r.get('source_data') == 'em_concept'],
                         key=lambda x: x.get('_raw', {}).get('change_pct', 0), reverse=True)[:5]
    if em_concepts:
        lines.append("💡 <b>概念板块 TOP5</b>")
        for r in em_concepts:
            raw = r.get('_raw', {})
            pct = raw.get('change_pct', 0) / 100.0
            lines.append(f"  · {raw.get('name', '')} {pct:+.1%}")
        lines.append("")

    # ── 个股涨幅 TOP5 ──
    em_stocks = sorted([r for r in records if r.get('source_data') == 'em_stock'],
                       key=lambda x: x.get('_raw', {}).get('change_pct', 0), reverse=True)[:5]
    if em_stocks:
        lines.append("📈 <b>个股涨幅 TOP5</b>")
        for r in em_stocks:
            raw = r.get('_raw', {})
            pct = raw.get('change_pct', 0) / 100.0
            lines.append(f"  · <b>{raw.get('name', '')}</b> {pct:+.1%}")
        lines.append("")

    # ── 看空信号（风险警示） ──
    bear_signals = [r for r in tgb if r['sentiment'] == '看空' and r.get('reads', 0) > 500]
    if bear_signals:
        lines.append("🟢 <b>看空信号（风险提示）</b>")
        for r in bear_signals[:3]:
            tl = r.get('trade_logic', {})
            strategies = tl.get('strategies', [])[:2]
            lines.append(f"  · <b>{r['title'][:40]}</b> {' | '.join(strategies)}")
        lines.append("")

    lines.append(f"📋 <i>详情见报告: report_{date_str}.md</i>")
    return '\n'.join(lines)


# ════════════════════════════════════════════════
# 报告生成（含执行摘要）
# ════════════════════════════════════════════════
def generate_report(records, date_str):
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report_path = REPORT_DIR / f"report_{date_str}.md"

    if not records:
        print('⚠️  无数据，跳过报告生成')
        return None

    tgb = [r for r in records if r['site'] == '淘股论坛']
    em_concepts = sorted([r for r in records if r.get('source_data') == 'em_concept'],
                         key=lambda x: x.get('_raw', {}).get('change_pct', 0), reverse=True)
    em_stocks = sorted([r for r in records if r.get('source_data') == 'em_stock'],
                       key=lambda x: x.get('_raw', {}).get('change_pct', 0), reverse=True)

    # 情绪统计
    sc = Counter(r['sentiment'] for r in tgb)
    bull, bear, neu = sc.get('看多', 0), sc.get('看空', 0), sc.get('中性', 0)
    bull_pct = bull / len(tgb) * 100 if tgb else 0
    bear_pct = bear / len(tgb) * 100 if tgb else 0

    # 股票池（合并 stocks + stock_actions）
    all_stocks = Counter()
    for r in tgb:
        for s in r.get('stocks', []):
            all_stocks[s] += 1
        for stock, _ in r.get('trade_logic', {}).get('stock_actions', []):
            all_stocks[stock] += 1

    # 关键词
    all_kw = []
    for r in tgb:
        all_kw.extend(r.get('keywords', []))
    kw_counts = Counter(all_kw)
    top_kw = kw_counts.most_common(15)

    # 分类
    realtrade_posts = sorted([r for r in tgb if r.get('realtrade_amount', 0) > 0],
                             key=lambda x: x['reads'], reverse=True)[:8]
    recommend_posts = sorted([r for r in tgb if '推荐' in r.get('post_types', [])],
                             key=lambda x: x['reads'], reverse=True)[:10]
    analysis_posts = sorted([r for r in tgb if '分析' in r.get('post_types', [])],
                            key=lambda x: x['reads'], reverse=True)[:10]
    contest_posts = sorted([r for r in tgb if '大赛' in r.get('post_types', [])],
                           key=lambda x: x['reads'], reverse=True)[:5]
    tgb_top_reads = sorted(tgb, key=lambda x: x.get('reads', 0), reverse=True)[:10]
    bull_posts = [r for r in tgb if r['sentiment'] == '看多']
    bear_posts = [r for r in tgb if r['sentiment'] == '看空']

    # 执行摘要: 从 sorted by signal_score 取 TOP3
    def signal_score(r):
        tl = r.get('trade_logic', {})
        return (r.get('reads', 0), len(tl.get('stock_actions', [])) + len(tl.get('actions', [])))

    top3_signals = sorted(tgb, key=signal_score, reverse=True)[:3]

    # 情绪倾向
    if bull_pct > bear_pct:
        trend = '🔴 偏多'
    elif bear_pct > bull_pct:
        trend = '🟢 偏空'
    else:
        trend = '⚪ 中性'

    # 识别热门概念（与股票分开展示）
    concept_terms = {'算力', '半导体', 'AI', '芯片', '机器人', '商业航天', '液冷',
                     '储能', '创新药', '军工', '低空经济', '卫星互联网', '人工智能',
                     '新能源车', '氢能', '风电', '光伏', '固态电池', '人形机器人'}
    hot_concepts = [s for s, _ in all_stocks.most_common(8) if s in concept_terms][:3]
    hot_stocks = [s for s, _ in all_stocks.most_common(8) if s not in concept_terms][:3]

    report = f"""# 🔥 A股热帖交易情报报告 v3.0
> 报告日期: {date_str} | 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 数据: 淘股论坛 {len(tgb)}条 + 东财 {len(records)-len(tgb)}条 | 总计 {len(records)}条

---

## 📋 执行摘要

| 维度 | 结论 |
|------|------|
| 情绪倾向 | {trend}（看多 {bull_pct:.0f}% / 看空 {bear_pct:.0f}% / 中性 {100-bull_pct-bear_pct:.0f}%）|
| 热门股票 | {', '.join(hot_stocks) or '无'} |
| 热门概念 | {', '.join(hot_concepts) or '无'} |

**📢 TOP3 今日信号：**
"""
    for i, r in enumerate(top3_signals, 1):
        tl = r.get('trade_logic', {})
        sa = tl.get('stock_actions', [])[:3]
        sa_str = ' | '.join(f'{s}→{a}' for s, a in sa) if sa else '—'
        report += f"- **{i}. {r['title'][:50]}** — {r['stats']} | 📈 {sa_str}\n"

    report += f"""
---

## 📊 淘股论坛情绪概况

| 情绪 | 帖子数 | 占比 |
|------|-------|------|
| 🔴 看多 | {bull} | {bull_pct:.1f}% |
| 🟢 看空 | {bear} | {bear_pct:.1f}% |
| ⚪ 中性 | {neu} | {100-bull_pct-bear_pct:.1f}% |

**倾向**: {trend}

---

## 🧠 交易逻辑详解（深度）

| 作者 | 标题 | 操作动作 | 策略/逻辑 | 股票×动作 |
|------|------|---------|----------|----------|
"""
    for r in sorted(tgb, key=signal_score, reverse=True):
        tl = r.get('trade_logic', {})
        actions = tl.get('actions', [])
        strategies = tl.get('strategies', [])
        stock_actions = tl.get('stock_actions', [])
        if not actions and not strategies and not stock_actions:
            continue
        actions_str = '、'.join(actions) if actions else '—'
        strategies_str = '、'.join(strategies) if strategies else '—'
        stock_str = ' | '.join([f'{s}→{a}' for s, a in stock_actions[:3]]) if stock_actions else '—'
        report += f"| {r['author']} | {r['title'][:45]} | {actions_str} | {strategies_str} | {stock_str} |\n"

    report += f"""
---

## 💰 实盘交易（含金额）

| 作者 | 标题 | 实盘金额 | 阅读 | 评论 | 操作 | 策略 |
|------|------|---------|-----|------|------|------|
"""
    for r in realtrade_posts:
        amt = r['realtrade_amount']
        unit = '万' if amt >= 1 else '千'
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        report += f"| {r['author']} | {r['title'][:45]} | {amt:.0f}{unit} | {r['reads']} | {r['comments']} | {actions_str} | {strategies_str} |\n"

    report += f"""
---

## 📣 推荐帖精选

| 作者 | 标题 | 阅读 | 评论 | 策略 | 操作 | 股票×动作 |
|------|------|-----|------|------|------|----------|
"""
    for r in recommend_posts:
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        stock_str = ' | '.join([f'{s}→{a}' for s, a in tl.get('stock_actions', [])[:2]]) if tl.get('stock_actions') else '—'
        report += f"| {r['author']} | {r['title'][:40]} | {r['reads']} | {r['comments']} | {strategies_str} | {actions_str} | {stock_str} |\n"

    report += f"""
---

## 📝 分析帖精选

| 作者 | 标题 | 阅读 | 评论 | 情绪 | 操作 | 策略 |
|------|------|-----|------|------|------|------|
"""
    for r in analysis_posts:
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        report += f"| {r['author']} | {r['title'][:40]} | {r['reads']} | {r['comments']} | {r['sentiment']} | {actions_str} | {strategies_str} |\n"

    report += f"""
---

## 🏆 实盘大赛

| 作者 | 标题 | 阅读 | 评论 |
|------|------|-----|------|
"""
    if contest_posts:
        for r in contest_posts:
            report += f"| {r['author']} | {r['title'][:55]} | {r['reads']} | {r['comments']} |\n"
    else:
        report += "*暂无大赛相关帖子*\n"

    report += f"""
---

## 🎯 被提及的热门股票/概念

| 股票/概念 | 提及次数 |
|----------|---------|
"""
    for stock, cnt in all_stocks.most_common(15):
        report += f"| {stock} | {cnt} |\n"

    report += f"""
---

## 🔥 淘股论坛热帖 TOP10 (阅读量)

| 排名 | 作者 | 标题 | 阅读 | 评论 | 情绪 | 标签 | 提及股票 | 操作动作 | 策略 |
|-----|-----|------|-----|-----|------|------|---------|---------|------|
"""
    for i, r in enumerate(tgb_top_reads, 1):
        tags = '、'.join(r.get('post_types', []))
        stocks_str = '、'.join(r.get('stocks', [])[:3]) or '—'
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        report += f"| {i} | {r['author']} | {r['title'][:35]} | {r['reads']} | {r['comments']} | {r['sentiment']} | {tags} | {stocks_str} | {actions_str} | {strategies_str} |\n"

    report += f"""
---

## 💡 概念板块涨幅 TOP10

| 排名 | 概念 | 涨跌幅 | 成交额(亿) |
|-----|------|--------|-----------|
"""
    for i, r in enumerate(em_concepts[:10], 1):
        raw = r.get('_raw', {})
        pct = raw.get('change_pct', 0) / 100.0
        money = raw.get('turnover', 0)
        report += f"| {i} | {raw.get('name', '')} | {pct:+.1%} | {money:.1f} |\n"

    report += f"""
---

## 📈 个股涨幅 TOP10

| 排名 | 代码 | 名称 | 涨跌幅 | 成交额(亿) |
|-----|------|------|--------|-----------|
"""
    for i, r in enumerate(em_stocks[:10], 1):
        raw = r.get('_raw', {})
        pct = raw.get('change_pct', 0) / 100.0
        money = raw.get('turnover', 0)
        report += f"| {i} | {raw.get('code', '')} | {raw.get('name', '')} | {pct:+.1%} | {money:.1f} |\n"

    report += f"""
---

## 🔍 热门关键词 TOP15

| 关键词 | 出现次数 |
|-------|---------|
"""
    for kw, cnt in top_kw:
        report += f"| {kw} | {cnt} |\n"

    report += f"""
---

## 🔴 看多热帖精选

| 来源 | 标题 | 阅读 | 关键词 | 提及股票 | 操作 | 策略 |
|-----|------|-----|-------|---------|------|------|
"""
    for r in bull_posts[:8]:
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        kw_str = '、'.join(r['keywords'][:3])
        stocks_str = '、'.join(r.get('stocks', [])[:3]) or '—'
        report += f"| {r['site']} | {r['title'][:40]} | {r['reads']} | {kw_str} | {stocks_str} | {actions_str} | {strategies_str} |\n"

    report += f"""
---

## 🟢 看空热帖精选

| 来源 | 标题 | 阅读 | 关键词 | 提及股票 | 操作 | 策略 |
|-----|------|-----|-------|---------|------|------|
"""
    for r in bear_posts[:8]:
        tl = r.get('trade_logic', {})
        actions_str = '、'.join(tl.get('actions', [])) if tl.get('actions') else '—'
        strategies_str = '、'.join(tl.get('strategies', [])) if tl.get('strategies') else '—'
        kw_str = '、'.join(r['keywords'][:3])
        stocks_str = '、'.join(r.get('stocks', [])[:3]) or '—'
        report += f"| {r['site']} | {r['title'][:40]} | {r['reads']} | {kw_str} | {stocks_str} | {actions_str} | {strategies_str} |\n"

    report += f"""
---

## 📋 数据明细
**采集时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**数据文件**: posts_{date_str}.jsonl
**报告文件**: report_{date_str}.md
**推送**: Telegram ({TG_CHAT_ID})

---
*本报告由 A股热帖交易情报系统 v3.0 自动生成*
*数据来源于公开论坛热帖 + 东方财富公开数据，仅供参考，不构成投资建议*
"""

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f'📊 报告生成: {report_path}')
    return report_path


# ════════════════════════════════════════════════
# 数据采集入口
# ════════════════════════════════════════════════
def fetch_site(name, method, pw_script=None):
    if method == 'playwright':
        r = subprocess.run(
            ['node', '-e', pw_script],
            cwd=str(PW_DIR), capture_output=True, text=True, timeout=180,
        )
        if r.returncode != 0:
            print(f'❌ {name}采集失败: {r.stderr[:300]}')
            return ''
        return r.stdout


def run():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime('%Y%m%d')
    jsonl_path = OUTPUT_DIR / f'posts_{today}.jsonl'
    today_records = []

    # ── 淘股论坛（主数据源）— Playwright 取正文区域 ──
    pw_tgb = '''
const { chromium } = require("./index.js");
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  await page.goto("https://m.tgb.cn/", { waitUntil: "networkidle", timeout: 30000 });
  await page.waitForTimeout(4000);
  const links = await page.evaluate(() => {
    const as = document.querySelectorAll("a");
    const seen = new Set(), arr = [];
    for (const a of as) {
      const h = a.href || "";
      if (/^https:\\/\\/m\\.tgb\\.cn\\/a\\/[A-Za-z0-9]+$/.test(h) && !seen.has(h)) {
        seen.add(h); arr.push(h);
      }
    }
    return arr.slice(0, 25);
  });
  const out = [];
  for (const url of links) {
    try {
      await page.goto(url, { waitUntil: "networkidle", timeout: 20000 });
      await page.waitForTimeout(2000);
      const title = (await page.evaluate(() =>
        document.querySelector("h1")?.textContent?.trim() || document.title)) || "";
      // 取正文区域（article/正文容器），不取整页
      const body = (await page.evaluate(() => {
        const els = document.querySelectorAll("article, .article-content, .post-content, #post-content, .content-area");
        return els.length ? els[0].innerText : document.body.innerText;
      })) || "";
      out.push(JSON.stringify({ url, title, body }));
    } catch(e) {
      out.push(JSON.stringify({ url, title: "", body: "", err: e.message }));
    }
  }
  console.log(out.join("\\n"));
  await browser.close();
})().catch(e => { console.error("ERR:"+e.message); process.exit(1); });
'''
    raw = fetch_site('淘股论坛', 'playwright', pw_script=pw_tgb)
    if raw:
        posts = parse_tgb_full(raw)
        today_records.extend([{**p, 'site': '淘股论坛'} for p in posts])
        print(f'✅ 淘股论坛: {len(posts)} 条 (含详情页正文)')

    # ── 东财概念板块 ──
    concept_top = fetch_em_concept_top()
    for c in concept_top:
        s, sc, kw = classify_sentiment(c['name'], '')
        today_records.append({
            'site': '东财·概念板块', 'source_data': 'em_concept',
            'ts': datetime.now().isoformat(), 'author': '东财',
            'title': f"{c['name']} ({c['change_pct']:+.1%})",
            'content': f"成交额{c['turnover']:.1f}亿",
            'stats': f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            'reads': int(c['turnover'] * 1e4), 'comments': 0,
            'sentiment': s, 'score': sc, 'keywords': kw,
            'post_types': ['数据'], 'stocks': [], 'realtrade_amount': 0,
            'trade_logic': {'actions': [], 'strategies': [], 'stock_actions': [], 'rationale': '', 'strategy_sentences': []},
            '_raw': c,
        })
    print(f'✅ 东财·概念板块: {len(concept_top)} 条')

    # ── 东财行业板块 ──
    industry_top = fetch_em_industry_top()
    for c in industry_top:
        s, sc, kw = classify_sentiment(c['name'], '')
        today_records.append({
            'site': '东财·行业板块', 'source_data': 'em_industry',
            'ts': datetime.now().isoformat(), 'author': '东财',
            'title': f"{c['name']} ({c['change_pct']:+.1%})",
            'content': f"成交额{c['turnover']:.1f}亿",
            'stats': f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            'reads': int(c['turnover'] * 1e4), 'comments': 0,
            'sentiment': s, 'score': sc, 'keywords': kw,
            'post_types': ['数据'], 'stocks': [], 'realtrade_amount': 0,
            'trade_logic': {'actions': [], 'strategies': [], 'stock_actions': [], 'rationale': '', 'strategy_sentences': []},
            '_raw': c,
        })
    print(f'✅ 东财·行业板块: {len(industry_top)} 条')

    # ── 东财个股 ──
    stock_top = fetch_em_stock_top()
    for c in stock_top:
        s, sc, kw = classify_sentiment(c['name'], '')
        today_records.append({
            'site': '东财·个股', 'source_data': 'em_stock',
            'ts': datetime.now().isoformat(), 'author': c.get('code', ''),
            'title': f"{c['name']} ({c.get('code', '')}) ({c['change_pct']:+.1%})",
            'content': f"成交额{c['turnover']:.1f}亿",
            'stats': f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            'reads': int(c['turnover'] * 1e4), 'comments': 0,
            'sentiment': s, 'score': sc, 'keywords': kw,
            'post_types': ['数据'], 'stocks': [c.get('name', '')], 'realtrade_amount': 0,
            'trade_logic': {'actions': [], 'strategies': [], 'stock_actions': [], 'rationale': '', 'strategy_sentences': []},
            '_raw': c,
        })
    print(f'✅ 东财·个股: {len(stock_top)} 条')

    if not today_records:
        print('❌ 所有数据源均失败')
        return

    # ── 去重 + 写JSONL ──
    seen, records = set(), []
    with open(jsonl_path, 'w', encoding='utf-8') as f:
        for p in today_records:
            key = hashlib.md5((p['site'] + p['title']).encode()).hexdigest()[:16]
            if key in seen:
                continue
            seen.add(key)
            if 'sentiment' not in p:
                s, sc, kw = classify_sentiment(p['title'], p.get('content', ''))
                p['sentiment'], p['score'], p['keywords'] = s, sc, kw
            f.write(json.dumps(p, ensure_ascii=False) + '\n')
            records.append(p)

    print(f'📊 去重 {len(records)} 条 → {jsonl_path}')

    # ── 生成报告 ──
    report_path = generate_report(records, today)

    # ── Telegram推送 ──
    if report_path:
        tg_text = build_telegram_message(records, today)
        _send_split(tg_text)


if __name__ == '__main__':
    run()
