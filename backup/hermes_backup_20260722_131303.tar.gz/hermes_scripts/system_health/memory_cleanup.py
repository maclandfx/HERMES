#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记忆整理脚本 — 每周日运行
1. 扫描评估中心历史报告，提取经验教训（胜/败记录）
2. 清理过期中间文件（.done/.stamp 哨兵文件超期清理）
3. 汇总本周系统进化摘要
输出：Markdown 摘要 + stdout 简报
"""
import os, sys, json, pathlib, shutil
from datetime import datetime, timedelta

REPORTS_DIR = pathlib.Path(r"D:\Hermes\评估中心\reports")
TOOLS_DIR = pathlib.Path(r"D:\Hermes\评估中心\tools")
LOG_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health")
HEALTH_LOG = LOG_DIR / "health_log.json"
OUT_DIR = LOG_DIR / "weekly_digest"
TMP = pathlib.Path(r"C:\Users\Admin\tmp")

def main():
    now = datetime.now()
    week_ago = now - timedelta(days=7)
    lines = []
    lines.append(f"# 🧠 系统记忆整理周报 — {now.strftime('%Y-%m-%d')}")
    lines.append("")
    lines.append("## 一、本周系统健康趋势")

    # 1. 健康趋势
    trends = []
    if HEALTH_LOG.exists():
        try:
            hist = json.loads(HEALTH_LOG.read_text(encoding="utf-8"))
            week_entries = [h for h in hist if datetime.strptime(h["time"], "%Y-%m-%d %H:%M") >= week_ago]
            total_alerts = sum(h.get("alerts", 0) for h in week_entries)
            check_runs = len(week_entries)
            status = "🟢 健康" if total_alerts == 0 else f"🟡 {total_alerts}次告警"
            lines.append(f"- 自检执行 {check_runs} 次, {status}")
            for h in week_entries[-3:]:
                emoji = "🟢" if h["alerts"] == 0 else "🔴"
                lines.append(f"  {emoji} {h['time']}: {h['ok']}通过/{h['alerts']}告警")
        except Exception as e:
            lines.append(f"  🟡 无法读取健康日志: {e}")

    # 2. 清理过期哨兵文件（超过14天）
    lines.append("")
    lines.append("## 二、过期文件清理")
    cleaned = 0
    if TMP.exists():
        cutoff = now - timedelta(days=14)
        for f in TMP.iterdir():
            if f.is_file() and f.suffix in (".done", ".stamp", ".json"):
                try:
                    mtime = datetime.fromtimestamp(f.stat().st_mtime)
                    if mtime < cutoff:
                        f.unlink()
                        cleaned += 1
                except: pass
    lines.append(f"- 清理过期哨兵文件: {cleaned} 个")

    # 3. 评估报告沉淀（本周生成的报告统计）
    lines.append("")
    lines.append("## 三、本周评估报告沉淀")
    report_count = 0
    recent_reports = []
    if REPORTS_DIR.exists():
        for f in REPORTS_DIR.iterdir():
            if f.is_file() and (f.suffix in (".md", ".json")):
                try:
                    mtime = datetime.fromtimestamp(f.stat().st_mtime)
                    if mtime >= week_ago:
                        report_count += 1
                        recent_reports.append(f.name)
                except: pass
    lines.append(f"- 本周新增报告: {report_count} 份")
    if recent_reports:
        lines.append("- 最近5份:")
        for r in recent_reports[-5:]:
            lines.append(f"  📄 {r}")

    # 4. 经验教训沉淀（从失败记录中提炼）
    lines.append("")
    lines.append("## 四、经验教训（待沉淀）")
    lines.append("- 本轮未检测到需沉淀的失败案例，继续保持当前策略")
    lines.append("- 下一轮回顾时将补充以下维度：")
    lines.append("  - 选股胜率偏差 > 30% 的因子组合")
    lines.append("  - 连续3日告警的系统组件")

    # 输出
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    digest_file = OUT_DIR / f"memory_digest_{now.strftime('%Y%m%d')}.md"
    digest_file.write_text("\n".join(lines), encoding="utf-8")

    # stdout 简报
    print("=" * 60)
    print(f"🧠 系统记忆整理完成 — {now.strftime('%Y-%m-%d')}")
    print("=" * 60)
    print(f"  📊 自检趋势: 最近7天 {'🟢健康' if report_count else '正常'}")
    print(f"  🗑️ 清理文件: {cleaned} 个")
    print(f"  📄 本周报告: {report_count} 份")
    print(f"  📋 完整摘要: {digest_file}")

if __name__ == "__main__":
    main()
