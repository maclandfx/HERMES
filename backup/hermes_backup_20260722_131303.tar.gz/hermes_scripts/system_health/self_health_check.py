#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统自我进化健康检查 — 在环境自检基础上，增加五个关键薄弱环节扫描：
1. 元认知层（知道能力边界）
2. 主动探索（空闲扫描新信号/新数据源）
3. 架构自评（反思系统应如何长）
4. 复盘执行（failure_case/best_solution_library 是否真正被检索）
5. 最优方案库调用（写入后是否被实际使用）
"""
import os, sys, json, pathlib, datetime, re, subprocess

# 路径
MEMORY_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\agent-memory")
FAILED_FILE = MEMORY_DIR / "failure_case.md"
BEST_FILE = MEMORY_DIR / "best_solution_library.md"
SCRIPTS_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts")
REPORT_DIR = pathlib.Path(r"D:\Hermes\研报研习\reports\analysis")
SUMM_DIR = pathlib.Path(r"D:\Hermes\研报研习\data\summaries")
HEALTH_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health")
SELF_HEALTH_LOG = HEALTH_DIR / "self_health_log.json"

def load_db(p):
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding='utf-8'))
    except:
        return None

def log_result(alerts, ok_count, warnings):
    SELF_HEALTH_LOG.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ok": ok_count,
        "warnings": len(warnings),
        "alerts": len(alerts),
    }
    history = []
    if SELF_HEALTH_LOG.exists():
        try:
            history = json.loads(SELF_HEALTH_LOG.read_text(encoding='utf-8'))
            history = history[-30:]
        except:
            pass
    history.append(entry)
    SELF_HEALTH_LOG.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding='utf-8')

def main():
    ok_count = 0
    alerts = []
    warnings = []

    # ===========================
    # 1. 元认知层：系统是否有明确的"能力边界"记录
    # ===========================
    has_capability_doc = any(MEMORY_DIR.glob("*capability*")) or any(MEMORY_DIR.glob("*boundary*"))
    if not has_capability_doc:
        alerts.append("【元认知缺失】没有能力边界文档，系统无法判断自己该不该做某件事")
        ok_count += 0
    else:
        ok_count += 1

    # ===========================
    # 2. 主动探索：是否有空闲时的自主扫描任务
    # ===========================
    # 检查是否有探索性脚本（如 idle_scan.py 或类似）
    explore_scripts = list(SCRIPTS_DIR.glob("*explore*")) + list(SCRIPTS_DIR.glob("*scan*"))
    if not explore_scripts:
        warnings.append("【主动探索缺失】空闲时没有自主扫描环境/数据源的机制，系统只跑cron")
    else:
        ok_count += 1

    # ===========================
    # 3. 架构自评：最近是否有系统架构反思报告
    # ===========================
    # 检查 reports 目录是否有 architecture / self_review 相关报告
    arch_reports = list(REPORT_DIR.glob("*architecture*")) + list(REPORT_DIR.glob("*self_review*"))
    # 也检查 system_health 下
    arch_reports += list(HEALTH_DIR.glob("*architecture*")) + list(HEALTH_DIR.glob("*self_review*"))
    # 检查评估中心reports
    eval_reports_dir = pathlib.Path(r"D:\Hermes\评估中心\reports")
    if eval_reports_dir.exists():
        arch_reports += list(eval_reports_dir.glob("*architecture*")) + list(eval_reports_dir.glob("*self_review*"))
    
    if not arch_reports:
        warnings.append("【架构自评缺失】系统从未产出过'系统应该长什么样'的反思报告")
    else:
        ok_count += 1

    # ===========================
    # 4. 复盘执行：failure_case.md 最近是否被更新
    # ===========================
    if FAILED_FILE.exists():
        try:
            content = FAILED_FILE.read_text(encoding='utf-8')
            # 统计案例数
            cases = re.findall(r'## 案例', content)
            # 检查最近更新时间
            stat = FAILED_FILE.stat()
            last_update = datetime.datetime.fromtimestamp(stat.st_mtime)
            days_since_update = (datetime.datetime.now() - last_update).days
            
            if days_since_update > 7:
                warnings.append(f"【复盘陈旧】failure_case.md 已 {days_since_update} 天未更新，教训可能过时")
            else:
                ok_count += 1
            
            if len(cases) < 3:
                warnings.append(f"【教训库薄弱】仅有 {len(cases)} 个案例，样本太少，不足以形成有效约束")
            
        except Exception as e:
            alerts.append(f"【复盘文件异常】无法读取 failure_case.md: {e}")
    else:
        alerts.append("【复盘文件缺失】failure_case.md 不存在，系统无历史教训库")

    # ===========================
    # 5. 最优方案库调用：best_solution_library.md 是否真正被检索
    # ===========================
    if BEST_FILE.exists():
        try:
            content = BEST_FILE.read_text(encoding='utf-8')
            solutions = re.findall(r'## 方案', content)
            # 检查是否有"未调用"标记或过旧
            stat = BEST_FILE.stat()
            last_update = datetime.datetime.fromtimestamp(stat.st_mtime)
            days_since_update = (datetime.datetime.now() - last_update).days
            
            if len(solutions) < 2:
                warnings.append(f"【方案库薄弱】仅有 {len(solutions)} 个最优方案，样本太少")
            else:
                ok_count += 1
            
            if days_since_update > 14:
                warnings.append(f"【方案库陈旧】best_solution_library.md 已 {days_since_update} 天未更新")
            
        except Exception as e:
            alerts.append(f"【方案库异常】无法读取 best_solution_library.md: {e}")
    else:
        alerts.append("【方案库缺失】best_solution_library.md 不存在，最优方案未被沉淀")

    # ===========================
    # 6. 研报分析引擎调用验证
    # ===========================
    analyzer_script = pathlib.Path(r"D:\Hermes\研报研习\scripts\report_analyzer.py")
    push_script = pathlib.Path(r"D:\Hermes\研报研习\scripts\report_analysis_push.py")
    
    if analyzer_script.exists():
        ok_count += 1
    else:
        alerts.append("【分析引擎缺失】report_analyzer.py 不存在")
    
    if push_script.exists():
        ok_count += 1
    else:
        alerts.append("【推送脚本缺失】report_analysis_push.py 不存在")

    # ===========================
    # 7. summaries 数据新鲜度
    # ===========================
    if SUMM_DIR.exists():
        json_files = list(SUMM_DIR.glob("*.json"))
        if json_files:
            latest = max(json_files, key=lambda x: x.stat().st_mtime)
            latest_time = datetime.datetime.fromtimestamp(latest.stat().st_mtime)
            hours_since = (datetime.datetime.now() - latest_time).total_seconds() / 3600
            if hours_since > 24 * 3:
                warnings.append(f"【数据陈旧】summaries 最新文件距今 {hours_since:.0f} 小时")
            else:
                ok_count += 1
        else:
            alerts.append("【数据源空】summaries 目录无 JSON 文件")
    else:
        alerts.append("【数据源缺失】summaries 目录不存在")

    # ===========================
    # 输出
    # ===========================
    print(f"📊 系统自我进化健康检查 — {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print("=" * 50)
    print(f"\n✅ 通过: {ok_count} 项")
    
    if warnings:
        print(f"\n⚠️ 警告 ({len(warnings)} 项):")
        for w in warnings:
            print(f"  {w}")
    
    if alerts:
        print(f"\n🔴 异常 ({len(alerts)} 项):")
        for a in alerts:
            print(f"  {a}")
    
    if not warnings and not alerts:
        print("\n🟢 系统自我进化机制完整，无薄弱环节")
    
    # 保存日志
    log_result(alerts, ok_count, warnings)
    
    print(f"\n📝 日志已保存: {SELF_HEALTH_LOG}")
    print("=" * 50)

if __name__ == "__main__":
    main()
