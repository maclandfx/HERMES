#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
每周评估滚动反馈 + 系统进化汇总
工作日 18:00 运行，轻量校准 + 本周趋势总结
"""
import subprocess, pathlib, sys, json
from datetime import datetime

PYTHON = r"C:\Users\Admin\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe"
TOOLS_DIR = pathlib.Path(r"D:\Hermes\评估中心\tools")
OUT_LOG = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health\weekly_feedback_log.json")

def run_cmd(cmd, timeout=600):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "TIMEOUT"
    except Exception as e:
        return -2, "", str(e)

def main():
    now = datetime.now()
    lines = []
    lines.append(f"# 📈 评估系统滚动反馈 — {now.strftime('%Y-%m-%d %H:%M')}")
    lines.append("")

    # 1. 运行周线分析（如果存在）
    weekly_script = TOOLS_DIR / "weekly_analysis.py"
    if weekly_script.exists():
        code, out, err = run_cmd(f"{PYTHON} {weekly_script}")
        if code == 0:
            lines.append("## ✅ 周线分析")
            lines.append("```\n" + out[:2000] + "\n```")
        else:
            lines.append(f"## ❌ 周线分析失败 (exit={code})\n```\n{err[:500]}\n```")

    # 2. 运行因子校准（如果存在）
    calib_script = TOOLS_DIR / "factor_calibrator.py"
    if calib_script.exists():
        code, out, err = run_cmd(f"{PYTHON} {calib_script}")
        if code == 0:
            lines.append("\n## ✅ 因子滚动校准")
            lines.append("```\n" + out[:2000] + "\n```")
        else:
            lines.append(f"\n## ❌ 因子校准失败 (exit={code})\n```\n{err[:500]}\n```")

    # 3. 记录日志
    OUT_LOG.parent.mkdir(parents=True, exist_ok=True)
    log_entry = {
        "time": now.strftime("%Y-%m-%d %H:%M"),
        "weekly_analysis": "ok" if weekly_script.exists() else "skipped",
        "calibration": "ok" if calib_script.exists() else "skipped",
    }
    history = []
    if OUT_LOG.exists():
        try:
            history = json.loads(OUT_LOG.read_text(encoding="utf-8"))
            history = history[-20:]
        except: pass
    history.append(log_entry)
    OUT_LOG.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")

    report_content = "\n".join(lines)
    # 保存本周反馈报告
    report_dir = pathlib.Path(r"D:\Hermes\评估中心\reports")
    report_dir.mkdir(parents=True, exist_ok=True)
    report_path = report_dir / f"weekly_feedback_{now.strftime('%Y%m%d')}.md"
    report_path.write_text(report_content, encoding="utf-8")

    print(report_content)
    print(f"\n📄 报告已保存: {report_path}")

if __name__ == "__main__":
    main()
