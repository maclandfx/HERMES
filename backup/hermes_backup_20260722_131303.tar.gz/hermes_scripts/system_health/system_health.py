#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
系统环境自检脚本 — 每日空闲时运行，检查关键工具健康度
输出：正常 → 静默；异常 → stdout 告警（cron no_agent 模式可靠投递）
"""
import os, sys, time, json, pathlib, socket, subprocess, importlib
from datetime import datetime

TOOLS_DIR = pathlib.Path(r"D:\Hermes\评估中心\tools")
PYTHON = r"C:\Python314\python.exe"
HEALTH_LOG = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health\health_log.json")

alerts = []
ok_count = 0

def check(name, ok: bool, detail: str = ""):
    global ok_count
    if ok:
        ok_count += 1
    else:
        alerts.append(f"  🔴 {name}: {detail}")

def main():
    global ok_count
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # 1. Python 可用
    try:
        r = subprocess.run([PYTHON, "--version"], capture_output=True, text=True, timeout=10)
        check("Python解释器", r.returncode == 0, f"exit={r.returncode} {r.stderr.strip()}")
    except Exception as e:
        check("Python解释器", False, str(e))

    # 2. 关键 Python 包
    for pkg in ["pandas", "numpy", "requests", "playwright", "tushare"]:
        try:
            importlib.import_module(pkg)
            ok_count += 1
        except ImportError:
            alerts.append(f"  🔴 缺失包: {pkg}")
        except Exception as e:
            alerts.append(f"  🟡 包异常 {pkg}: {e}")

    # 3. 关键脚本存在
    key_scripts = [
        TOOLS_DIR / "eval_smart.py",
        TOOLS_DIR / "factor_engine.py",
        TOOLS_DIR / "tdx_scanner_local.py",
        pathlib.Path(r"D:\Hermes\研报研习\scripts\track_monitor.py"),
        pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\qzjjxr_collector.py"),
        pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\cn_tracker.py"),
    ]
    for p in key_scripts:
        check(f"脚本存在: {p.name}", p.exists(), str(p))

    # 4. 代理连通性 (Clash 7890)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(3)
        s.connect(("127.0.0.1", 7890))
        s.close()
        ok_count += 1
    except Exception as e:
        alerts.append(f"  🔴 代理(127.0.0.1:7890)不可达: {e}")

    # 5. 输出目录可写
    for d in [pathlib.Path(r"D:\Hermes\评估中心\reports"),
              pathlib.Path(r"D:\Hermes\研报研习\reports")]:
        try:
            test_f = d / ".health_test"
            test_f.write_text(now, encoding="utf-8")
            test_f.unlink()
            ok_count += 1
        except Exception as e:
            alerts.append(f"  🔴 目录不可写 {d}: {e}")

    # 6. 数据库文件新鲜度（tdx .day 数据，标准 vipdoc 目录）
    tdx_data = pathlib.Path(r"D:\TDX\vipdoc")
    if tdx_data.exists():
        day_files = list(tdx_data.glob("**/*.day"))
        check("TDX数据存在", len(day_files) > 0, f"找到{len(day_files)}个.day文件")
    else:
        # 兜底：检查 T0002 老路径
        tdx_data2 = pathlib.Path(r"D:\TDX\T0002")
        day_files2 = list(tdx_data2.glob("**/*.day")) if tdx_data2.exists() else []
        check("TDX数据存在", len(day_files2) > 0, f"找到{len(day_files2)}个.day文件")

    # 7. 磁盘空间
    try:
        total, used, free = shutil.disk_usage("/")
        if free / (1024**3) < 5:
            alerts.append(f"  🔴 磁盘空间不足: 剩余 {free/(1024**3):.1f}GB")
        else:
            ok_count += 1
    except Exception as e:
        alerts.append(f"  🟡 无法检查磁盘: {e}")

    # 记录日志
    HEALTH_LOG.parent.mkdir(parents=True, exist_ok=True)
    log_entry = {
        "time": now,
        "total_checks": ok_count + len(alerts),
        "ok": ok_count,
        "alerts": len(alerts),
    }
    # 保留最近30条
    history = []
    if HEALTH_LOG.exists():
        try:
            history = json.loads(HEALTH_LOG.read_text(encoding="utf-8"))
            history = history[-29:]
        except: pass
    history.append(log_entry)
    HEALTH_LOG.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")

    # 投递：正常静默，异常输出
    if not alerts:
        print(f"🟢 系统自检通过 ({now}): {ok_count}项检查全部正常")
        return

    print(f"⚠️ 系统自检完成 ({now}): {ok_count}通过, {len(alerts)}项异常")
    print("")
    for a in alerts:
        print(a)

if __name__ == "__main__":
    import shutil
    main()
