#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
qzjjxr 研报采集 cron 包装器
用法: TELEGRAM_CODE=xxxxx python qzjjxr_cron_wrapper.py
"""
import os, sys, pathlib

COLLECTOR = pathlib.Path(r"D:\Hermes\研报研习\scripts\qzjjxr_collector.py")
TRACK_MONITOR = pathlib.Path(r"D:\Hermes\研报研习\scripts\track_monitor.py")

def run_collector():
    print("📡 开始采集 qzjjxr 频道研报...")
    env = os.environ.copy()
    r = subprocess.run([sys.executable, str(COLLECTOR)], env=env, timeout=300)
    return r.returncode

def run_track_scan():
    print("📊 开始扫描5大赛道研报...")
    r = subprocess.run([sys.executable, str(TRACK_MONITOR), "--scan"], timeout=600)
    return r.returncode

if __name__ == "__main__":
    import subprocess
    mode = sys.argv[1] if len(sys.argv) > 1 else "both"

    if mode in ("both", "qz"):
        run_collector()
    if mode in ("both", "track"):
        run_track_scan()
    print("✅ 研报采集+扫描完成")
