#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_policy_tracker.py — 政策落地进度追踪表
============================================================
功能：
  1. 维护 policy_tracker 表：政策名、目标值、当前进度、截止日
  2. 输出 Markdown 进度表，含进度条 emoji 🟢🟡🔴
  3. 可被 cn_tracker.py 尾部调用

库文件: D:/Hermes/同中书门下/产出/policy_tracker.db
"""
import sys, sqlite3, pathlib, datetime, json
DB_PATH = pathlib.Path("D:/Hermes/同中书门下/产出/policy_tracker.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def init_db():
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS policy_tracker (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            policy_name TEXT,
            indicator TEXT,
            target_value TEXT,
            current_value TEXT,
            current_pct REAL,
            deadline TEXT,
            source TEXT,
            update_date TEXT
        )
    """)
    conn.commit()
    return conn

def seed_if_empty(conn):
    """种子数据：十五五能源规划关键指标"""
    if conn.execute("SELECT COUNT(*) FROM policy_tracker").fetchone()[0] > 0:
        return
    today = datetime.date.today().strftime("%Y-%m-%d")
    seeds = [
        ("十五五新型储能", "新型储能装机", "3亿千瓦 (2030)", "1.5亿千瓦 (2024)", 50.0, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五抽水蓄能", "抽水蓄能装机", "1.6亿千瓦 (2030)", "0.95亿千瓦 (2024)", 59.4, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五虚拟电厂", "虚拟电厂调节能力", ">5000万千瓦 (2030)", "1800万千瓦 (2024)", 36.0, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五西电东送", "西电东送能力", ">4.2亿千瓦 (2030)", "3.4亿千瓦 (2024)", 81.0, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五核电", "在运核电装机", "~1.1亿千瓦 (2030)", "0.56亿千瓦 (2024)", 50.9, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五非化石能源发电", "非化石能源发电量比重", "50% (2030)", "42.3% (2024)", 84.6, "2030-12-31", "发改能源〔2026〕884号", today),
        ("十五五风光装机", "风光装机比重", ">50% (2030)", "43% (2024)", 86.0, "2030-12-31", "发改能源〔2026〕884号", today),
        ("工业互联网", "工业5G专网数量", "5万张 (2030)", "2.8万张 (2024)", 56.0, "2030-12-31", "工信部八部门实施意见 2026-06-29", today),
        ("工业互联网", "规上企业安全分类分级普及率", "80% (2030)", "42% (2024)", 52.5, "2030-12-31", "工信部八部门实施意见 2026-06-29", today),
    ]
    for s in seeds:
        conn.execute("""
            INSERT INTO policy_tracker (policy_name,indicator,target_value,current_value,current_pct,deadline,source,update_date)
            VALUES (?,?,?,?,?,?,?,?)
        """, s)
    conn.commit()

def render_table(conn):
    cur = conn.execute("""
        SELECT policy_name, indicator, target_value, current_value, current_pct, deadline, update_date
        FROM policy_tracker ORDER BY current_pct DESC
    """)
    rows = cur.fetchall()
    if not rows:
        return "⚠️ 无政策进度数据"
    out = []
    out.append("## 📋 政策落地进度追踪")
    out.append("")
    out.append("| 政策 | 指标 | 目标值 | 当前值 | 进度 | 进度条 | 截止日 | 最近更新 |")
    out.append("|---|---|---|---|---|---|---|---|")
    for name, indicator, target, current, pct, deadline, updt in rows:
        if pct is None: pct = 0
        # 进度条 10格
        bars = int(pct / 10)
        bar = "▰" * bars + "▱" * (10 - bars)
        if pct >= 80:
            flag = "🟢"
        elif pct >= 40:
            flag = "🟡"
        else:
            flag = "🔴"
        out.append(f"| {name} | {indicator} | {target} | {current} | {pct:.1f}% {flag} | {bar} | {deadline} | {updt} |")
    out.append("")
    return "\n".join(out)

def main():
    conn = init_db()
    seed_if_empty(conn)
    print(render_table(conn))
    conn.close()

if __name__ == "__main__":
    main()
