#!/bin/bash
# 每日系统进化报告 - Hermes Agent 系统自我评估

HERMES_HOME="/c/Users/Admin/AppData/Local/hermes"
SKILLS_DIR="$HERMES_HOME/skills"
LOGS_DIR="$HERMES_HOME/logs"
SESSIONS_DIR="$HERMES_HOME/sessions"
REPORT_TIME=$(date '+%Y-%m-%d %H:%M')
DATE_TODAY=$(date '+%Y-%m-%d')

echo "# 🌅 系统进化日报 - Hermes Agent"
echo ""
echo "**日期**: $DATE_TODAY | **生成时间**: $REPORT_TIME"
echo "**系统版本**: $(cat $HERMES_HOME/hermes-agent/VERSION 2>/dev/null || echo 'unknown')"
echo ""

echo "---"
echo ""

echo "## 1. 🧠 技能生态进化"
echo ""
echo "### 1.1 已安装技能"
echo ""
if [ -d "$SKILLS_DIR" ]; then
    skill_count=$(ls -1 $SKILLS_DIR 2>/dev/null | wc -l)
    echo "- **总技能数**: $skill_count"
    echo ""
    echo "**最近安装/更新的技能** (过去24小时):"
    echo ""
    find $SKILLS_DIR -type d -mmin -1440 2>/dev/null | head -10 | while read skill; do
        skill_name=$(basename $skill)
        echo "- \`$skill_name\`"
    done
    if [ $? -ne 0 ]; then
        echo "- 无新技能安装"
    fi
    echo ""
    echo "**技能分类分布**:"
    echo ""
    ls -1 $SKILLS_DIR 2>/dev/null | head -20 | while read skill; do
        echo "- $skill"
    done
else
    echo "- 技能目录不存在"
fi
echo ""

echo "---"
echo ""

echo "## 2. 📊 任务执行统计"
echo ""
if [ -d "$SESSIONS_DIR" ]; then
    recent_sessions=$(find $SESSIONS_DIR -name "*.jsonl" -mmin -1440 2>/dev/null | wc -l)
    echo "- **过去24小时会话数**: $recent_sessions"
    echo ""
    echo "**最近完成的会话**:"
    echo ""
    find $SESSIONS_DIR -name "*.jsonl" -mmin -1440 -type f 2>/dev/null | head -5 | while read session; do
        session_name=$(basename $session .jsonl)
        echo "- $session_name"
    done
else
    echo "- 会话目录不存在"
fi
echo ""

echo "---"
echo ""

echo "## 3. ⚙️ 配置变更"
echo ""
if [ -f "$HERMES_HOME/config.yaml" ]; then
    config_mtime=$(stat -c %y $HERMES_HOME/config.yaml 2>/dev/null | cut -d' ' -f1)
    echo "- **配置文件**: 最后修改 $config_mtime"
    if [ $(date +%s) - $(date -d "$config_mtime" +%s 2>/dev/null || echo 0) -lt 86400 ]; then
        echo "- ⚠️ 配置在过去24小时内有变更"
    fi
else
    echo "- 配置文件不存在"
fi
echo ""

echo "---"
echo ""

echo "## 4. 🐛 错误与问题"
echo ""
if [ -f "$LOGS_DIR/error.log" ]; then
    recent_errors=$(grep -c "$(date -d 'yesterday' '+%Y-%m-%d')\|$(date '+%Y-%m-%d')" $LOGS_DIR/error.log 2>/dev/null || echo 0)
    echo "- **过去24小时错误数**: $recent_errors"
    if [ $recent_errors -gt 0 ]; then
        echo ""
        echo "**最近错误摘要**:"
        grep "$(date -d 'yesterday' '+%Y-%m-%d')\|$(date '+%Y-%m-%d')" $LOGS_DIR/error.log 2>/dev/null | tail -5
    fi
else
    echo "- 错误日志不存在"
fi
echo ""

echo "---"
echo ""

echo "## 5. 🎯 系统健康度"
echo ""
# 检查各组件状态
echo "### 5.1 核心组件状态"
echo ""

# 检查 Hermes 进程
if pgrep -f hermes-agent > /dev/null; then
    echo "- ✅ Hermes Agent 进程: 运行中"
else
    echo "- ❌ Hermes Agent 进程: 未运行"
fi

# 检查配置
if [ -f "$HERMES_HOME/config.yaml" ]; then
    echo "- ✅ 配置文件: 存在"
else
    echo "- ❌ 配置文件: 不存在"
fi

# 检查技能
if [ -d "$SKILLS_DIR" ]; then
    echo "- ✅ 技能目录: 存在 ($skill_count 个技能)"
else
    echo "- ❌ 技能目录: 不存在"
fi

# 检查日志
if [ -f "$LOGS_DIR/error.log" ]; then
    echo "- ✅ 错误日志: 存在"
else
    echo "- ❌ 错误日志: 不存在"
fi

echo ""
echo "### 5.2 进化建议"
echo ""
echo "基于系统当前状态，建议:"
echo ""
echo "1. **技能优化**: 检查是否有过时或重复的技能需要更新"
echo "2. **配置审查**: 定期审查配置文件，移除无用配置"
echo "3. **日志清理**: 定期归档旧日志，避免磁盘占用过大"
echo "4. **性能监控**: 关注会话数量和处理时间，优化响应速度"
echo "5. **错误分析**: 分析错误日志，解决常见问题"
echo ""

echo "---"
echo ""
echo "**报告生成**: Hermes Agent 系统自动化"
echo "**下次推送**: 明天 $(date -d '+1 day' '+%Y-%m-%d') 09:00"
