# -*- coding: utf-8 -*-
"""盘前推送 (08:50) — 静默跑流程，只输出干净摘要给 Telegram"""
import os, sys, subprocess, datetime

WORK_DIR = r"D:\Hermes\评估中心"
TOOLS = os.path.join(WORK_DIR, "tools")
PYTHON = r"C:\Python314\python"

def run_silent(name, args=""):
    """静默执行子脚本；仅采集异常错误"""
    cmd = f'"{PYTHON}" "{TOOLS}/{name}" {args}'.strip()
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True,
                           encoding="utf-8", timeout=600)
        if r.returncode != 0 and r.stderr:
            err = r.stderr.strip()
            for line in err.split("\n"):
                if "Error" in line or "Traceback" in line:
                    print(f"⚠️ {name} 报错: {line.strip()}")
        return r.returncode == 0
    except subprocess.TimeoutExpired:
        print(f"⚠️ {name} 超时")
        return False
    except Exception as e:
        print(f"⚠️ {name} 异常: {e}")
        return False


def main():
    now = datetime.datetime.now()
    day = now.strftime("%Y-%m-%d")
    parts = []

    # [1] 数据同步（静默，只报结果）
    ok = run_silent("tdx_data_sync.py", "--check")
    parts.append(("🔄 数据同步", "✅ 完成" if ok else "⚠️ 异常"))

    # [2] 因子引擎
    ok = run_silent("factor_engine.py")
    parts.append(("🧮 因子计算", "✅ 完成" if ok else "⚠️ 异常"))

    # [3] 因子日报
    ok = run_silent("factor_reporter.py")
    parts.append(("📊 因子日报", "✅ 生成" if ok else "⚠️ 异常"))

    # [4] 追踪扫描
    ok = run_silent("tdx_tracker.py")
    parts.append(("📡 追踪扫描", "✅ 完成" if ok else "⚠️ 跳过"))

    # [5] 推送报告
    ok = run_silent("push_all_reports.py")
    parts.append(("📤 报告推送", "✅ 已推送" if ok else "⚠️ 异常"))

    # [6] PIAF 重大信号监控
    try:
        sys.path.insert(0, TOOLS)
        from alert_signals import check_signals, _send_alert
        triggered, text = check_signals()
        if triggered:
            _send_alert(text)
            print(f"\n🚨 PIAF 信号: 已推送预警")
        else:
            parts.append(("🔍 PIAF信号监控", "✅ 无重大信号"))
    except Exception as e:
        print(f"\n⚠️ PIAF监控异常: {e}")

    # ── 最终摘要（这就是发给 Telegram 的全部内容） ──
    lines = [
        f"# 📡 盘前推送 — {day}",
        f"⏰ {now.strftime('%H:%M')}  工作日",
        "",
        "**执行状态**",
        "",
        "| 模块 | 状态 |",
        "|------|------|",
    ]
    for module, status in parts:
        lines.append(f"| {module} | {status} |")

    lines.append("")
    lines.append("> 详细因子排名、评估报告已随附件下发")
    lines.append(f"*{day} 08:50 盘前流程完成*")

    print("\n".join(lines))


if __name__ == "__main__":
    main()
