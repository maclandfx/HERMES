#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""中国资本动向看门狗：核对 cn_tracker 哨兵新鲜度
正常 → 静默（不输出，cron no_agent 安静）
异常 → stdout 输出告警（cron verbatim投递）
"""
import os, sys, json, time, pathlib, datetime

TMP = pathlib.Path("C:/Users/Admin/tmp")
DONE = TMP / ".cn_tracker.done"
STAMP = TMP / "cn_tracker.stamp"
THRESH_H = 26  # 容许周末/节假日跳过


def alert(msg):
    print(msg)
    sys.exit(0)


def main():
    if not DONE.exists() and not STAMP.exists():
        alert("⚠️ 中国资本动向看门狗告警：cn_tracker 未运行过（无哨兵文件）")

    ts = None
    if STAMP.exists():
        try:
            ts = int(STAMP.read_text().strip())
        except Exception:
            ts = None
    if ts is None and DONE.exists():
        try:
            ts = int(json.loads(DONE.read_text(encoding="utf-8")).get("ts", 0))
        except Exception:
            ts = None
    if ts is None:
        alert("⚠️ 中国资本动向看门狗告警：哨兵文件存在但时间戳不可读")

    age_h = (time.time() - ts) / 3600
    if age_h > THRESH_H:
        dt = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
        print(f"⚠️ 中国资本动向看门狗告警：上次采集 {dt}，距今 {age_h:.1f}h 超过{THRESH_H}h阈值。可能 cron 未按时执行。")
        meta = {}
        if DONE.exists():
            try:
                meta = json.loads(DONE.read_text(encoding="utf-8"))
            except Exception:
                pass
        diag = []
        for f, key in [("ndrc_d.html", "ndrc_bytes"), ("miit_d.html", "miit_bytes"),
                       ("nea_d.html", "nea_bytes"), ("cn300750_d.json", "cn300750_bytes")]:
            sz = meta.get(key)
            if sz is None:
                p = TMP / f
                sz = p.stat().st_size if p.exists() else 0
            status = "OK" if sz > 1000 else "异常小"
            if sz <= 1000:
                diag.append(f"  - {f}: {sz}B ({status})")
        if diag:
            print("\n产物体检：\n" + "\n".join(diag))
        sys.exit(0)

    # 体积体检
    meta = {}
    if DONE.exists():
        try:
            meta = json.loads(DONE.read_text(encoding="utf-8"))
        except Exception:
            pass
    bad = []
    for f, key in [("ndrc_d.html", "ndrc_bytes"), ("miit_d.html", "miit_bytes"),
                   ("nea_d.html", "nea_bytes"), ("cn300750_d.json", "cn300750_bytes")]:
        sz = meta.get(key)
        if sz is None:
            p = TMP / f
            sz = p.stat().st_size if p.exists() else 0
        if sz <= 1000:
            bad.append(f"  - {f}: 哨兵记录 {sz}B（疑似抓取失败）")
    if bad:
        dt = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
        print(f"⚠️ 中国资本动向看门狗告警：上次采集 {dt}（{age_h:.1f}h前）产物体积异常")
        print("\n".join(bad))
        sys.exit(0)

    # 全正常 → 静默（空stdout = cron不推送）


if __name__ == "__main__":
    main()
