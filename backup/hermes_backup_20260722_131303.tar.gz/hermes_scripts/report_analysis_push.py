#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
研报深度分析推送包装器 v2.0
工作日 09:30 运行，获取最新研报 → 深度分析 → 推送 Telegram

数据源（优先级从高到低）：
1. summaries目录的JSON摘要文件（主数据源）
2. qzjjxr/reports目录的Markdown研报
3. 东方财富API（备用）
"""
import subprocess, pathlib, sys, json, datetime, os, urllib.request, urllib.error, time, glob, re
from pathlib import Path

# ===== 路径 =====
PYTHON = r"C:\Python314\python.exe"
ANALYZER_SCRIPT = Path(r"D:/Hermes/研报研习/scripts/report_analyzer.py")
SUMMARIES_DIR = Path(r"D:/Hermes/研报研习/data/summaries")
QZJJXR_REPORTS_DIR = Path(r"D:/Hermes/研报研习/data/qzjjxr/reports")
REPORTS_DIR = Path(r"D:/Hermes/研报研习/reports")
ANALYSIS_DIR = REPORTS_DIR / "analysis"

# ===== Telegram 配置 =====
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "8572871704:AAEFYo1h5IfqUS_5Sh621Mub39Z9yKD0GOM")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID", "8673372605")
TG_PROXY = os.environ.get("TG_PROXY", "http://127.0.0.1:7890")

def run_cmd(cmd, timeout=300):
    """运行命令并返回输出"""
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "TIMEOUT"
    except Exception as e:
        return -2, "", str(e)

def get_latest_summaries(limit=5):
    """从summaries目录获取最新研报摘要，从summary文本中提取元数据"""
    reports = []
    summaries = list(SUMMARIES_DIR.glob("*.json"))
    # 按修改时间排序
    summaries.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    for sp in summaries[:limit]:
        try:
            data = json.loads(sp.read_text(encoding='utf-8'))
            summary_text = data.get('summary', '')
            if not summary_text:
                continue
            
            # === 从summary文本中提取元数据 ===
            info_code = sp.stem.split('_')[0] if '_' in sp.stem else sp.stem
            
            # 1. 提取分析师：模式 "分析师：XXX" 或 "XXX（分析师）"
            analysts = re.findall(r'(?:证券)?分析师[:：]\s*([^,，\n，]+)', summary_text)
            if not analysts:
                analysts = re.findall(r'([\u4e00-\u9fff]{2,4})（分析师）', summary_text)
            if not analysts:
                analysts = re.findall(r'分析师[:：]?\s*(\w[\u4e00-\u9fff]+)', summary_text)
            analyst_str = '、'.join(analysts[:3]) if analysts else '未识别'
            
            # 2. 提取券商：从risk字段末尾找 "证券研究报告 XX证券"
            broker = '未识别'
            risk = data.get('risk', '')
            broker_match = re.search(r'证券研究报告\s*([\u4e00-\u9fff]{2,6}证券)', risk)
            if not broker_match:
                broker_match = re.search(r'([\u4e00-\u9fff]{2,6}证券)[，,\s]*$', summary_text[:500])
            if broker_match:
                broker = broker_match.group(1)
            
            # 3. 提取标题：尝试多种模式
            title = f"研报摘要_{info_code}"
            # 模式1: "—标题" 结尾
            title_match = re.search(r'—([^,\n，]+(?:报告|策略|分析|观点|周报|月报|展望|研究))', summary_text)
            if title_match:
                title = title_match.group(1).strip()
            else:
                # 模式2: 第一段关键信息作为标题
                first_line = summary_text.split('，')[0].split(',')[0].split('\n')[0]
                first_line = first_line.replace('▌', '').replace('◼', '').replace('➢', '').strip()
                if len(first_line) > 10:
                    # 清理过长标题
                    if len(first_line) > 60:
                        first_line = first_line[:57] + "..."
                    title = first_line
            
            # 4. 提取评级
            rating = data.get('rating', '未识别')
            if not rating:
                rating = '未识别'
            
            # 5. 提取风险
            risk_text = data.get('risk', '')
            if risk_text and risk_text != '未识别':
                risk_text = risk_text[:150] + "..." if len(risk_text) > 150 else risk_text
            
            # 6. 提取摘要前200字作为简介
            intro = summary_text[:200].replace('\n', ' ').strip()
            if len(summary_text) > 200:
                intro += "..."
            
            reports.append({
                'title': title,
                'broker': broker,
                'analyst': analyst_str,
                'rating': rating,
                'risk': risk_text,
                'content': summary_text,
                'intro': intro,
                'info_code': info_code,
                'pages_parsed': data.get('pages_parsed', 0),
                'text_chars': data.get('text_chars', 0),
            })
        except Exception as e:
            print(f"Error reading {sp}: {e}")
            continue
    
    return reports

def get_latest_reports_from_qzjjxr(limit=5):
    """从qzjjxr目录获取最新Markdown研报"""
    reports = []
    if not QZJJXR_REPORTS_DIR.exists():
        return reports
    
    md_files = list(QZJJXR_REPORTS_DIR.glob("*.md"))
    md_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    for fp in md_files[:limit]:
        try:
            content = fp.read_text(encoding='utf-8')
            # 从文件名提取标题
            title = fp.stem.replace('_', ' ')
            reports.append({
                'title': title,
                'broker': 'qzjjxr频道',
                'analyst': '未识别',
                'content': content,
            })
        except Exception as e:
            print(f"Error reading {fp}: {e}")
            continue
    
    return reports

def get_latest_reports_from_eastmoney(limit=5):
    """从东方财富获取最新研报列表"""
    reports = []
    
    try:
        url = "https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=%E7%A0%94%E8%AF%B8%E6%8A%A5%E6%95%B0%E6%8D%AE&pageSize=5&sortTypes=-1&sortColumns=REPORT_TIME"
        
        proxy_handler = urllib.request.ProxyHandler({
            'http': TG_PROXY,
            'https': TG_PROXY,
        })
        opener = urllib.request.build_opener(proxy_handler)
        urllib.request.install_opener(opener)
        
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://data.eastmoney.com/',
        })
        
        resp = urllib.request.urlopen(req, timeout=30)
        data = json.loads(resp.read())
        
        result = data.get('result')
        if not result:
            return reports
        
        data_list = result.get('data')
        if not data_list:
            return reports
        
        for item in data_list:
            if not item:
                continue
            title = item.get('REPORT_TITLE', '')
            broker = item.get('INSTITUTION_NAME', '')
            analyst = item.get('RESEARCHER_NAME', '')
            if title:
                reports.append({
                    'title': title,
                    'broker': broker,
                    'analyst': analyst,
                    'content': f"东方财富研报: {title}\n券商: {broker}\n分析师: {analyst}",
                })
    except Exception as e:
        print(f"Error fetching from eastmoney: {e}")
    
    return reports

def analyze_report(report):
    """使用report_analyzer.py分析研报"""
    # 构建完整的研报文本
    full_text = (
        f"标题：{report.get('title', '')}\n"
        f"券商：{report.get('broker', '未识别')}\n"
        f"分析师：{report.get('analyst', '未识别')}\n"
        f"评级：{report.get('rating', '未识别')}\n"
        f"\n正文：\n{report.get('content', '')}"
    )
    
    # 保存临时文件
    temp_file = ANALYSIS_DIR / f"temp_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.txt"
    temp_file.parent.mkdir(parents=True, exist_ok=True)
    temp_file.write_text(full_text, encoding='utf-8')
    
    # 运行分析脚本
    code, out, err = run_cmd(f"{PYTHON} {ANALYZER_SCRIPT} --file {temp_file}")
    
    if code == 0:
        temp_file.unlink(missing_ok=True)
        return out
    else:
        temp_file.unlink(missing_ok=True)
        print(f"Analysis failed for {report.get('title', '')}: {err}")
        return None

def build_telegram_report(reports):
    """构建Telegram推送报告"""
    now = datetime.datetime.now()
    lines = []

    lines.append("# 📊 研报深度分析日报")
    lines.append(f"📅 {now.strftime('%Y-%m-%d')}  研报数: {len(reports)}篇  ")
    lines.append("")

    if not reports:
        lines.append("⚠️ 今日暂无最新研报")
        lines.append("")
        lines.append("---")
        lines.append(f"*数据来源: summaries目录+qzjjxr频道+东方财富*")
        return "\n".join(lines)

    # 统计券商 / 评级
    brokers = []
    ratings = []
    for r in reports:
        if r.get('broker') and r['broker'] != '未识别':
            brokers.append(r['broker'])
        if r.get('rating') and r['rating'] != '未识别':
            ratings.append(r['rating'])
    broker_str = "、".join(dict.fromkeys(brokers)[:5])
    rating_str = "、".join(dict.fromkeys(ratings)) if ratings else "未识别"

    lines.append(f"**覆盖券商**: {broker_str}  |  **评级分布**: {rating_str}")
    lines.append("")

    # 研报清单（精简：标题+券商+评级）
    lines.append("## 📑 研报清单")
    lines.append("")
    lines.append("| # | 标题 | 券商 | 评级 |")
    lines.append("|---|------|------|------|")
    for i, r in enumerate(reports[:8], 1):
        t = r.get('title', '未命名')
        if len(t) > 38:
            t = t[:35] + "..."
        b = r.get('broker') or "—"
        ra = r.get('rating') or "—"
        lines.append(f"| {i} | {t} | {b} | {ra} |")
    lines.append("")

    # 选取第一篇做深度分析摘要（完整分析存入MD附件）
    first = reports[0]
    first_title = first.get('title', '未命名')
    if len(first_title) > 42:
        first_title = first_title[:39] + "..."
    analyst = first.get('analyst', '未识别')
    broker = first.get('broker', '未识别')

    lines.append("## 🔍 深度分析（首页研报）")
    lines.append("")
    lines.append(f"**{first_title}**")
    lines.append(f"🏢 {broker}  👤 {analyst}")
    lines.append("")

    analysis = analyze_report(first)
    if analysis:
        # 只摘关键结论：事实核查概况 + 最终判断 + 一句话总结
        summary_block = extract_conclusion(analysis)
        lines.append(summary_block)
    else:
        summary = first.get('content', '')
        lines.append(f"> {summary[:300]}...")
    lines.append("")

    lines.append("## 💡 操作建议")
    lines.append("")
    lines.append("• 关注量化目标与政策红利落地节奏")
    lines.append("• 警惕一致预期过热、估值方法缺失、缺乏负面观点")
    lines.append("• 完整分析见下方 MD 附件")
    lines.append("")
    lines.append("---")
    lines.append(f"*分析引擎: report_analyzer.py  |  {now.strftime('%Y-%m-%d %H:%M')}*")

    return "\n".join(lines)

def extract_conclusion(analysis):
    """从完整分析结果中提取简报结论（最终判断 + 一句话总结）"""
    lines = analysis.split("\n")
    result = []
    in_final = False
    in_summary = False

    for line in lines:
        if "最终判断" in line:
            in_final = True
            in_summary = False
            result.append(line)
            continue
        if "一句话总结" in line:
            in_final = False
            in_summary = True
            result.append(line)
            continue
        if in_final:
            if line.startswith("#") or line.startswith("##"):
                in_final = False
                if "一句话" not in line:
                    continue
                in_summary = True
            result.append(line)
        elif in_summary:
            if line.startswith("#"):
                in_summary = False
            result.append(line)

    # 兜底：如果没匹配到结构化结论，取最后 10 行
    if len(result) < 3:
        # 找"整体判断"和"一句话"两行
        for line in lines:
            if "整体判断" in line or "一句话" in line or "硬伤" in line:
                result.append(line)

    return "\n".join(result[:15]) if result else analysis[:600] + "\n..."


def push_to_telegram(content, bot_token=TG_BOT_TOKEN, chat_id=TG_CHAT_ID):
    """推送简报消息到Telegram，分块发送"""
    lines = content.split('\n')
    chunks = []
    current_chunk = []
    current_len = 0
    
    for line in lines:
        # 缩短过长的行
        if len(line) > 3000:
            line = line[:3000] + "..."
        if current_len + len(line) + 1 > 3500 and current_chunk:
            chunks.append('\n'.join(current_chunk))
            current_chunk = [line]
            current_len = len(line)
        else:
            current_chunk.append(line)
            current_len += len(line) + 1
    if current_chunk:
        chunks.append('\n'.join(current_chunk))
    
    proxy_handler = urllib.request.ProxyHandler({
        'http': TG_PROXY,
        'https': TG_PROXY,
    })
    opener = urllib.request.build_opener(proxy_handler)
    urllib.request.install_opener(opener)
    
    success = True
    for i, chunk in enumerate(chunks):
        # 使用纯文本模式，避免Markdown/HTML转义问题
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        data = json.dumps({
            "chat_id": chat_id,
            "text": chunk,
            "disable_web_page_preview": True,
        }).encode('utf-8')
        
        try:
            req = urllib.request.Request(url, data=data, headers={'Content-Type': 'application/json'})
            resp = urllib.request.urlopen(req, timeout=30)
            result = json.loads(resp.read())
            if not result.get('ok', False):
                print(f"Failed to send chunk {i+1}: {result}")
                success = False
        except Exception as e:
            print(f"Failed to send chunk {i+1}: {e}")
            success = False
        time.sleep(1)

    return success


def tg_send_file(filepath, caption=""):
    """发送文件附件（sendDocument）"""
    if not os.path.exists(filepath):
        print(f"  ⚠️ 文件不存在: {filepath}")
        return False
    try:
        import http.client, mimetypes
        boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
        fname = os.path.basename(filepath)
        with open(filepath, "rb") as f:
            fdata = f.read()
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="chat_id"\r\n\r\n{TG_CHAT_ID}\r\n'
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="document"; filename="{fname}"\r\n'
            f"Content-Type: text/markdown\r\n\r\n"
        ).encode("utf-8") + fdata + f"\r\n--{boundary}--\r\n".encode("utf-8")
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendDocument",
            data=body,
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        )
        proxy_handler = urllib.request.ProxyHandler({"http": TG_PROXY, "https": TG_PROXY})
        opener = urllib.request.build_opener(proxy_handler)
        resp = opener.open(req, timeout=30)
        result = json.loads(resp.read())
        if result.get("ok"):
            print(f"  ✅ 附件 {fname} 发送成功 ({len(fdata)} bytes)")
            return True
        else:
            print(f"  ❌ 附件发送失败: {result}")
            return False
    except Exception as e:
        print(f"  ❌ 附件发送失败: {e}")
        return False


def main():
    print("📊 研报深度分析推送 v3.0")
    print("=" * 50)

    # 获取研报（多数据源）
    summaries = get_latest_summaries(limit=8)
    print(f"summaries目录: {len(summaries)} 篇")

    qzjjxr = get_latest_reports_from_qzjjxr(limit=3)
    print(f"qzjjxr频道: {len(qzjjxr)} 篇")

    em_reports = get_latest_reports_from_eastmoney(limit=3)
    print(f"东方财富: {len(em_reports)} 篇")

    # 合并所有研报，优先使用summaries
    all_reports = summaries + qzjjxr + em_reports

    if not all_reports:
        print("\n⚠️ 所有数据源均无研报")
        return

    print(f"\n共 {len(all_reports)} 篇研报")

    # 构建简报（消息正文）
    print("\n构建简报...")
    brief = build_telegram_report(all_reports)

    # 保存完整报告（MD附件）
    report_path = ANALYSIS_DIR / f"daily_analysis_{datetime.datetime.now().strftime('%Y%m%d')}.md"
    report_path.write_text(brief, encoding="utf-8")
    print(f"报告已保存: {report_path}")

    # 发送简报消息
    print("\n发送简报消息...")
    success = push_to_telegram(brief)

    # 发送完整报告附件
    print("\n发送MD附件...")
    tg_send_file(str(report_path), caption="📊 研报深度分析日报（完整版）")

    print(f"\n{'=' * 50}")

if __name__ == "__main__":
    main()
