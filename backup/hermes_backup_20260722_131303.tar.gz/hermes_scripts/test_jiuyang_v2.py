#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""韭研公社采集测试 v2 — 修复点击超时问题"""
import subprocess, json, os, sys

PW_DIR = os.path.expanduser("~/AppData/Roaming/npm/node_modules/playwright")
COOKIE_DIR = os.path.expanduser("~/AppData/Local/hermes/data/sentiment_collector/cookies")
os.makedirs(COOKIE_DIR, exist_ok=True)
COOKIE_PATH = os.path.join(COOKIE_DIR, "jiuyang_cookies.json")

PW_SCRIPT = r'''
const { chromium } = require("./index.js");
const fs = require("fs");

(async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  page.setViewportSize({ width: 1280, height: 800 });

  const COOKIE_PATH = "${COOKIE_PATH}";

  // ── 1. 加载 Cookie（如果有的话）──
  if (fs.existsSync(COOKIE_PATH)) {
    const cookies = JSON.parse(fs.readFileSync(COOKIE_PATH, "utf8"));
    await context.addCookies(cookies);
    console.log("[JIUYAN] Loaded", cookies.length, "cookies");
  }

  // ── 2. 访问首页，检查登录状态 ──
  await page.goto("https://www.jiuyangongshe.com/", { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(5000);

  // 检查是否已登录 — 看是否有用户名/用户标识
  const loginCheck = await page.evaluate(() => {
    // 检查弹窗是否打开（登录弹窗）
    const loginDialog = document.querySelector(".el-dialog");
    const hasLoginDialog = loginDialog !== null;

    // 检查是否有用户菜单
    const userMenu = document.querySelector("[class*=user-menu], [class*=avatar]");
    const userText = userMenu ? userMenu.innerText.trim() : "";

    // 检查页面上是否有 "登录注册" 按钮
    const loginBtnText = document.body.innerText;
    const hasLoginBtn = loginBtnText.includes("登录注册");

    return {
      hasLoginDialog: hasLoginDialog,
      userText: userText.slice(0, 50),
      hasLoginBtn: hasLoginBtn,
      pageTitle: document.title,
      bodyLength: document.body.innerText.length,
    };
  });

  console.log("[JIUYAN] Login check:", JSON.stringify(loginCheck));

  let needsLogin = loginCheck.hasLoginBtn && !loginCheck.userText.includes("任盈盈");

  if (needsLogin) {
    console.log("[JIUYAN] Attempting login...");

    // 等待登录弹窗出现（如果已有弹窗则跳过）
    if (!loginCheck.hasLoginDialog) {
      // 点击登录按钮
      try {
        await page.click(".el-button--primary, button:has-text('登录')", { timeout: 5000 });
        await page.waitForTimeout(2000);
      } catch(e) {
        console.log("[JIUYAN] Could not click login button:", e.message);
      }
    }

    // 等待登录弹窗出现
    try {
      await page.waitForSelector(".el-dialog", { timeout: 3000 });
    } catch(e) {
      console.log("[JIUYAN] Login dialog not found, continuing anyway...");
    }

    // 点击账号密码 tab
    try {
      await page.click("#tab-accounts, .el-tabs__item:has-text('账号密码')", { timeout: 3000 });
      await page.waitForTimeout(1000);
    } catch(e) {
      console.log("[JIUYAN] Tab click failed:", e.message);
    }

    // 填写手机号
    try {
      await page.fill("#pane-accounts input[name=phone], input[type=tel]", "${JIUYAN_PHONE}", { timeout: 3000 });
    } catch(e) {
      console.log("[JIUYAN] Phone fill failed:", e.message);
    }

    // 填写密码
    try {
      await page.fill("#pane-accounts input[name=password], input[type=password]", "${JIUYAN_PASSWORD}", { timeout: 3000 });
    } catch(e) {
      console.log("[JIUYAN] Password fill failed:", e.message);
    }

    await page.waitForTimeout(500);

    // 点击登录按钮 — 用 page.click 在 dialog 内找按钮
    try {
      // 尝试多种选择器
      const loginBtnSelector = ".el-dialog button:has-text('登录'), .el-dialog .el-button--primary, .el-dialog button:last-child";
      const btn = await page.$(loginBtnSelector);
      if (btn) {
        await btn.click({ timeout: 5000 });
        console.log("[JIUYAN] Login button clicked");
      } else {
        console.log("[JIUYAN] Login button not found, trying press Enter");
        await page.keyboard.press("Enter");
      }
      await page.waitForTimeout(5000);
    } catch(e) {
      console.log("[JIUYAN] Login submit failed:", e.message);
    }

    // 保存 cookies
    const cookies = await context.cookies();
    try {
      fs.writeFileSync(COOKIE_PATH, JSON.stringify(cookies, null, 2));
      console.log("[JIUYAN] Saved", cookies.length, "cookies");
    } catch(e) {
      console.log("[JIUYAN] Failed to save:", e.message);
    }
  } else {
    console.log("[JIUYAN] Already logged in or no login needed");
  }

  // ── 3. 重新加载首页，采集帖子 ──
  await page.goto("https://www.jiuyangongshe.com/", { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(5000);

  // 再次检查登录状态
  const afterLogin = await page.evaluate(() => document.body.innerText.includes("任盈盈"));
  console.log("[JIUYAN] After login, user visible:", afterLogin);

  // 截图保存（调试用）
  await page.screenshot({ path: "/tmp/jiuyang_debug.png" });
  console.log("[JIUYAN] Screenshot saved to /tmp/jiuyang_debug.png");

  // 采集帖子
  const posts = await page.evaluate(() => {
    const results = [];
    const sections = document.querySelectorAll("section");
    sections.forEach(section => {
      const titleEl = section.querySelector(".book-title, h2, h3");
      const title = titleEl ? titleEl.innerText.trim() : "";
      if (!title) return;

      const authorEl = section.querySelector("[class*=author], [class*=user]");
      const author = authorEl ? authorEl.innerText.trim().slice(0, 20) : "未知";

      const timeEl = section.querySelector("[class*=time]");
      const time = timeEl ? timeEl.innerText.trim() : "";

      const fullText = section.innerText.slice(0, 1000);

      results.push({
        title: title.slice(0, 150),
        author: author,
        time: time,
        fullText: fullText,
      });
    });
    return results;
  });

  // 获取页面完整文本（备用）
  const fullPageText = await page.evaluate(() => document.body.innerText.slice(0, 5000));

  console.log(JSON.stringify({
    posts: posts,
    fullPageText: fullPageText.slice(0, 2000),
    timestamp: new Date().toISOString(),
  }, null, 2));

  await browser.close();
})().catch(e => {
  console.error("[JIUYAN] FATAL:", e.message);
  process.exit(1);
});
'''

r = subprocess.run(
    ["node", "-e", PW_SCRIPT],
    cwd=PW_DIR, capture_output=True, text=True, timeout=120,
)

if r.returncode != 0:
    print(f"❌ 韭研公社采集失败: {r.stderr[:500]}")
    sys.exit(1)

print("✅ 韭研公社采集完成:")
print(r.stdout)