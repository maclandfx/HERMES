import subprocess, os, sys
py = r"C:/Python314/python.exe"
script = os.path.join(os.path.dirname(__file__), "tdx_blk_monitor.py")
os.chdir(os.path.dirname(__file__))
r = subprocess.run([py, script])
sys.exit(r.returncode)
