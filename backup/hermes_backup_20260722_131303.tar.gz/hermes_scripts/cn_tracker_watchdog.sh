#!/usr/bin/env bash
# 看门狗：核对 cn_tracker 哨兵新鲜度
# 正常 → 静默（不输出，cron no_agent 会安静发送）
# 异常 → stdout 输出告警（cron 会推送）
set -u
/c/Python314/python.exe - <<'PY' 2>&1
import json, time, pathlib, datetime, sys
b=pathlib.Path("C:/Users/Admin/tmp")
alerts=[]

# 1. 哨兵文件存在性
done=b/".cn_tracker.done"; stamp=b/"cn_tracker.stamp"
if not done.exists() and not stamp.exists():
    print("⚠️ 中国资本动向看门狗告警：cn_tracker 未运行过（无哨兵文件）")
    sys.exit(0)

# 2. 时间戳新鲜度（26小时阈值，容许周末/节假日跳过）
ts=None
if stamp.exists():
    try: ts=int(stamp.read_text().strip())
    except: pass
if ts is None and done.exists():
    try: ts=int(json.loads(done.read_text(encoding="utf-8")).get("ts",0))
    except: pass
if ts is None:
    print("⚠️ 中国资本动向看门狗告警：哨兵文件存在但时间戳不可读")
    sys.exit(0)

age_h=(time.time()-ts)/3600
if age_h>26:
    dt=datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
    print(f"⚠️ 中国资本动向看门狗告警：上次采集 {dt}，距今 {age_h:.1f}h 超过26h阈值。可能 cron 未按时执行。")
    # 同时核对各产物体积以辅助诊断
    for f in ["ndrc_d.html","miit_d.html","nea_d.html","cn300750_d.json"]:
        p=b/f; sz=p.stat().st_size if p.exists() else 0
        status="OK" if sz>1000 else "异常小"
        if sz<=1000: alerts.append(f"  - {f}: {sz}B ({status})")
    if alerts: print("\n产物体检：\n"+"\n".join(alerts))
    sys.exit(0)

# 3. 各产物体积下限（1KB）
meta={}
if done.exists():
    try: meta=json.loads(done.read_text(encoding="utf-8"))
    except: pass
for f,key in [("ndrc_d.html","ndrc_bytes"),("miit_d.html","miit_bytes"),("nea_d.html","nea_bytes"),("cn300750_d.json","cn300750_bytes")]:
    sz=meta.get(key)
    if sz is None:
        p=b/f; sz=p.stat().st_size if p.exists() else 0
    if sz<=1000:
        alerts.append(f"  - {f}: 哨兵记录 {sz}B（疑似抓取失败）")
if alerts:
    dt=datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")
    print(f"⚠️ 中国资本动向看门狗告警：上次采集 {dt}（{age_h:.1f}h前）产物体积异常")
    print("\n".join(alerts))
    sys.exit(0)

# 全正常 → 静默（空stdout = cron不推送）
PY
