#!/usr/bin/env python3
"""收盘因子快读 — no_agent cron wrapper"""
import subprocess, sys

PYTHON = r"C:\Python314\python.exe"
SCRIPT = r"D:\Hermes\评估中心\tools\closing_factors_brief.py"
WORKDIR = r"D:\Hermes\评估中心\tools"

r = subprocess.run(
    [PYTHON, SCRIPT],
    capture_output=True, text=True, encoding="utf-8",
    cwd=WORKDIR, timeout=300,
)
sys.stdout.write(r.stdout)
if r.returncode != 0:
    sys.stdout.write(f"\n❌ 执行失败 (rc={r.returncode})\n{r.stderr[-500:]}")
sys.exit(r.returncode)
