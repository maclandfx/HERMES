@echo off
chcp 65001 >nul
set "PYTHON=C:\Users\Admin\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe"
set "REPORT=%~dp0daily_evolution_report.py"
set "PUSH=%~dp0push_mcp_report.py"
set "OUT=%~dp0evolution_report_today.txt"

%PYTHON% "%REPORT%" > "%OUT%" 2>nul
%PYTHON% "%PUSH%" --file "%OUT%" 2>nul
