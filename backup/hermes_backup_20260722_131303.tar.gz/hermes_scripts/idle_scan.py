#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主动探索脚本 idle_scan.py — 空闲时自主扫描环境
扫描内容：
1. 数据源新鲜度
2. 异常信号（连续失败任务、磁盘异常、代理异常）
3. 新数据源机会
4. 系统配置变更

运行方式：每周三 01:00 cron 调度，或手动 python idle_scan.py
输出：发现的新信号/异常/机会 → stdout
"""

import os, sys, json, pathlib, datetime, socket, subprocess, re
from datetime import datetime, timedelta

PYTHON = r"C:\Python314\python.exe"
MEMORY_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\agent-memory")
FAILED_FILE = MEMORY_DIR / "failure_case.md"
BEST_FILE = MEMORY_DIR / "best_solution_library.md"
SUMMARIES_DIR = pathlib.Path(r"D:\Hermes\研报研习\data\summaries")
REPORTS_DIR = pathlib.Path(r"D:\Hermes\研报研习\data\qzjjxr\reports")
EVAL_REPORTS_DIR = pathlib.Path(r"D:\Hermes\评估中心\reports")
SCRIPTS_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts")
HEALTH_LOG = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health\self_health_log.json")
CRON_DATA_DIR = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\.cron")

# 可能的新数据源（待探索）
POTENTIAL_SOURCES = [
    ("Alpha Vantage", "https://www.alphavantage.co/", "财经数据API"),
    ("FRED 美联储", "https://fred.stlouisfed.org/", "宏观经济指标"),
    ("Wind 万得", "https://www.wind.com.cn/", "终端数据"),
    ("同花顺 iFinD", "https://www.51ifind.com/", "金融数据"),
    ("雪球", "https://xueqiu.com/", "投资社区+数据"),
    ("东方财富股吧", "https://guba.eastmoney.com/", "投资者情绪"),
    ("巨潮资讯", "http://www.cninfo.com.cn/", "公告数据"),
    ("国家数据", "https://data.stats.gov.cn/", "统计局"),
]


def check_proxy():
    """检查代理连接状态"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(3)
        s.connect(("127.0.0.1", 7890))
        s.close()
        return True, "代理(127.0.0.1:7890)正常"
    except Exception as e:
        return False, f"代理异常: {e}"


def check_cron_failures():
    """检查cron任务失败情况"""
    findings = []
    if not CRON_DATA_DIR.exists():
        return findings
    
    cron_files = list(CRON_DATA_DIR.glob("*.json"))
    for cf in cron_files:
        try:
            data = json.loads(cf.read_text(encoding="utf-8"))
            # 看是否有连续失败记录
            if isinstance(data, dict) and data.get("last_status") == "failed":
                findings.append(f"  ⚠️ Cron任务失败: {data.get('name', 'unknown')}")
            if isinstance(data, dict) and data.get("consecutive_failures", 0) >= 2:
                findings.append(f"  🔴 Cron连续失败≥2次: {data.get('name', 'unknown')}")
        except:
            pass
    return findings


def check_summary_freshness():
    """检查summaries目录新鲜度"""
    findings = []
    if not SUMMARIES_DIR.exists():
        return ["  🔴 summaries目录不存在"]
    
    json_files = list(SUMMARIES_DIR.glob("*.json"))
    if not json_files:
        return ["  🟡 summaries目录为空"]
    
    latest = max(json_files, key=lambda x: x.stat().st_mtime)
    latest_time = datetime.fromtimestamp(latest.stat().st_mtime)
    hours_since = (datetime.now() - latest_time).total_seconds() / 3600
    
    total_files = len(json_files)
    today_files = sum(1 for f in json_files 
                     if datetime.fromtimestamp(f.stat().st_mtime).date() == datetime.now().date())
    
    findings.append(f"  📊 summaries: {total_files}个文件, 最新{hours_since:.0f}小时前, 今日{today_files}个")
    
    if hours_since > 72:
        findings.append(f"  ⚠️ 数据陈旧: 最新文件距今{hours_since:.0f}小时")
    
    return findings


def check_reports_freshness():
    """检查研报报告目录新鲜度"""
    findings = []
    for d, label in [(REPORTS_DIR, "qzjjxr研报"), (EVAL_REPORTS_DIR, "评估报告")]:
        if not d.exists():
            findings.append(f"  🔴 {label}目录不存在")
            continue
        
        md_files = list(d.glob("*.md"))
        if not md_files:
            findings.append(f"  🟡 {label}目录为空")
            continue
        
        latest = max(md_files, key=lambda x: x.stat().st_mtime)
        latest_time = datetime.fromtimestamp(latest.stat().st_mtime)
        hours_since = (datetime.now() - latest_time).total_seconds() / 3600
        
        findings.append(f"  📄 {label}: {len(md_files)}个文件, 最新{hours_since:.0f}小时前")
    
    return findings


def check_disk_space():
    """检查磁盘空间"""
    findings = []
    try:
        total, used, free = shutil.disk_usage("/")
        free_gb = free / (1024**3)
        if free_gb < 5:
            findings.append(f"  🔴 磁盘空间不足: 剩余{free_gb:.1f}GB")
        else:
            findings.append(f"  🟢 磁盘空间: 剩余{free_gb:.1f}GB")
    except Exception as e:
        findings.append(f"  ⚠️ 无法检查磁盘: {e}")
    return findings


def check_data_source_connectivity():
    """检查可能的新数据源连通性"""
    findings = []
    import urllib.request
    for name, url, desc in POTENTIAL_SOURCES:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                status = resp.status
                if status == 200:
                    findings.append(f"  🟢 {name}({url}) 可访问")
                else:
                    findings.append(f"  🟡 {name} 返回状态{status}")
        except Exception as e:
            findings.append(f"  🔴 {name} 不可达: {str(e)[:40]}")
    return findings


def check_skill_changes():
    """检查技能/脚本是否有新变更"""
    findings = []
    try:
        scripts = list(SCRIPTS_DIR.glob("*.py"))
        for s in scripts:
            mtime = datetime.fromtimestamp(s.stat().st_mtime)
            hours_ago = (datetime.now() - mtime).total_seconds() / 3600
            if hours_ago < 24:
                findings.append(f"  📝 脚本变更: {s.name} ({hours_ago:.0f}小时前)")
    except:
        pass
    return findings


def check_failure_case_update():
    """检查failure_case是否近期更新"""
    findings = []
    if not FAILED_FILE.exists():
        return ["  🔴 failure_case.md 不存在"]
    
    mtime = datetime.fromtimestamp(FAILED_FILE.stat().st_mtime)
    days_ago = (datetime.now() - mtime).days
    findings.append(f"  📋 failure_case: 最后更新{days_ago}天前")
    
    if days_ago > 7:
        findings.append(f"  🟡 教训库陈旧: 已超过7天未更新")
    
    return findings


def main():
    print(f"# 🔬 主动探索报告 — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    
    all_findings = []
    
    # 1. 代理检查
    print("\n## 📡 代理连接")
    ok, msg = check_proxy()
    print(f"  {msg}")
    all_findings.append(msg)
    
    # 2. Cron任务失败检查
    print("\n## ⚠️ Cron异常")
    cron_findings = check_cron_failures()
    if cron_findings:
        for f in cron_findings:
            print(f)
        all_findings.extend(cron_findings)
    else:
        print("  ✅ 无异常")
    
    # 3. 数据源新鲜度
    print("\n## 📊 数据源新鲜度")
    for f in check_summary_freshness():
        print(f)
        all_findings.append(f)
    for f in check_reports_freshness():
        print(f)
        all_findings.append(f)
    
    # 4. 磁盘空间
    print("\n## 💾 磁盘空间")
    for f in check_disk_space():
        print(f)
        all_findings.append(f)
    
    # 5. 新数据源连通性
    print("\n## 🔍 新数据源探测")
    for f in check_data_source_connectivity():
        print(f)
        all_findings.append(f)
    
    # 6. 脚本变更
    print("\n## 📝 系统变更")
    for f in check_skill_changes():
        print(f)
        all_findings.append(f)
    
    # 7. failure_case更新状态
    print("\n## 📋 教训库状态")
    for f in check_failure_case_update():
        print(f)
        all_findings.append(f)
    
    # 总结
    print("\n" + "=" * 50)
    critical = [f for f in all_findings if f.startswith("  🔴")]
    warning = [f for f in all_findings if f.startswith("  🟡")]
    info = [f for f in all_findings if f.startswith("  📊") or f.startswith("  📄")]
    
    print(f"\n📈 探索总结:")
    print(f"  🔴 关键异常: {len(critical)}个")
    print(f"  🟡 警告: {len(warning)}个")
    print(f"  📊 信息: {len(info)}个")
    
    if critical:
        print(f"\n  ⚠️ 发现关键异常，建议立即处理:")
        for f in critical:
            print(f"    {f}")
    
    # 保存日志
    log_dir = pathlib.Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\system_health")
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "idle_scan_log.json"
    
    try:
        history = []
        if log_file.exists():
            history = json.loads(log_file.read_text(encoding="utf-8"))
            history = history[-30:]
        history.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "critical": len(critical),
            "warning": len(warning),
            "info": len(info),
        })
        log_file.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")
    except:
        pass
    
    print("\n📝 日志已保存: idle_scan_log.json")


if __name__ == "__main__":
    import shutil
    main()
