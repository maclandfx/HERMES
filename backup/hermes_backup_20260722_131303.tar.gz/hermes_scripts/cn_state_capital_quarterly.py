#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
cn_state_capital_quarterly.py — 国家队季度持仓追踪
============================================================
功能：
  1. 抓取布局池所有标的的前十大流通股东 (top10_floatholders)
  2. 筛选国家队账户（汇金/证金/大基金/诚通/国新/社保/养老金）
  3. 与上季度持仓对比，输出 增持/减持/新进/退出 四级信号
  4. 持久化到同中书门下/产出/国家队员仓.jsonl

cron触发: 季初（1月/4月/7月/10月）季报披露截止后
手动: python cn_state_capital_quarterly.py
"""
import os, sys, json, time, datetime, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from tushare_client import call, as_records

TMP = pathlib.Path("C:/Users/Admin/tmp")
TMP.mkdir(parents=True, exist_ok=True)
OUT_DIR = pathlib.Path("D:/Hermes/同中书门下/产出")
OUT_DIR.mkdir(parents=True, exist_ok=True)
HISTORY_FILE = OUT_DIR / "国家队员仓.jsonl"

# ============================================================================F
# 布局池 标的清单（行业代表性 + 政策锚定）
# ============================================================================F
LAYOUT_POOL = [
    # 新型电力系统 / 储能
    ("600406.SH", "国电南瑞", "电网/智能调度"),
    ("300274.SZ", "阳光电源", "储能/PCS"),
    ("300750.SZ", "宁德时代", "动力电池/储能"),
    # 半导体自主可控
    ("002049.SZ", "紫光国微", "特种集成电路"),
    ("688981.SZ", "中芯国际", "晶圆代工"),
    # 商业航天 / 低空
    ("600118.SH", "中国卫星", "卫星制造"),
    # 中特估 / 央企
    ("600938.SH", "中国海油", "能源央企"),
    ("601728.SH", "中国电信", "通信央企"),
    # 工业互联网
    ("600845.SH", "宝信软件", "工业软件/平台"),
]

# ============================================================================F
# 国家队账户关键词（substring 匹配 holder_name）
# ============================================================================F
NATIONAL_TEAM_KEYWORDS = [
    "中央汇金", "汇金资产管理", "汇金资产管理有限责任公司",
    "中国证券金融", "证金公司", "证金金融产品",
    "国家集成电路产业投资基金", "国华集成电路", "大基金",
    "中国国新", "国新控股", "诚通", "诚通基金",
    "全国社保基金", "社保基金理事会", "基本养老保险",
    "中国国有企业结构调整基金", "国家制造业转型基金",
]


def is_national_team(holder_name):
    if not holder_name:
        return False
    nm = holder_name.replace(" ", "")
    return any(k.replace(" ", "") in nm for k in NATIONAL_TEAM_KEYWORDS)


def fetch_top10_float(ts_code, period):
    """抓取某股某季前十大流通股东; period 例: 20260331
    返回最多10条 (按ann_date最新去重, 同holder_name保留最新公告)
    """
    d = call("top10_floatholders",
             {"ts_code": ts_code, "end_date": period},
             ["ts_code", "ann_date", "end_date", "holder_name",
              "hold_amount", "hold_ratio", "hold_float_ratio", "hold_change",
              "holder_type"])
    records = as_records(d)
    if not records:
        return []
    # 同holder_name保留ann_date最大的一条 (季报多次修订时取最新披露)
    by_name = {}
    for r in records:
        nm = r.get("holder_name", "")
        ann = r.get("ann_date", "")
        if nm and (nm not in by_name or ann > by_name[nm].get("ann_date", "")):
            by_name[nm] = r
    return list(by_name.values())


def load_last_quarter_snapshot(cur_period):
    """加载与 cur_period 不同的最近一个period的快照(dict[ts_code] -> {holders, period, ...})"""
    if not HISTORY_FILE.exists():
        return {}
    # 按ts_code分组,挑period<cur_period中最大的记录
    by_code = {}
    for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
        try:
            rec = json.loads(line)
        except Exception:
            continue
        code = rec.get("ts_code")
        per = rec.get("period", "")
        if not code or not per or per >= cur_period:
            continue
        if code not in by_code or per > by_code[code]["period"]:
            by_code[code] = rec
    return by_code


def build_quarter_period(ref_date=None):
    """算出'本季度末报告期'.在1/4/7/10月触发,对应上季末:
       1月->去年Q4(YYYY1231); 4月->当年Q1(YYYY0331); 7月->Q2(YYYY0630); 10月->Q3(YYYY0931)
    """
    d = ref_date or datetime.date.today()
    y, m = d.year, d.month
    if m in (1, 2, 3):
        return f"{y-1}1231"
    if m in (4, 5, 6):
        return f"{y}0331"
    if m in (7, 8, 9):
        return f"{y}0630"
    return f"{y}0930"


def main(period=None):
    period = period or build_quarter_period()
    print(f"# 国家队季度持仓追踪 · 报告期 {period}")
    print(f"生成时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"布局池标的: {len(LAYOUT_POOL)}只  监控国家队关键词: {len(NATIONAL_TEAM_KEYWORDS)}个")
    print("")

    prev_snapshot = load_last_quarter_snapshot(period)
    if prev_snapshot:
        print(f"已加载上季度快照: {len(prev_snapshot)}只标的 (period={list(prev_snapshot.values())[0].get('period','?')})")
    else:
        print("⚠️ 未找到历史快照（首次运行或文件未建）——本次仅建立基线")
    print("")

    cur_snapshot = {}
    rows_out = []

    for ts_code, sec_name, sector in LAYOUT_POOL:
        try:
            holders = fetch_top10_float(ts_code, period)
        except Exception as e:
            sys.stderr.write(f"[{ts_code}] 抓取异常: {e}\n")
            continue
        if not holders:
            sys.stderr.write(f"[{ts_code}] 内无 {period} 前十大流通股东数据 (季报可能未披露)\n")
            continue
        # 筛国家队
        nat_holders = [h for h in holders if is_national_team(h.get("holder_name", ""))]
        if not nat_holders:
            continue
        cur_snapshot[ts_code] = {
            "snapshot_ts": time.time(),
            "ts_code": ts_code, "sec_name": sec_name, "sector": sector,
            "period": period, "holders": nat_holders,
        }
        # 与上季对比
        prev = prev_snapshot.get(ts_code, {})
        prev_holders = {h["holder_name"]: h for h in prev.get("holders", [])}
        for h in nat_holders:
            nm = h.get("holder_name", "")
            amt = h.get("hold_amount", 0) or 0
            prev_amt = (prev_holders.get(nm, {}) or {}).get("hold_amount", 0) or 0
            if prev_amt == 0:
                signal = "🟢 新进"
            elif amt > prev_amt:
                signal = "🔺 增持"
            elif amt < prev_amt:
                signal = "🔻 减持"
            else:
                signal = "➖ 持仓不变"
            delta = amt - prev_amt
            rows_out.append({
                "ts_code": ts_code, "sec_name": sec_name, "sector": sector,
                "holder": nm[:30],
                "hold_amount": amt, "hold_float_ratio": h.get("hold_float_ratio", 0),
                "prev_amount": prev_amt, "delta": delta, "signal": signal,
            })

        sys.stderr.write(f"[{ts_code} {sec_name}] 国家队: {len(nat_holders)}家\n")

    # 写历史
    for ts_code, rec in cur_snapshot.items():
        with HISTORY_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    sys.stderr.write(f"历史写入: {HISTORY_FILE} (+{len(cur_snapshot)}条)\n")

    # 输出表格
    if rows_out:
        rows_out.sort(key=lambda r: (r["ts_code"], r["holder"]))
        print(f"## 国家队持仓变动明细（{len(rows_out)}条）")
        print(f"| 股票 | 股东 | 当期持仓(股) | 上期持仓 | 变动 | 占流通比 | 信号 |")
        print(f"|---|---|---|---|---|---|---|")
        for r in rows_out:
            delta_s = f"{r['delta']:+,.0f}" if r["delta"] else "0"
            print(f"| {r['sec_name']} | {r['holder'][:20]} | {r['hold_amount']:,.0f} | {r['prev_amount']:,.0f} | {delta_s} | {r['hold_float_ratio']:.2f}% | {r['signal']} |")
        print("")
        # 信号计数
        from collections import Counter
        sig_cnt = Counter(r["signal"] for r in rows_out)
        print("## 信号汇总")
        for sig, n in sig_cnt.most_common():
            print(f"- {sig}: {n}家")
        print("")
    else:
        print("⚠️ 本期未在布局池标的中发现国家队持仓（季报披露未到  或布局池标的未被国家队持有）")
        print("建议: 季报披露高峰为4月30日/8月31日/10月31日，可调整触发时间")

    print("---完成---")
    # 哨兵
    meta = {
        "script": "cn_state_capital_quarterly.py",
        "ts": time.time(),
        "dt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "period": period,
        "pool_size": len(LAYOUT_POOL),
        "national_team_hits": len(rows_out),
        "cur_snapshot_count": len(cur_snapshot),
        "prev_snapshot_count": len(prev_snapshot),
    }
    (TMP / ".cn_quarterly.done").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    return rows_out


if __name__ == "__main__":
    main()
