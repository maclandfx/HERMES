#!/usr/bin/env python3
"""每日系统进化报告 - Hermes Agent 系统自我评估"""

import os
import subprocess
import json
from datetime import datetime, timedelta

HERMES_HOME = os.environ.get('HERMES_HOME', '/c/Users/Admin/AppData/Local/hermes')
SKILLS_DIR = os.path.join(HERMES_HOME, 'skills')
LOGS_DIR = os.path.join(HERMES_HOME, 'logs')
SESSIONS_DIR = os.path.join(HERMES_HOME, 'sessions')

def run_cmd(cmd):
    """运行命令并返回输出"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
        return result.stdout.strip()
    except Exception as e:
        return f"Error: {e}"

def get_recent_files(directory, hours=24):
    """获取指定时间范围内的文件"""
    recent = []
    cutoff = datetime.now() - timedelta(hours=hours)
    if os.path.isdir(directory):
        for root, dirs, files in os.walk(directory):
            for f in files:
                fpath = os.path.join(root, f)
                try:
                    mtime = datetime.fromtimestamp(os.path.getmtime(fpath))
                    if mtime > cutoff:
                        recent.append(fpath)
                except:
                    pass
    return recent

def main():
    report_time = datetime.now().strftime('%Y-%m-%d %H:%M')
    date_today = datetime.now().strftime('%Y-%m-%d')
    
    report = []
    report.append("# 🌅 系统进化日报 - Hermes Agent")
    report.append("")
    report.append(f"**日期**: {date_today} | **生成时间**: {report_time}")
    
    # 获取系统版本
    version_file = os.path.join(HERMES_HOME, 'hermes-agent', 'VERSION')
    version = open(version_file).read().strip() if os.path.exists(version_file) else 'unknown'
    report.append(f"**系统版本**: {version}")
    report.append("")
    
    # 1. 技能生态
    report.append("---")
    report.append("")
    report.append("## 1. 🧠 技能生态进化")
    report.append("")
    
    if os.path.isdir(SKILLS_DIR):
        skills = [d for d in os.listdir(SKILLS_DIR) if os.path.isdir(os.path.join(SKILLS_DIR, d))]
        report.append(f"- **总技能数**: {len(skills)}")
        report.append("")
        
        # 最近安装的技能
        recent_skills = get_recent_files(SKILLS_DIR, 24)
        if recent_skills:
            report.append("**最近安装/更新** (过去24小时):")
            for skill in recent_skills[:10]:
                report.append(f"- `{os.path.basename(skill)}`")
        else:
            report.append("**最近安装/更新**: 无")
        
        report.append("")
        report.append("**技能列表**:")
        for skill in sorted(skills)[:30]:
            report.append(f"- {skill}")
    else:
        report.append("- 技能目录不存在")
    
    # 2. 任务统计
    report.append("")
    report.append("---")
    report.append("")
    report.append("## 2. 📊 任务执行统计")
    report.append("")
    
    if os.path.isdir(SESSIONS_DIR):
        recent_sessions = get_recent_files(SESSIONS_DIR, 24)
        report.append(f"- **过去24小时会话数**: {len(recent_sessions)}")
        if recent_sessions:
            report.append("")
            report.append("**最近完成的会话**:")
            for session in recent_sessions[:5]:
                report.append(f"- {os.path.basename(session)}")
    else:
        report.append("- 会话目录不存在")
    
    # 3. 配置变更
    report.append("")
    report.append("---")
    report.append("")
    report.append("## 3. ⚙️ 配置变更")
    report.append("")
    
    config_file = os.path.join(HERMES_HOME, 'config.yaml')
    if os.path.exists(config_file):
        mtime = datetime.fromtimestamp(os.path.getmtime(config_file))
        report.append(f"- **配置文件**: 最后修改 {mtime.strftime('%Y-%m-%d %H:%M')}")
        if (datetime.now() - mtime).total_seconds() < 86400:
            report.append("- ⚠️ 配置在过去24小时内有变更")
    else:
        report.append("- 配置文件不存在")
    
    # 4. 错误统计
    report.append("")
    report.append("---")
    report.append("")
    report.append("## 4. 🐛 错误与问题")
    report.append("")
    
    error_log = os.path.join(LOGS_DIR, 'error.log')
    if os.path.exists(error_log):
        # 简单统计今天的错误
        today_str = datetime.now().strftime('%Y-%m-%d')
        with open(error_log, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
            today_errors = [l for l in lines if today_str in l]
            report.append(f"- **今日错误数**: {len(today_errors)}")
            if today_errors:
                report.append("")
                report.append("**最近错误**:")
                for err in today_errors[-3:]:
                    report.append(f"- {err.strip()[:200]}")
    else:
        report.append("- 错误日志不存在")
    
    # 5. 健康度
    report.append("")
    report.append("---")
    report.append("")
    report.append("## 5. 🎯 系统健康度")
    report.append("")
    
    # 检查Hermes进程
    pgrep = run_cmd("pgrep -f hermes-agent 2>/dev/null")
    if pgrep:
        report.append("- ✅ Hermes Agent 进程: 运行中")
    else:
        report.append("- ❌ Hermes Agent 进程: 未运行")
    
    report.append("- ✅ 配置文件: " + ("存在" if os.path.exists(config_file) else "不存在"))
    report.append("- ✅ 技能目录: " + (f"存在 ({len(skills)} 个技能)" if os.path.isdir(SKILLS_DIR) else "不存在"))
    report.append("- ✅ 错误日志: " + ("存在" if os.path.exists(error_log) else "不存在"))
    
    # 进化建议
    report.append("")
    report.append("### 进化建议")
    report.append("")
    report.append("1. **技能优化**: 检查是否有过时或重复的技能需要更新")
    report.append("2. **配置审查**: 定期审查配置文件，移除无用配置")
    report.append("3. **日志清理**: 定期归档旧日志，避免磁盘占用过大")
    report.append("4. **性能监控**: 关注会话数量和处理时间，优化响应速度")
    report.append("5. **错误分析**: 分析错误日志，解决常见问题")
    
    report.append("")
    report.append("---")
    report.append("")
    report.append(f"**报告生成**: Hermes Agent 系统自动化")
    report.append(f"**下次推送**: 明天 {(datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')} 09:00")
    
    return "\n".join(report)

if __name__ == '__main__':
    print(main())
