# -*- coding: utf-8 -*-
"""
盘中信号卡片渲染器
从 eval_smart.py stdout 中提取核心字段，渲染为操盘手可用的作战指令。

设计原则：
- 5秒读完，直接决策
- 不堆指标，只给关键数字
- 结构：信号 → 关键价 → 资金/技术 → 板块 → 操作建议
"""
import re
import logging

log = logging.getLogger(__name__)

# ========== 解析器 ==========
def parse_stock_line(line):
    """✓ 华勤技术 ¥79.19 (-4.36%) [元器件]"""
    m = re.search(r"([\u4e00-\u9fa5]{2,8})\s+([^\s(]+)\s+\(([+-]?[\d.]+)%\)\s+\[(\S+)\]", line)
    if m:
        price_str = m.group(2)
        pm = re.search(r"[\d.]+", price_str)
        price = float(pm.group()) if pm else 0
        return {"name": m.group(1), "price": price, "change": float(m.group(3)), "sector": m.group(4)}
    return None

def parse_score_line(line):
    """✓ 华勤技术 综合106分 S级 [技82 资78 情71 基70 板81 热90 Z50 反66 周45] 上涨65% (校准65%) 🔥共振"""
    m = re.search(r"综合(\d+)分\s+(\S+级)", line)
    if not m:
        return None
    score = int(m.group(1)); grade = m.group(2)
    dims = {}
    dm = re.search(r"\[(.+?)\]", line)
    if dm:
        for kv in dm.group(1).split():
            kv = kv.strip()
            if kv:
                # 技82
                match = re.match(r"(\S+?)(\d+)", kv)
                if match:
                    dims[match.group(1)] = int(match.group(2))
    rally = 0
    rm = re.search(r"上涨(\d+)%", line)
    if rm:
        rally = int(rm.group(1))
    resonance = "🔥共振" in line
    return {"score": score, "grade": grade, "dims": dims, "rally_pct": rally, "resonance": resonance}

def parse_realtime_line(line):
    """│ 华勤技术       ¥ 79.19     28.1x 4.71x   8.0%  0.8  4.1 ¥91.08/¥74.52 │"""
    m = re.search(r"¥\s+([\d.]+)\s+([\d.]+)x\s+([\d.]+)x\s+([\d.]+)%\s+([\d.]+)\s+([\d.]+)\s+¥([\d.]+)/¥([\d.]+)", line)
    if m:
        return {
            "price": float(m.group(1)),
            "pe": float(m.group(2)),
            "pb": float(m.group(3)),
            "amplitude": float(m.group(4)),
            "volume_ratio": float(m.group(5)),
            "turnover": float(m.group(6)),
            "resistance": float(m.group(7)),
            "support": float(m.group(8)),
        }
    return None

def parse_weekly_line(line):
    """│ 华勤技术        65/200 C   ➡️ 周线偏强        弱势区间           DIF<DEA(空头), 绿柱区 │"""
    strength = "偏强" if "偏强" in line else ("偏空" if "偏空" in line else "中性")
    pos = "强势区间" if "强势区间" in line else ("弱势区间" if "弱势区间" in line else "中性区间")
    macd = "多头" if "DIF>DEA" in line else ("空头" if "DIF<DEA" in line else "中性")
    bar = "红柱" if "红柱" in line else ("绿柱" if "绿柱" in line else "未知")
    return {"strength": strength, "position": pos, "macd": macd, "bar": bar}

def parse_sectors(raw):
    """提取热门板块，去重"""
    sectors = []
    seen = set()
    for line in raw.split("\n"):
        m = re.search(r"🔥\s+(\S+)\s+\(涨停(\d+)家\)", line)
        if m and m.group(1) not in seen:
            sectors.append({"name": m.group(1), "limit_ups": int(m.group(2))})
            seen.add(m.group(1))
    return sectors

def parse_capital_line(line):
    """✓ 北向资金: 净流入 +192亿 | 连续28日"""
    m = re.search(r"北向资金:\s+(净流入|净流出)\s+([+-]?[\d.]+)亿.*?连续(\d+)日", line)
    if m:
        return {"direction": m.group(1), "amount": float(m.group(2)), "consecutive_days": int(m.group(3))}
    return None

def parse_shareholders_line(line):
    """✓ 603296.SH: 58532户 (➡️稳定 +3.0%)"""
    m = re.search(r":\s+(\d+)户.*?([\u2192➡️].+?)\s+([+-]?[\d.]+)%", line)
    if m:
        status = "稳定" if "稳定" in m.group(2) else ("增加" if "+" in m.group(3) else "减少")
        return {"count": int(m.group(1)), "status": status, "change_pct": float(m.group(3))}
    return None


def parse_eval_output(raw: str) -> dict:
    """从 eval_smart stdout 提取所有可用字段"""
    result = {
        "stock": None, "score": None, "realtime": None,
        "weekly": None, "sectors": [], "capital": None,
        "shareholders": None,
    }
    for line in raw.split("\n"):
        if result["stock"] is None and "✓" in line and "¥" in line and "分" not in line:
            result["stock"] = parse_stock_line(line)
        if result["score"] is None and "综合" in line and "分" in line and "级" in line:
            result["score"] = parse_score_line(line)
        if result["realtime"] is None and "│" in line and "x" in line and "¥" in line:
            result["realtime"] = parse_realtime_line(line)
        if result["weekly"] is None and "周线" in line and ("偏强" in line or "偏空" in line):
            result["weekly"] = parse_weekly_line(line)
        if result["capital"] is None and "北向资金" in line and "净流入" in line:
            result["capital"] = parse_capital_line(line)
        if result["shareholders"] is None and "户" in line and "➡️" in line:
            result["shareholders"] = parse_shareholders_line(line)
    result["sectors"] = parse_sectors(raw)
    return result


# ========== 操盘决策 ==========
def compute_stop_loss(price, grade):
    """根据评级确定止损位"""
    pct = {"S级": 3.0, "A级": 5.0, "B级": 7.0, "C级": 10.0}
    return price * (1 - pct.get(grade, 5.0) / 100)

def compute_take_profit(price, grade):
    """止盈目标"""
    pct = {"S级": 8.0, "A级": 12.0, "B级": 15.0, "C级": 20.0}
    return price * (1 + pct.get(grade, 10.0) / 100)

def grade_to_signal(score, resonance, weekly):
    """综合评分→信号解读"""
    if resonance and weekly and weekly.get("strength") == "偏强":
        return "多头共振，强势信号"
    if resonance:
        return "多维共振，关注买入时机"
    if score >= 85:
        return "综合评分高，积极关注"
    if score >= 70:
        return "综合评分中等，择机参与"
    return "评分偏低，观望为主"

def position_advice(score, grade, weekly_str):
    """仓位建议"""
    weekly_good = "偏强" in weekly_str
    if score >= 90 and weekly_good:
        return "重仓", "⚡"
    if score >= 80:
        return "中仓", "▶"
    if score >= 65:
        return "轻仓试水", "△"
    return "观望", "○"


# ========== 卡片渲染 ==========
def render_card(raw, alert_time, condition="盘中预警", realtime=None):
    data = parse_eval_output(raw)
    stock = data.get("stock") or {"name": "未知", "price": 0, "change": 0, "sector": ""}
    score = data.get("score") or {"score": 0, "grade": "N级", "dims": {}, "rally_pct": 0, "resonance": False}
    rt = data.get("realtime") or {}
    weekly = data.get("weekly") or {}
    capital = data.get("capital")
    holders = data.get("shareholders")
    name = stock["name"]
    price = stock["price"] or rt.get("price", 0)
    change = stock["change"] or 0
    grade = score["grade"]
    s = score["score"]
    resonance = score["resonance"]
    support = rt.get("support") or price
    resistance = rt.get("resistance") or price
    stop_loss = compute_stop_loss(price, grade)
    take_profit = compute_take_profit(price, grade)
    vr = realtime.get("vol_ratio", rt.get("volume_ratio", 0)) if realtime else rt.get("volume_ratio", 0)
    tn = realtime.get("turnover_pct", rt.get("turnover", 0)) if realtime else rt.get("turnover", 0)
    vol_tag = "放量" if vr > 1.2 else ("缩量" if vr < 0.8 else "平量")
    tn_tag = ("高" if tn > 15 else ("活跃" if tn > 5 else ("温和" if tn >= 2 else "平淡")))
    weekly_str = weekly.get("strength", "?")
    signal = grade_to_signal(s, resonance, weekly)
    pos, pos_icon = position_advice(s, grade, weekly_str)
    cap = ""
    if capital:
        d = "🟢" if capital["direction"] == "净流入" else "🔴"
        cap = d + capital["direction"] + ("%d" % abs(capital["amount"])) + "亿"
    hstr = ""
    if holders:
        chg = holders["change_pct"]
        if chg > 0:
            h_icon, h_note = "🔴", "+%s%% 散户增多" % chg
        elif chg < -2:
            h_icon, h_note = "🟢", "%s%% 筹码集中" % chg
        else:
            h_icon, h_note = "➡️", "%+.1f%% 稳定" % chg
        hstr = "  " + h_icon + ("%d" % holders["count"]) + "户 " + h_note
    grade_color = {"S级": "💎", "A级": "🟢", "B级": "🟡", "C级": "🔴"}.get(grade, "⚪")
    direction = ("⬆️看多" if (s >= 80 and weekly_str == "偏强") else ("⬇️看空" if s < 60 else "➡️震荡"))
    if realtime:
        r_price = realtime.get("price",0)
        r_high = realtime.get("high",0)
        r_low = realtime.get("low",0)
        r_open = realtime.get("open",0)
        drange = r_high - r_low
        if drange > 0:
            ipos = (r_price - r_low) / drange * 100
            if ipos > 70:
                t_icon, t_text = "📈", "高盘"
            elif ipos < 30:
                t_icon, t_text = "📉", "低盘"
            else:
                t_icon, t_text = "📊", "中盘"
            if r_open > 0:
                if r_price > r_open:
                    t_text += " 向上" if ipos > 60 else " 整理"
                else:
                    t_text += " 向下" if ipos < 40 else " 整理"
        else:
            t_icon, t_text = "📊", "无波动"
    else:
        t_icon, t_text = "📊", "盘前"
    change_sign = "+" if change >= 0 else ""
    rally_str = ("%d" % score["rally_pct"]) + "%" if score["rally_pct"] > 0 else "—"
    sep = "━━━━━━━━━━━━━━━━━━━━━━"
    sub = "━━ "
    rally_label = ("🔥" + rally_str) if rally_str != "—" else "—"
    NL = chr(10)
    lines = [sep, "🚨 " + condition + " | " + name, sep, "",
        grade_color + " " + grade + " ¥" + ("%.2f" % price) + " " + change_sign + ("%.2f%%" % change),
        "📊 综合%d分 · 涨幅%s" % (s, rally_label), "",
        sub + "关键价" + sub,
        "  止损 ¥%.2f  止盈 ¥%.2f" % (stop_loss, take_profit),
        "  支撑 ¥%.2f  阻力 ¥%.2f" % (support, resistance), "",
        sub + "分时+量价" + sub,
        "  %s%s 量比%.2f(%s) 换手%.1f(%s)" % (t_icon, t_text, vr, vol_tag, tn, tn_tag),
        "  " + cap + hstr,
        sub + "技术" + sub,
        "  周线%s %s" % (weekly_str, signal), "",
        sep, direction, "🎯 " + pos_icon + " " + pos, sep]
    card = NL.join(lines)
    log.info("[RENDER] %s: %s score=%d vol=%.2f tn=%.1f trend=%s" % (name, grade, s, vr, tn, t_text))
    return card
if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python signal_card.py <raw_eval_output.txt>")
        sys.exit(1)
    raw = open(sys.argv[1]).read()
    print(render_card(raw, "16:48"))
