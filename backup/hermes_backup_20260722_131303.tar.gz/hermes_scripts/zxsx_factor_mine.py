#!/usr/bin/env python3
"""周线手选因子反推引擎 — no_agent cron wrapper"""
import subprocess, sys

PYTHON = r"C:\Python314\python.exe"
SCRIPT = r"D:/Hermes/评估中心/tools/tdx_connector/scripts/zxsx_factor_mine.py"

result = subprocess.run([PYTHON, SCRIPT], capture_output=False, text=True, timeout=120)
sys.exit(result.returncode)
