#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 自动生成 by eval_center_push.py —— 推送 日印互动分析_20240709.md 到 Telegram
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="backslashreplace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="backslashreplace")

import re
import time
from pathlib import Path

REPORT_PATH = Path(r"D:\Hermes\地缘政策模型\日本高市早苗政府上台后的中方战略应对研究.md")
PAYLOAD_FILE = Path(r"C:\Users\Admin\AppData\Local\hermes\scripts\_td_payload.txt")
MAX_CHARS = 3900
DELAY = 0.05


def flush_print(s):
    try:
        sys.stdout.write(s + "\n")
        sys.stdout.flush()
    except Exception:
        pass
    try:
        sys.stderr.write(s + "\n")
        sys.stderr.flush()
    except Exception:
        pass


def split(text, mx):
    if len(text) <= mx:
        return [text]
    chunks = re.split(r"(?m)^(#{1,3} .+)$", text)
    pieces, i = [], 0
    while i < len(chunks):
        if i == 0 and chunks[i] == "":
            i += 1; continue
        pieces.append(chunks[i] + (chunks[i + 1] if i + 1 < len(chunks) else ""))
        i += 2
    merged, cur = [], ""
    for p in pieces:
        if len(cur) + len(p) <= mx:
            cur = (cur + "\n" + p) if cur else p
        else:
            if cur: merged.append(cur)
            cur = p
    if cur: merged.append(cur)
    final, done = [], False
    for m in merged:
        if done: break
        if len(m) <= mx:
            final.append(m); continue
        cur = ""
        for line in m.split("\n"):
            t = (cur + "\n" + line) if cur else line
            if len(t) <= mx:
                cur = t
            else:
                if cur: final.append(cur)
                cur = line
                if len(cur) > mx:
                    while len(cur) > mx:
                        final.append(cur[:mx]); cur = cur[mx:]
                    if cur: final.append(cur)
        if cur: final.append(cur)
        done = True
    safe = []
    for s in final:
        if len(s) <= mx: safe.append(s)
        else:
            for i in range(0, len(s), mx):
                safe.append(s[i:i + mx])
    return safe


def main():
    if not REPORT_PATH.exists():
        flush_print(f"[推送失败] 报告不存在: {REPORT_PATH}"); sys.exit(1)
    raw = REPORT_PATH.read_text(encoding="utf-8")
    chunks = split(raw, MAX_CHARS)
    print(f"split {len(chunks)} chunks ({len(raw)} chars)", file=sys.stderr)

    # 双保险: 写 payload 文件, 供后续 cron/output 比对 or fallback cat
    PAYLOAD_FILE.write_text("\x04\n" + "\n\x05".join(chunks) + "\n", encoding="utf-8", errors="replace")

    for i, ch in enumerate(chunks, 1):
        prefix = f"\n>>> 📄 报告片段 {i}/{len(chunks)} <<<\n\n" if len(chunks) > 1 else ""
        suffix = f"\n\n>>> 续见下一条 ({i+1}/{len(chunks)}) <<<" if i < len(chunks) else "\n\n— END —"
        flush_print(prefix + ch + suffix)
        time.sleep(DELAY)
    flush_print('{"wakeAgent": true}')
    flush_print(f"DONE chunks={len(chunks)} ts={int(time.time())}")


if __name__ == "__main__":
    main()
