#!/usr/bin/env python3
"""盘前政策弹药包 — no_agent cron wrapper
直接 import 评估中心模块，规避路径解析问题。
"""
import subprocess, os, sys

# 固定物理路径，不依赖 cwd / __file__
PYTHON = r"C:\Python314\python.exe"
SCRIPT = r"D:\Hermes\评估中心\tools\morning_policy_brief.py"
WORKDIR = r"D:\Hermes\评估中心\tools"

r = subprocess.run(
    [PYTHON, SCRIPT],
    capture_output=True, text=True, encoding="utf-8",
    cwd=WORKDIR, timeout=300,
)
# no_agent: stdout verbatim = Telegram 推送内容
sys.stdout.write(r.stdout)
if r.returncode != 0:
    sys.stdout.write(f"\n❌ 执行失败 (rc={r.returncode})\n{r.stderr[-500:]}")
sys.exit(r.returncode)
