#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_pool_backtest.py — 布局池 SQLite 持久化 + 回测闭环
============================================================
功能：
  1. 每日收盘后自动写入布局池标的最新 close & pct_chg (Tushare daily)
  2. 对比沪深300当日表现，输出累计超额收益
  3. 报告格式化输出，插入 cn_tracker.py 尾部

库文件: D:/Hermes/同中书门下/产出/pool.db
"""
import os, sys, json, time, datetime, pathlib, sqlite3, urllib.parse
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from tushare_client import call, as_records

DB_PATH = pathlib.Path("D:/Hermes/同中书门下/产出/pool.db")
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

LAYOUT_POOL = [
    ("600406.SH", "国电南瑞"), ("300274.SZ", "阳光电源"),
    ("300750.SZ", "宁德时代"), ("002049.SZ", "紫光国微"),
    ("688981.SZ", "中芯国际"), ("600118.SH", "中国卫星"),
    ("600938.SH", "中国海油"), ("601728.SH", "中国电信"),
    ("600845.SH", "宝信软件"),
]
BENCHMARK = "000300.SH"  # 沪深300


def init_db():
    conn = sqlite3.connect(str(DB_PATH))
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS layout_pool (
            ts_code TEXT PRIMARY KEY,
            sec_name TEXT,
            sector TEXT,
            added_date TEXT,
            reason TEXT,
            active INTEGER DEFAULT 1,
            removed_date TEXT,
            removed_reason TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS pool_perf (
            ts_code TEXT,
            trade_date TEXT,
            close REAL,
            pct_chg REAL,
            amount REAL,
            vs_benchmark_pct REAL,
            ret_1d REAL,
            PRIMARY KEY (ts_code, trade_date)
        )
    """)
    conn.commit()
    return conn


def upsert_pool(conn, ts_code, sec_name, sector, added_date, reason):
    conn.execute("""
        INSERT OR REPLACE INTO layout_pool (ts_code, sec_name, sector, added_date, reason, active)
        VALUES (?, ?, ?, ?, ?, COALESCE((SELECT active FROM layout_pool WHERE ts_code=?), 1))
    """, (ts_code, sec_name, sector, added_date, reason, ts_code))


def sync_pool_today(conn):
    """把当前 LAYOUT_POOL 写入 layout_pool 表 (新条目插入, 已存在忽略)"""
    today = datetime.date.today().strftime("%Y-%m-%d")
    for ts_code, sec_name in LAYOUT_POOL:
        upsert_pool(conn, ts_code, sec_name, "政策/资本", today, "基线纳入")
    conn.commit()


def fetch_daily_prices(ts_codes, trade_date):
    """批量获取单日收盘价"""
    codes_str = ",".join(ts_codes)
    d = call("daily", {"trade_date": trade_date, "ts_code": codes_str},
             ["ts_code", "trade_date", "close", "pct_chg", "amount"])
    return as_records(d)


def write_perf(conn, records):
    """写入 pool_perf (主键 (ts_code, trade_date) 防重复)"""
    if not records:
        return 0, []
    for rec in records:
        try:
            conn.execute("""
                INSERT OR REPLACE INTO pool_perf (ts_code, trade_date, close, pct_chg, amount, ret_1d)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                rec["ts_code"], rec["trade_date"],
                rec.get("close"), rec.get("pct_chg", 0), rec.get("amount", 0),
                rec.get("pct_chg", 0) / 100.0 if rec.get("pct_chg") is not None else None,
            ))
        except Exception as e:
            sys.stderr.write(f"[write_perf] {rec['ts_code']} err: {e}\n")
    conn.commit()
    return len(records), records


def update_vs_benchmark(conn, trade_date):
    """更新 vs_benchmark_pct: 标的收益 - 沪深300 收益"""
    d = call("daily", {"trade_date": trade_date, "ts_code": BENCHMARK},
             ["ts_code", "trade_date", "pct_chg"])
    bench = as_records(d)
    bench_pct = (bench[0].get("pct_chg") or 0) / 100.0 if bench else None
    if bench_pct is None:
        return
    cur = conn.execute("SELECT ts_code, pct_chg FROM pool_perf WHERE trade_date = ?", (trade_date,))
    rows = cur.fetchall()
    for ts_code, pct_chg in rows:
        if pct_chg is None:
            continue
        pool_pct = pct_chg / 100.0
        alpha = pool_pct - bench_pct
        conn.execute("UPDATE pool_perf SET vs_benchmark_pct = ? WHERE ts_code = ? AND trade_date = ?",
                     (alpha, ts_code, trade_date))
    conn.commit()


def fetch_backtest_summary(conn_arg=None, top_n=3, benchmark_monthly=None):
    """生成回测摘要 Markdown：加入以来 vs 沪深300 累计超额
    不用外部 conn，内部自开，读完后自己关。
    """
    _conn = sqlite3.connect(str(DB_PATH))
    today = datetime.date.today().strftime("%Y-%m-%d")
    cur = _conn.execute("""
        SELECT p.ts_code, l.sec_name, MIN(p.trade_date) as first_date,
               MAX(p.trade_date) as last_date,
               COUNT(*) as days,
               SUM(p.pct_chg) as cum_pct,
               AVG(p.pct_chg) as avg_pct,
               SUM(p.vs_benchmark_pct) as cum_alpha
        FROM pool_perf p
        JOIN layout_pool l ON p.ts_code = l.ts_code
        WHERE l.active = 1 AND p.trade_date <= ?
        GROUP BY p.ts_code
        HAVING days >= 1
        ORDER BY cum_alpha DESC
    """, (today,))
    rows = cur.fetchall()
    if not rows:
        return ""
    out = []
    out.append("## 布局池回测摘要 (vs 沪深300)")
    out.append("")
    out.append("| 代码 | 名称 | 入场日 | 运行天数 | 累计收益 | 日均收益 | 累计超额(alpha) | 评价 |")
    out.append("|---|---|---|---|---|---|---|---|")
    for ts_code, name, first, last, days, cum_pct, avg_pct, cum_alpha in rows:
        if cum_pct is None:
            continue
        cum_alpha = cum_alpha or 0
        alpha_str = f"{cum_alpha*100:+.2f}%"
        if cum_alpha > 0.05:
            grade = "🟢 显著跑赢"
        elif cum_alpha > 0:
            grade = "🟢 跑赢"
        elif cum_alpha > -0.05:
            grade = "🟡 同步"
        else:
            grade = "🔻 跑输"
        out.append(f"| {ts_code} | {name} | {first} | {days}天 | {cum_pct:+.2f}% | {avg_pct:+.3f}% | {alpha_str} | {grade} |")
    out.append("")
    # 池子整体
    pool_cum = sum(r[5] or 0 for r in rows) / len(rows) if rows else 0
    pool_alpha = sum(r[7] or 0 for r in rows) / len(rows) if rows else 0
    grade_pool = "🟢 池子整体跑赢" if pool_alpha > 0.03 else "🟡 池子与大盘同步" if pool_alpha > -0.03 else "🔻 池子整体跑输"
    out.append(f"> 布局池整体平均累计收益: {pool_cum:+.2f}% | 平均超额: {pool_alpha*100:+.2f}% → {grade_pool}")
    out.append("")
    return "\n".join(out)


def sync_today_and_summary():
    """主入口：刷新今日数据 + 生成回测摘要片段"""
    today = datetime.date.today().strftime("%Y%m%d")
    conn = init_db()
    sync_pool_today(conn)
    # 批量拉取
    prices = fetch_daily_prices([c for c, _ in LAYOUT_POOL], today)
    write_perf(conn, prices)
    # 对标
    update_vs_benchmark(conn, today)
    conn.close()
    return fetch_backtest_summary(conn)


if __name__ == "__main__":
    print(sync_today_and_summary())
