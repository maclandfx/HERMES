#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_moneyflow_daily.py — 当日资金流向模块
被 cn_tracker.py 导入调用, 产出布局池标的的主力净流入 + 北向资金净流入 + 5日累计.
独立运行也可直接print报告. 不写哨兵(由主脚本统一控制).
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from tushare_client import call, as_records

# 与 cn_state_capital_quarterly.py 保持一致的布局池
LAYOUT_POOL = [
    ("600406.SH", "国电南瑞"), ("300274.SZ", "阳光电源"),
    ("300750.SZ", "宁德时代"), ("002049.SZ", "紫光国微"),
    ("688981.SZ", "中芯国际"), ("600118.SH", "中国卫星"),
    ("600938.SH", "中国海油"), ("601728.SH", "中国电信"),
    ("600845.SH", "宝信软件"),
]


def yesterday_trade_date():
    """上一个交易日(简化:往前找1天OfWeekDay). cron 09:00 跑, 数据用的是昨日."""
    import datetime
    d = datetime.date.today()
    # 周一(0)→ 周五5; 周日(6)→ 周五5; 周六(5)→ 周四4 否则-1
    if d.weekday() == 0: back = 3
    elif d.weekday() == 6: back = 2
    else: back = 1
    return (d - datetime.timedelta(days=back)).strftime("%Y%m%d")


def fetch_north_money(trade_date):
    """北向资金(net流入沪股通+深股通). 返回 dict 或 None"""
    d = call("moneyflow_hsgt", {"trade_date": trade_date},
             ["trade_date", "north_money", "south_money", "hgt", "sgt"])
    rs = as_records(d)
    return rs[0] if rs else None


def fetch_north_money_5d(trade_date):
    """取该日往前5个交易日的累计北向净流入"""
    import datetime
    end = trade_date
    start = (datetime.datetime.strptime(end, "%Y%m%d").date() -
             datetime.timedelta(days=10)).strftime("%Y%m%d")
    d = call("moneyflow_hsgt", {"start_date": start, "end_date": end},
             ["trade_date", "north_money"])
    rs = as_records(d)
    if not rs: return None, None
    rs.sort(key=lambda r: r["trade_date"])
    recent5 = rs[-5:] if len(rs) >= 5 else rs
    def _to_float(x):
        try: return float(x)
        except Exception: return 0.0
    cum = sum(_to_float(r.get("north_money", 0)) for r in recent5)
    count = len(recent5)
    return cum, count


def fetch_stock_moneyflow(ts_code, trade_date):
    """个股当日资金流向. 关键字段 net_mf_amount."""
    d = call("moneyflow", {"ts_code": ts_code, "trade_date": trade_date},
             ["ts_code", "trade_date", "buy_elg_amount", "sell_elg_amount",
              "buy_lg_amount", "sell_lg_amount",
              "buy_sm_amount", "sell_sm_amount",
              "net_mf_amount", "net_mf_vol"])
    rs = as_records(d)
    return rs[0] if rs else None


def fmt_wan(v):
    """万 → 亿"""
    if v is None: return "N/A"
    try: v = float(v)
    except Exception: return str(v)
    return f"{v/10000:+.2f}亿" if abs(v) >= 10000 else f"{v:+.0f}万"


def _f(v):
    try: return float(v)
    except Exception: return 0.0

def render_section(trade_date=None):
    """输出 Markdown 片段供 cn_tracker.py 拼接."""
    if trade_date is None:
        trade_date = yesterday_trade_date()
    out = []
    out.append("## 资金流向 · " + trade_date)
    out.append("")

    # ---- 北向 ----
    n = fetch_north_money(trade_date)
    north_v = _f(n.get("north_money")) if n else None
    if n and north_v is not None:
        out.append(f"**北向资金当日净流入**: {fmt_wan(north_v)}")
    else:
        out.append("**北向资金**: ⚠️ 无数据(可能非交易日或晚18点更新)")
    cum5, cnt = fetch_north_money_5d(trade_date)
    if cum5 is not None:
        emoji = "🟢" if cum5 > 0 else "🔴" if cum5 < 0 else "⚪"
        out.append(f"**近{cnt}日累计净流入**: {fmt_wan(cum5)} {emoji}")
    out.append("")

    # ---- 布局池 ----
    out.append("**布局池主力资金 (大单+超大单净额)**")
    out.append("| 代码 | 名称 | 主力净流入 | 超大单净 | 大单净 |")
    out.append("|---|---|---|---|---|")
    rows = []
    for ts_code, name in LAYOUT_POOL:
        m = fetch_stock_moneyflow(ts_code, trade_date)
        if not m:
            out.append(f"| {ts_code} | {name} | N/A | - | - |")
            continue
        elg_net = (m.get("buy_elg_amount") or 0) - (m.get("sell_elg_amount") or 0)
        lg_net = (m.get("buy_lg_amount") or 0) - (m.get("sell_lg_amount") or 0)
        net = m.get("net_mf_amount")
        rows.append((name, net))
        out.append(f"| {ts_code} | {name} | {fmt_wan(net)} | {fmt_wan(elg_net)} | {fmt_wan(lg_net)} |")
    out.append("")

    # 背离 / 共振摘要
    if n and rows:
        north_pos = _f(n.get("north_money")) > 0
        pos_count = sum(1 for _, net in rows if net and net > 0)
        neg_count = sum(1 for _, net in rows if net and net < 0)
        out.append("## 资金共振分析")
        out.append(f"- 北向: {'流入' if north_pos else '流出'}")
        out.append(f"- 布局池: 主力净流入 {pos_count} 只 / 净流出 {neg_count} 只")
        if north_pos and neg_count > pos_count + 1:
            out.append(f"- ⚠️ **背离信号**: 北向流入但布局池多数主力流出，警惕'拉指数出货'")
        if not north_pos and pos_count > neg_count + 1:
            out.append(f"- ⚠️ **背离信号**: 北向流出但布局池多数主力流入，观察'机构吸筹'")
        out.append("")

    return "\n".join(out)


if __name__ == "__main__":
    print(render_section())
