#!/usr/bin/env bash
# 中国政策与国家队资本动向追踪 - 每日09:00数据采集脚本
# 输出stdout由cron verbatim投递
set -u
TMPDIR="C:/Users/Admin/tmp"
mkdir -p "$TMPDIR"
UA="Mozilla/5.0"
sep(){ echo ""; echo "$1"; echo ""; }
# ===== 1. 发改委头条 =====
curl -s -L --max-time 20 -A "$UA" https://www.ndrc.gov.cn/ -o "$TMPDIR/ndrc_d.html" 2>&1
# ===== 2. 工信部头条 =====
curl -s -L --max-time 20 -A "$UA" http://www.miit.gov.cn/ -o "$TMPDIR/miit_d.html" 2>&1
# ===== 3. 能源局头条 =====
curl -s -L --max-time 20 -A "$UA" http://www.nea.gov.cn/ -o "$TMPDIR/nea_d.html" 2>&1
# ===== 4. 巨潮监控池公告 (宁德时代) =====
curl -s -L --max-time 20 -A "$UA" 'http://www.cninfo.com.cn/new/hisAnnouncement/query' -X POST \
  --data-urlencode 'stock=300750,GD165627' --data-urlencode 'tabName=fulltext' \
  --data-urlencode 'pageSize=15' --data-urlencode 'pageNum=1' \
  --data-urlencode 'column=szse' --data-urlencode 'category=category_ndsz_szmb' --data-urlencode 'plate=sz' \
  -H 'Content-Type: application/x-www-form-urlencoded' -H 'Referer: http://www.cninfo.com.cn/' \
  -o "$TMPDIR/cn300750_d.json" 2>&1
# ===== 5. Python汇总输出 =====
/c/Python314/python.exe - <<'PY' 2>&1
import re, json, pathlib, datetime, os
b=pathlib.Path("C:/Users/Admin/tmp")
def load(f):
    p=b/f
    if not p.exists(): return ""
    raw=p.read_bytes()
    for enc in ["utf-8","gbk"]:
        try: return raw.decode(enc)
        except: pass
    return ""
def links(html, kws):
    out=[]; seen=set()
    # 优先匹配带title的链接；退而匹配 href + 文本
    cand=[]
    for m in re.finditer(r'<a[^>]*?title=[\x27\x22]([^<]{4,80})[\x27\x22][^>]*?href="([^"]+)"|<a[^>]*?href="([^"]+)"[^>]*?title=[\x27\x22]([^<]{4,80})[\x27\x22]', html):
        txt=m.group(1) or m.group(4); href=m.group(2) or m.group(3)
        cand.append((txt.strip(), href))
    # 无title的fallback
    for m in re.finditer(r'<a[^>]*?href="([^"]+)"[^>]*?>([^<]{4,80})</a>', html):
        href,txt=m.group(1),m.group(2).strip()
        if not any(t==txt and h==href for t,h in cand):
            cand.append((txt,href))
    for txt,href in cand:
        if not txt or txt in seen: continue
        if any(k in txt for k in kws):
            out.append((txt,href)); seen.add(txt)
    return out
print("# 中国政策与资本动向每日快报")
print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
print()
kw=["规划","意见","办法","通知","发展","改革","能源","数据","低空","航天","半导体","芯片","储能","电网","算力","十五五","新质","碳","卫星","电池","自主可控","国防","产业","投资","战略","建设","工业互联网","新兴产业"]
for name,lbl in [("ndrc_d.html","发改委"),("miit_d.html","工信部"),("nea_d.html","能源局")]:
    h=load(name); ls=links(h,kw)
    print(f"## {lbl} ({len(ls)}条)")
    for t,u in ls[:8]: print(f"- {t}")
    print()
try:
    d=json.loads((b/"cn300750_d.json").read_text(encoding="utf-8",errors="ignore"))
    print("## 300750 宁德时代 最新公告")
    for a in (d.get("announcements") or [])[:5]:
        dt=datetime.datetime.fromtimestamp(a["announcementTime"]/1000).strftime("%Y-%m-%d")
        print(f"- {dt} | {a['announcementTitle']}")
except Exception as e:
    print("## 公告解析失败:",e)
print()
print("---采集完成，下一步：交给agent按第四阶段模板分析并填布局池调整---")
PY
# ===== 哨兵文件：记录本次采集的元数据供看门狗核对 =====
/c/Python314/python.exe - <<'PY2' 2>&1
import os, json, time, pathlib, datetime
b=pathlib.Path("C:/Users/Admin/tmp")
m={"script":"cn_tracker.sh","ts":time.time(),"dt":datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
   "ndrc_bytes":(b/"ndrc_d.html").stat().st_size if (b/"ndrc_d.html").exists() else 0,
   "miit_bytes":(b/"miit_d.html").stat().st_size if (b/"miit_d.html").exists() else 0,
   "nea_bytes":(b/"nea_d.html").stat().st_size if (b/"nea_d.html").exists() else 0,
   "cn300750_bytes":(b/"cn300750_d.json").stat().st_size if (b/"cn300750_d.json").exists() else 0}
p=b/".cn_tracker.done"
p.write_text(json.dumps(m,ensure_ascii=False),encoding="utf-8")
# 同时写时间戳文件（看门狗用更简单的mtime判断）
(b/"cn_tracker.stamp").write_text(str(int(time.time())),encoding="utf-8")
print("SENTINEL written:",p,m)
PY2

