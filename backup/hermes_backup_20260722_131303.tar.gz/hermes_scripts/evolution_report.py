#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成系统进化报告，输出到 stdout，由 cron job 通过 Hermes gateway 投递到 Telegram"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="backslashreplace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="backslashreplace")
import os, subprocess, datetime
from pathlib import Path

HERMES_HOME = Path(os.environ.get("HERMES_HOME", "/c/Users/Admin/AppData/Local/hermes"))
SKILLS_DIR = HERMES_HOME / "skills"
LOGS_DIR = HERMES_HOME / "logs"
SESSIONS_DIR = HERMES_HOME / "sessions"

def run(cmd):
    """Run a shell command and return stdout, suppressing stderr to avoid cron output pollution."""
    try:
        import subprocess
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=15)
        return r.stdout.strip()
    except:
        return ""

def check_gateway_running():
    """Check if Hermes gateway is running without spawning a noisy subprocess."""
    import subprocess
    try:
        r = subprocess.run(["hermes", "gateway", "status"], capture_output=True, text=True, timeout=10)
        return "Gateway process running" in (r.stdout or "")
    except:
        return False

def recent_files(d, hours=24):
    out = []
    if not d.exists(): return out
    cutoff = datetime.datetime.now() - datetime.timedelta(hours=hours)
    for root, _, files in os.walk(d):
        for f in files:
            try:
                if datetime.datetime.fromtimestamp(os.path.getmtime(os.path.join(root,f))) > cutoff:
                    out.append(f)
            except: pass
    return out

def main():
    now = datetime.datetime.now()
    report = []
    report.append("# 🌅 Hermes Agent 系统进化日报")
    report.append("")
    report.append(f"**日期**: {now.strftime('%Y-%m-%d')} | **时间**: {now.strftime('%H:%M')}")
    report.append("")
    
    # 版本
    vf = HERMES_HOME / "hermes-agent" / "VERSION"
    ver = vf.read_text().strip() if vf.exists() else "unknown"
    report.append(f"**版本**: {ver}")
    report.append("")
    report.append("---")
    report.append("")
    
    # 技能
    report.append("## 🧠 技能生态")
    report.append("")
    if SKILLS_DIR.exists():
        skills = sorted([d.name for d in SKILLS_DIR.iterdir() if d.is_dir() and not d.name.startswith('.')])
        report.append(f"- 总技能数: **{len(skills)}**")
        report.append("")
        recent = recent_files(SKILLS_DIR, 24)
        if recent:
            report.append("**24h 内变更:**")
            for f in recent[:8]:
                report.append(f"  - `{f}`")
        report.append("")
        report.append("**技能列表:** " + " ".join(f"`{s}`" for s in skills[:30]))
    report.append("")
    report.append("---")
    report.append("")
    
    # 任务
    report.append("## 📊 任务统计")
    report.append("")
    if SESSIONS_DIR.exists():
        sess = recent_files(SESSIONS_DIR, 24)
        report.append(f"- 过去24小时会话数: **{len(sess)}**")
    else:
        report.append("- 会话目录不存在")
    report.append("")
    report.append("---")
    report.append("")
    
    # 配置
    report.append("## ⚙️ 配置")
    report.append("")
    cf = HERMES_HOME / "config.yaml"
    if cf.exists():
        mt = datetime.datetime.fromtimestamp(cf.stat().st_mtime)
        report.append(f"- 最后修改: {mt.strftime('%Y-%m-%d %H:%M')}")
        if (now - mt).total_seconds() < 86400:
            report.append("- ⚠️ 配置24h内有变更")
    else:
        report.append("- 配置文件不存在")
    report.append("")
    report.append("---")
    report.append("")
    
    # 健康度
    report.append("## 🎯 健康度")
    report.append("")
    pgrep = run("pgrep -f hermes-agent")
    report.append(f"- Hermes Agent: {'✅ 运行中' if pgrep else '❌ 未运行'}")
    report.append(f"- 配置: {'✅' if cf.exists() else '❌'}")
    report.append(f"- 技能: {'✅ (' + str(len(skills)) + '个)' if SKILLS_DIR.exists() else '❌'}")
    report.append(f"- 日志: {'✅' if LOGS_DIR.exists() else '❌'}")
    report.append("")
    report.append("---")
    report.append("")
    report.append("**下次推送**: 明天 09:00")
    report.append("")
    
    text = "\n".join(report)
    # Hermes gateway cron delivery reads stdout, wraps with header/footer
    print(text)

if __name__ == "__main__":
    main()
