#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
A股研报采集脚本 - 从 qzjjxr TG频道抓取研报
依赖: pip install pyrogram[fast]
配置: TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION_FILE
输出: ~/AppData\Local\hermes\data\qzjjxr\reports\
"""

import os
import sys
import json
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional
import re

# ── 配置 ──────────────────────────────────────────────
API_ID = int(os.environ.get("TELEGRAM_API_ID", ""))
API_HASH = os.environ.get("TELEGRAM_API_HASH", "")
CHANNEL_USERNAME = "qzjjxr"          # 目标频道
SESSION_FILE = os.environ.get(
    "TELEGRAM_SESSION_FILE",
    Path.home() / "AppData" / "Local" / "hermes" / "data" / "qzjjxr" / "session.json"
)
OUTPUT_DIR = Path.home() / "AppData" / "Local" / "hermes" / "data" / "qzjjxr" / "reports"
STATE_FILE = OUTPUT_DIR / "last_message_id.json"  # 去重记录

# ── 关键词过滤（A股研报相关） ─────────────────────────
REPORT_KEYWORDS = [
    "研报", "研究报告", "深度报告", "行业研究", "公司研究",
    "盈利预测", "投资评级", "买入", "增持", "推荐",
    "EPS", "PE", "PEG", "一致预期", "券商",
    "目标价", "评级调整", "机构预测",
    ".pdf", "pdf", "PDF", "研报下载",
]
SKIP_KEYWORDS = [
    "广告", "推广", "推广合作", "关注公众号", "免费领",
]

# ── 主逻辑 ────────────────────────────────────────────
async def fetch_reports() -> List[dict]:
    """从 qzjjxr 频道抓取研报相关消息，返回 dict 列表"""
    if not API_ID or not API_HASH:
        print("❌ 缺少 TG API 凭据。请设置 TELEGRAM_API_ID 和 TELEGRAM_API_HASH 环境变量。")
        sys.exit(1)

    from pyrogram import Client

    client = Client(
        name="qzjjxr_collector",
        api_id=API_ID,
        api_hash=API_HASH,
        session_string=None,  # 首次需扫码登录
        workdir=str(OUTPUT_DIR),
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    async with client:
        # 读取上次采集位置
        last_id = 0
        if STATE_FILE.exists():
            last_id = int(STATE_FILE.read_text().strip())

        channel = await client.get_chat(CHANNEL_USERNAME)
        messages: List[dict] = []
        fetched_count = 0

        async for msg in client.get_chat_history(channel.id, limit=50):
            if msg.id <= last_id:
                break
            fetched_count += 1

            # 拼接文本内容
            text = ""
            if msg.caption:
                text = msg.caption
            elif msg.text:
                text = msg.text

            if not text:
                continue

            # 过滤：必须命中研报关键词，且不命中广告
            hits_report = any(kw.lower() in text.lower() for kw in REPORT_KEYWORDS)
            hits_ad = any(kw in text for kw in SKIP_KEYWORDS)

            if not hits_report or hits_ad:
                continue

            # 提取 PDF 链接
            pdf_links = re.findall(r'https?://[^\s]+\.(?:pdf|PDF)', text)
            if not pdf_links and msg.media:
                # 如果是文件附件（PDF），尝试下载
                pdf_links.append(f"media:{msg.media.file_name}")

            report = {
                "msg_id": msg.id,
                "date": msg.date.isoformat() if msg.date else None,
                "text": text[:2000],  # 截断过长文本
                "pdf_links": pdf_links,
                "channel": CHANNEL_USERNAME,
            }
            messages.append(report)

            # 保存文件
            fname = OUTPUT_DIR / f"report_{msg.id}_{datetime.now().strftime('%Y%m%d')}.md"
            fname.write_text(f"# {msg.id}\n\n{text}\n\n---\nLinks: {pdf_links}\n",
                             encoding="utf-8")

        # 更新状态
        if messages:
            STATE_FILE.write_text(str(messages[0]["msg_id"]))

        print(f"✅ 采集完成: 扫描 {fetched_count} 条, 命中 {len(messages)} 篇研报")
        return messages


def main():
    reports = asyncio.run(fetch_reports())
    # 输出摘要（供 cron deliver 使用）
    if not reports:
        print("🔕 无新研报")
        return

    print("\n📋 今日研报清单:")
    for r in reports[:10]:
        print(f"  [{r['msg_id']}] {r['date']} — {r['text'][:60]}...")
        if r["pdf_links"]:
            print(f"        🔗 {r['pdf_links']}")


if __name__ == "__main__":
    main()