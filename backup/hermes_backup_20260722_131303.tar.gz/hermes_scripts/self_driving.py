"""Cron wrapper: self-driving backtest at 3am (no_agent)"""
import sys, os
sys.path.insert(0, r'D:/Hermes/评估中心/tools/tdx_connector/scripts')
from self_driving_backtest import run
run()
print('DONE')
