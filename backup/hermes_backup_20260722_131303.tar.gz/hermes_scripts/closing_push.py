#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""收盘推送 (15:15) — 数据同步+智能评估+因子引擎+追踪+推送"""
import os, subprocess, datetime

WORK_DIR = r"D:\Hermes\评估中心"
TOOLS = os.path.join(WORK_DIR, "tools")
PYTHON = r"C:\Python314\python"

def run(name, args=""):
    script = os.path.join(TOOLS, name)
    cmd = f'"{PYTHON}" "{script}" {args}'
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True, encoding="utf-8", timeout=600)
    if r.stdout: print(r.stdout[-400:])
    if r.stderr: print(f"ERR: {r.stderr[-200:]}")
    return r.returncode

now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
print(f"📡 收盘推送 ({now})")
print("="*50)

print("\n[1] 数据同步...")
run("tdx_data_sync.py")

print("\n[2] 20只标的智能评估...")
run("eval_smart.py", '--stocks "甘咨询,四方科技,杭州园林,中远通,当虹科技,高凌信息,华勤技术,深信服,大恒科技,山东墨龙,瑞芯微,沐曦股份,四环生物,昆仑万维,利扬芯片,中国卫星,同益中,亚联机械,贵绳股份,高德红外"')

print("\n[3] 因子引擎...")
run("factor_engine.py")
run("factor_reporter.py")

print("\n[4] 追踪扫描...")
run("tdx_tracker.py")

print("\n[5] 推送(摘要+4份完整报告)...")
run("push_all_reports.py")

# [6] PIAF 重大信号监控（机会+风险双向预警）
try:
    sys.path.insert(0, TOOLS)
    from alert_signals import check_signals, _send_alert
    triggered, text = check_signals()
    if triggered:
        _send_alert(text)
        print(f"\n🚨 PIAF 信号: 已推送预警")
except Exception as e:
    print(f"\n⚠️ PIAF监控异常: {e}")

print(f"\n✅ 收盘推送完成")
