@echo off
chcp 65001 >nul
cd /d "C:\Users\Admin\AppData\Local\hermes\scripts"
python daily_evolution_report.py >> daily_evolution_report.log 2>&1
echo [Completed] %date% %time% >> daily_evolution_report.log
