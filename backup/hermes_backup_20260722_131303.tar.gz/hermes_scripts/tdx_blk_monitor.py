#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通达信 blk 文件监控脚本 — Hermes cron no_agent 模式 (v2.0)

审计修复 (2026-07-13):
- 异常处理: 具体异常类型, 无 bare except
- 并发安全: tracked.json 文件锁
- 日志记录: logging 模块 + 日轮转
- 安全: 股票代码校验, 命令注入防护
- 边界: 文件锁定检测, 节假日判断
"""

import json
import logging
import os
import re
import subprocess
import sys
import time
from datetime import datetime, date
from pathlib import Path

# === 配置 ===
TDX_BLK_DIR = Path(r"D:\TDX\T0002\blocknew")
MONITOR_FILES = [".blk", "tjg.blk", "zxg.blk", "PZYJ.blk"]  # PZYJ.blk = 盘中预警（条件预警结果）
TRACKED_DIR = Path(r"D:\Hermes\评估中心\tools\tdx_connector")
LOG_DIR = TRACKED_DIR / "logs"
EVAL_SCRIPT = Path(r"D:\Hermes\评估中心\tools\eval_smart.py")
PYTHON_PATH = r"C:/Python314/python.exe"
TRACK_TIMEOUT_SEC = 300

# === 日志 ===
LOG_DIR.mkdir(parents=True, exist_ok=True)
log_file = LOG_DIR / f"monitor_{datetime.now().strftime('%Y%m%d')}.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(log_file, encoding="utf-8"),
        logging.StreamHandler(sys.stderr),  # stdout 保留给预警输出，正常日志写 stderr
    ]
)
log = logging.getLogger("tdx_monitor")

# === 股票代码校验 ===
SH_CODES = set()
SZ_CODES = set()

def _load_code_sets():
    """加载沪深股票代码白名单（含 6 位+7 位基金/LOF）"""
    global SH_CODES, SZ_CODES
    try:
        sh_dir = Path(r"D:\TDX\vipdoc\sh\lday")
        sz_dir = Path(r"D:\TDX\vipdoc\sz\lday")
        if sh_dir.exists():
            SH_CODES = {f.stem.replace("sh","") for f in sh_dir.iterdir() if f.suffix==".day"}
        if sz_dir.exists():
            SZ_CODES = {f.stem.replace("sz","") for f in sz_dir.iterdir() if f.suffix==".day"}
        log.info(f"Loaded code sets: SH={len(SH_CODES)}, SZ={len(SZ_CODES)}")
    except Exception as e:
        log.warning(f"Failed to load code sets: {e}")
        SH_CODES = SZ_CODES = set()

_load_code_sets()

def validate_stock_code(code: str) -> bool:
    """校验股票代码合法性（6-7 位，含基金/LOF）"""
    if not re.match(r"^\d{6,7}$", code):
        return False
    if code in SH_CODES or code in SZ_CODES:
        return True
    if len(code) == 6:
        # 按前缀推断合法性
        prefix = code[:3]
        if prefix in ("000", "001", "002", "003", "300", "600", "601", "603", "605", "688", "689"):
            return True
    # 7 位代码（基金/LOF）默认接受
    if len(code) == 7:
        return True
    return False

def get_market(code: str) -> str:
    """根据股票代码前缀推断市场"""
    prefix = code[:3]
    if prefix in ("000", "001", "002", "003", "300"):
        return "sz"
    elif prefix in ("600", "601", "603", "605", "688", "689"):
        return "sh"
    return "sz"  # 默认深市

def infer_market_from_code(code: str) -> str:
    """7位代码推断市场（部分 blk 含 7 位）"""
    # 7位代码通常是 sz 市场（如 1688508）
    if len(code) == 7:
        return "sz"
    return get_market(code)

# === 文件锁 ===
def _with_lock(func, lock_path: Path, timeout=10):
    """跨平台文件锁（原子写入 + 临时文件）"""
    import tempfile
    start = time.time()
    lock_file_path = lock_path.with_suffix(lock_path.suffix + ".lock")
    while time.time() - start < timeout:
        try:
            # 尝试创建锁文件
            lock_fd = os.open(str(lock_file_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            os.close(lock_fd)
            try:
                result = func()
            finally:
                lock_file_path.unlink(missing_ok=True)
            return result
        except FileExistsError:
            time.sleep(0.05)
    raise TimeoutError(f"Lock timeout: {lock_path}")

# === 去重文件 ===
def get_tracked_path() -> Path:
    return TRACKED_DIR / f"tracked_{date.today().strftime('%Y%m%d')}.json"

def load_tracked() -> dict:
    p = get_tracked_path()
    if not p.exists():
        return {}
    lock_p = p.with_suffix(".json.lock")
    try:
        return _with_lock(lambda: json.load(open(p, encoding="utf-8")), lock_p)
    except json.JSONDecodeError as e:
        log.error(f"tracked.json corrupted: {e}")
        return {}
    except FileNotFoundError:
        return {}
    except Exception as e:
        log.error(f"Failed to load tracked: {e}")
        return {}

def save_tracked(tracked: dict):
    p = get_tracked_path()
    lock_p = p.with_suffix(".json.lock")
    try:
        _with_lock(lambda: open(p, "w", encoding="utf-8").write(json.dumps(tracked, ensure_ascii=False, indent=2)), lock_p)
    except Exception as e:
        log.error(f"Failed to save tracked: {e}")
        raise

# === blk 解析 ===
def parse_blk(blk_path: Path) -> list:
    if not blk_path.exists():
        return []
    if not os.access(blk_path, os.R_OK):
        log.warning(f"No read permission: {blk_path}")
        return []
    try:
        raw = blk_path.read_text(encoding="gbk", errors="ignore")
        return [line.strip() for line in raw.splitlines() if line.strip() and len(line.strip()) in (6, 7)]
    except PermissionError:
        log.warning(f"File locked: {blk_path}")
        return []
    except Exception as e:
        log.error(f"Parse failed {blk_path}: {e}")
        return []

def normalize_code(code: str, source_file: str) -> str:
    """通达信 7 位预警代码 -> 标准 6 位股票代码
    zxg.blk（条件选股）和 PZYJ.blk（盘中预警）首位=市场前缀(1=sh,0=sz)
    其他 blk 文件中的 7 位代码视为基金代码，保持原样
    """
    if source_file in ("zxg.blk", "PZYJ.blk") and len(code) == 7:
        return code[1:]
    return code

def get_all_codes() -> list:
    codes = set()
    for fn in MONITOR_FILES:
        raw_codes = parse_blk(TDX_BLK_DIR / fn)
        normalized = [normalize_code(c, fn) for c in raw_codes]
        codes.update(normalized)
        if raw_codes != normalized:
            log.info(f"[PARSE] {fn}: {raw_codes} -> {normalized}")
    # 只接受 6 位股票代码
    valid = [c for c in sorted(codes) if len(c) == 6 and validate_stock_code(c)]
    filtered = sorted(c for c in codes if len(c) != 6)
    if filtered:
        log.info(f"[SKIP] 非6位代码（基金/LOF，eval_smart不支持）: {filtered}")
    return valid

# === 评估 ===
def run_eval(code: str) -> str:
    market = infer_market_from_code(code)
    full_code = f"{market}{code}"
    log.info(f"[EVAL] 开始评估: {code} ({market}), 代码格式: {full_code}")

    # 无效代码拦截（批量评估里混入 880009/999999 会炸掉 eval_smart）
    pure = code[1:] if len(code) == 7 and code[0] in "01" else code
    if not validate_stock_code(pure):
        log.warning(f"[EVAL] 跳过无效代码: {pure}")
        return ""

    start = time.time()
    for attempt in range(3):
        try:
            result = subprocess.run(
                [PYTHON_PATH, str(EVAL_SCRIPT), "-c", code],
                capture_output=True, text=True, timeout=TRACK_TIMEOUT_SEC,
                check=False
            )
            elapsed = time.time() - start
            if result.returncode == 0 and result.stdout and "Traceback" not in result.stdout:
                log.info(f"[EVAL] 评估成功: {code}, 耗时 {elapsed:.1f}s")
                return result.stdout
            else:
                log.warning(f"[EVAL] 评估失败 attempt {attempt+1}/3: {code}, code={result.returncode}, stderr={result.stderr[:200]}")
        except subprocess.TimeoutExpired:
            log.warning(f"[EVAL] 评估超时 attempt {attempt+1}/3: {code} ({TRACK_TIMEOUT_SEC}s)")
        except FileNotFoundError as e:
            log.error(f"[EVAL] Python 不可用: {e}")
            return f"[ERROR] Python 不可用: {e}"
        except Exception as e:
            log.warning(f"[EVAL] 评估异常 attempt {attempt+1}/3: {code}: {e}")
        
        if attempt < 2:
            time.sleep(5)
    
    elapsed = time.time() - start
    return f"[ERROR] 评估失败 (3次重试后): {code}, 总耗时 {elapsed:.1f}s"

def run_batch_eval(codes: list) -> dict:
    """批量评估（合并为一次 eval_smart 调用）"""
    if not codes:
        return {}
    # 单股不走批量（避免整批被一只炸掉）
    if len(codes) == 1:
        return {codes[0]: run_eval(codes[0])}

    # 无效代码前置过滤：880009/999999 等会让 eval_smart 整体崩溃
    valid = [c for c in codes if validate_stock_code(c)]
    dropped = [c for c in codes if c not in valid]
    if dropped:
        log.warning(f"[EVAL] 批量前过滤无效代码: {dropped}")
    if not valid:
        return {c: "" for c in codes}
    if len(valid) == 1:
        return {c: run_eval(c) if c == valid[0] else "" for c in codes}

    combined = ",".join(valid)
    log.info(f"[EVAL] 批量评估: {len(valid)}只, 代码: {combined}")
    start = time.time()

    try:
        result = subprocess.run(
            [PYTHON_PATH, str(EVAL_SCRIPT), "-c", combined],
            capture_output=True, text=True, timeout=TRACK_TIMEOUT_SEC * 2,
            check=False
        )
        elapsed = time.time() - start
        if result.returncode == 0 and result.stdout and "Traceback" not in result.stdout:
            log.info(f"[EVAL] 批量评估成功: {len(valid)}只, 耗时 {elapsed:.1f}s")
            return {c: result.stdout for c in valid}
        else:
            # 批量失败 → 回退逐股评估（避免一锅端）
            log.warning(f"[EVAL] 批量失败 → 回退逐股: stderr={result.stderr[:200]}")
            return {c: run_eval(c) for c in valid}
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start
        log.warning(f"[EVAL] 批量评估超时: {elapsed:.1f}s")
        return {code: f"[ERROR] 批量评估超时 ({elapsed:.1f}s)" for code in codes}
    except Exception as e:
        log.error(f"[EVAL] 批量评估异常: {e}")
        return {code: f"[ERROR] {e}" for code in codes}

# === Telegram 推送（信号卡片）===
def send_to_telegram(code: str, eval_raw: str, condition: str = "盘中预警"):
    """用 signal_card 渲染操作卡片后推送（带实时行情+散户数据）"""
    # 空评估结果 / 报错堆栈：不写队列
    if not eval_raw or "[ERROR]" in eval_raw or "Traceback" in eval_raw or "[ERROR] 评估失败" in eval_raw:
        log.info(f"[SKIP] {code} eval 为空或失败，不写队列")
        return ""
    import sys as _sys
    _sys.path.insert(0, os.path.dirname(__file__))
    _sys.path.insert(0, r"D:/Hermes/评估中心/tools")
    # 拉取实时行情（量比/换手）
    try:
        from astock_bridge import tencent_quote
        qt = tencent_quote([code])
        realtime = qt.get(code)
    except Exception as e:
        log.warning(f"[QT] tencent_quote failed: {e}")
        realtime = None
    # 渲染
    try:
        from signal_card import render_card
        card = render_card(eval_raw, datetime.now().strftime("%H:%M"), condition, realtime=realtime)
    except Exception as e:
        log.warning(f"signal_card failed, fallback: {e}")
        card = f"# 🚨 {condition}\n\n**代码**: {code}\n**时间**: {datetime.now().strftime('%H:%M:%S')}\n\n{eval_raw[:800]}\n"
    qd = TRACKED_DIR / "telegram_queue"
    qd.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%H%M%S%f")[:8]
    f = qd / f"{code}_{ts}.txt"
    try:
        with open(f, "w", encoding="utf-8") as fp:
            fp.write(card)
        log.info(f"PUSH: {f}")
        return card
    except Exception as e:
        log.error(f"Failed to write telegram queue: {e}")
        return card

# === Telegram 队列清理 ===
def cleanup_telegram_queue(max_age_days=7):
    """清理超过 max_age_days 天的推送队列文件"""
    qd = TRACKED_DIR / "telegram_queue"
    if not qd.exists():
        return
    cutoff = time.time() - max_age_days * 86400
    removed = 0
    for f in qd.iterdir():
        if f.suffix == ".txt" and f.stat().st_mtime < cutoff:
            try:
                f.unlink()
                removed += 1
            except Exception as e:
                log.warning(f"Failed to clean up {f}: {e}")
    if removed:
        log.info(f"Cleaned up {removed} old telegram queue files")

# === 节假日 ===
HOLIDAYS = {
    "20260101", "20260129", "20260130", "20260131", "20260201",
    "20260404", "20260501", "20260505", "20260622", "20261001"
}

def is_holiday() -> bool:
    d = date.today().strftime("%Y%m%d")
    return d in HOLIDAYS

# === 主逻辑 ===
def main():
    try:
        now = datetime.now()
        tm = now.hour * 60 + now.minute
        if not (9*60 <= tm <= 15*60):
            # 非交易时间：静默
            return
        if is_holiday():
            # 节假日：静默
            return

        tracked = load_tracked()
        all_codes = get_all_codes()
        new_codes = [c for c in all_codes if c not in tracked]

        if not new_codes:
            # 正常状态：静默，不输出（避免 cron 推送空消息）
            return

        # 标记所有新代码为已追踪（先标记，再评估）
        for code in new_codes:
            tracked[code] = {"time": now.strftime("%H:%M:%S"), "condition": "盘中预警", "status": "analyzing"}
        try:
            save_tracked(tracked)
        except Exception:
            log.warning("Failed to save tracked initial state")

        # 批量评估（合并为一次 eval_smart 调用，提升效率）
        if len(new_codes) > 1:
            log.info(f"[INFO] 批量评估 {len(new_codes)} 只股票")
            eval_results = run_batch_eval(new_codes)
        else:
            log.info(f"[INFO] 单股评估")
            eval_results = {new_codes[0]: run_eval(new_codes[0])}

        # 推送每个评估结果（仅推送成功的卡片）
        for code in new_codes:
            eval_result = eval_results.get(code, "")
            # 跳过空结果（无效代码 / eval 失败）
            if not eval_result or "[ERROR]" in eval_result or "Traceback" in eval_result:
                log.info(f"[SKIP] {code} 无有效评估结果，不推送")
                continue
            card_text = send_to_telegram(code, eval_result)
            # stdout 直接输出卡片，cron 捕获后推 Telegram
            print(card_text)
            # 更新状态为已分析
            tracked[code]["status"] = "analyzed"
        try:
            save_tracked(tracked)
        except Exception:
            log.warning("Failed to save tracked final state")
        log.info(f"[DONE] 处理完成: {len(new_codes)} 只股票")

    except Exception as e:
        log.exception(f"[FATAL] 主流程异常: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
