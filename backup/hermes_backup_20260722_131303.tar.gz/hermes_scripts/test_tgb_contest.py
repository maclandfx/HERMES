#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试淘股论坛大赛频道采集"""
import subprocess, json, os

PW_DIR = os.path.expanduser("~/AppData/Roaming/npm/node_modules/playwright")

r = subprocess.run(
    ["node", "-e", """
const { chromium } = require("./index.js");
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  page.setViewportSize({ width: 375, height: 667 });
  await page.goto("https://mp.tgb.cn/", { waitUntil: "networkidle", timeout: 20000 });
  await page.waitForTimeout(3000);
  const bodyText = await page.evaluate(() => document.body.innerText.slice(0, 3000));
  const links = await page.evaluate(() => {
    const results = [];
    document.querySelectorAll("a[href]").forEach(a => {
      const t = a.innerText.trim();
      if (t.length > 3) results.push(t.slice(0, 50));
    });
    return results.slice(0, 20);
  });
  console.log(JSON.stringify({ text: bodyText, links }, null, 2));
  await browser.close();
})().catch(e => { console.error(e.message); process.exit(1); });
"""],
    cwd=PW_DIR, capture_output=True, text=True, timeout=60,
)
print("STDOUT:", r.stdout[:3000])
print("STDERR:", r.stderr[:500])
print("RC:", r.returncode)