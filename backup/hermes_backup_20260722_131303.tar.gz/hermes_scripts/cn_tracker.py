#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
中国政策与国家队资本动向追踪器 v3.0
============================================================
核心能力：
  1. cninfo 全量扫描（前50页=1500条公告）+ 本地关键词筛选
     → 自动发现大基金/汇金/证金/诚通/国新/社保的减持/增持/权益变动
  2. 部委政策扫描（发改委/工信部/能源局/国家数据局）
  3. 马斯克科技概念对应板块监控
  4. 板块联动传导链分析
============================================================
"""
import os, sys, re, json, time, datetime, pathlib, urllib.request
import urllib.parse, threading

TMP = pathlib.Path("C:/Users/Admin/tmp")
TMP.mkdir(parents=True, exist_ok=True)
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}

# ============================================================================
# 国家队监控关键词（本地筛选用）
# ============================================================================
KW_NATIONAL_TEAM = [
    # 国家队主体
    "大基金", "集成电路产业投资基金", "汇金", "证金", "诚通", "国新",
    "社保基金", "养老金", "全国社保", "基本养老",
    # 资本动作
    "减持", "增持", "权益变动", "股份转让", "协议转让", "大宗交易",
    "定增", "定向增发", "减持计划", "股东权益", "持股5%",
    "持股变动", "减持进展", "减持结果", "质押", "解质押",
    # 央企相关
    "央企", "国有企业", "国有资本", "中特估", "央企科技",
    # ETF相关
    "ETF", "交易型开放式",
]

KW_POLICIES = [
    "规划", "意见", "办法", "通知", "发展", "改革", "能源", "数据", "低空",
    "航天", "半导体", "芯片", "储能", "电网", "算力", "十五五", "新质",
    "碳", "卫星", "电池", "自主可控", "国防", "产业", "投资", "战略",
    "建设", "工业互联网", "新兴产业", "人工智能", "智能", "机器人",
    "光刻", "光刻机", "EDA", "HBM", "固态", "氢能", "虚拟电厂",
    "超算", "数据中心", "低轨", "商业航天", "星地一体", "招标",
]

KW_MUSK_CONCEPT = [
    "机器人", "人形", "自动驾驶", "智能驾驶", "激光雷达", "固态电池",
    "星链", "卫星", "低轨", "商业航天", "算力", "AI", "人工智能",
    "数据中心", "超算", "固态", "氢能", "无人机", "低空",
]

# ============================================================================
# cninfo 全量扫描 + 本地筛选（核心能力）
# ============================================================================
CNINFO_BASE = "http://www.cninfo.com.cn/new/hisAnnouncement/query"

def cninfo_fullscan(page_size=50, max_pages=30):
    """
    cninfo 全量公告扫描（前 max_pages 页）+ 本地关键词筛选
    返回：[(secCode, secName, announcementTitle, announcementTime, dateStr), ...]
    """
    results = []
    errors = []
    
    for page_num in range(1, max_pages + 1):
        # 深市
        try:
            data_sz = urllib.parse.urlencode({
                "tabName": "fulltext",
                "pageSize": str(page_size),
                "pageNum": str(page_num),
                "column": "szse",
                "category": "category_ndsz_szmb",
                "plate": "sz",
            }).encode("utf-8")
            req = urllib.request.Request(CNINFO_BASE, data=data_sz,
                                         headers={**UA, "Content-Type": "application/x-www-form-urlencoded",
                                                 "Referer": "http://www.cninfo.com.cn/"},
                                         method="POST")
            with urllib.request.urlopen(req, timeout=15) as r:
                d_sz = json.loads(r.read().decode("utf-8", errors="ignore"))
            
            for a in d_sz.get("announcements", []):
                title = a.get("announcementTitle", "")
                if any(k in title for k in KW_NATIONAL_TEAM):
                    try:
                        dt = datetime.datetime.fromtimestamp(
                            a["announcementTime"] / 1000
                        ).strftime("%Y-%m-%d")
                    except Exception:
                        dt = "未知"
                    results.append((a.get("secCode", "?"), a.get("secName", "?"),
                                    title, a.get("announcementTime", 0), dt))
        except Exception as e:
            errors.append(f"深市第{page_num}页: {e}")
        
        # 沪市
        try:
            data_sh = urllib.parse.urlencode({
                "tabName": "fulltext",
                "pageSize": str(page_size),
                "pageNum": str(page_num),
                "column": "sse",
                "category": "category_ndsz_szmb",
                "plate": "sh",
            }).encode("utf-8")
            req = urllib.request.Request(CNINFO_BASE, data=data_sh,
                                         headers={**UA, "Content-Type": "application/x-www-form-urlencoded",
                                                 "Referer": "http://www.cninfo.com.cn/"},
                                         method="POST")
            with urllib.request.urlopen(req, timeout=15) as r:
                d_sh = json.loads(r.read().decode("utf-8", errors="ignore"))
            
            for a in d_sh.get("announcements", []):
                title = a.get("announcementTitle", "")
                if any(k in title for k in KW_NATIONAL_TEAM):
                    try:
                        dt = datetime.datetime.fromtimestamp(
                            a["announcementTime"] / 1000
                        ).strftime("%Y-%m-%d")
                    except Exception:
                        dt = "未知"
                    results.append((a.get("secCode", "?"), a.get("secName", "?"),
                                    title, a.get("announcementTime", 0), dt))
        except Exception as e:
            errors.append(f"沪市第{page_num}页: {e}")
        
        # 每5页输出进度
        if page_num % 5 == 0:
            sys.stderr.write(f"[cninfo_fullscan] 已扫描{page_num}页，命中{len(results)}条\n")
    
    return results, errors

# ============================================================================
# 部委官网采集
# ============================================================================

def fetch(url, dst, timeout=20):
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = r.read()
        dst.write_bytes(data)
        return len(data)
    except Exception as e:
        sys.stderr.write(f"[fetch] {url} err: {e}\n")
        return 0

def load_html(p):
    raw = p.read_bytes() if p.exists() else b""
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except Exception:
            pass
    return ""

def extract_links(html, kws, max_items=15):
    out, seen = [], set()
    cand = []
    for m in re.finditer(
        r'<a[^>]*?title=[\x27\x22]([^<]{4,80})[\x27\x22][^>]*?href="([^"]+)'
        r'|<a[^>]*?href="([^"]+)"[^>]*?title=[\x27\x22]([^<]{4,80})[\x27\x22]',
        html,
    ):
        txt = m.group(1) or m.group(4)
        href = m.group(2) or m.group(3)
        cand.append((txt.strip(), href))
    for m in re.finditer(r'<a[^>]*?href="([^"]+)"[^>]*?>([^<]{4,80})</a>', html):
        href, txt = m.group(1), m.group(2).strip()
        if not any(t == txt and h == href for t, h in cand):
            cand.append((txt, href))
    for txt, href in cand:
        if not txt or txt in seen:
            continue
        if any(k in txt for k in kws):
            out.append((txt, href))
            seen.add(txt)
        if len(out) >= max_items:
            break
    return out

# ============================================================================
# 报告生成
# ============================================================================

def main():
    sizes = {}
    out = []
    out.append("# 中国政策与国家队资本动向每日快报")
    out.append(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
    out.append("")
    
    # ---- 阶段1：部委官网采集 ----
    sizes["ndrc"] = fetch("https://www.ndrc.gov.cn/", TMP / "ndrc_d.html")
    sizes["miit"] = fetch("http://www.miit.gov.cn/", TMP / "miit_d.html")
    sizes["nea"] = fetch("http://www.nea.gov.cn/", TMP / "nea_d.html")
    sizes["nda"] = fetch("https://www.nda.gov.cn/", TMP / "nda_d.html")
    sizes["sasac"] = fetch("https://www.sasac.gov.cn/", TMP / "sasac_d.html")
    sizes["csrc"] = fetch("http://www.csrc.gov.cn/csrc/c100028/common_list.shtml", TMP / "csrc_d.html")
    sizes["sast"] = fetch("http://www.sastind.gov.cn/", TMP / "sastind_d.html")
    sizes["caac"] = fetch("http://www.caac.gov.cn/XXGK/XXGK/TZTG/", TMP / "caac_d.html")
    
    kw_all = KW_POLICIES + KW_MUSK_CONCEPT
    
    for name, lbl in [("ndrc_d.html", "发改委"), ("miit_d.html", "工信部"),
                      ("nea_d.html", "能源局"), ("nda_d.html", "国家数据局"),
                      ("sasac_d.html", "国资委")]:
        h = load_html(TMP / name)
        if not h:
            continue
        ls = extract_links(h, kw_all)
        out.append(f"## {lbl} ({len(ls)}条)")
        for t, u in ls[:10]:
            out.append(f"- {t}")
        out.append("")
    
    # ---- 阶段2：cninfo全量扫描 + 本地筛选（核心能力） ----
    out.append("## 国家队资本动向（全量扫描）")
    out.append(f"扫描范围：cninfo全量公告（前30页=1500条）+ 本地关键词筛选")
    out.append("")
    
    national_hits, scan_errors = cninfo_fullscan(page_size=50, max_pages=30)
    
    if national_hits:
        # 按日期+股票代码排序
        national_hits.sort(key=lambda x: (x[4], x[0]), reverse=True)
        # 去重（同一天同一标的只保留第一条）
        seen = set()
        deduped = []
        for item in national_hits:
            key = (item[0], item[4])  # secCode + date
            if key not in seen:
                seen.add(key)
                deduped.append(item)
        
        out.append(f"**共发现 {len(deduped)} 条国家队相关公告：**")
        out.append("")
        for secCode, secName, title, _, dt in deduped:
            # 判断类型
            title_lower = title.lower()
            if "减持" in title:
                tag = "🔻减持"
            elif "增持" in title:
                tag = "🔺增持"
            elif "权益变动" in title or "持股变动" in title:
                tag = "🔄权益变动"
            elif "股东" in title:
                tag = "📊股东"
            else:
                tag = "📌其他"
            out.append(f"- {tag} [{secCode}] {secName} | {dt} | {title[:60]}")
        out.append("")
    else:
        out.append("✅ 今日cninfo全量扫描未命中国家队相关关键词公告")
        out.append("")
    
    if scan_errors:
        out.append(f"⚠️ 扫描错误：{len(scan_errors)}处（已自动跳过）")
        out.append("")
    
    # ---- 阶段3：马斯克科技概念对应板块 ----
    out.append("## 马斯克科技概念 — 中国对应板块")
    out.append("| 马斯克概念 | 中国对应 | 关注标的 |")
    out.append("|-----------|---------|---------|")
    out.append("| 人形机器人 | 工业自动化/具身智能 | 汇川技术/埃斯顿 |")
    out.append("| Starship/猎鹰 | 商业航天/低轨卫星 | 中国卫星/航天宏图 |")
    out.append("| Cybertruck/FSD | 智能驾驶/激光雷达 | 德赛西威/经纬恒润 |")
    out.append("| 特斯拉4680电池 | 固态电池/储能 | 宁德时代/比亚迪 |")
    out.append("| 星链 | 卫星互联网 | 中国卫通/海格通信 |")
    out.append("")
    
    # ---- 阶段4：板块联动传导链 ----
    out.append("## 板块联动传导链")
    out.append("**半导体/算力**：北方华创（设备）→ 中微公司（刻蚀）→ 拓荆科技（薄膜）→ 华海清科（抛光）")
    out.append("**能源**：国电南瑞（电网）→ 阳光电源（储能）→ 宁德时代（电池）→ 南网储能（抽水蓄能）")
    out.append("**航天/低空**：中国卫星（卫星制造）→ 莱斯信息（空管）→ 斯瑞新材（火箭材料）")
    out.append("**中特估**：中国海油（能源央企）→ 中国电信（通信央企）→ 中航西飞（军工央企）")
    out.append("")
    
    # ---- 阶段6：环境温度计 ----
    out.append("## 🌡️ 环境温度计")
    try:
        from cn_temperature import render_temperature
        out.append(render_temperature())
    except Exception as e:
        out.append(f"_(温度计模块异常: {e})_")
        out.append("")

    # ---- 阶段7：资金流向 ----
    out.append("## 💰 资金流向")
    try:
        from cn_moneyflow_daily import render_section as render_money
        out.append(render_money())
    except Exception as e:
        out.append(f"_(资金模块异常: {e})_")
        out.append("")

    # ---- 阶段8：回测摘要 ----
    out.append("## 📈 布局池回测")
    try:
        from cn_pool_backtest import fetch_backtest_summary
        out.append(fetch_backtest_summary())
    except Exception as e:
        out.append(f"_(回测模块异常: {e})_")
        out.append("")

    # ---- 阶段8b：政策进度追踪 ----
    out.append("## 📋 政策落地进度")
    try:
        from cn_policy_tracker import init_db as init_pt, seed_if_empty, render_table
        _pc = init_pt()
        seed_if_empty(_pc)
        out.append(render_table(_pc))
        _pc.close()
    except Exception as e:
        out.append(f"_(进度追踪异常: {e})_")
        out.append("")

    # ---- 阶段9：后续关注 ----
    out.append("## 后续关注")
    out.append("- 大基金减持/新增投资动向（季报披露期重点关注）")
    out.append("- ETF放量信号（汇金/证金托市）")
    out.append("- 商业航天/低空经济政策催化节点")
    out.append("- 新型电力系统/长时储能/固态电池配套细则")
    out.append("- 央企科技指数成分股调整（诚通/国新主导）")
    out.append("")
    
    # ---- 来源索引 ----
    out.append("## 来源索引")
    out.append("- 发改委: https://www.ndrc.gov.cn/")
    out.append("- 工信部: http://www.miit.gov.cn/")
    out.append("- 国家能源局: http://www.nea.gov.cn/")
    out.append("- 国家数据局: https://www.nda.gov.cn/")
    out.append("- 国资委: https://www.sasac.gov.cn/")
    out.append("- 巨潮公告: http://www.cninfo.com.cn/")
    out.append("- 上交所: http://www.sse.com.cn/")
    out.append("- 深交所: http://www.szse.cn/")
    out.append("")
    
    out.append("---采集完成，下一步：交给agent按第四阶段模板分析并填布局池调整---")
    
    # ---- 输出报告 ----
    stdout = "\n".join(out)
    print(stdout)
    
    # ---- 哨兵文件 ----
    meta = {
        "script": "cn_tracker.py",
        "ts": time.time(),
        "dt": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ndrc_bytes": sizes["ndrc"],
        "miit_bytes": sizes["miit"],
        "nea_bytes": sizes["nea"],
        "nda_bytes": sizes["nda"],
        "sasac_bytes": sizes["sasac"],
        "cninfo_fullscan_pages": 30,
        "cninfo_fullscan_hits": len(national_hits),
        "cninfo_scan_errors": len(scan_errors),
        "national_hits_detail": national_hits[:20],
    }
    (TMP / ".cn_tracker.done").write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
    (TMP / "cn_tracker.stamp").write_text(str(int(meta["ts"])), encoding="utf-8")
    sys.stderr.write(f"SENTINEL written: national_hits={len(national_hits)}\n")


if __name__ == "__main__":
    main()
