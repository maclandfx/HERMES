#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""通用 Telegram 推送脚本，接受 --file 参数"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="backslashreplace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="backslashreplace")
import argparse, re, time, os
from pathlib import Path

# 从 .env 读取 Telegram 配置
ENV_PATH = Path(os.environ.get("HERMES_HOME", Path(__file__).parent.parent)) / ".env"
BOT_TOKEN = None
CHAT_ID = None
if ENV_PATH.exists():
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        if line.startswith("TELEGRAM_BOT_TOKEN="):
            BOT_TOKEN = line.split("=",1)[1].strip()
        elif line.startswith("TELEGRAM_CHAT_ID="):
            CHAT_ID = line.split("=",1)[1].strip()

MAX_CHARS = 3900

def flush_print(s):
    try:
        sys.stdout.write(s + "\n")
        sys.stdout.flush()
    except: pass
    try:
        sys.stderr.write(s + "\n")
        sys.stderr.flush()
    except: pass

def split(text, mx):
    if len(text) <= mx:
        return [text]
    chunks = re.split(r"(?m)^(#{1,3} .+)$", text)
    pieces, i = [], 0
    while i < len(chunks):
        if i == 0 and chunks[i] == "":
            i += 1; continue
        pieces.append(chunks[i] + (chunks[i+1] if i+1 < len(chunks) else ""))
        i += 2
    merged, cur = [], ""
    for p in pieces:
        if len(cur) + len(p) <= mx:
            cur = (cur + "\n" + p) if cur else p
        else:
            if cur: merged.append(cur)
            cur = p
    if cur: merged.append(cur)
    final, done = [], False
    for m in merged:
        if done: break
        if len(m) <= mx:
            final.append(m); continue
        cur = ""
        for line in m.split("\n"):
            t = (cur + "\n" + line) if cur else line
            if len(t) <= mx:
                cur = t
            else:
                if cur: final.append(cur)
                cur = line
                if len(cur) > mx:
                    while len(cur) > mx:
                        final.append(cur[:mx]); cur = cur[mx:]
                    if cur: final.append(cur)
        if cur: final.append(cur)
        done = True
    safe = []
    for s in final:
        if len(s) <= mx: safe.append(s)
        else:
            for i in range(0, len(s), mx):
                safe.append(s[i:i+mx])
    return safe

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--file", required=True, help="要推送的文件路径")
    args = parser.parse_args()
    
    report_path = Path(args.file)
    if not report_path.exists():
        flush_print(f"[推送失败] 文件不存在: {report_path}")
        sys.exit(1)
    
    raw = report_path.read_text(encoding="utf-8", errors="replace")
    chunks = split(raw, MAX_CHARS)
    print(f"split {len(chunks)} chunks ({len(raw)} chars)", file=sys.stderr)
    
    for i, ch in enumerate(chunks, 1):
        prefix = f"\n>>> 📄 报告片段 {i}/{len(chunks)} <<<\n\n" if len(chunks) > 1 else ""
        suffix = f"\n\n>>> 续见下一条 ({i+1}/{len(chunks)}) <<<" if i < len(chunks) else "\n\n— END —"
        flush_print(prefix + ch + suffix)
        time.sleep(0.1)
    
    flush_print('{"wakeAgent": true}')
    flush_print(f"DONE chunks={len(chunks)} ts={int(time.time())}")

if __name__ == "__main__":
    main()
