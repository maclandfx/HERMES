#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_temperature.py — 环境温度计
每日产出：
  1. 涨跌停统计（涨停家数 / 跌停家数 / 炸板率）
  2. 市场温度分档 (🟢🟡🔴)
  3. 龙虎榜中国国家队员仓标的命中
  4. 与配置池整体强弱（涨幅 TOP +跌幅 LOSER）
"""
import sys, pathlib, datetime
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from tushare_client import call, as_records

LAYOUT_POOL_CODES = [
    "600406.SH","300274.SZ","300750.SZ","002049.SZ","688981.SZ",
    "600118.SH","600938.SH","601728.SH","600845.SH"
]
LAYOUT_POOL_NAMES = {
    "600406.SH":"国电南瑞","300274.SZ":"阳光电源","300750.SZ":"宁德时代",
    "002049.SZ":"紫光国微","688981.SZ":"中芯国际","600118.SH":"中国卫星",
    "600938.SH":"中国海油","601728.SH":"中国电信","600845.SH":"宝信软件",
}

def today_or_last():
    d = datetime.date.today()
    wd = d.weekday()
    if wd == 0:  # 周一
        d -= datetime.timedelta(days=3)
    elif wd == 6:
        d -= datetime.timedelta(days=2)
    elif wd == 5:
        d -= datetime.timedelta(days=1)
    return d.strftime("%Y%m%d")


def render_temperature(trade_date=None):
    if trade_date is None:
        trade_date = today_or_last()
    errs = []
    out = []
    out.append("## 🌡️ 环境温度计 · " + trade_date)
    out.append("")

    # 1) 涨跌停统计（limit_list_d）
    d = call("limit_list_d", {"trade_date": trade_date})
    if not d:
        errs.append(f"涨跌停 stats 空 ({trade_date})")
        limits = []
    else:
        limits = as_records(d)
    ups = [(x["ts_code"], x["name"], x["pct_chg"]) for x in limits if x.get("limit") == "U"]
    downs = [(x["ts_code"], x["name"], x["pct_chg"]) for x in limits if x.get("limit") == "D"]
    zha = [(x["ts_code"], x["name"], x.get("open_times",0), x.get("fd_amount") or 0)
           for x in limits if x.get("open_times",0) > 0]
    out.append(f"**涨停**: {len(ups)}家 | **跌停**: {len(downs)}家 | **炸板**: {len(zha)}家")
    out.append("")

    # 温度评分
    score = len(ups) - 2 * len(zha) - len(downs)
    if score >= 80: temp, temp_txt = "🟢", "强 (>400只涨停)"
    elif score >= 40: temp, temp_txt = "🟡", "中性 (150-399)"
    elif score >= 10: temp, temp_txt = "⚠️", "偏弱 (50-149)"
    else: temp, temp_txt = "🔴", "弱 (<50)"
    out.append(f"**环境温度**：{temp} {temp_txt} | 评分 {score}")
    out.append("")

    # 2) 涨停 TOP5
    out.append("**板块涨停强度 TOP5**")
    sectors = {}
    for _, name, pct in ups:
        for rec in limits:
            if rec.get("name","") == name and rec.get("limit") == "U":
                sec = rec.get("industry","未知")
                sectors[sec] = sectors.get(sec, 0) + 1
                break
    top5 = sorted(sectors.items(), key=lambda x: x[1], reverse=True)[:5]
    for sec, n in top5:
        out.append(f"- {sec}：{n}只涨停")
    out.append("")

    # 3) 炸板预警
    if zha:
        out.append("**炸板预警（开板≥1次）**")
        for ts, name, times, fd in zha[:8]:
            fd_yi = fd/1e8 if fd else 0
            out.append(f"- {name} | 开板{times}次 | 封单金额 {fd_yi:.1f}亿")
        out.append("")

    # 4) 龙虎榜布局池命中
    d_tl = call("top_list", {"trade_date": trade_date})
    if not d_tl:
        errs.append(f"top_list 空 ({trade_date})")
        hits = []
    else:
        tl = as_records(d_tl)
        hits = [x for x in tl if x.get("ts_code","").replace(".SH",".SH") in LAYOUT_POOL_CODES or x.get("ts_code","").replace(".SZ",".SZ") in LAYOUT_POOL_CODES]
    out.append("**龙虎榜 · 布局池标的命中**")
    if hits:
        for x in hits[:12]:
            nm = LAYOUT_POOL_NAMES.get(x["ts_code"], x.get("name","?"))
            out.append(f"- {x['trade_date']} | {x['ts_code']} {nm} | {x.get('pct_change',0):+.2f}% | 龙虎榜原因: {x.get('reason','')[:50]}")
    else:
        out.append("_(无命中或今日无龙虎榜)_")
    out.append("")

    if errs:
        out.append("**数据缺失**：")
        for e in errs:
            out.append(f"- ⚠️ {e}")
        out.append("")

    return "\n".join(out)


if __name__ == "__main__":
    print(render_temperature())
