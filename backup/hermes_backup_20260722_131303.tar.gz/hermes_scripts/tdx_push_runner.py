#!/usr/bin/env python3
"""盘中预警推送引擎 — no_agent cron wrapper"""
import subprocess, sys

PYTHON = r"C:\Python314\python.exe"
SCRIPT = r"D:\Hermes\评估中心\tools\tdx_push_runner.py"
WORKDIR = r"D:\Hermes\评估中心\tools"

r = subprocess.run(
    [PYTHON, SCRIPT],
    capture_output=True, text=True, encoding="utf-8",
    cwd=WORKDIR, timeout=600,
)
sys.stdout.write(r.stdout)
if r.returncode != 0:
    sys.stdout.write(f"\n❌ 执行失败 (rc={r.returncode})\n{r.stderr[-500:]}")
sys.exit(r.returncode)
