#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""发送系统进化报告到 Telegram（修复 Markdown 格式问题）"""
import sys, io, json, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="backslashreplace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="backslashreplace")

import os
import urllib.request
import urllib.parse
from pathlib import Path

HERMES_HOME = Path(os.environ.get("HERMES_HOME", "/c/Users/Admin/AppData/Local/hermes"))
REPORT_PATH = HERMES_HOME / "scripts" / "evolution_report_test.md"
ENV_PATH = HERMES_HOME / ".env"

# 读 Telegram 配置
BOT_TOKEN = None
CHAT_ID = None
PROXY = None
if ENV_PATH.exists():
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        if line.startswith("TELEGRAM_BOT_TOKEN="):
            BOT_TOKEN = line.split("=",1)[1].strip()
        elif line.startswith("TELEGRAM_HOME_CHANNEL="):
            CHAT_ID = line.split("=",1)[1].strip()
        elif line.startswith("TELEGRAM_PROXY="):
            PROXY = line.split("=",1)[1].strip()

if not BOT_TOKEN or not CHAT_ID:
    print("[FAIL] 缺少 BOT_TOKEN 或 CHAT_ID", file=sys.stderr)
    sys.exit(1)

def md_to_html(text):
    """极简 Markdown → HTML 转换，只处理 Telegram 需要的几种"""
    # 先处理代码行
    lines = text.split("\n")
    html_lines = []
    in_code = False
    code_buf = []
    for line in lines:
        if line.startswith("```"):
            if not in_code:
                in_code = True
                code_buf = []
            else:
                in_code = False
                html_lines.append("<pre>" + "\n".join(code_buf) + "</pre>")
                code_buf = []
        elif in_code:
            code_buf.append(line)
        else:
            # 处理粗体 **text**
            line = line.replace("**", "<b>", 1) if line.count("**") >= 2 else line
            # 简单处理
            import re
            line = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", line)
            line = re.sub(r"`(.+?)`", r"<code>\1</code>", line)
            line = line.replace("* ", "• ")
            line = line.replace("- ", "• ")
            html_lines.append(line)
    
    if in_code:
        html_lines.append("<pre>" + "\n".join(code_buf) + "</pre>")
    
    # 处理标题
    result = "\n".join(html_lines)
    result = re.sub(r"^## (.+)$", r"<b>\1</b>", result, flags=re.MULTILINE)
    result = re.sub(r"^# (.+)$", r"<b>\1</b>", result, flags=re.MULTILINE)
    return result

def send_to_telegram(text, token, chat_id, proxy_url=None):
    """通过 Bot API 发送消息"""
    html_text = md_to_html(text)
    data = {
        "chat_id": chat_id,
        "text": html_text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    body = json.dumps(data, ensure_ascii=False).encode("utf-8")
    
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    
    if proxy_url:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url}))
        urllib.request.install_opener(opener)
    
    try:
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read())
            return result
    except Exception as e:
        return {"ok": False, "error": str(e)}

def main():
    if not REPORT_PATH.exists():
        print(f"[FAIL] 报告不存在: {REPORT_PATH}", file=sys.stderr)
        sys.exit(1)
    
    raw = REPORT_PATH.read_text(encoding="utf-8")
    print(f"[INFO] 报告长度: {len(raw)} 字符", file=sys.stderr)
    
    # Telegram 单条消息限制 4096 字符
    MAX = 4000
    if len(raw) > MAX:
        # 分块
        chunks = [raw[i:i+MAX] for i in range(0, len(raw), MAX)]
        print(f"[INFO] 分 {len(chunks)} 块发送", file=sys.stderr)
        for i, chunk in enumerate(chunks):
            result = send_to_telegram(chunk, BOT_TOKEN, CHAT_ID, PROXY)
            if result.get("ok"):
                print(f"[OK] 块 {i+1}/{len(chunks)} 发送成功", file=sys.stderr)
            else:
                print(f"[FAIL] 块 {i+1}/{len(chunks)}: {result}", file=sys.stderr)
            if i < len(chunks) - 1:
                time.sleep(0.5)
    else:
        result = send_to_telegram(raw, BOT_TOKEN, CHAT_ID, PROXY)
        if result.get("ok"):
            print(f"[OK] 消息发送成功", file=sys.stderr)
            print(json.dumps(result), file=sys.stderr)
        else:
            print(f"[FAIL] 发送失败: {result}", file=sys.stderr)

if __name__ == "__main__":
    main()
