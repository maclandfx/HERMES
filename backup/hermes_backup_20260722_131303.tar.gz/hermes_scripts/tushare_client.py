#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tushare_client.py — 极简Tushare REST客户端 (stdlib only)
独立模块, 被cn_tracker.py和cn_state_capital_quarterly.py共享调用.
所有调用走POST https://api.tushare.pro. token读环境变量TUSHARE_TOKEN.
"""
import os, json, urllib.request, time, sys

TUSHARE_URL = "https://api.tushare.pro"
_TOKEN = None


def _get_token():
    global _TOKEN
    if _TOKEN:
        return _TOKEN
    tok = os.environ.get("TUSHARE_TOKEN", "")
    if not tok:
        # 兜底: 从~/.hermes/.env读取
        import pathlib
        env = pathlib.Path("C:/Users/Admin/AppData/Local/hermes/.env")
        if env.exists():
            for line in env.read_text(encoding="utf-8", errors="ignore").splitlines():
                if line.startswith("TUSHARE_TOKEN="):
                    tok = line.split("=", 1)[1].strip()
                    break
    if not tok:
        sys.stderr.write("[TUSHARE] 未配置TUSHARE_TOKEN环境变量\n")
    _TOKEN = tok
    return tok


def call(api_name, params=None, fields=None, timeout=30, retries=3):
    """调用Tushare REST API. 返回 {"fields":[...], "items":[...]} 或 None."""
    tok = _get_token()
    if not tok:
        return None
    body = {"api_name": api_name, "token": tok, "params": params or {}}
    if fields:
        body["fields"] = ",".join(fields) if isinstance(fields, list) else fields
    data = json.dumps(body).encode("utf-8")
    last_err = None
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                TUSHARE_URL, data=data,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=timeout) as r:
                res = json.loads(r.read().decode("utf-8", errors="ignore"))
            if res.get("code") == 0:
                return res["data"]
            last_err = f"code={res.get('code')} msg={res.get('msg','')}"
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
        if attempt < retries:
            time.sleep(1.5 * attempt)
    sys.stderr.write(f"[TUSHARE] {api_name} 调用失败(retries={retries}): {last_err}\n")
    return None


def as_records(data):
    """把 Tushare {"fields":[...], "items":[[...],...]} 转成 list[dict]"""
    if not data or "fields" not in data:
        return []
    fields = data["fields"]
    return [dict(zip(fields, row)) for row in data.get("items", [])]


if __name__ == "__main__":
    # 自测
    d = call("daily", {"trade_date": "20260703", "ts_code": "600406.SH"},
             ["ts_code", "trade_date", "close", "pct_chg", "amount"])
    print(as_records(d))
