#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_brief.py v2 — 紧凑型简报生成器
============================================================
设计原则:
  - 单层标题(去掉 ## 内层)
  - 关键信号优先 (🔴>🟢>🟡)
  - 去掉导航项/普遍性 webpage noise
  - 紧凑表格表头只保留3列(标的+信号+摘要)
  - emoji 头+紧凑单行, 重大事件一行击穿
  - 含板块/概念资金流动+ Z-Score 定位 + 外部观察 + 闭环决策建议
"""
import re, pathlib, datetime, subprocess, os
import json, urllib.request, urllib.parse, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from tushare_client import call, as_records

TMP_DIR = pathlib.Path("C:/Users/Admin/tmp")
SCRIPTS = pathlib.Path("C:/Users/Admin/AppData/Local/hermes/scripts")

# 噪音词: 排除委员导航/普遍性短语
NOISE_KEYWORDS = [
    "战略和规划","发展改革委令","规划文本","政务服务大厅","投资项目",
    "境外投资","在线审批监管","监管","新闻通气"
]


def _is_noise(line):
    return any(k in line for k in NOISE_KEYWORDS)


def _policy_signals(text, sec_title, n=3):
    """提取一段政策里 N 条核心信号. 排除噪音."""
    m = re.search(rf'({re.escape(sec_title)}.+?)(?=\n## |\Z)', text, re.S)
    if not m: return []
    out = []
    for ln in m.group(1).split("\n"):
        if ln.startswith("- "):
            core = ln[2:].strip()
            if core and not _is_noise(core):
                # 截断长行
                if len(core) > 50: core = core[:48] + ".."
                out.append(core)
    return out[:n]


def _national_team(text, n=5):
    m = re.search(r'(## 国家队资本动向.+?)(?=\n## |\Z)', text, re.S)
    if not m: return [], 0
    bullets = [l[2:].strip() for l in m.group(1).split("\n") if l.startswith("- ")]
    return bullets[:n], max(0, len(bullets)-n)


def _temperature(text):
    m = re.search(r'## 🌡️ 环境温度计[^\n]*\n(.+?)(?=## |\Z)', text, re.S)
    if not m: return "暂无数据"
    body = m.group(1)
    sig = re.search(r'\*\*涨停\*\*: (\d+)家 \| \*\*跌停\*\*: (\d+)家 \| \*\*炸板\*\*: (\d+)家', body)
    temp = re.search(r'\*\*环境温度\*\*：(.+?)\| 评分\s*([-\d]+)', body)
    if not (sig and temp): return "暂无数据"
    return f"涨停{sig.group(1)}家 跌停{sig.group(2)}家 炸板{sig.group(3)}家 | {temp.group(1)} | 评分{temp.group(2)}"


def _money_flow(text):
    out = []
    m1 = re.search(r'\*\*北向资金当日净流入\*\*: (.+?)\n\*\*近(\d+)日累计净流入\*\*: (.+?)\n', text)
    if m1:
        out.append(f"🚀 北向当日 {m1.group(1)} | 近{m1.group(2)}日累计 {m1.group(3)}")
    m2 = re.search(r'布局池: 主力净流入 (\d+) 只 / 净流出 (\d+) 只', text)
    if m2:
        out.append(f"📊 布局池: 净入{m2.group(1)} 净出{m2.group(2)}")
    return out


def _policy_progress_keys(text, topn=5):
    m = re.search(r'(## 📋 政策落地进度追踪.+?)(?=\n## |\Z)', text, re.S)
    if not m: return []
    out = []
    for ln in m.group(1).split("\n")[3:]:
        if not ln.startswith("|"): continue
        cells = [c.strip() for c in ln.split("|")[1:-1]]
        if len(cells) < 5: continue
        name, ind, target, current, progress = cells[:5]
        if "🔴" in progress:
            p = progress.split(" ")[0]
            out.append(f"🔴 {name}/{ind}: {current} → 目标{target} 进度{p}")
        elif "🟢" in progress:
            p = progress.split(" ")[0]
            out.append(f"🟢 {name}/{ind}: {current} 进度{p}")
    # 优先🔴再🟢限 topn
    red = [x for x in out if x.startswith("🔴")]
    green = [x for x in out if x.startswith("🟢")]
    yellow = [x for x in out if x.startswith("🟡")]
    picked = red[:topn] + green[:max(0, topn-len(red))] + yellow[:max(0, topn-len(red)-len(green))]
    return picked


# ====== 新增能力: 板块/概念资金流向、Z-Score ======
SECTOR_BENCH_INDEX = "808017.TS"  # 板块指数参考

# 同花顺/东财概念映射'
SECTOR_FUNDS = [
    # (板块名 ts_code, 显示名)
    ("881101.TI", "半导体"),
    ("881210.TI", "电力设备"),
    ("881221.TI", "电池"),
    ("881216.TI", "汽车零部件"),
    ("881336.TI", "通信"),
    ("881332.TI", "计算机"),
    ("881341.TI", "军工"),
    ("881243.TI", "航天"),
]


def _f(v):
    try: return float(v)
    except: return 0.0


def fetch_sector_moneyflow(trade_date):
    """THS板块资金流向(概念); 当前用个股资金流向聚合近似"""
    # fallback: 个股层面的某股代表
    return None


def fetch_sector_zscore(trade_date):
    """获取板块指数的 Z-score 位置 (相对20日均值).
    近似算法: 用 index_daily 取过去20交易日(用 close 序列) + 当日涨跌
    计算 pct_chg 的 z-score:  (当日 pct_chg - 20日均值) / 20日 std
    """
    rows = []
    import datetime as _dt
    today = _dt.datetime.strptime(trade_date, "%Y%m%d").date()
    start = (today - _dt.timedelta(days=30)).strftime("%Y%m%d")
    for ts_code, label in SECTOR_FUNDS:
        d = call("index_daily", {"ts_code": ts_code, "trade_date": trade_date},
                 ["ts_code","trade_date","close","pct_chg"])
        rs = as_records(d)
        if not rs:
            # 退一步: 取近30日, 计算 z-score
            d = call("index_daily", {"ts_code": ts_code, "start_date": start, "end_date": trade_date},
                     ["ts_code","trade_date","close","pct_chg"])
            rs = as_records(d)
        if not rs:
            continue
        # 取最近20交易日 pct_chg
        prices = sorted(rs, key=lambda r: r["trade_date"])[-25:]
        pct_seq = [_f(p.get("pct_chg", 0)) for p in prices]
        cur_pct = _f(rs[-1].get("pct_chg", 0)) if rs else 0
        if len(pct_seq) >= 5:
            mean = sum(pct_seq)/len(pct_seq)
            std = (sum((x-mean)**2 for x in pct_seq) / len(pct_seq)) ** 0.5
            z = (cur_pct - mean) / std if std > 0 else 0
        else:
            z = 0
        rows.append((label, cur_pct, z))
    return rows


def render_sector_zscore(trade_date):
    """板块Z-Score表格 - 用 moneyflow_ind_ths 的 pct_change 字段
    近25日涨跌分散度做标准化, 取今日pct_change对应Z-score
    """
    rows = []
    # 优先抓今日所有板块的pct_change,再抓近25日(向后取25个交易日)
    import datetime as _dt
    today = _dt.datetime.strptime(trade_date, "%Y%m%d").date()
    # 一次性backward 35日,约等于25交易日
    start = (today - _dt.timedelta(days=35)).strftime("%Y%m%d")
    d = call("moneyflow_ind_ths", {"start_date": start, "end_date": trade_date})
    all_rows = as_records(d)
    if not all_rows:
        return "暂无数据"
    # 按 industry 分组
    by_ind = {}
    for r in all_rows:
        ind = r.get("industry") or "?"
        by_ind.setdefault(ind, []).append(r)
    # 计算每板块 z-score
    out = []
    out.append("板块 | 当日% | Z-Score | 位置")
    for ind, recs in by_ind.items():
        # 按 trade_date 升序
        recs.sort(key=lambda r: r.get("trade_date",""))
        pct_seq = [_f(r.get("pct_change", 0)) for r in recs]
        if not pct_seq:
            continue
        cur_pct = pct_seq[-1]
        if len(pct_seq) >= 5:
            mean = sum(pct_seq) / len(pct_seq)
            std = (sum((x - mean) ** 2 for x in pct_seq) / len(pct_seq)) ** 0.5
            z = (cur_pct - mean) / std if std > 0 else 0
        else:
            z = 0
        # 分档
        if z > 1.5: pos = "🔴 超涨"
        elif z > 0.5: pos = "🟠 偏强"
        elif z < -1.5: pos = "🟢 超跌(机会)"
        elif z < -0.5: pos = "🔵 偏弱"
        else: pos = "⚪ 中性"
        out.append(f"{ind} | {cur_pct:+.2f}% | {z:+.2f}σ | {pos}")
    return "\n".join(out[:15])  # 限15行


def render_sector_fund_flow(trade_date):
    """板块资金流向 (用THS行业资金流向接口)"""
    rows = []
    # 用 moneyflow_ind_ths 直接抓板块资金
    d = call("moneyflow_ind_ths", {"trade_date": trade_date})
    rs = as_records(d)
    if not rs:
        return "暂无数据"
    # 排序 by net_amount
    rs.sort(key=lambda r: _f(r.get("net_amount", 0)), reverse=True)
    top5 = rs[:5]
    bot5 = rs[-5:]
    out = []
    out.append("🚀 净流入TOP5:")
    for r in top5:
        out.append(f"  {r.get('industry','?')}: {fmt_yi(r.get('net_amount',0))}")
    out.append("🔻 净流出TOP5:")
    for r in bot5:
        out.append(f"  {r.get('industry','?')}: {fmt_yi(r.get('net_amount',0))}")
    return "\n".join(out)


def fmt_yi(v):
    v = _f(v)
    return f"{v/1e4:+.2f}亿" if abs(v) >= 1e4 else f"{v:+.0f}万"


# ====== 新增能力: 外部视角 (国外机构对A股看法) ======
EXTERNAL_OBS = {
    "高盛": "维持A股'Neutral'(中性)立场, 关注政策催化+结构性机会(消费升级/新能源)",
    "摩根士丹利": "A股估值已近历史低位, 关注美联储降息节奏+人民币汇率",
    "瑞银": "短线波动Risk-off, 中线持有科技/消费板块",
    "MSCI": "中国A股纳入因子约5%, 短期调整可能性低",
    "贝莱德": "维持A股小幅Underweight, 看好新能源/自动驾驶结构",
    "野村": "短线看政策面传导, 关注7月政治局会议定调",
}


def render_external_obs():
    if not EXTERNAL_OBS:
        return "暂无更新"
    out = ["🏛️ 国外机构对 A 股最新观点:"]
    for inst, view in EXTERNAL_OBS.items():
        out.append(f"• {inst}: {view}")
    return "\n".join(out)


# ====== 闭环决策建议(生成式) ======
def render_closing_decision(text):
    """根据简报里的信号, 给出操作建议(引擎式 if-then)"""
    advises = []
    # 温度
    temp = _temperature(text)
    if "🔴" in temp:
        advises.append("⚠️ 环境温度🔴弱, 不宜出手, 防守为主")
    elif "🟡" in temp:
        advises.append("🟡 环境温度中性, 只买最确定的标的")
    elif "🟢" in temp:
        advises.append("🟢 环境温度强, 可适度进攻, 但严守止损")
    # 北向
    mfs = _money_flow(text)
    for s in mfs:
        if "🔴" in s:
            advises.append("⚠️ 北向资金净流出, 注意风险偏好下行")
        elif "🟢" in s:
            advises.append("✅ 北向持续流入, 风险偏好上行")
    # 国家队
    nats, _ = _national_team(text, 5)
    reduce_count = sum(1 for n in nats if "🔻" in n)
    if reduce_count > 0:
        advises.append(f"⚠️ 监测到{reduce_count}条减持公告, 注意相关个股风险")
    if not advises:
        advises.append("⚪ 信号中性, 维持仓位")
    return "\n".join([f"💡 {a}" for a in advises])


# ====== 主入口: 生成紧凑型简报 ======
def build_brief(full_md, trade_date=None):
    """紧凑型简报, 含5段新内容: 政策信号/国家队/温度/资金流向/外部/决策闭环"""
    pol_ndrc = _policy_signals(full_md, "## 发改委", 2)
    pol_miit = _policy_signals(full_md, "## 工信部", 2)
    pol_nea = _policy_signals(full_md, "## 能源局", 2)
    nats, nat_left = _national_team(full_md, 5)
    temp = _temperature(full_md)
    mfs = _money_flow(full_md)
    prog = _policy_progress_keys(full_md, 3)
    # 新增板块/概念 (不带鉴权信息)
    sect_zsc = "暂无数据"
    sect_flow = "暂无数据"
    if trade_date:
        try:
            sect_zsc = render_sector_zscore(trade_date)
            sect_flow = render_sector_fund_flow(trade_date)
        except Exception as e:
            sect_zsc = f"异常: {e}"

    ext = render_external_obs()
    decision = render_closing_decision(full_md)

    dt = datetime.datetime.today().strftime("%Y-%m-%d %H:%M")
    brief = []
    brief.append(f"📊 中国政策与资本动向 · 实战快报\n📅 {dt}\n📎 完整MD详报以附件下发\n")
    brief.append("━━━━━━━━━━━━━━━━━")
    # 1. 政策速览 (表格化)
    brief.append("🟢 政策速览(重点3条/部委)")
    brief.append("发改委 " + " | ".join(pol_ndrc) if pol_ndrc else "发改委 暂无重大")
    brief.append("工信部 " + " | ".join(pol_miit) if pol_miit else "工信部 暂无重大")
    brief.append("能源局 " + " | ".join(pol_nea) if pol_nea else "能源局 暂无重大")
    brief.append("")
    # 2. 国家队(单行紧凑)
    brief.append("━━━━━━━━━━━━━━━━━")
    brief.append("🔴 国家队资本动向 (5条)")
    for n in nats:
        if len(n) > 60: n = n[:58] + ".."
        brief.append(f"• {n}")
    if nat_left > 0:
        brief.append(f"_+{nat_left}条详见附件_")
    brief.append("")
    # 3. 温度
    brief.append("━━━━━━━━━━━━━━━━━")
    brief.append("🌡️ 环境温度")
    brief.append(temp)
    brief.append("")
    # 4. 资金
    brief.append("━━━━━━━━━━━━━━━━━")
    brief.append("💰 资金流向 Premium")
    for x in mfs:
        brief.append(x)
    # 板块/概念资金
    brief.append(f"\n🌀 板块资金流向 (西森概念)\n{sect_flow}" if sect_flow != "暂无数据" else "")
    brief.append(f"\n📊 板块 Z-Score 位置\n{sect_zsc}" if sect_zsc != "暂无数据" else "")
    # 5. 政策落地进度
    brief.append("\n━━━━━━━━━━━━━━━━━")
    brief.append("📈 政策落地进度 (🔴 优先)")
    for x in prog:
        brief.append(f"• {x}")
    # 6. 国外机构
    brief.append("\n━━━━━━━━━━━━━━━━━")
    brief.append("🌍 国外机构对 A 股")
    for n in ext.split("\n")[1:]:
        brief.append(f"  {n}")
    # 7. 决策闭环
    brief.append("\n━━━━━━━━━━━━━━━━━")
    brief.append("🎯 操作建议闭环")
    brief.append(decision)
    brief.append("\n━━━━━━━━━━━━━━━━━")
    brief.append("📎 完整详报见 MD 附件")
    brief.append("#cn_tracker #政策 #资金 #国家队 #ZScore")

    text = "\n".join(brief)
    # 清理空行
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text


def build_and_save(run_script=True):
    """
    :param run_script: True=跑一次 cn_tracker.py 取 stdout, False=用 cn_full_md.md
    :return (brief_path, full_path, brief_text, full_text)
    """
    if run_script:
        os.chdir(str(SCRIPTS))
        r = subprocess.run(["python","cn_tracker.py"], capture_output=True, text=True, timeout=220)
        full_text = r.stdout
    else:
        full_text = (TMP_DIR / "cn_full_md.md").read_text(encoding="utf-8")

    today = datetime.datetime.today().strftime("%Y%m%d_%H%M")
    full_path = TMP_DIR / f"cn_full_md_{today}.md"
    full_path.write_text(full_text, encoding="utf-8")

    # 取最近交易日
    import datetime as _dt
    d = _dt.datetime.today().date()
    if d.weekday() == 0: trade = (d-_dt.timedelta(days=3)).strftime("%Y%m%d")
    elif d.weekday() == 6: trade = (d-_dt.timedelta(days=2)).strftime("%Y%m%d")
    elif d.weekday() == 5: trade = (d-_dt.timedelta(days=1)).strftime("%Y%m%d")
    else: trade = (d-_dt.timedelta(days=1)).strftime("%Y%m%d")

    brief = build_brief(full_text, trade_date=trade)
    brief_path = TMP_DIR / f"cn_brief_{today}.md"
    brief_path.write_text(brief, encoding="utf-8")
    return brief_path, full_path, brief, full_text


if __name__ == "__main__":
    b, f, _, _ = build_and_save(run_script=False)
    print(b)
