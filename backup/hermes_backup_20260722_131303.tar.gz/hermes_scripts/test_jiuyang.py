#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试韭研公社 Playwright 登录 + 数据采集（独立脚本）"""
import subprocess, json, os, sys

PW_DIR = os.path.expanduser("~/AppData/Roaming/npm/node_modules/playwright")
COOKIE_DIR = os.path.expanduser("~/AppData/Local/hermes/data/sentiment_collector/cookies")
os.makedirs(COOKIE_DIR, exist_ok=True)
COOKIE_PATH = os.path.join(COOKIE_DIR, "jiuyang_cookies.json")

JIUYAN_PHONE = "13917888160"
JIUYAN_PASSWORD = "1qa2ws3ed"

PW_SCRIPT = r'''
const { chromium } = require("./index.js");
const fs = require("fs");

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  page.setViewportSize({ width: 1280, height: 800 });

  const COOKIE_PATH = "${COOKIE_PATH}";

  // ── 1. 加载 Cookie ──
  if (fs.existsSync(COOKIE_PATH)) {
    const cookies = JSON.parse(fs.readFileSync(COOKIE_PATH, "utf8"));
    await page.context().addCookies(cookies);
    console.log("[JIUYAN] Loaded", cookies.length, "cookies");
  } else {
    console.log("[JIUYAN] No saved cookies");
  }

  // ── 2. 登录 ──
  await page.goto("https://www.jiuyangongshe.com/", { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(3000);

  const isLoggedIn = await page.evaluate(() => !document.body.innerText.includes("登录注册"));

  if (!isLoggedIn) {
    console.log("[JIUYAN] Not logged in, attempting login...");

    // 点击登录按钮
    const loginBtn = await page.$(".el-button--primary");
    if (loginBtn) {
      await loginBtn.click();
      await page.waitForTimeout(2000);
    }

    // 点击账号密码登录tab
    const tabBtn = await page.$("#tab-accounts");
    if (tabBtn) {
      await tabBtn.click();
      await page.waitForTimeout(1500);
    }

    // 填写表单
    await page.fill("#pane-accounts input[name=phone]", "${JIUYAN_PHONE}");
    await page.fill("#pane-accounts input[name=password]", "${JIUYAN_PASSWORD}");
    await page.waitForTimeout(500);

    // 点击登录按钮
    try {
      await page.click(".el-dialog .el-button--primary");
      await page.waitForTimeout(4000);
    } catch(e) {
      console.log("[JIUYAN] Login click failed:", e.message);
    }

    // 保存新的 cookies
    const newCookies = await page.context().cookies();
    try {
      fs.writeFileSync(COOKIE_PATH, JSON.stringify(newCookies, null, 2));
      console.log("[JIUYAN] Saved", newCookies.length, "new cookies");
    } catch(e) {
      console.log("[JIUYAN] Failed to save cookies:", e.message);
    }
  } else {
    console.log("[JIUYAN] Already logged in");
  }

  // ── 3. 采集首页帖子 ──
  await page.goto("https://www.jiuyangongshe.com/", { waitUntil: "domcontentloaded", timeout: 15000 });
  await page.waitForTimeout(4000);

  const posts = await page.evaluate(() => {
    const results = [];
    const sections = document.querySelectorAll("section");
    sections.forEach(section => {
      const titleEl = section.querySelector(".book-title, h2, h3");
      const title = titleEl ? titleEl.innerText.trim() : "";
      if (!title) return;

      const authorEl = section.querySelector("[class*=author], [class*=user]");
      const author = authorEl ? authorEl.innerText.trim().slice(0, 20) : "未知";

      const timeEl = section.querySelector("[class*=time]");
      const time = timeEl ? timeEl.innerText.trim() : "";

      const statsText = section.innerText;
      const readMatch = statsText.match(/(\d+(?:\.\d+)?)\s*(?:万)?\s*阅读/);
      const readCount = readMatch ? readMatch[1] : "0";

      const fullText = section.innerText.slice(0, 1000);

      results.push({
        title: title.slice(0, 150),
        author: author,
        time: time,
        readCount: readCount,
        fullText: fullText,
      });
    });
    return results;
  });

  console.log(JSON.stringify({
    posts: posts,
    timestamp: new Date().toISOString(),
  }, null, 2));

  await browser.close();
})().catch(e => {
  console.error("[JIUYAN] FATAL:", e.message);
  process.exit(1);
});
'''

script = PW_SCRIPT

r = subprocess.run(
    ["node", "-e", script],
    cwd=PW_DIR, capture_output=True, text=True, timeout=90,
)

if r.returncode != 0:
    print(f"❌ 韭研公社采集失败: {r.stderr[:500]}")
    sys.exit(1)

output = r.stdout.strip()
if not output:
    print("❌ 无输出")
    sys.exit(1)

print("✅ 韭研公社采集成功，输出:")
print(output)

try:
    data = json.loads(output)
    posts = data.get("posts", [])
    print(f"\n📊 采集到 {len(posts)} 条帖子")
    for p in posts[:3]:
        print(f"  - {p.get('title','')} | {p.get('author','')} | {p.get('readCount','0')}阅读")
except:
    print("⚠️ 输出无法解析为JSON")