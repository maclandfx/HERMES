#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""cn_tg_push.py — Telegram 推送：简报正文 + 详报MD附件
============================================================
依赖 cn_brief.py 的 build_and_save 生成简报+详报, 然后两路推送.
"""
import json, urllib.request, urllib.parse, pathlib, time, datetime

TOK = None
def _load_token():
    global TOK
    if TOK: return TOK
    env = pathlib.Path("C:/Users/Admin/AppData/Local/hermes/.env").read_text(encoding="utf-8")
    TOK = next(l.split("=",1)[1].strip() for l in env.splitlines() if l.startswith("TELEGRAM_BOT_TOKEN="))
    return TOK

CHAT = 8673372605
PROXY = "http://127.0.0.1:7890"


def _opener():
    proxy = urllib.request.ProxyHandler({"http": PROXY, "https": PROXY})
    return urllib.request.build_opener(proxy)


def send_message(text, chat_id=CHAT, reply_to=None, parse_mode=None, retries=5):
    """发送文本消息, 返回 message_id 或 None"""
    tok = _load_token()
    opener = _opener()
    params = {"chat_id": chat_id, "text": text, "disable_web_page_preview": "true"}
    if reply_to: params["reply_to_message_id"] = reply_to
    if parse_mode: params["parse_mode"] = parse_mode
    data = urllib.parse.urlencode(params).encode("utf-8")
    req = urllib.request.Request(f"https://api.telegram.org/bot{tok}/sendMessage", data=data, method="POST")
    for attempt in range(retries):
        try:
            with opener.open(req, timeout=45) as r:
                res = json.loads(r.read().decode("utf-8"))
            if res.get("ok"): return res["result"]["message_id"]
            sys_err = f"API: {res}"
            break
        except Exception as e:
            sys_err = f"{type(e).__name__}: {e}"
            time.sleep(3)
    print(f"❌ sendMessage 失败: {sys_err}")
    return None


def send_document(file_path, chat_id=CHAT, caption="", reply_to=None, retries=5):
    """发送文档附件, 返回 message_id 或 None"""
    tok = _load_token()
    opener = _opener()
    file_path = pathlib.Path(file_path)
    with open(file_path, "rb") as f:
        file_bytes = f.read()
    boundary = f"----HermesBoundary{int(time.time()*1000)}"
    body_parts = []
    def add_field(name, val):
        body_parts.append(f"--{boundary}\r\n".encode())
        body_parts.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body_parts.append(f"{val}\r\n".encode())
    add_field("chat_id", chat_id)
    if reply_to: add_field("reply_to_message_id", reply_to)
    if caption: add_field("caption", caption)
    body_parts.append(f"--{boundary}\r\n".encode())
    body_parts.append(f'Content-Disposition: form-data; name="document"; filename="{file_path.name}"\r\n'.encode())
    body_parts.append(b'Content-Type: text/markdown\r\n\r\n')
    body_parts.append(file_bytes)
    body_parts.append(f"\r\n--{boundary}--\r\n".encode())
    body = b"".join(body_parts)
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{tok}/sendDocument",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST")
    for attempt in range(retries):
        try:
            with opener.open(req, timeout=120) as r:
                res = json.loads(r.read().decode("utf-8"))
            if res.get("ok"): return res["result"]["message_id"]
            print(f"❌ sendDocument API: {res}")
            break
        except Exception as e:
            print(f"⚠ sendDocument 尝试{attempt+1}/{retries} {str(e)[:80]}")
            time.sleep(3)
    return None


def push_brief_and_full(brief_path, full_path):
    """两路推送：先简报正文, 后详报附件(reply_to 简报mid)"""
    brief = pathlib.Path(brief_path).read_text(encoding="utf-8")
    mid = send_message(brief)
    if not mid:
        print("简报推送失败, 中止")
        return None, None
    time.sleep(1.5)
    cap = f"📎 完整详报 MD · {datetime.datetime.today().strftime('%Y-%m-%d %H:%M')}\n含全量数据: 部委/国家队/温度计/资金/回测/政策进度"
    doc_mid = send_document(full_path, caption=cap, reply_to=mid)
    return mid, doc_mid


if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(pathlib.Path(__file__).parent))
    from cn_brief import build_and_save
    b, f, _, _ = build_and_save(run_script=True)
    print(f"简报: {b} ({b.stat().st_size}B)")
    print(f"详报: {f} ({f.stat().st_size}B)")
    mid, doc_mid = push_brief_and_full(b, f)
    print(f"✅ 简报 mid={mid}, 详报 mid={doc_mid}")
