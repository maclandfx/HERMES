#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
研报研习 watchdog+推送 合一
- 调用 track_monitor.py --scan 跑当日完整摘要
- 读取 tracks_summary_YYYYMMDD.md
- 输出到 stdout (cron no_agent 模式原样推送到 Telegram:8673372605)
"""
import io, os, sys, time, datetime, subprocess, pathlib, re

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="backslashreplace")
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="backslashreplace")

PYTHON_EXE = r"C:\Python314\python.exe"
BASE_DIR   = pathlib.Path(r"D:\Hermes\研报研习")
SUMMARY_DIR = BASE_DIR / "reports" / "summaries"
TRACK_MONITOR = BASE_DIR / "scripts" / "track_monitor.py"

MAX_CHARS = 3900
DELAY = 0.1
TMP_TAG = pathlib.Path(r"C:\Users\Admin\tmp\report_daily.stamp")


def log(s):
    for s2 in [s]:
        try:
            sys.stderr.write(f"[report_daily] {s2}\n"); sys.stderr.flush()
        except Exception:
            pass


def flush_print(s):
    try:
        sys.stdout.write(s + "\n"); sys.stdout.flush()
    except Exception:
        pass


def split_chunks(text, mx):
    """按行切，不超 mx 字符"""
    if len(text) <= mx:
        return [text]
    chunks, cur = [], ""
    for line in text.split("\n"):
        cand = (cur + "\n" + line) if cur else line
        if len(cand) <= mx:
            cur = cand
        else:
            if cur:
                chunks.append(cur)
            if len(line) > mx:
                # 单行太长，硬切
                for i in range(0, len(line), mx):
                    chunks.append(line[i:i+mx])
                cur = ""
            else:
                cur = line
    if cur:
        chunks.append(cur)
    return chunks


def main():
    today = datetime.datetime.now().strftime("%Y%m%d")
    today_label = datetime.datetime.now().strftime("%Y-%m-%d")

    # ─── 1. 跑 track_monitor.py --scan ─────────────
    #  --scan 模式: 重写当日完整摘要（各赛道 N 篇 + 新增），适合每天推送的日报
    #  --daily 模式: 仅显示新增（baseline后多数日子都是0篇，不适合日报）
    log(f"调用 track_monitor.py --scan (today={today})")
    cmd = [PYTHON_EXE, str(TRACK_MONITOR), "--scan"]
    log(f"exec: {cmd[0]} {cmd[1]}")
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(BASE_DIR),
            capture_output=True, text=True, encoding="utf-8",
            timeout=240, shell=False
        )
        log(f"track_monitor exit={proc.returncode}")
        if proc.stderr:
            log(f"stderr(head 300): {proc.stderr[:300]}")
    except subprocess.TimeoutExpired:
        flush_print(f"⚠️ 研报研习推送告警：track_monitor.py --scan 超时 240s（东财 API 疑似封禁）")
        sys.exit(0)
    except Exception as e:
        flush_print(f"⚠️ 研报研习推送告警：调用 track_monitor.py 失败 - {type(e).__name__}: {e}")
        sys.exit(0)

    # ─── 2. 读取今日摘要 ─────────────
    summary = SUMMARY_DIR / f"tracks_summary_{today}.md"
    if not summary.exists():
        log(f"摘要未生成，尝试取最近一个")
        cands = sorted(SUMMARY_DIR.glob("tracks_summary_*.md"), reverse=True)
        if not cands:
            flush_print(f"⚠️ 研报研习推送告警：摘要目录 {SUMMARY_DIR} 下无任何摘要文件")
            sys.exit(0)
        summary = cands[0]
        today_label = summary.stem.replace("tracks_summary_", "")
        log(f"fallback 到 {summary.name}")

    raw = summary.read_text(encoding="utf-8")
    log(f"读取摘要 {summary.name} chars={len(raw)}")

    if len(raw.strip()) < 50:
        flush_print(f"⚠️ 研报研习推送告警：{summary.name} 摘要文件仅 {len(raw)} 字符，疑似空报告")
        sys.exit(0)

    # ─── 3. 头条推送 ─────────────
    head = f"🧭 研报研习日报 — {today_label}\n📡 数据源：东财研报 API（5赛道：AI算力 / 人形机器人 / 半导体 / 新能源 / 低空商业航天）\n\n"
    header_only = head
    if len(head) + len(raw) <= MAX_CHARS:
        flush_print(head + raw)
        stamp_ok = True
    else:
        # 分片推送
        chunks = split_chunks(raw, MAX_CHARS - 50)  # 留一点 header 空间
        total = len(chunks)
        flush_print(header_only + f"（共{total}段）")
        for i, ch in enumerate(chunks, 1):
            prefix = f"\n>>> 📄 片段 {i}/{total} <<<\n\n" if total > 1 else ""
            suffix = f"\n\n>>> 续见下一条 ({i+1}/{total}) <<<" if i < total else "\n\n— END —"
            flush_print(prefix + ch + suffix)
            time.sleep(DELAY)
        stamp_ok = True

    # ─── 4. stamp 记录成功 ─────────────
    TMP_TAG.parent.mkdir(parents=True, exist_ok=True)
    TMP_TAG.write_text(str(int(time.time())), encoding="utf-8")
    log(f"推送完成，已写入 stamp")


if __name__ == "__main__":
    main()
