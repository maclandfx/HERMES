#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
A股热帖交易情报系统 v3.0 — 三数据源深度版
数据源: 淘股论坛(m.tgb.cn) + 韭研公社(jiuyangongshe.com) + 东方财富公开API
输出: 
  - posts_YYYYMMDD.jsonl
  - reports/report_YYYYMMDD.md
推送: Telegram

核心升级v3.0:
  - 淘股论坛：首页帖子 → 点进详情页 → 提取完整正文 → 股票×动作
  - 韭研公社：账号密码登录 + Cookie保活 → 首页帖子深度抓取 → 大赛持仓分析
  - 东财API：新增新浪备用数据源
  - 报告新增：实盘大赛持仓板块、股票热力图、交易逻辑深度
"""
import os, sys, json, re, hashlib, subprocess, urllib.request, urllib.error
from pathlib import Path
from datetime import datetime
from collections import Counter

OUTPUT_DIR = Path.home() / "AppData" / "Local" / "hermes" / "data" / "sentiment_collector"
REPORT_DIR = OUTPUT_DIR / "reports"
PW_DIR = Path.home() / "AppData" / "Roaming" / "npm" / "node_modules" / "playwright"
COOKIE_DIR = OUTPUT_DIR / "cookies"
COOKIE_DIR.mkdir(parents=True, exist_ok=True)

TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "")
TG_CHAT_ID = os.environ.get("TG_CHAT_ID", "8673372605")

# ── 韭研公社账号 ──
JIUYAN_PHONE = "13917888160"
JIUYAN_PASSWORD = "1qa2ws3ed"

# ── 情绪关键词词典 v2 ──
POS = ["暴涨","涨停","强势","突破","新高","主升","加仓","满仓","机会","利好",
       "底部","抄底","牛市","翻倍","大肉","吃肉","大妖","龙头","连板","放量上涨",
       "资金流入","净流入","上车","踏准","趋势向上","多头","做多","看好",
       "超预期","强于预期","产业","国产替代","大基金","央企改革","突破",
       "放量突破","买入","增持","推荐","强于大盘","放量拉升","放量封板","放量涨停",
       "强势反弹","强势上涨","强势突破","强势整理","强势拉升","强势封板"]
NEG = ["暴跌","跌停","大跌","杀跌","清仓","空仓","割肉","套牢","被套","亏损",
       "止损","出局","离场","跑路","见顶","拐点","调整","回调","走弱",
       "利空","监管","减持","解禁","破位","资金流出","净流出","踩踏","冰点",
       "退潮","核按钮","一字跌停","放量下跌","放量杀跌","恐慌","恐高",
       "失望","绝望","垃圾","韭菜","被杀","亏惨","套牢盘","A杀","阴跌",
       "放量跳水","放量暴跌","放量砸盘","放量出逃","放量减仓","放量派发",
       "放量出货","放量下跌","放量洗盘","放量回补","放量补跌","放量破位"]

# ── 股票名称/简称关键词（完整版）──
STOCK_KW = {
    # 低空经济
    "万丰奥威", "宗申动力", "中信海直", "深城交", "四川九洲", "莱斯信息",
    # 半导体设备
    "北方华创", "中微公司", "拓荆科技", "华峰测控", "盛美上海", "华海清科",
    # 半导体材料
    "江丰电子", "沪硅产业", "立昂微", "华虹", "中芯国际", "上海合晶", "有研硅",
    # 半导体设计
    "寒武纪", "海光信息", "龙芯中科", "兆易创新", "韦尔股份", "圣邦股份",
    "北京君正", "景嘉微", "紫光国微", "复旦微电", "国科微",
    "汇顶科技", "卓胜微", "格科微",
    # 封装测试
    "长电科技", "通富微通", "华天科技", "晶方科技", "甬矽电子", "芯海科技",
    # 其他
    "埃斯顿", "万邦医药", "正帆科技", "先锋精科", "亚虹医药", "理工导航",
    # 算力
    "浪潮信息", "中科曙光", "工业富联", "紫光股份", "紫光国微", "寒武纪",
    # 机器人
    "埃斯顿", "汇川技术", "绿的谐波", "鸣志电器", "拓普集团", "三花智控",
    # 光伏/储能
    "宁德时代", "比亚迪", "隆基绿能", "通威股份", "阳光电源",
    "亿纬锂能", "中创新航", "鹏辉能源", "欣旺达",
    # 显示
    "TCL科技", "京东方A", "京东方", "维信诺",
    # 消费电子
    "立讯精密", "歌尔股份", "蓝思科技", "信维通信",
    # AI
    "科大讯飞", "海康威视", "大华股份",
    # 概念
    "机器人", "商业航天", "卫星互联网", "固态电池", "储能", "光伏",
    "钠离子电池", "液冷", "HBM", "光刻胶", "半导体", "芯片", "AI",
    "算力", "GPU", "华为", "英伟达", "创新药", "CXO", "低空经济",
    "核电", "风电", "氢能", "绿电", "消费", "白酒", "医药",
    "传媒", "游戏", "军工", "航空", "无人机", "地产", "基建",
    "农业", "种业", "化工", "石化",
    # 热点个股
    "天娱数科", "华天科技", "长电科技", "蜀道装备", "富瑞特装",
    "铜冠铜箔", "瑞芯微", "盛科通信", "松发股份", "安博通",
    "金时科技", "白云电器", "天禄科技", "致远新能",
}

# ── 交易逻辑关键词 ──
TRADE_LOGIC_KW = {
    "买入": ["买入", "建仓", "进场", "上车", "布局", "潜伏", "抄底", "低吸", "吸筹"],
    "卖出": ["卖出", "清仓", "离场", "出局", "跑路", "割肉", "减仓", "止盈"],
    "潜伏": ["潜伏", "埋伏", "提前", "先手", "提前布局"],
    "低吸": ["低吸", "接盘", "接回", "接筹码", "逢低"],
    "打板": ["打板", "追板", "封板", "首板", "二板", "连板"],
    "止损": ["止损", "认错", "纠错", "撤退"],
    "空仓": ["空仓", "休息", "管住手", "观望"],
    "主升": ["主升", "主升浪", "主升段", "趋势向上"],
    "逃顶": ["逃顶", "高点", "高位", "兑现"],
    "调仓": ["调仓", "切换", "高低切换", "换仓"],
    "快进快出": ["快进快出", "快闪", "短打", "一日游"],
    "攻守兼备": ["攻守兼备", "攻守", "兼顾", "均衡"],
    "分批": ["分批", "分批买入", "分仓", "分仓买入"],
    "重仓": ["重仓", "重仓持有", "满仓"],
    "轻仓": ["轻仓", "小仓", "试探", "小仓买入"],
    "逻辑清晰": ["逻辑清晰", "逻辑", "逻辑正确", "逻辑成立"],
    "预期": ["预期", "预期差", "超预期"],
    "趋势": ["趋势", "趋势向上", "趋势向下", "趋势反转", "趋势线"],
    "技术": ["技术", "技术面", "技术形态", "形态突破", "形态整理"],
    "基本面": ["基本面", "业绩", "财报", "估值", "低估"],
    "热点": ["热点", "主线", "主线方向", "主线逻辑"],
    "题材": ["题材", "题材股", "题材逻辑", "题材炒作"],
}

# ── 持仓/实盘关键词（用于大赛）──
HOLDING_KW = ["持仓", "实盘", "大赛", "排名", "收益率", "收益", "工分",
              "冠军", "亚军", "季军", "榜单", "战绩", "晒单", "交割单",
              "资金", "净值", "跑赢", "跑输", "回撤", "盈亏"]


def classify_sentiment(title, content=""):
    text = (title + " " + content).lower()
    ph = [k for k in POS if k in text]
    nh = [k for k in NEG if k in text]
    if len(ph) > len(nh):
        return "看多", round(min(len(ph)*0.25,1.0),2), ph
    elif len(nh) > len(ph):
        return "看空", round(min(len(nh)*0.25,1.0),2), nh
    else:
        return "中性", 0.0, ph + nh


def classify_post_type(title, content=""):
    text = (title + " " + content).lower()
    types = []
    TYPE_KW = {
        "实盘": ["实盘", "记录", "实盘过程", "长征", "分仓", "交割单", "晒单", "战绩"],
        "推荐": ["推荐", "推荐关注", "买入", "上车", "布局", "潜伏", "机会", "低吸", "标的"],
        "分析": ["分析", "复盘", "拆解", "逻辑", "心法", "策略", "判断", "结论", "验证"],
        "大赛": ["大赛", "比赛", "PK", "对决", "争霸", "长韭杯", "实盘大赛"],
    }
    for ttype, kws in TYPE_KW.items():
        if any(kw.lower() in text for kw in kws):
            types.append(ttype)
    return types if types else ["普通"]


def extract_trade_logic(title, content=""):
    text = (title + " " + content).lower()
    
    ACTION_KWS = {
        "买入": ["买入", "建仓", "上车", "布局", "潜伏", "抄底", "低吸", "吸筹"],
        "卖出": ["卖出", "清仓", "离场", "出局", "跑路", "割肉", "减仓", "止盈"],
    }
    STRATEGY_KWS = TRADE_LOGIC_KW.copy()
    
    actions = []
    for action, kws in ACTION_KWS.items():
        if any(kw in text for kw in kws):
            actions.append(action)
    
    strategies = []
    for strat, kws in STRATEGY_KWS.items():
        if any(kw in text for kw in kws):
            strategies.append(strat)
    
    stock_actions = []
    for kw in sorted(STOCK_KW, key=len, reverse=True):
        kw_lower = kw.lower()
        idx = text.find(kw_lower)
        if idx < 0: continue
        context_start = max(0, idx - 100)
        context_end = min(len(text), idx + 100)
        context = text[context_start:context_end]
        matched_action = None
        for a, kws in ACTION_KWS.items():
            if any(act_kw.lower() in context for act_kw in kws):
                matched_action = a
                break
        if not matched_action:
            for s, kws in STRATEGY_KWS.items():
                if any(strat_kw.lower() in context for strat_kw in kws):
                    matched_action = s
                    break
        if matched_action:
            if (kw, matched_action) not in stock_actions:
                stock_actions.append((kw, matched_action))
    
    rationale = title[:120] if len(title) > 120 else title
    logic_idx = text.find("逻辑")
    if logic_idx >= 0:
        seg_start = max(0, logic_idx - 60)
        seg_end = min(len(text), logic_idx + 60)
        rationale += " | " + text[seg_start:seg_end].strip()
    
    strategy_sentences = []
    for kw in ["策略", "逻辑", "节奏", "理由", "原因", "判断", "核心"]:
        idx = text.find(kw)
        if idx >= 0:
            seg_start = max(0, idx - 80)
            seg_end = min(len(text), idx + 80)
            seg = text[seg_start:seg_end].strip()
            if seg and len(seg) > 10 and seg not in strategy_sentences:
                strategy_sentences.append(seg)
    
    return {
        "actions": list(set(actions)),
        "strategies": list(set(strategies)),
        "stock_actions": stock_actions,
        "rationale": rationale[:250],
        "strategy_sentences": strategy_sentences[:3],
    }


def extract_stocks(title, content=""):
    text = (title + " " + content)
    found = []
    for kw in STOCK_KW:
        if kw in text and kw not in found:
            found.append(kw)
    codes = re.findall(r'([0-9]{6})', text)
    for c in codes:
        if c not in found:
            found.append(c)
    return found[:15]


def extract_realtrade_amount(title, content=""):
    text = (title + " " + content)
    matches = re.findall(r'([\d.]+)\s*[万Ww万元元]', text)
    if matches:
        try:
            return float(matches[0])
        except:
            pass
    return 0


def extract_holding_info(content=""):
    """从帖子中提取持仓/实盘大赛信息"""
    text = content.lower()
    info = {
        "is_contest": False,
        "positions": [],      # [(股票名, 操作描述), ...]
        "return_pct": 0,
        "total_amount": 0,
        "rank": None,
        "contest_name": None,
    }
    
    # 判断是否大赛帖
    for kw in HOLDING_KW:
        if kw in text:
            info["is_contest"] = True
            break
    
    # 提取大赛名称
    m = re.search(r'长韭杯|实盘大赛|大赛', content)
    if m:
        start = max(0, m.start()-10)
        end = min(len(content), m.end()+30)
        info["contest_name"] = content[start:end].strip()
    
    # 提取持仓股票及操作描述
    for kw in sorted(STOCK_KW, key=len, reverse=True):
        kw_lower = kw.lower()
        idx = text.find(kw_lower)
        if idx >= 0:
            context_start = max(0, idx - 50)
            context_end = min(len(text), idx + 50)
            context = text[context_start:context_end]
            
            # 查找操作描述关键词
            action_desc = ""
            for a in ["买入", "加仓", "减仓", "清仓", "持有", "卖出", "止损", "打板", "低吸"]:
                if a.lower() in context:
                    action_desc = a
                    break
            
            if action_desc:
                info["positions"].append((kw, action_desc))
    
    # 提取收益率
    pct_match = re.search(r'收益率[：:]\s*([+-]?[\d.]+)%', content)
    if pct_match:
        try:
            info["return_pct"] = float(pct_match.group(1))
        except:
            pass
    
    # 提取资金量
    amt_match = re.findall(r'([\d.]+)\s*万', content)
    if amt_match:
        try:
            info["total_amount"] = float(amt_match[0])
        except:
            pass
    
    return info


def fetch_jiuyang_with_login(browser_context_code):
    """
    韭研公社登录后采集首页帖子（含大赛跟踪）。
    返回: JSON 字符串，格式为帖子数组
    """
    cookie_path = str(COOKIE_DIR / "jiuyang_cookies.json")
    
    pw_script = f'''
const {{ chromium }} = require("./index.js");
const fs = require("fs");

(async () => {{
  const browser = await chromium.launch({{ headless: true }});
  const context = await browser.newContext();
  const page = await context.newPage();
  page.setViewportSize({{ width: 1280, height: 800 }});
  
  // ── 1. 加载 Cookie ──
  const cookiePath = "{cookie_path}";
  if (fs.existsSync(cookiePath)) {{
    const cookies = JSON.parse(fs.readFileSync(cookiePath, "utf8"));
    await context.addCookies(cookies);
    console.log("[JIUYAN] Loaded", cookies.length, "cookies");
  }} else {{
    console.log("[JIUYAN] No saved cookies");
  }}
  
  // ── 2. 登录 ──
  await page.goto("https://www.jiuyangongshe.com/", {{ waitUntil: "domcontentloaded", timeout: 15000 }});
  await page.waitForTimeout(5000);
  
  const loginCheck = await page.evaluate(() => {{
    const bodyText = document.body.innerText;
    const hasLoginBtn = bodyText.includes("登录注册");
    const hasUserInfo = bodyText.includes("任盈盈") || bodyText.includes("无名小韭");
    return {{ hasLoginBtn: hasLoginBtn, hasUserInfo: hasUserInfo }};
  }});
  
  console.log("[JIUYAN] Login check:", JSON.stringify(loginCheck));
  
  if (loginCheck.hasLoginBtn && !loginCheck.hasUserInfo) {{
    console.log("[JIUYAN] Attempting login...");
    
    // 尝试点击登录按钮
    try {{
      await page.click(".el-button--primary", {{ timeout: 3000 }});
      await page.waitForTimeout(1500);
    }} catch(e) {{
      console.log("[JIUYAN] Login button click timeout, continuing");
    }}
    
    // 等待弹窗出现
    try {{
      await page.waitForSelector(".el-dialog", {{ timeout: 3000 }});
    }} catch(e) {{
      console.log("[JIUYAN] No login dialog found");
    }}
    
    // 点击账号密码 tab
    try {{
      await page.click("#tab-accounts", {{ timeout: 3000 }});
      await page.waitForTimeout(800);
    }} catch(e) {{
      console.log("[JIUYAN] Tab click failed");
    }}
    
    // 填写手机号
    try {{
      await page.fill("#pane-accounts input[name=phone]", "{JIUYAN_PHONE}", {{ timeout: 3000 }});
    }} catch(e) {{
      console.log("[JIUYAN] Phone fill failed:", e.message);
    }}
    
    // 填写密码
    try {{
      await page.fill("#pane-accounts input[name=password]", "{JIUYAN_PASSWORD}", {{ timeout: 3000 }});
    }} catch(e) {{
      console.log("[JIUYAN] Password fill failed:", e.message);
    }}
    
    await page.waitForTimeout(500);
    
    // 按 Enter 提交（最可靠的登录方式）
    try {{
      await page.keyboard.press("Enter");
      await page.waitForTimeout(4000);
      console.log("[JIUYAN] Submitted login via Enter");
    }} catch(e) {{
      console.log("[JIUYAN] Enter submit failed:", e.message);
    }}
    
    // 保存 cookies
    const cookies = await context.cookies();
    try {{
      fs.writeFileSync(cookiePath, JSON.stringify(cookies, null, 2));
      console.log("[JIUYAN] Saved", cookies.length, "cookies");
    }} catch(e) {{
      console.log("[JIUYAN] Save cookies failed:", e.message);
    }}
  }} else {{
    console.log("[JIUYAN] Already logged in");
  }}
  
  // ── 3. 采集首页帖子 ──
  await page.goto("https://www.jiuyangongshe.com/", {{ waitUntil: "domcontentloaded", timeout: 15000 }});
  await page.waitForTimeout(5000);
  
  // 截图（调试用）
  await page.screenshot({{ path: "{COOKIE_DIR}/jiuyang_debug.png" }});
  
  // 提取帖子列表
  const posts = await page.evaluate(() => {{
    const results = [];
    const sections = document.querySelectorAll("section");
    sections.forEach(section => {{
      const titleEl = section.querySelector(".book-title, h2, h3");
      const title = titleEl ? titleEl.innerText.trim() : "";
      if (!title) return;
      
      const authorEl = section.querySelector("[class*=author], [class*=user]");
      const author = authorEl ? authorEl.innerText.trim().slice(0, 20) : "未知";
      
      const timeEl = section.querySelector("[class*=time]");
      const time = timeEl ? timeEl.innerText.trim() : "";
      
      const fullText = section.innerText.slice(0, 1500);
      
      results.push({{
        title: title.slice(0, 150),
        author: author,
        time: time,
        fullText: fullText,
      }});
    }});
    return results;
  }});
  
  // 获取页面完整文本
  const fullPageText = await page.evaluate(() => document.body.innerText.slice(0, 5000));
  
  const output = JSON.stringify({{
    posts: posts,
    fullPageText: fullPageText,
    timestamp: new Date().toISOString(),
  }}, null, 2);
  console.log(output);
  
  await browser.close();
}})().catch(e => {{ 
  console.error("[JIUYAN] FATAL:", e.message); 
  process.exit(1); 
}});
'''
    r = subprocess.run(
        ["node", "-e", pw_script],
        cwd=str(PW_DIR), capture_output=True, text=True, timeout=120,
    )
    if r.returncode != 0:
        print(f"❌ 韭研公社采集失败: {r.stderr[:500]}")
        return ""
    return r.stdout.strip()


def parse_jiuyang_data(raw_json):
    """解析韭研公社返回的 JSON（可能包含日志行）"""
    # 提取纯 JSON 部分（去除日志行）
    lines = raw_json.strip().split("\n")
    json_start = -1
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("{") and stripped.endswith("}"):
            json_start = i
            break
        elif stripped.startswith("{"):
            # JSON 可能跨多行
            json_start = i
            break
    
    if json_start >= 0:
        json_text = "\n".join(lines[json_start:])
    else:
        json_text = raw_json.strip()
    
    try:
        data = json.loads(json_text)
    except Exception as e:
        print(f"❌ 韭研公社 JSON 解析失败: {e}")
        print(f"   JSON文本前200字: {json_text[:200]}")
        return []
    
    records = []
    for p in data.get("posts", []):
        title = p.get("title", "")
        body = p.get("fullText", "")
        s, sc, kw = classify_sentiment(title, body)
        types = classify_post_type(title, body)
        stocks = extract_stocks(title, body)
        amount = extract_realtrade_amount(title, body)
        trade_logic = extract_trade_logic(title, body)
        holding = extract_holding_info(body)
        
        records.append({
            "site": "韭研公社",
            "author": p.get("author", ""),
            "title": title[:300],
            "content": body[:2000],
            "stats": f"{p.get('readCount','0')}阅读",
            "reads": int(float(str(p.get('readCount','0'))).replace('万','0000')) if p.get('readCount') else 0,
            "comments": 0,
            "sentiment": s,
            "score": sc,
            "keywords": kw,
            "post_types": types,
            "stocks": stocks,
            "realtrade_amount": amount,
            "trade_logic": trade_logic,
            "holding_info": holding,
        })
    
    # 大赛数据单独处理
    contest = data.get("contest", {})
    if contest.get("text"):
        contest_text = contest["text"]
        # 在大赛页面中查找排名/持仓信息
        s, sc, kw = classify_sentiment(contest["title"], contest_text)
        stocks = extract_stocks(contest["title"], contest_text)
        holding = extract_holding_info(contest_text)
        records.append({
            "site": "韭研公社·大赛",
            "author": "长韭杯官方",
            "title": contest.get("title", ""),
            "content": contest_text[:3000],
            "stats": "大赛跟踪",
            "reads": 99999,
            "comments": 0,
            "sentiment": s,
            "score": sc,
            "keywords": kw,
            "post_types": ["大赛"],
            "stocks": stocks,
            "realtrade_amount": 0,
            "trade_logic": extract_trade_logic(contest.get("title",""), contest_text),
            "holding_info": holding,
        })
    
    return records


def fetch_tgb_with_detail(browser_context_code):
    """淘股论坛：首页帖子 → 点进详情页 → 提取完整正文"""
    pw_script = '''
const { chromium } = require("./index.js");
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  page.setViewportSize({ width: 375, height: 667 });  // 移动端
  
  await page.goto("https://m.tgb.cn/", { waitUntil: "networkidle", timeout: 30000 });
  await page.waitForTimeout(4000);
  
  // 提取首页帖子列表（标题 + 链接）
  const postLinks = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll("a[href]").forEach(a => {
      const text = a.innerText.trim();
      const href = a.href;
      // 过滤：有标题内容、是帖子链接
      if (text.length > 5 && href && /thread\\//i.test(href) || (text.length > 10 && !/导航|首页|登录|注册|论坛|视频|更多/i.test(text))) {
        links.push({ text: text.slice(0, 200), href: href });
      }
    });
    return links.slice(0, 15);  // 最多处理15个帖子
  });
  
  const posts = [];
  for (const post of postLinks) {
    try {
      await page.goto(post.href, { waitUntil: "domcontentloaded", timeout: 15000 });
      await page.waitForTimeout(2000);
      
      const detail = await page.evaluate(() => {
        const title = document.title || document.querySelector("h1")?.innerText || "";
        const authorEl = document.querySelector("[class*=author], [class*=username]");
        const author = authorEl ? authorEl.innerText.trim() : "";
        
        // 正文：通常是文章区域
        const article = document.querySelector("article, .article, .content, .post, .thread-content, main");
        const bodyText = article ? article.innerText.trim() : document.body.innerText.trim();
        
        // 统计数据
        const text = document.body.innerText;
        const readMatch = text.match(/(\\d+(?:\\.\\d+)?)\\s*万?\\s*阅读/);
        const commentMatch = text.match(/(\\d+)\\s*评论/);
        
        return {
          title: title.slice(0, 200),
          author: author.slice(0, 30),
          bodyText: bodyText.slice(0, 2000),
          readCount: readMatch ? readMatch[1] : "0",
          commentCount: commentMatch ? commentMatch[1] : "0",
        };
      });
      
      posts.push({ ...post, detail });
      
    } catch(e) {
      console.log("[TGB] Failed to fetch detail:", post.href, e.message);
      posts.push({ ...post, detail: { title: post.text, author: "", bodyText: "", error: e.message } });
    }
  }
  
  console.log(JSON.stringify(posts, null, 2));
  await browser.close();
})();
'''
    r = subprocess.run(
        ["node", "-e", pw_script],
        cwd=str(PW_DIR), capture_output=True, text=True, timeout=180,
    )
    if r.returncode != 0:
        print(f"❌ 淘股论坛详情页采集失败: {r.stderr[:500]}")
        return ""
    return r.stdout.strip()


def parse_tgb_detail(raw_json):
    """解析淘股论坛详情页返回的 JSON（可能包含日志行）"""
    lines = raw_json.strip().split("\n")
    json_start = -1
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("["):
            json_start = i
            break
    
    if json_start >= 0:
        json_text = "\n".join(lines[json_start:])
    else:
        json_text = raw_json.strip()
    
    try:
        posts = json.loads(json_text)
    except Exception as e:
        print(f"❌ 淘股论坛 JSON 解析失败: {e}")
        print(f"   JSON文本前200字: {json_text[:200]}")
        return []
    
    records = []
    for p in posts:
        detail = p.get("detail", {})
        title = detail.get("title", p.get("text", ""))
        body = detail.get("bodyText", "")
        author = detail.get("author", "")
        
        if not title: continue
        
        s, sc, kw = classify_sentiment(title, body)
        types = classify_post_type(title, body)
        stocks = extract_stocks(title, body)
        amount = extract_realtrade_amount(title, body)
        trade_logic = extract_trade_logic(title, body)
        holding = extract_holding_info(body)
        
        records.append({
            "site": "淘股论坛",
            "author": author,
            "title": title[:300],
            "content": body[:3000],
            "stats": f"{detail.get('readCount','0')}阅读 {detail.get('commentCount','0')}评论",
            "reads": int(detail.get("readCount", 0)) if detail.get("readCount") else 0,
            "comments": int(detail.get("commentCount", 0)) if detail.get("commentCount") else 0,
            "sentiment": s, "score": sc, "keywords": kw,
            "post_types": types,
            "stocks": stocks,
            "realtrade_amount": amount,
            "trade_logic": trade_logic,
            "holding_info": holding,
        })
    
    return records


def fetch_tgb_contest(browser_context_code):
    """淘股论坛大赛频道采集 — 通过 m.tgb.cn 搜索大赛帖"""
    pw_script = """
const { chromium } = require("./index.js");
(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();
  page.setViewportSize({ width: 375, height: 667 });
  
  await page.goto("https://m.tgb.cn/", { waitUntil: "networkidle", timeout: 30000 });
  await page.waitForTimeout(4000);
  
  // 查找大赛相关链接
  const contestLinks = await page.evaluate(() => {
    const results = [];
    document.querySelectorAll("a[href]").forEach(a => {
      const text = a.innerText.trim();
      const href = a.href;
      if (/大赛|实盘|比赛|争霸|PK/i.test(text) && text.length > 3) {
        results.push({ text: text.slice(0, 200), href: href });
      }
    });
    return results.slice(0, 10);
  });
  
  // 对每个大赛链接尝试获取内容
  const posts = [];
  for (const link of contestLinks) {
    try {
      await page.goto(link.href, { waitUntil: "domcontentloaded", timeout: 15000 });
      await page.waitForTimeout(2000);
      const detail = await page.evaluate(() => {
        const title = document.title || document.querySelector("h1")?.innerText || "";
        const authorEl = document.querySelector("[class*=author], [class*=username]");
        const author = authorEl ? authorEl.innerText.trim() : "";
        const article = document.querySelector("article, .article, .content, .post, .thread-content, main");
        const bodyText = article ? article.innerText.trim() : document.body.innerText.trim();
        return { title: title.slice(0, 200), author: author.slice(0, 30), bodyText: bodyText.slice(0, 2000) };
      });
      posts.push({ title: link.text, detail });
    } catch(e) {
      posts.push({ title: link.text, error: e.message });
    }
  }
  
  console.log(JSON.stringify(posts, null, 2));
  await browser.close();
})();
"""
    r = subprocess.run(
        ["node", "-e", pw_script],
        cwd=str(PW_DIR), capture_output=True, text=True, timeout=120,
    )
    if r.returncode != 0:
        print(f"⚠️  淘股大赛频道采集失败: {r.stderr[:200]}")
        return ""
    return r.stdout.strip()


def parse_tgb_contest(raw_json):
    """解析淘股大赛频道返回的 JSON"""
    try:
        posts = json.loads(raw_json)
    except:
        return []
    
    records = []
    for p in posts:
        detail = p.get("detail", {})
        title = detail.get("title", p.get("title", ""))
        body = detail.get("bodyText", "")
        author = detail.get("author", "")
        
        if not title: continue
        
        s, sc, kw = classify_sentiment(title, body)
        stocks = extract_stocks(title, body)
        amount = extract_realtrade_amount(title, body)
        trade_logic = extract_trade_logic(title, body)
        holding = extract_holding_info(body)
        
        records.append({
            "site": "淘股·大赛",
            "author": author,
            "title": title[:300],
            "content": body[:3000],
            "stats": "大赛频道",
            "reads": 0,
            "comments": 0,
            "sentiment": s,
            "score": sc,
            "keywords": kw,
            "post_types": ["大赛"],
            "stocks": stocks,
            "realtrade_amount": amount,
            "trade_logic": trade_logic,
            "holding_info": holding,
        })
    
    return records


# ── 东方财富API + 新浪备用 ──
EM_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
    "Referer": "https://quote.eastmoney.com/",
}
SN_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
}


def em_fetch(url, timeout=15, retries=3):
    last_err = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers=EM_HEADERS)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return data.get('data', {}).get('diff', [])
        except Exception as e:
            last_err = e
            import time; time.sleep(1)
    print(f"❌ 东财API请求失败 ({url[:60]}...): {last_err}")
    return []


def fetch_em_concept_top():
    url = ("https://push2.eastmoney.com/api/qt/clist/get?"
           "pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa"
           "&fid=f3&fs=m:90+t:3")
    items = em_fetch(url)
    results = []
    for it in items:
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                "name": name, "change_pct": change / 100.0,
                "turnover": money / 1e8, "source": "概念板块",
            })
    return results


def fetch_em_industry_top():
    url = ("https://push2.eastmoney.com/api/qt/clist/get?"
           "pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa"
           "&fid=f3&fs=m:90+t:2")
    items = em_fetch(url)
    results = []
    for it in items:
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                "name": name, "change_pct": change / 100.0,
                "turnover": money / 1e8, "source": "行业板块",
            })
    return results


def fetch_em_stock_top():
    url = ("https://push2.eastmoney.com/api/qt/clist/get?"
           "pn=1&pz=30&po=1&np=1&ut=bd1d9ddb04089700cf992760f6050daa"
           "&fid=f3&fs=m:0+t:6+m:0+t:80+m:1+t:2+m:1+t:23")
    items = em_fetch(url)
    results = []
    for it in items:
        code = it.get('f12', '')
        name = it.get('f14', '')
        change = it.get('f3', 0)
        money = it.get('f6', 0) or 0
        if name:
            results.append({
                "code": code, "name": name,
                "change_pct": change / 100.0,
                "turnover": money / 1e8, "source": "个股",
            })
    return results


# ── 新浪备用数据源 ──
def sn_fetch_top_concepts():
    """新浪财经：热门概念板块"""
    try:
        url = "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?page=1&num=20&sort=changepercent&asc=0&node=hsgjjc"
        req = urllib.request.Request(url, headers=SN_HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            results = []
            for it in data:
                results.append({
                    "name": it.get('name', ''),
                    "code": it.get('code', ''),
                    "change_pct": float(it.get('changepercent', 0)),
                    "turnover": float(it.get('amount', 0)) / 1e8,
                    "source": "新浪·概念板块",
                })
            return results
    except Exception as e:
        print(f"❌ 新浪概念板块失败: {e}")
        return []


def sn_fetch_top_stocks():
    """新浪财经：涨幅榜"""
    try:
        url = "https://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?page=1&num=20&sort=changepercent&asc=0&node=hs_a"
        req = urllib.request.Request(url, headers=SN_HEADERS)
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            results = []
            for it in data:
                results.append({
                    "name": it.get('name', ''),
                    "code": it.get('code', ''),
                    "change_pct": float(it.get('changepercent', 0)),
                    "turnover": float(it.get('amount', 0)) / 1e8,
                    "source": "新浪·个股",
                })
            return results
    except Exception as e:
        print(f"❌ 新浪个股失败: {e}")
        return []


# ── Telegram推送 ──
def send_telegram(text):
    if not TG_BOT_TOKEN:
        print("⚠️  未配置TG_BOT_TOKEN，跳过Telegram推送")
        return
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage"
    payload = json.dumps({
        "chat_id": TG_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
    }).encode('utf-8')
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            if result.get('ok'):
                print("✅ Telegram推送成功")
            else:
                print(f"❌ Telegram推送失败: {result.get('description', 'unknown')}")
    except Exception as e:
        print(f"❌ Telegram推送失败: {e}")


# ── Telegram消息构建 v3 ──
def build_telegram_message(records, date_str):
    tgb = [r for r in records if r.get("site") == "淘股论坛"]
    jy  = [r for r in records if "韭研公社" in r.get("site", "")]
    contest = [r for r in records if r.get("site") == "韭研公社·大赛"]
    
    # 合并所有论坛帖子
    all_posts = tgb + jy
    
    # 股票热力图
    all_stocks = Counter()
    stock_actions_counter = Counter()
    for r in all_posts:
        for s in r.get("stocks", []):
            all_stocks[s] += 1
        for stock, action in r.get("trade_logic", {}).get("stock_actions", []):
            stock_actions_counter[f"{stock}→{action}"] += 1
    
    # 交易逻辑帖
    logic_posts = []
    for r in all_posts:
        tl = r.get("trade_logic", {})
        if tl.get("stock_actions") or tl.get("strategies") or tl.get("actions"):
            logic_posts.append(r)
    
    # 实盘/大赛
    realtrade_posts = [r for r in all_posts if r.get("realtrade_amount", 0) > 0]
    contest_posts = [r for r in all_posts if "大赛" in r.get("post_types", [])]
    
    # 情绪
    sentiment_counts = Counter(r["sentiment"] for r in all_posts)
    bull = sentiment_counts.get("看多", 0)
    bear = sentiment_counts.get("看空", 0)
    
    lines = [
        f"🔥 <b>A股热帖交易情报 v3.0</b>",
        f"📅 {date_str} | 淘股{len(tgb)}条 + 韭研{len(jy)}条 + 东财{len(records)-len(all_posts)}条",
        "",
        f"📊 <b>情绪</b> 🔴看多{bull} 🟢看空{bear} ⚪中性{sentiment_counts.get('中性',0)}",
    ]
    
    # ── 交易逻辑详解 ──
    if logic_posts:
        lines.extend(["", "🎯 <b>交易逻辑详解（含股票×动作）</b>"])
        for r in logic_posts[:8]:
            tl = r.get("trade_logic", {})
            title = r['title'][:40]
            actions = tl.get("actions", [])
            strategies = tl.get("strategies", [])
            stock_actions = tl.get("stock_actions", [])
            line = f"  · [{r.get('site','')}] <b>{r['author']}</b> | {title}"
            if stock_actions:
                for stock, action in stock_actions[:3]:
                    line += f" | <b>{stock}</b>→{action}"
            if actions:
                line += f" | [{','.join(actions)}]"
            if strategies:
                line += f" | 策略:{','.join(strategies)}"
            lines.append(line)
    
    # ── 实盘大赛持仓分析 ──
    if contest or contest_posts:
        lines.extend(["", "🏆 <b>实盘大赛持仓分析</b>"])
        for r in (contest + contest_posts)[:5]:
            title = r['title'][:50]
            hl = r.get("holding_info", {})
            positions = hl.get("positions", [])
            ret = hl.get("return_pct", 0)
            amt = hl.get("total_amount", 0)
            pos_str = "、".join([f"<b>{s}</b>({a})" for s,a in positions[:3]]) if positions else "—"
            line = f"  · <b>{title}</b>"
            if ret: line += f" | 收益率:{ret:+.1f}%"
            if amt: line += f" | 资金:{amt:.0f}万"
            line += f" | 持仓:{pos_str}"
            lines.append(line)
    
    # ── 股票热力图 ──
    if all_stocks:
        lines.extend(["", "🎯 <b>股票提及热力图</b>"])
        for stock, cnt in all_stocks.most_common(10):
            emoji = "🔥" if cnt >= 3 else "📌" if cnt >= 2 else "  "
            lines.append(f"  {emoji} <b>{stock}</b> ×{cnt}")
    
    # ── 概念板块 ──
    em_concepts = sorted([r for r in records if r.get("source_data") == "em_concept"],
                         key=lambda x: x.get("_raw", {}).get("change_pct", 0), reverse=True)[:5]
    if em_concepts:
        lines.extend(["", "💡 <b>概念板块TOP5</b>"])
        for r in em_concepts:
            pct = r.get("_raw", {}).get("change_pct", 0) / 100.0
            lines.append(f"  · <b>{r.get('name','')}</b> {pct:+.1%}")
    
    # ── 个股涨幅 ──
    em_stocks = sorted([r for r in records if r.get("source_data") == "em_stock"],
                       key=lambda x: x.get("_raw", {}).get("change_pct", 0), reverse=True)[:5]
    if em_stocks:
        lines.extend(["", "📈 <b>个股涨幅TOP5</b>"])
        for r in em_stocks:
            raw = r.get("_raw", {})
            pct = raw.get("change_pct", 0) / 100.0
            lines.append(f"  · {raw.get('code','')} <b>{raw.get('name','')}</b> {pct:+.1%}")
    
    lines.extend(["", f"📋 <i>详情见报告: report_{date_str}.md</i>"])
    return "\n".join(lines)


# ── 报告生成 v3 ──
def generate_report(records, date_str):
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    report_path = REPORT_DIR / f"report_{date_str}.md"
    
    if not records:
        print("⚠️  无数据，跳过报告生成")
        return None
    
    # 分类
    tgb = [r for r in records if r["site"] == "淘股论坛"]
    jy  = [r for r in records if "韭研公社" in r.get("site", "")]
    contest = [r for r in records if r.get("site") == "韭研公社·大赛"]
    all_posts = tgb + jy
    
    # 情绪
    sentiment_counts = Counter(r["sentiment"] for r in all_posts)
    bull_posts = [r for r in all_posts if r["sentiment"] == "看多"]
    bear_posts = [r for r in all_posts if r["sentiment"] == "看空"]
    neutral_posts = [r for r in all_posts if r["sentiment"] == "中性"]
    bull_pct = len(bull_posts) / len(all_posts) * 100 if all_posts else 0
    
    # 股票池
    all_stocks = Counter()
    stock_action_detail = Counter()
    for r in all_posts:
        for s in r.get("stocks", []):
            all_stocks[s] += 1
        for stock, action in r.get("trade_logic", {}).get("stock_actions", []):
            all_stocks[stock] += 1
            stock_action_detail[f"{stock}→{action}"] += 1
    
    # 实盘大赛
    contest_posts = [r for r in all_posts if "大赛" in r.get("post_types", [])]
    
    # 东财
    em_concepts = sorted([r for r in records if r.get("source_data") == "em_concept"],
                         key=lambda x: x.get("_raw", {}).get("change_pct", 0), reverse=True)
    em_stocks = sorted([r for r in records if r.get("source_data") == "em_stock"],
                       key=lambda x: x.get("_raw", {}).get("change_pct", 0), reverse=True)
    
    # 关键词
    all_kw = []
    for r in all_posts:
        all_kw.extend(r.get("keywords", []))
    top_kw = Counter(all_kw).most_common(15)
    
    report = f"""# 🔥 A股热帖交易情报报告 v3.0
> 报告日期: {date_str} | 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 数据: 淘股论坛 {len(tgb)}条 + 韭研公社 {len(jy)}条 + 东财 {len(records)-len(all_posts)}条 | 总计 {len(records)}条

---

## 📊 淘股+韭研公社情绪概况

| 情绪 | 帖子数 | 占比 |
|------|-------|------|
| 🔴 看多 | {len(bull_posts)} | {bull_pct:.1f}% |
| 🟢 看空 | {len(bear_posts)} | {len(bear_posts)/len(all_posts)*100 if all_posts else 0:.1f}% |
| ⚪ 中性 | {len(neutral_posts)} | {100-bull_pct-len(bear_posts)/len(all_posts)*100 if all_posts else 0:.1f}% |

**倾向**: {'🔴 偏多' if bull_pct > len(bear_posts)/len(all_posts)*100 else '🟢 偏空' if len(bear_posts)/len(all_posts)*100 > bull_pct else '⚪ 中性'}

---

## 🎯 交易逻辑详解（深度 — 含股票×操作）

| 来源 | 作者 | 标题 | 操作动作 | 策略 | 股票×动作 |
|------|------|------|---------|------|----------|"""
    for r in all_posts:
        tl = r.get("trade_logic", {})
        actions = tl.get("actions", [])
        strategies = tl.get("strategies", [])
        stock_actions = tl.get("stock_actions", [])
        if not actions and not strategies and not stock_actions:
            continue
        actions_str = "、".join(actions) if actions else "—"
        strategies_str = "、".join(strategies) if strategies else "—"
        stock_str = " | ".join([f"**{s}**→{a}" for s, a in stock_actions[:3]]) if stock_actions else "—"
        title = r['title'][:40]
        report += f"\n| {r.get('site','')} | {r.get('author','')} | {title} | {actions_str} | {strategies_str} | {stock_str} |"
    
    report += f"""

---

## 🏆 实盘大赛持仓分析

### 大赛帖汇总
| 来源 | 标题 | 持仓股票(操作) | 收益率 | 资金量 |
|------|------|--------------|--------|--------|"""
    for r in (contest + contest_posts):
        hl = r.get("holding_info", {})
        positions = hl.get("positions", [])
        ret = hl.get("return_pct", 0)
        amt = hl.get("total_amount", 0)
        pos_str = "、".join([f"**{s}**({a})" for s,a in positions[:5]]) if positions else "—"
        report += f"\n| {r.get('site','')} | {r['title'][:45]} | {pos_str} | {'N/A' if not ret else f'{ret:+.1f}%'} | {'N/A' if not amt else f'{amt:.0f}万'} |"
    
    if not (contest or contest_posts):
        report += "\n*当前数据中未检测到实盘大赛帖*"
    
    report += f"""

### 大赛持仓股票汇总

| 股票 | 操作(出现次数) |
|------|--------------|"""
    if stock_action_detail:
        for item, cnt in stock_action_detail.most_common(15):
            report += f"\n| **{item.split('→')[0]}**→{item.split('→')[1]} | {cnt} |"
    else:
        report += "\n*暂无持仓数据*"
    
    report += f"""

---

## 🎯 股票提及热力图（跨论坛）

| 股票/概念 | 提及次数 | 操作分布 |
|----------|---------|---------|"""
    for stock, cnt in all_stocks.most_common(20):
        actions_for_stock = [key.split("→")[1] for key, c in stock_action_detail.items() if key.startswith(f"{stock}→")]
        action_str = "、".join(actions_for_stock) if actions_for_stock else "—"
        report += f"\n| **{stock}** | {cnt} | {action_str} |"
    
    report += f"""

---

## 💰 实盘交易（含金额）

| 来源 | 作者 | 标题 | 实盘金额 | 阅读 | 操作 | 策略 | 持仓 |
|------|------|------|---------|-----|------|------|------|"""
    for r in [x for x in all_posts if x.get("realtrade_amount", 0) > 0][:8]:
        amt = r["realtrade_amount"]
        unit = "万" if amt >= 1 else "千"
        tl = r.get("trade_logic", {})
        actions_str = "、".join(tl.get("actions", [])) if tl.get("actions") else "—"
        strategies_str = "、".join(tl.get("strategies", [])) if tl.get("strategies") else "—"
        holding = r.get("holding_info", {})
        pos_str = "、".join([f"**{s}**({a})" for s,a in holding.get("positions", [])[:3]]) if holding.get("positions") else "—"
        report += f"\n| {r.get('site','')} | {r.get('author','')} | {r['title'][:35]} | {amt:.0f}{unit} | {r['reads']} | {actions_str} | {strategies_str} | {pos_str} |"
    
    report += f"""

---

## 📣 推荐帖精选

| 来源 | 作者 | 标题 | 阅读 | 策略 | 操作 | 股票×动作 |
|------|------|------|-----|------|------|----------|"""
    recommend_posts = [r for r in all_posts if "推荐" in r.get("post_types", [])]
    for r in recommend_posts[:10]:
        tl = r.get("trade_logic", {})
        actions_str = "、".join(tl.get("actions", [])) if tl.get("actions") else "—"
        strategies_str = "、".join(tl.get("strategies", [])) if tl.get("strategies") else "—"
        stock_str = " | ".join([f"**{s}**→{a}" for s, a in tl.get("stock_actions", [])[:2]]) if tl.get("stock_actions") else "—"
        report += f"\n| {r.get('site','')} | {r.get('author','')} | {r['title'][:35]} | {r['reads']} | {strategies_str} | {actions_str} | {stock_str} |"
    
    report += f"""

---

## 🔥 热帖 TOP10 (阅读量)

| 排名 | 来源 | 作者 | 标题 | 阅读 | 情绪 | 标签 | 提及股票 | 操作动作 | 策略 |
|-----|------|------|------|-----|------|------|---------|---------|------|"""
    top_posts = sorted(all_posts, key=lambda x: x.get("reads", 0), reverse=True)[:10]
    for i, r in enumerate(top_posts, 1):
        title = r["title"][:30]
        tags = "、".join(r.get("post_types", []))
        stocks_str = "、".join([f"**{s}**" for s in r.get("stocks", [])[:3]]) or "—"
        tl = r.get("trade_logic", {})
        actions_str = "、".join(tl.get("actions", [])) if tl.get("actions") else "—"
        strategies_str = "、".join(tl.get("strategies", [])) if tl.get("strategies") else "—"
        report += f"\n| {i} | {r.get('site','')} | {r.get('author','')} | {title} | {r['reads']} | {r['sentiment']} | {tags} | {stocks_str} | {actions_str} | {strategies_str} |"
    
    report += f"""

---

## 💡 概念板块涨幅 TOP10

| 排名 | 概念 | 涨跌幅 | 成交额(亿) |
|-----|------|--------|-----------|"""
    for i, r in enumerate(em_concepts[:10], 1):
        raw = r.get("_raw", {})
        pct = raw.get("change_pct", 0) / 100.0
        money = raw.get("turnover", 0)
        report += f"\n| {i} | {raw.get('name','')} | {pct:+.1%} | {money:.1f} |"
    
    report += f"""

---

## 📈 个股涨幅 TOP10

| 排名 | 代码 | 名称 | 涨跌幅 | 成交额(亿) |
|-----|------|------|--------|-----------|"""
    for i, r in enumerate(em_stocks[:10], 1):
        raw = r.get("_raw", {})
        pct = raw.get("change_pct", 0) / 100.0
        money = raw.get("turnover", 0)
        report += f"\n| {i} | {raw.get('code','')} | {raw.get('name','')} | {pct:+.1%} | {money:.1f} |"
    
    report += f"""

---

## 🔍 热门关键词 TOP15

| 关键词 | 出现次数 |
|-------|---------|"""
    for kw, cnt in top_kw:
        report += f"\n| {kw} | {cnt} |"
    
    report += f"""

---

## 🔴 看多热帖精选

| 来源 | 标题 | 阅读 | 关键词 | 提及股票 | 操作 | 策略 |
|-----|------|-----|-------|---------|------|------|"""
    for r in bull_posts[:8]:
        tl = r.get("trade_logic", {})
        actions_str = "、".join(tl.get("actions", [])) if tl.get("actions") else "—"
        strategies_str = "、".join(tl.get("strategies", [])) if tl.get("strategies") else "—"
        title = r["title"][:40]
        kw_str = "、".join(r["keywords"][:3])
        stocks_str = "、".join([f"**{s}**" for s in r.get("stocks", [])[:3]]) or "—"
        report += f"\n| {r.get('site','')} | {title} | {r['reads']} | {kw_str} | {stocks_str} | {actions_str} | {strategies_str} |"

    report += f"""

---

## 🟢 看空热帖精选

| 来源 | 标题 | 阅读 | 关键词 | 提及股票 | 操作 | 策略 |
|-----|------|-----|-------|---------|------|------|"""
    for r in bear_posts[:8]:
        tl = r.get("trade_logic", {})
        actions_str = "、".join(tl.get("actions", [])) if tl.get("actions") else "—"
        strategies_str = "、".join(tl.get("strategies", [])) if tl.get("strategies") else "—"
        title = r["title"][:40]
        kw_str = "、".join(r["keywords"][:3])
        stocks_str = "、".join([f"**{s}**" for s in r.get("stocks", [])[:3]]) or "—"
        report += f"\n| {r.get('site','')} | {title} | {r['reads']} | {kw_str} | {stocks_str} | {actions_str} | {strategies_str} |"
    
    report += f"""

---

## 📋 数据明细

**采集时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**数据文件**: posts_{date_str}.jsonl  
**报告文件**: report_{date_str}.md  
**推送**: Telegram ({TG_CHAT_ID})

---
*本报告由 A股热帖交易情报系统 v3.0 自动生成*  
*数据来源于淘股论坛 + 韭研公社 + 东方财富公开数据，仅供参考，不构成投资建议*
"""
    
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"📊 报告生成: {report_path}")
    return report_path


def run():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y%m%d")
    jsonl_path = OUTPUT_DIR / f"posts_{today}.jsonl"
    today_records = []
    
    # ── 1. 淘股论坛（详情页模式）──
    raw_tgb = fetch_tgb_with_detail("")
    if raw_tgb:
        tgb_posts = parse_tgb_detail(raw_tgb)
        today_records.extend([{**p, "site": "淘股论坛"} for p in tgb_posts])
        print(f"✅ 淘股论坛(详情页): {len(tgb_posts)} 条")
    
    # ── 2. 淘股大赛频道 ──
    raw_contest = fetch_tgb_contest("")
    if raw_contest:
        contest_posts = parse_tgb_contest(raw_contest)
        today_records.extend(contest_posts)
        print(f"✅ 淘股·大赛频道: {len(contest_posts)} 条")
    
    # ── 3. 韭研公社（登录+采集）──
    raw_jy = fetch_jiuyang_with_login("")
    if raw_jy:
        jy_posts = parse_jiuyang_data(raw_jy)
        today_records.extend(jy_posts)
        print(f"✅ 韭研公社(登录): {len(jy_posts)} 条")
    
    # ── 3. 东财概念板块 ──
    concept_top = fetch_em_concept_top()
    for c in concept_top:
        s, sc, kw = classify_sentiment(c["name"], "")
        today_records.append({
            "site": "东财·概念板块", "source_data": "em_concept",
            "author": "东财",
            "title": f"{c['name']} ({c['change_pct']:+.1%})",
            "content": f"成交额{c['turnover']:.1f}亿",
            "stats": f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            "reads": int(c['turnover'] * 1e4), "comments": 0,
            "sentiment": s, "score": sc, "keywords": kw,
            "post_types": ["数据"], "stocks": [], "realtrade_amount": 0,
            "trade_logic": {"actions":[], "strategies":[], "stock_actions":[], "rationale":"", "strategy_sentences":[]},
            "holding_info": {"is_contest": False, "positions": [], "return_pct": 0},
            "_raw": c,
        })
    print(f"✅ 东财·概念板块: {len(concept_top)} 条")
    
    # ── 4. 东财行业板块 ──
    industry_top = fetch_em_industry_top()
    for c in industry_top:
        s, sc, kw = classify_sentiment(c["name"], "")
        today_records.append({
            "site": "东财·行业板块", "source_data": "em_industry",
            "author": "东财",
            "title": f"{c['name']} ({c['change_pct']:+.1%})",
            "content": f"成交额{c['turnover']:.1f}亿",
            "stats": f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            "reads": int(c['turnover'] * 1e4), "comments": 0,
            "sentiment": s, "score": sc, "keywords": kw,
            "post_types": ["数据"], "stocks": [], "realtrade_amount": 0,
            "trade_logic": {"actions":[], "strategies":[], "stock_actions":[], "rationale":"", "strategy_sentences":[]},
            "holding_info": {"is_contest": False, "positions": [], "return_pct": 0},
            "_raw": c,
        })
    print(f"✅ 东财·行业板块: {len(industry_top)} 条")
    
    # ── 5. 东财个股 ──
    stock_top = fetch_em_stock_top()
    for c in stock_top:
        s, sc, kw = classify_sentiment(c["name"], "")
        today_records.append({
            "site": "东财·个股", "source_data": "em_stock",
            "author": c.get("code", ""),
            "title": f"{c['name']} ({c.get('code','')}) ({c['change_pct']:+.1%})",
            "content": f"成交额{c['turnover']:.1f}亿",
            "stats": f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
            "reads": int(c['turnover'] * 1e4), "comments": 0,
            "sentiment": s, "score": sc, "keywords": kw,
            "post_types": ["数据"], "stocks": [c.get("name","")], "realtrade_amount": 0,
            "trade_logic": {"actions":[], "strategies":[], "stock_actions":[], "rationale":"", "strategy_sentences":[]},
            "holding_info": {"is_contest": False, "positions": [], "return_pct": 0},
            "_raw": c,
        })
    print(f"✅ 东财·个股: {len(stock_top)} 条")
    
    # ── 6. 新浪备用（如果东财失败）──
    if len(concept_top) == 0:
        sn_concepts = sn_fetch_top_concepts()
        for c in sn_concepts:
            s, sc, kw = classify_sentiment(c["name"], "")
            today_records.append({
                "site": "新浪·概念板块", "source_data": "sn_concept",
                "author": "新浪",
                "title": f"{c['name']} ({c['change_pct']:+.1%})",
                "content": f"成交额{c['turnover']:.1f}亿",
                "stats": f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
                "reads": int(c['turnover'] * 1e4), "comments": 0,
                "sentiment": s, "score": sc, "keywords": kw,
                "post_types": ["数据"], "stocks": [], "realtrade_amount": 0,
                "trade_logic": {"actions":[], "strategies":[], "stock_actions":[], "rationale":"", "strategy_sentences":[]},
                "holding_info": {"is_contest": False, "positions": [], "return_pct": 0},
                "_raw": c,
            })
        print(f"✅ 新浪·概念板块(备用): {len(sn_concepts)} 条")
    
    if len(stock_top) == 0:
        sn_stocks = sn_fetch_top_stocks()
        for c in sn_stocks:
            s, sc, kw = classify_sentiment(c["name"], "")
            today_records.append({
                "site": "新浪·个股", "source_data": "sn_stock",
                "author": c.get("code", ""),
                "title": f"{c['name']} ({c.get('code','')}) ({c['change_pct']:+.1%})",
                "content": f"成交额{c['turnover']:.1f}亿",
                "stats": f"涨幅{c['change_pct']:+.1%} 成交额{c['turnover']:.1f}亿",
                "reads": int(c['turnover'] * 1e4), "comments": 0,
                "sentiment": s, "score": sc, "keywords": kw,
                "post_types": ["数据"], "stocks": [c.get("name","")], "realtrade_amount": 0,
                "trade_logic": {"actions":[], "strategies":[], "stock_actions":[], "rationale":"", "strategy_sentences":[]},
                "holding_info": {"is_contest": False, "positions": [], "return_pct": 0},
                "_raw": c,
            })
        print(f"✅ 新浪·个股(备用): {len(sn_stocks)} 条")
    
    if not today_records:
        print("❌ 所有数据源均失败")
        return
    
    # ── 去重 + 写JSONL ──
    seen, records = set(), []
    with open(jsonl_path, "w", encoding="utf-8") as f:
        for p in today_records:
            key = hashlib.md5((p["site"] + p["title"]).encode()).hexdigest()[:16]
            if key in seen: continue
            seen.add(key)
            if "sentiment" not in p:
                s, sc, kw = classify_sentiment(p["title"], p.get("content",""))
                p["sentiment"], p["score"], p["keywords"] = s, sc, kw
            f.write(json.dumps(p, ensure_ascii=False) + "\n")
            records.append(p)
    
    print(f"📊 去重 {len(records)} 条 → {jsonl_path}")
    
    # ── 生成报告 ──
    report_path = generate_report(records, today)
    
    # ── Telegram推送 ──
    if report_path:
        tg_text = build_telegram_message(records, today)
        send_telegram(tg_text)


if __name__ == "__main__":
    run()