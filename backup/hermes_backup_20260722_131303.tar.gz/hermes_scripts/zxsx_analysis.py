#!/usr/bin/env python3
"""周线手选板块滚动分析 — 每日收盘后运行（no_agent cron wrapper）"""
import subprocess, sys

PYTHON = r"C:\Python314\python.exe"
SCRIPT = r"D:/Hermes/评估中心/tools/tdx_connector/scripts/zxsx_analysis.py"

result = subprocess.run([PYTHON, SCRIPT], capture_output=False, text=True, timeout=120)
print(f"exit={result.returncode}")
