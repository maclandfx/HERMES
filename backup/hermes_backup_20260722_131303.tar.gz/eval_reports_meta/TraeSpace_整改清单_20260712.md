# 📋 TraeSpace 评估系统 — 整改清单

> 生成时间：2026-07-12  
> 目标目录：`C:\Users\Admin\Documents\TraeSpace\评估系统\`（只读，本文档不触及原目录）  
> 评估维度：安全 / 工程规范 / 架构一致性 / 可维护性

---

## 🔴 P0 — 紧急（必须立即修）

### 1. Token 明文硬编码 → 抽到 .env

| 文件                                             | 位置      | 泄露内容                         |
| ---------------------------------------------- | ------- | ---------------------------- |
| `stock_eval_system/utils/telegram_notifier.py` | 第15-16行 | Telegram Bot Token + Chat ID |
| `stock_eval_system/core/config.py`             | 第13-14行 | Tushare API Token            |

**整改方案：**

- 新建 `.env` 文件：
  
  ```
  TUSHARE_TOKEN=3de9976db504a798ec235a8cfaa5292ba7b5cb7f20957d6929e04287
  TELEGRAM_BOT_TOKEN=8902112817:AAG80vABzIzBVR44USHx-pPhbtUQojDyUBY
  TELEGRAM_CHAT_ID=8673372605
  ```
- 两个脚本改为从 `.env` 读取（用 `dotenv` 或手动解析）
- `.env` 加入 `.gitignore`，永不提交

### 2. 路径硬编码 → 参数化

| 文件                                 | 位置   | 硬编码路径                                                                           | 问题                 |
| ---------------------------------- | ---- | ------------------------------------------------------------------------------- | ------------------ |
| `stock_eval_system/core/config.py` | 第20行 | `ZSCORE_DATA_DIR = r'C:\Users\Admin\Documents\TraeSpace\板块热度观察\data\processed'` | 指向另一个无关项目目录；换电脑直接崩 |

**整改方案：**

- 改为相对路径或 `.env` 配置
- 路径指向本项目内的 `data/` 目录

---

## 🟠 P1 — 高优先级（应尽快修）

### 3. 无 Git 版本控制

当前状态：`No commits yet`，所有历史改动不可回溯。

**整改方案：**

```bash
cd "C:\Users\Admin\Documents\TraeSpace\评估系统"
git init
```

`.gitignore` 内容：

```
__pycache__/
*.pyc
.env
reports/粗评/
reports/组合/
reports/个股/
reports/berkshire/
*.xlsx
*.html
```

首次提交作为基线版本。

### 4. DEFAULT_WEIGHTS 权重之和 = 1.35（评分系统性偏高）

```python
tech(0.25) + cap(0.20) + sent(0.10) + fund(0.10) + sect(0.08) + hot(0.05)
+ zscore(0.05) + reflexivity(0.02) + holder(0.05) + mainforce(0.05)
+ policy(0.30) + national(0.10) = 1.35
```

**整改方案（二选一）：**

**方案A：归一化到 1.0** — 所有权重 ÷ 1.35：

```python
DEFAULT_WEIGHTS = {
    'tech': 0.185, 'cap': 0.148, 'sent': 0.074, 'fund': 0.074,
    'sect': 0.059, 'hot': 0.037, 'zscore': 0.037, 'reflexivity': 0.015,
    'holder': 0.037, 'mainforce': 0.037, 'policy': 0.222, 'national': 0.074,
}
```

**方案B：移除无效维度** — `policy`/`national` 在 engine.py 的 11 个维度模块中无对应代码，直接删除这两项，然后归一化剩余 10 项。

> 推荐方案B，语义更清晰。

### 5. 重复入口脚本（run_dual_eval.py vs run_dual_report.py）

两个入口脚本功能重叠，`diff` 显示内容不同但方向一致。维护两套容易分叉。

**整改方案：**

- 保留 `run_dual_report.py` 为主入口
- `run_dual_eval.py` 移入 `deprecated/` 或直接删除
- 所有 cron 任务统一指向一个入口

---

## 🟡 P2 — 中优先级（建议修）

### 6. signal_tracker 回测闭环未生效

当前状态：70+ 只信号记录，全部 `status: "pending"`，`verified_at: null`，`hit: null`。

**问题：** 回测追踪数据在写，但验证逻辑未触发，形同虚设。

**整改方案：**

- 检查 `backtest/tracker.py` 中验证触发的条件（是否在指定日期自动跑？）
- 添加 cron 任务：每个交易日收盘后自动验证昨日信号

### 7. reports/ 目录命名不统一

`reports/粗评/` 下 40+ 文件，命名混乱：

- `粗评报告_5只_20260606_0914.md`（时间戳格式）
- `磁谷科技_芯朋微_灿芯股份_地铁设计_评估_20260710_1554.md`（股票名格式）
- `v51_final.md`（版本号格式）
- `ZSCORE修复验证.md`（功能名格式）

**整改方案：**

- 统一命名规范：`YYYYMMDD_HHMM_标的简称_等级.md`
- 示例：`20260710_1554_磁谷芯朋灿芯地铁_A.md`

### 8. 两个入口脚本中的推送逻辑重复

`telegram_notifier.py` 有独立推送模块，但 `run_dual_report.py` 和 `engine.py` 中可能也有推送调用，导致 Telegram Bot Token 在多处被使用。

**整改方案：**

- 确认所有推送都走 `telegram_notifier.py`
- 移除其他文件中的直接 Bot API 调用

---

## 🟢 P3 — 低优先级（可后续优化）

### 9. 清理 __pycache__ 缓存

`telegram_notifier.cpython-310.pyc` 等缓存混在工作目录中，随代码修改更新但占用空间。

**整改方案：**

```bash
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null
```

（已加入 .gitignore，自动排除）

### 10. 添加项目 README.md

当前无项目总览说明，新成员无法快速了解系统结构和运行方式。

**整改方案：**

- 根目录新建 `README.md`，包含：
  - 项目简介（双评估系统：十维度短线 + Berkshire 价值投资）
  - 快速开始（如何运行 `run_dual_report.py`）
  - 模块结构图
  - 环境依赖（Python 版本、tushare、telegram 等）

### 11. 反身性模块权重过低（0.02）

`reflexivity` 模块在 engine.py 中有完整实现（SBI 指标、三阶段判断、象限分析），但权重仅 0.02，实际对总评贡献极小。

**整改方案：**

- 若反身性是核心评估维度之一，建议调整到 0.05-0.08
- 与所有者确认设计意图后再调整

---

## 📊 整改优先级汇总

| 优先级      | 数量     | 预计耗时       | 影响范围       |
| -------- | ------ | ---------- | ---------- |
| 🔴 P0 紧急 | 2      | 30分钟       | 安全性、跨环境运行  |
| 🟠 P1 高  | 3      | 1小时        | 版本控制、评分准确性 |
| 🟡 P2 中  | 3      | 2小时        | 回测闭环、文件管理  |
| 🟢 P3 低  | 3      | 1小时        | 代码清洁度、文档   |
| **合计**   | **11** | **~6.5小时** |            |

---

## ⚠️ 执行约束

- 本文档为**只读建议**，不触及 Trae 原目录
- 所有整改操作需所有者确认后执行
- Token 相关操作（P0-1）建议在离线环境进行

---

*生成：Hermes Agent · 2026-07-12*
